package com.mobiowin.admin.service;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mobiowin.admin.dao.IBroadcastDao;
import com.mobiowin.windchim.bean.BranchMasterBean;
import com.mobiowin.windchim.bean.ClassMasterBean;
import com.mobiowin.windchim.bean.EventMasterBean;
import com.mobiowin.windchim.bean.GeneralBroadcastMasterBean;
import com.mobiowin.windchim.bean.HomeworkBroadcastMasterBean;
import com.mobiowin.windchim.service.helper.IAppSyncHelperServie;

@Service("broadcastService")
public class BroadcastService implements IBroadcastService {
	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private IBroadcastDao broadcastDao;
	
	@Autowired
	private IAppSyncHelperServie appSyncService;
	

	public List<BranchMasterBean> fetchBranchDetails(BranchMasterBean branchMaster) {
		log.info("Inside BroadcastService/fetchBranchDetails()");

		List<BranchMasterBean> branchList = broadcastDao.fetchBranchDetails(branchMaster);

		return branchList;
	}

	public List<ClassMasterBean> fetchClassDetails(ClassMasterBean classMasterBean) {
		log.info("Inside BroadcastService/fetchClassDetails()");

		List<ClassMasterBean> classList = broadcastDao.fetchClassDetails(classMasterBean);

		return classList;
	}

	public String addGeneralNotification(GeneralBroadcastMasterBean generalBroadcastBean) {
		String response = broadcastDao.saveGeneralBroadcast(generalBroadcastBean);
		return response;
	}

	public List<GeneralBroadcastMasterBean> activeGeneralBroadcastSearch(
			GeneralBroadcastMasterBean broadcastMasterBean) {

		List<GeneralBroadcastMasterBean> generalBroadcastList = broadcastDao
				.getActiveGeneralBroadcastList(broadcastMasterBean);

		return generalBroadcastList;
	}

	public List<HomeworkBroadcastMasterBean> activeHomeworkNotificationSearch(
			HomeworkBroadcastMasterBean homeworkBroadcastMasterBean) {
		List<HomeworkBroadcastMasterBean> homeworkNotificationList = broadcastDao
				.getActiveHomeworkNotificationList(homeworkBroadcastMasterBean);

		return homeworkNotificationList;
	}

	public String addHomeworkNotification(HomeworkBroadcastMasterBean homeworkBroadcastMasterBean) {
		String response = broadcastDao.saveHwNotification(homeworkBroadcastMasterBean);
		return response;
	}

	public List<EventMasterBean> activeEventSearch(EventMasterBean eventMasterBean) {
		List<EventMasterBean> eventNotificationList = broadcastDao.getActiveEventList(eventMasterBean);
		return eventNotificationList;
	}

}
