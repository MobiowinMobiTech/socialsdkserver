package com.mobiowin.admin.service;

import java.util.List;

import com.mobiowin.windchim.bean.SystemUser;

public interface ISystemUserService {

	List<SystemUser> authenticateUser(SystemUser userBean);

	List<SystemUser> activeUserSearch(SystemUser systemUser);

	void add(SystemUser systemUser);

	List<SystemUser> doUserSearch(SystemUser searchSystemuser);

}
