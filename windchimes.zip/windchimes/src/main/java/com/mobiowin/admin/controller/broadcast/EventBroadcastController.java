package com.mobiowin.admin.controller.broadcast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.mobiowin.admin.service.IBroadcastService;
import com.mobiowin.admin.service.ISystemUserService;
import com.mobiowin.windchim.bean.EventMasterBean;
import com.mobiowin.windchim.commons.IdGeneratorUtility;

@Controller
public class EventBroadcastController extends MultiActionController {
	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private ISystemUserService systemUserService;

	@Autowired
	private IBroadcastService broadcastService;

	@Autowired
	private @Resource Map<String, List<String>> imageconfig;
	
	public ModelAndView addEvent(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		log.info("---------In UserController / addUser()----------");

		EventMasterBean homeworkBroadcastMasterBean = getEventMasterBean(request);
		
		/*try {
			HttpSession session = request.getSession();
			
			homeworkBroadcastMasterBean.setCreatedBy("SYSTEM");
			homeworkBroadcastMasterBean.setModifiedBy("SYSTEM");
			homeworkBroadcastMasterBean.setCreateDt(new Date());
			homeworkBroadcastMasterBean.setModifyDt(new Date());
			homeworkBroadcastMasterBean.setDeleteFlag("F");
			broadcastService.addHomeworkNotification(homeworkBroadcastMasterBean);
		} catch (Exception e) {
			throw new RuntimeErrorException(null);
		}*/
		
		

		

		return getEventNotificationList(request, response);
	}
	
	private EventMasterBean getEventMasterBean(HttpServletRequest request) 
	{
		int count = 0;
		String imageExtension = null;
		String conceptImagePath = null;
		String conceptImageLocation = null;
		List<String> imageBasePath = (List<String>) imageconfig.get("EVENT_BASE_PATH");
		//List<String> imageDirectoryNames = (List<String>) imageConfig.get("IMAGE_DIRECTORY_NAMES");
		String code = IdGeneratorUtility.generateOtp();
		final MultipartHttpServletRequest multiRequest = (MultipartHttpServletRequest) request;
		log.info("---------After multipart----------");
		final Map files = multiRequest.getFileMap();

		List<Object> filesList = new Vector<Object>(files.values());
		
		log.info("filesList : " + filesList.size());

		for (Object object : filesList)
		{
			CommonsMultipartFile commonsMultipartFile = (CommonsMultipartFile) object;
			if (!commonsMultipartFile.isEmpty())
			{
				count++;
			}
		}

		log.info("count is::" + count);

		for (Object object : filesList)
		{
			System.out.println("class name : " + object.getClass());
			CommonsMultipartFile commonsMultipartFile = (CommonsMultipartFile) object;
			log.info("\n\nOriginalFilename = " + commonsMultipartFile.getOriginalFilename());
			log.info("ContentType = " + commonsMultipartFile.getContentType());
			log.info("Name = " + commonsMultipartFile.getName());
			log.info("Size = " + commonsMultipartFile.getSize());
			log.info("StorageDescription " + commonsMultipartFile.getStorageDescription());

			String fileName = commonsMultipartFile.getOriginalFilename().toLowerCase();
			log.info("fileName is:" + fileName);

			if (!fileName.isEmpty())
			{

				int indexOfDot = fileName.lastIndexOf(".");

				String extension = fileName.substring(indexOfDot + 1);

				log.info("extension is::" + extension.toLowerCase());

				String basedir = imageBasePath.get(0);
				//String basedir = SyncConstants.IMGPATH;

				if (commonsMultipartFile.getName() != null)
				{
					log.info("in productfile");
					log.info("file name is::" + fileName);

					int lastIndex = fileName.lastIndexOf(".");

					log.info("lastIndex is::" + lastIndex);
					imageExtension = fileName.substring(lastIndex);
					log.info("extension is::" + imageExtension);
					
					log.info("basedir is::" + basedir);
					
					saveEmailImage(basedir, commonsMultipartFile, imageExtension);
				}
			}
		}

		return null;
	}

	private void saveEmailImage(String basedir, CommonsMultipartFile commonsMultipartFile, 
			String imageExtension) {
		
		try {
			File localEmailDir = new File(basedir);
			if (!localEmailDir.exists())
			{
				localEmailDir.mkdirs();

				File emaildir = new File(localEmailDir, IdGeneratorUtility.generateOtp() + imageExtension);

				FileOutputStream fileOutputStream = new FileOutputStream(emaildir);
				fileOutputStream.write(commonsMultipartFile.getBytes());

			}
			else
			{
				File emaildir = new File(localEmailDir, IdGeneratorUtility.generateOtp() + imageExtension);

				FileOutputStream fileOutputStream = new FileOutputStream(emaildir);
				fileOutputStream.write(commonsMultipartFile.getBytes());

			}
		} catch (FileNotFoundException e) {
			log.error("File not found exception : " + e.getMessage());
			e.printStackTrace();
		} catch (IOException e) {
			log.error("IO exception while saving file : " + e.getMessage());
			e.printStackTrace();
		}

		
	}

	public ModelAndView onAddClick(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// getDetails(request, response);

		return new ModelAndView("/masters/event/addEvent");

	}

	public ModelAndView getEventNotificationList(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		EventMasterBean eventMasterBean = new EventMasterBean();
		eventMasterBean.setDeleteFlag("F");
		List<EventMasterBean> eventMasterList = broadcastService.activeEventSearch(eventMasterBean);

		log.info("--- In hwBroadcastList  ---" + eventMasterList);
		log.info("EventBroadcastController/getEventNotificationList eventMasterList:"
				+ ((eventMasterList == null) ? "Null " : eventMasterList.size()));

		log.info("-------------------------------Final List--------------------------" + eventMasterList);

		HttpSession session = request.getSession();

		request.setAttribute("systemUserList", eventMasterList);

		return new ModelAndView("/masters/event/eventWorkbench");
	}
}
