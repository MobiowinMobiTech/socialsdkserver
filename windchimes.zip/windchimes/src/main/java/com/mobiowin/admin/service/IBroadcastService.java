package com.mobiowin.admin.service;

import java.util.List;

import com.mobiowin.windchim.bean.BranchMasterBean;
import com.mobiowin.windchim.bean.ClassMasterBean;
import com.mobiowin.windchim.bean.EventMasterBean;
import com.mobiowin.windchim.bean.GeneralBroadcastMasterBean;
import com.mobiowin.windchim.bean.HomeworkBroadcastMasterBean;

public interface IBroadcastService {

	List<BranchMasterBean> fetchBranchDetails(BranchMasterBean branchMaster);

	List<ClassMasterBean> fetchClassDetails(ClassMasterBean classMasterBean);

	String addGeneralNotification(GeneralBroadcastMasterBean generalBroadcastBean);

	List<GeneralBroadcastMasterBean> activeGeneralBroadcastSearch(GeneralBroadcastMasterBean broadcastMasterBean);

	List<HomeworkBroadcastMasterBean> activeHomeworkNotificationSearch(
			HomeworkBroadcastMasterBean homeworkBroadcastMasterBean);

	String addHomeworkNotification(HomeworkBroadcastMasterBean homeworkBroadcastMasterBean);

	List<EventMasterBean> activeEventSearch(EventMasterBean eventMasterBean);

}
