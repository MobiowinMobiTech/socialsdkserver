package com.mobiowin.admin.controller.user;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.management.RuntimeErrorException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.mobiowin.admin.service.IBroadcastService;
import com.mobiowin.admin.service.ISystemUserService;
import com.mobiowin.windchim.bean.BranchMasterBean;
import com.mobiowin.windchim.bean.ClassMasterBean;
import com.mobiowin.windchim.bean.GeneralBroadcastMasterBean;
import com.mobiowin.windchim.bean.SystemUser;
import com.mobiowin.windchim.commons.MobiowinConstants;
import com.mobiowin.windchim.notification.IFcmBroadcastService;

public class UserController extends MultiActionController {

	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private ISystemUserService systemUserService;

	@Autowired
	private IBroadcastService broadcastService;

	@Autowired
	private IFcmBroadcastService fcmBroadcastService;

	public ModelAndView addSystemUser(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		log.info("---------In UserController / addUser()----------");

		GeneralBroadcastMasterBean generalBroadcastBean = getGeneralNotificationBean(request);
		String dbResponse = null;
		HashMap<String, String> notificationDataMap = null;
		try {
			

			generalBroadcastBean.setModifiedBy("SYSTEM");
			generalBroadcastBean.setCreateDt(new Date());
			generalBroadcastBean.setModifyDt(new Date());
			generalBroadcastBean.setDeleteFlag("F");

			dbResponse = broadcastService.addGeneralNotification(generalBroadcastBean);
			
			log.info("UserController/addSystemUser() dbResponse is : " + dbResponse );

			if (dbResponse.equals(MobiowinConstants.TRUE))
			{
				notificationDataMap = new HashMap<String, String>();
				
				notificationDataMap.put("title", generalBroadcastBean.getTitle());
				notificationDataMap.put("subtitle",generalBroadcastBean.getSubTitle());
				notificationDataMap.put("body", generalBroadcastBean.getDiscription());
				fcmBroadcastService.sendGeneralBroadcastNotification(notificationDataMap);
			}

		} catch (Exception e) {
			log.error("Exception in addSystemUser : " + e.getMessage());
			e.printStackTrace();
		}

		return getGeneralNotificationList(request, response);
	}

	public ModelAndView getSystemUserList(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		log.info("--- In getSystemUserList  ---");
		SystemUser systemUser = new SystemUser();
		systemUser.setDeleteFlag("F");
		List<SystemUser> systemUserList = systemUserService.activeUserSearch(systemUser);

		log.info("--- In getSystemUserList  ---" + systemUserList);
		log.info("UserController/getSystemUserList SystemUserList:"
				+ ((systemUserList == null) ? "Null " : systemUserList.size()));

		log.info("-------------------------------Final List--------------------------" + systemUserList);

		HttpSession session = request.getSession();

		request.setAttribute("systemUserList", systemUserList);

		return new ModelAndView("/masters/user/userWorkbench");
	}

	public ModelAndView getGeneralNotificationList(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		log.info("--- In getGeneralNotificationList  ---");
		GeneralBroadcastMasterBean broadcastMasterBean = new GeneralBroadcastMasterBean();
		broadcastMasterBean.setDeleteFlag("F");
		List<GeneralBroadcastMasterBean> generalBroadcastList = broadcastService
				.activeGeneralBroadcastSearch(broadcastMasterBean);

		log.info("--- In generalBroadcastList  ---" + generalBroadcastList);
		log.info("UserController/getSystemUserList SystemUserList:"
				+ ((generalBroadcastList == null) ? "Null " : generalBroadcastList.size()));

		log.info("-------------------------------Final List--------------------------" + generalBroadcastList);

		HttpSession session = request.getSession();

		request.setAttribute("systemUserList", generalBroadcastList);

		return new ModelAndView("/masters/user/userWorkbench");
	}

	private SystemUser fetchExistingSystemUser(String code) {
		SystemUser searchSystemuser = new SystemUser();
		searchSystemuser.setCode(code);

		List<SystemUser> searchResult = systemUserService.doUserSearch(searchSystemuser);
		log.info("-------------------------------searchResult --------------------------" + searchResult);
		if (CollectionUtils.isEmpty(searchResult)) {
			return null;
		}

		if (searchResult.size() > 1) {
			throw new RuntimeException("Duplicate Records Found...");
		}

		return searchResult.get(0);
	}

	private GeneralBroadcastMasterBean getGeneralNotificationBean(HttpServletRequest request) {
		log.info("-------------- in getUserBean Method  -------------");

		GeneralBroadcastMasterBean generalBroadcastMasterBean = null;
		if (null != request) {
			generalBroadcastMasterBean = new GeneralBroadcastMasterBean();

			String title = request.getParameter("title").trim();
			String subTitle = request.getParameter("subtitle").trim();
			String discription = request.getParameter("discription").trim();
			String bracnchAddress = request.getParameter("profile").trim();
			String createdBy = request.getParameter("createdBy").trim();

			log.info("--------- title ----------" + title);
			log.info("-------- subTitle----------" + subTitle);
			log.info("---------subject----------" + discription);
			log.info("---------bracnchAddress----------" + bracnchAddress);
			log.info("---------createdBy----------" + createdBy);

			if ((title != null) && !title.equalsIgnoreCase("")) {
				generalBroadcastMasterBean.setTitle(title);
			}

			if ((subTitle != null) && !subTitle.equalsIgnoreCase("")) {
				generalBroadcastMasterBean.setSubTitle(subTitle);
			}

			if ((discription != null) && !discription.equalsIgnoreCase("")) {
				generalBroadcastMasterBean.setDiscription(discription);
			}

			if ((bracnchAddress != null) && !bracnchAddress.equalsIgnoreCase("")) {
				generalBroadcastMasterBean.setBranchName(bracnchAddress);
			}

			if ((createdBy != null) && !createdBy.equalsIgnoreCase("")) {
				generalBroadcastMasterBean.setCreatedBy(createdBy);
			}
		}

		// log.info("--------generalBroadcastMasterBean---------" +
		// generalBroadcastMasterBean.getId());
		return generalBroadcastMasterBean;
	}

	public ModelAndView onAddClick(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		getDetails(request, response);

		return new ModelAndView("/masters/user/addUser");

	}

	public void getDetails(HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		BranchMasterBean branchMaster = new BranchMasterBean();
		branchMaster.setDeleteFlag("F");
		List<BranchMasterBean> branchList = broadcastService.fetchBranchDetails(branchMaster);
		log.info("--- In addClick  ---" + branchList);
		log.info("UserController/getSystemUserList SystemUserList:"
				+ ((branchList == null) ? "Null " : branchList.size()));

		log.info("-------------------------------Final List--------------------------" + branchList);
		session.setAttribute("fullProfileList", branchList);

		ClassMasterBean classMasterBean = new ClassMasterBean();
		classMasterBean.setDeleteFlag("F");
		List<ClassMasterBean> classList = broadcastService.fetchClassDetails(classMasterBean);
		log.info("--- In addClick  ---" + branchList);
		log.info("UserController/getSystemUserList SystemUserList:"
				+ ((classList == null) ? "Null " : classList.size()));

		log.info("-------------------------------Final List--------------------------" + classList);
		session.setAttribute("classList", classList);

	}
}
