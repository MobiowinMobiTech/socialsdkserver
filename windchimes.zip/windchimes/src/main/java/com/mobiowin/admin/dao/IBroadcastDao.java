package com.mobiowin.admin.dao;

import java.util.List;

import com.mobiowin.windchim.bean.BranchMasterBean;
import com.mobiowin.windchim.bean.ClassMasterBean;
import com.mobiowin.windchim.bean.EventMasterBean;
import com.mobiowin.windchim.bean.GeneralBroadcastMasterBean;
import com.mobiowin.windchim.bean.HomeworkBroadcastMasterBean;
import com.mobiowin.windchim.bean.StudentNotificationBean;

public interface IBroadcastDao {

	List<BranchMasterBean> fetchBranchDetails(BranchMasterBean branchMaster);

	List<ClassMasterBean> fetchClassDetails(ClassMasterBean classMasterBean);

	String saveGeneralBroadcast(GeneralBroadcastMasterBean generalBroadcastBean);

	List<GeneralBroadcastMasterBean> getActiveGeneralBroadcastList(GeneralBroadcastMasterBean broadcastMasterBean);

	List<HomeworkBroadcastMasterBean> getActiveHomeworkNotificationList(
			HomeworkBroadcastMasterBean homeworkBroadcastMasterBean);

	String saveHwNotification(HomeworkBroadcastMasterBean homeworkBroadcastMasterBean);

	List<EventMasterBean> getActiveEventList(EventMasterBean eventMasterBean);

	String saveEventNotification(EventMasterBean eventMasterBean);

	List<HomeworkBroadcastMasterBean> doCustomSearch(HomeworkBroadcastMasterBean homeworkBroadcastMasterBean);

	List<StudentNotificationBean> getStudentHwNotificataionList(StudentNotificationBean studentNotificationBean);

	List<ClassMasterBean> getClassMasterList(String className);

}
