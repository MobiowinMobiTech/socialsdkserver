package com.mobiowin.windchim.commons;

public class ApplicationConstant {
	public static final String APP_NAME = "paalan";

	public static final String DEVICE_REQUEST_CHANNEL = "deviceRequestChannel";

	public static final String DEVICE_RESPONSE_CHANNEL = "deviceResponseChannel";

	public static final String RESPONSE = "response";

	public static final String DATA = "data";
	
	/*public static final String TRUE = "true";

	public static final String FALSE = "false";*/

	public static final String LOCATION_DATA = "location";

	public static final String LEVEL_INFO = "level";

	public static final String APPLICATION_ID = "appId";

	public static final String DEAL_RADIUS = "dealradius";

	public static final String IS_EXCLUSIVE = "isexclusive";

	public static final String ERR_MSG = "errmsg";

	public static final String REQUEST = "request";

	public static final String USER_LATITUDE = "latitude";

	public static final String USER_LONGITUDE = "longitude";

	public static final String TYPE = "type";

	public static final String ENTITY = "entity";

	public static final String ACTON = "action";

	public static final String TYPE_ACTION = "type_action";

	public static final String LOGIN = "login";

	public static final String ERROR = "error";

	public static final String STATUS = "status";

	public static final String SUCCESS = "success";

	public static final String MESSAGE = "message";

	public static final String SUCCESS_MESSAGE = "msg";

	public static final String INFO = "info";

	public static final String HISTORY = "history";

	public static final String EMPTY_STRING = "";

	public static final String STRING_SEPERATOR = "_";

	public static final String SECRET_KEY = "secretKey";

	public static final String IS_VALID = "isValid";

	public static final String IS_GIFT = "isGift";

	public static final String IMAGE_CONFIG = "imageconfig";

	public static final String FLASH_IMAGE_CONFIG = "flashImageConfig";

	public static final String TRUE = "true";

	public static final String FALSE = "false";

	public static final String AWARD_CODE = "promoCode";

	public static final String EMAIL_ID = "emailid";

	public static final String MOBILE_NO = "mobileno";

	// public static final String PINCODE = "pinCode";

	public static final String IMEI_NO = "imeino";

	public static final String FAILURE = "failure";

	public static final String ERROR_MESSAGE = "errMessage";

	public static final String FILE_PATH_SEPERATOR = "/";

	public static final String IMAGE_SERVLET_IMAGE_PARAM = "img";

	public static final String FLASH_IAMGE_FORMAT = ".jpg";

	public static final String FLASH_DEL_FLAG = "delflag";

	public static final String FLASH_URL_APPENDER = "&";

	public static final String FLASH_VALUE_ASSIGNER = "=";

	public static final String FLASH_REQUEST_HEADER = "type";

	public static final String FLASH_IMAGE_ASSIGNER = "img";

	public static final String FLASH_CUST_OTP = "otp";

	public static final String FLASH_PASSWORD = "password";

	public static final String FLASH_USER_ID = "userid";
	
	public static final String BRANCH_ID = "branchid";
	
	public static final String CLASS_NAME = "classname";

	public static final String FIRST_NAME = "firstname";

	public static final String LAST_NAME = "lastname";

	public static final String BRAND_NAME = "brandname";

	public static final String BRAND_CATEGORY = "brandcategory";

	public static final String CITY = "city";

	public static final String STATE = "state";

	public static final String COUNTRY = "country";

	public static final String PINCODE = "pincode";

	public static final String DISPLAY_IMAGE = "dpimage";

	public static final String MERCHANT_TYPE = "merchanttype";

	public static final String MERCHANT_ID = "merchantid";

	// Merhant Store

	public static final String STORE_NAME = "storename";

	public static final String STORE_CATEGORY = "storecategory";

	public static final String STORE_DISCRIPTION = "storediscription";

	public static final String MERCHANT_PROFILE = "merchantprofile";

	// Merchant Deal Constant

	public static final String MERCHANT_DEAL_NAME = "dealname";

	public static final String MERCHANT_DEAL_CATEGORY = "dealcategory";

	public static final String MERCHANT_DEAL_DISCRIPTION = "dealdiscription";

	public static final String MERCHANT_DEAL_IMAGE = "dealimage";

	public static final String DEAL_ID = "dealid";

	public static final String MERCHANT_DEAL_END_TIME = "dealendtime";

	public static final String MERCHANT_DEAL_START_TIME = "dealstarttime";

	public static final String MERCHANT_DEAL_RADIUS = "dealradius";

	public static final String MERCHANT_DEAL_STORE_ID = "dealstoreid";

	public static final String MERCHANT_STORE_LIST = "storelist";

	public static final String MERCHANT_DEAL_IMG = "flashMerchantDeal";

	public static final String MERCHANT_DEAL_IMG_PATH = "merchantdealimg";

	public static final String MERCHANT_STORE_ID = "storeid";

	public static final String ORG_ACHIEVEMENT_IMG = "achievementimg";

	public static final String ORG_ACHIEVEMENT_IMG_LIST = "achievementimglist";

	public static final String APP_SLIDER_LIST = "sliderlist";

	public static final String APP_CATEGORY_LIST = "categorylist";

	public static final String APP_VERSION = "appversion";

	public static final String SUBSCRIPTION_MODEL = "subscription";

	// public static final String STORE_ID = "storeid";
	// Standrad Bean

	public static final String SYSTEM_CREATED_BY = "SYSTEM";

	public static final String SYSTEM_MODIFIED_BY = "SYSTEM";

	public static final String ACTIVE_DEL_FLAG = "T";

	public static final String DEL_FLAG = "F";

	public static final String FIELD_APPENDER = ",";

	public static final String BASIC_MODEL = "basic";

	public static final String SILVER_MODEL = "silver";

	public static final String GOLD_MODEL = "gold";

	public static final String NOTIFICATION_ID = "notificationid";

	public static final String OS_TYPE = "ostype";

	public static final String OS_VERSION = "osversion";

	public static final String FCM_SERVER_AUTH_KEY = "serverkey";

	public static final String FCM_NOTIFICATION_URL = "fcmurl";

	public static final String DEVICE_MODEL = "devicemodel";

	public static final String DEVICE_ID = "deviceid";

	public static final String NAME = "name";
	
	public static final String LEAD_NAME = "leadname";

	public static final String ROLE = "role";

	public static final String IS_NEWS_LETTER = "isnewsletter";

	public static final String IS_GOV_REGISTERED = "isregisterd";

	public static final String GOVT_REGISTRATION_NO = "registrationno";

	public static final String ORG_ID = "orgid";
	
	public static final String RECORD_ID = "recordid";
	
	public static final String RECORD_TYPE = "recordtype";

	public static final String ACHIEVEMENT_ID = "achievementid";

	public static final String MEMBER_ID = "memberid";

	public static final String PASSWORD = "password";

	public static final String FB_LINK = "fblink";

	public static final String LINKEDIN_LINK = "linkedinlink";

	public static final String WEBSITE_LINK = "websitelink";

	public static final String TWITTER_LINK = "twitterlink";

	public static final String PRESENCE_AREA = "presencearea";

	public static final String ADDRESS = "address";

	public static final String PIN_CODE = "pincode";

	public static final String USER_TYPE = "usertype";

	public static final String ORG_ENTITY = "org";

	public static final String IND_ENTITY = "ind";
	
	public static final String DONATE_ENTITY = "donate";

	public static final String EVENT_ID = "eventid";
	
	public static final String HOMEWORK_ID = "homeworkid";

	public static final String REQUEST_ID = "requestid";

	public static final String TITLE = "title";

	public static final String SUB_TITLE = "subtitle";

	public static final String DISCRIPTION = "discription";

	public static final String START_DATE = "startdate";

	public static final String END_DATE = "enddate";

	public static final String LOCATION = "location";

	public static final String OTHERS = "others";

	public static final String CATEGORY = "category";

	public static final String ORG_LIST = "orglist";

	public static final String BANNER_LIST = "bannerlist";

	public static final String SCREEN_LIST = "screenlist";

	public static final String BROADCAST_TOPIC_LIST = "broadcasttopiclist";

	public static final String BRANCH_DETAILS_LIST = "branchlist";
	
	public static final String BROADCAST_TOPIC_NAME = "topicaname";
	
	public static final String BROADCAST_TOPIC = "topic";

	public static final String ORG_REQ_LIST = "orgreqlist";
	
	public static final String ORG_REC_LIST = "orgreclist";

	public static final String ORG_PROFILE_LIST = "orgprofilelist";

	public static final String ORG_ACHIEVEMENT_LIST = "orgachievementlist";

	public static final String EVENT_LIST = "eventlist";
	
	public static final String HOMEWORK_LIST = "homeworklist";

	public static final String LAST_SYNC_DATE = "lastsyncdate";

	// Notification Entites

	public static final String NOTIFICATION_TYPE = "notificationtype";
	
	public static final String PEER_TO_PEER_NOTIFICATIONS = "peertopeer";
	
	public static final String BROADCAST_NOTIFICATIONS = "broadcast";
	
	public static final String NOTIFICATION_ENTITY = "notificationentity";
	
	public static final String PEER_MESSAGE = "peermessage";
	
	public static final String BROADCAST_MESSAGE = "broadcastmessage";
	
	public static final String EVENT_TYPE = "eventtype";
	
	public static final String ACHIEVEMENT_TYPE = "achievement";
	
	public static final String REQUEST_TYPE = "request";
	
	//public static final String NOTIFICATION_ = "notificationevent";

	public static final String ORG_REGISTRATION = "orgregistration";

	public static final String ORG_NEW_EVENT = "orgeventnew";

	public static final String ORG_EVENT_UPATE = "orgeventupdate";

	public static final String ORG_NEW_ACHIEVEMENT = "orgachievementnew";

	public static final String ORG_ACHIEVEMENT_UPDATE = "orgachievementupdate";

	public static final String ORG_NEW_SOCIAL_REQUEST = "orgsocialreqnew";

	public static final String ORG_SOCIAL_REQIEST_UPDATE = "orgsocialrequpdate";

	public static final String INDIVIDUAL_REGISTRATION = "indregistration";

	public static final String DONATE_REQUEST = "donaterequest";

	public static final String DATE_REQUEST = "daterequest";

	public static final String COLLECTION_MODE = "collectionMode";

	public static final String FREE_TEXT1 = "freetext1";

	public static final String FREE_TEXT2 = "freetext2";

	public static final String FREE_TEXT3 = "freetext3";

	public static final String FREE_TEXT4 = "freetext4";
	
	public static final String DONATE_IMG = "img";
	
	public static final String PREVIOUS_EVENT = "previous";
	
	public static final String UPCOMING_EVENT = "upcoming";
	
	public static final String STUDENT_PROFILE_LIST = "studentprofile";
	
	public static final String FCM_MESSAGE_BODY = "body";
	
	public static final String FCM_MESSAGE_EVENT_TYPE = "event";
	
	

}
