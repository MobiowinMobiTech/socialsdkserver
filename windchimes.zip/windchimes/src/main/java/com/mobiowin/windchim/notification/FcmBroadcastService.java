package com.mobiowin.windchim.notification;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.mobiowin.windchim.bean.StudentNotificationBean;
import com.mobiowin.windchim.commons.ApplicationConstant;

@Service("fcmBroadcastService")
@Component
public class FcmBroadcastService implements IFcmBroadcastService {

	private Log log = LogFactory.getLog(this.getClass());

	/*
	 * @Autowired private RestTemplate restTemplate;
	 */

	@Autowired
	private @Resource Map<String, String> eventconfig;

	@Autowired
	private @Resource Map<String, String> notificationConfig;

	String fcmServerAuthKey = null;
	String fcmNotificationUrl = null;

	@Async
	public void sendBroadcastNotification(HashMap<String, String> notificationDetailMap) {
		log.info("Inside FCMBroadcastService / sendBroadcastNotification()");

		if (null != notificationDetailMap) {
			log.info("notificationDetailMap -------------- > : " + notificationDetailMap);

			if (notificationDetailMap.get(ApplicationConstant.NOTIFICATION_TYPE)
					.equals(ApplicationConstant.EVENT_TYPE)) {

				String message = String.format(String.valueOf(eventconfig.get(ApplicationConstant.BROADCAST_MESSAGE)),
						notificationDetailMap.get(ApplicationConstant.TITLE),
						notificationDetailMap.get(ApplicationConstant.NAME),
						notificationDetailMap.get(ApplicationConstant.LOCATION));

				log.info("Message is : " + message);

				notificationDetailMap.put(ApplicationConstant.BROADCAST_TOPIC_NAME,
						eventconfig.get(ApplicationConstant.BROADCAST_TOPIC_NAME));
				notificationDetailMap.put(ApplicationConstant.MESSAGE, message);
				notificationDetailMap.put(ApplicationConstant.NOTIFICATION_TYPE, ApplicationConstant.EVENT_TYPE);
				notificationDetailMap.put(ApplicationConstant.RECORD_ID,
						notificationDetailMap.get(ApplicationConstant.EVENT_ID));
				/*
				 * notificationDetailMap.put(ApplicationConstant.ORG_ID,
				 * notificationDetailMap.get(ApplicationConstant.ORG_ID));
				 */
				notificationDetailMap.put(ApplicationConstant.TITLE, eventconfig.get(ApplicationConstant.TITLE));

				log.info(" Notification Detail Map  " + notificationDetailMap);
			}

		}

		sendNotification(notificationDetailMap);

	}

	private void sendNotification(HashMap<String, String> notificationDetailMap) {
		String notificationJsonData = null;
		try {
			fcmServerAuthKey = String.valueOf(notificationConfig.get("serverkey"));
			fcmNotificationUrl = String.valueOf(notificationConfig.get("fcmurl"));

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set("Authorization", "key=" + fcmServerAuthKey);

			if (notificationDetailMap.get(ApplicationConstant.EVENT_TYPE).equals("event")) 
			{
				notificationJsonData = getEventNotificationData(notificationDetailMap);
			}
			else {
				notificationJsonData = getNotificationMessageData(notificationDetailMap);
			}

			HttpEntity<String> entity = new HttpEntity<String>(notificationJsonData, headers);
			RestTemplate restTemplate = new RestTemplate();
			String resposne = restTemplate.postForObject(fcmNotificationUrl, entity, String.class);
			JSONObject responseJson = new JSONObject(resposne);

			log.info("Resposne is : " + responseJson);
		} catch (RestClientException e) {
			log.error("Restclient exception is : " + e.getMessage());
			e.printStackTrace();
		} catch (JSONException e) {
			log.error("Exception in json parsing : " + e.getMessage());
			e.printStackTrace();
		} catch (Exception ex) {
			log.error("Exception in sendNotification : " + ex.getMessage());
		}

	}

	private String getEventNotificationData(HashMap<String, String> notificationDetailMap) {

		JSONObject notificationJson = new JSONObject();
		notificationJson.put("to", "/topics/promotion");
		JSONObject info = new JSONObject();
		info.put(ApplicationConstant.TITLE, notificationDetailMap.get(ApplicationConstant.TITLE));
		info.put(ApplicationConstant.FCM_MESSAGE_BODY, notificationDetailMap.get(ApplicationConstant.FCM_MESSAGE_BODY));
		info.put(ApplicationConstant.EVENT_TYPE, "event");
		info.put(ApplicationConstant.EVENT_ID,notificationDetailMap.get(ApplicationConstant.EVENT_ID));
		//info.put(ApplicationConstant.EVENT_ID, "1");
		notificationJson.put("data", info);

		if (log.isInfoEnabled()) {
			log.info("Notification json is : " + info);
			log.info("Notification json is : " + notificationJson);
		}

		return notificationJson.toString();
	}

	private String getNotificationMessageData(HashMap<String, String> notificationDetailMap) {

		JSONObject notificationJson = new JSONObject();
		notificationJson.put("to", "/topics/promotion");
		JSONObject info = new JSONObject();
		info.put(ApplicationConstant.TITLE, notificationDetailMap.get(ApplicationConstant.TITLE));
		info.put(ApplicationConstant.FCM_MESSAGE_BODY, notificationDetailMap.get(ApplicationConstant.FCM_MESSAGE_BODY));
		info.put(ApplicationConstant.EVENT_TYPE, notificationDetailMap.get(ApplicationConstant.SUB_TITLE));
		notificationJson.put("data", info);

		if (log.isInfoEnabled()) {
			log.info("Notification json is : " + info);
			log.info("Notification json is : " + notificationJson);
		}

		return notificationJson.toString();
	}

	@Async
	public void sendGeneralBroadcastNotification(HashMap<String, String> notificationDetailMap) {
		log.info("Inside FCMBroadcastService / sendGeneralBroadcastNotification()");

		if (null != notificationDetailMap) {
			log.info("notificationDetailMap -------------- > : " + notificationDetailMap);

			notificationDetailMap.put(ApplicationConstant.BROADCAST_TOPIC_NAME, "/topics/promotion");
			notificationDetailMap.put(ApplicationConstant.MESSAGE,
					notificationDetailMap.get(ApplicationConstant.FCM_MESSAGE_BODY));
			notificationDetailMap.put(ApplicationConstant.EVENT_TYPE,
					notificationDetailMap.get(ApplicationConstant.TITLE));
			notificationDetailMap.put(ApplicationConstant.TITLE, notificationDetailMap.get(ApplicationConstant.TITLE));
			notificationDetailMap.put(ApplicationConstant.SUB_TITLE,
					notificationDetailMap.get(ApplicationConstant.SUB_TITLE));

			log.info(" Notification Detail Map  " + notificationDetailMap);

		}

		sendNotification(notificationDetailMap);

	}

	@Async
	public void setEventNotification(HashMap<String, String> notificationDataMap) {
		if (null != notificationDataMap) {
			log.info("notificationDataMap -------------- > : " + notificationDataMap);

			notificationDataMap.put(ApplicationConstant.BROADCAST_TOPIC_NAME, "/topics/promotion");
			notificationDataMap.put(ApplicationConstant.FCM_MESSAGE_BODY,
					notificationDataMap.get(ApplicationConstant.FCM_MESSAGE_BODY));
			notificationDataMap.put(ApplicationConstant.EVENT_TYPE,
					notificationDataMap.get(ApplicationConstant.EVENT_TYPE));
			notificationDataMap.put(ApplicationConstant.TITLE, notificationDataMap.get(ApplicationConstant.TITLE));
			notificationDataMap.put(ApplicationConstant.EVENT_ID,
					notificationDataMap.get(ApplicationConstant.EVENT_ID));

			log.info(" Notification Detail Map  " + notificationDataMap);

		}

		sendNotification(notificationDataMap);

	}
	
	@Async
	public void sendHomeWorkNotification(List<StudentNotificationBean> studentHwNotificataionList,HashMap<String,String> dataMap) 
	{
		log.info("Inside FcmBroadcastService/sendHomeWorkNotification()");
		
		if(log.isInfoEnabled())
		{
			log.info("Student notification list is : " + studentHwNotificataionList);
		}
		
		JSONObject json = null;
		JSONObject info = null;
		
		for(StudentNotificationBean studentNotificationBean: studentHwNotificataionList)
		{
			json = new JSONObject();
			json.put("to", studentNotificationBean.getNotificationId());
			info = new JSONObject();
			info.put("title", dataMap.get(ApplicationConstant.TITLE));
			info.put("body", dataMap.get(ApplicationConstant.FCM_MESSAGE_BODY));
			json.put("data", info);
			
			sendHomeworkNotification(json);
		}
	}

	private void sendHomeworkNotification(JSONObject json) {
		fcmServerAuthKey = String.valueOf(notificationConfig.get("serverkey"));
		fcmNotificationUrl = String.valueOf(notificationConfig.get("fcmurl"));

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("Authorization", "key=" + fcmServerAuthKey);
		HttpEntity<String> entity = new HttpEntity<String>(json.toString(), headers);
		RestTemplate restTemplate = new RestTemplate();
		String resposne = restTemplate.postForObject(fcmNotificationUrl, entity, String.class);
		JSONObject responseJson = new JSONObject(resposne);
		
		log.info("Response Josn is : " + responseJson);
		
 	}

}
