package com.mobiowin.windchim.notification;

import java.util.HashMap;

public interface IFcmPeerNotificationService {

	

	void sendPeerToPeerNotification(HashMap<String, String> notificationDetailMap);

}
