package com.mobiowin.windchim.notification;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.Async;
import org.springframework.web.client.RestTemplate;

public class FCMIntegrationService implements IFCMIntegrationService{

	private Log log = LogFactory.getLog(this.getClass());

	/*@Autowired
	private RestTemplate restTemplate;*/

	@Autowired
	private @Resource Map<String, String> notificationConfig;
	
	@Autowired
	private @Resource Map<String, String> notificationMessageConfig;

	String fcmServerAuthKey = null;
	String fcmNotificationUrl = null;
	HttpEntity<String> entity = null;
	String notificationJsonData = null;
	String resposne = null;

	@Async
	public String sendFcmNotificationMessage(HashMap<String, String> notificationDataMap) 
	{

		fcmServerAuthKey = String.valueOf(notificationConfig.get("serverkey"));
		fcmNotificationUrl = String.valueOf(notificationConfig.get("fcmurl"));

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("Authorization", "key=" + fcmServerAuthKey);
		
		notificationJsonData = getNotificationMessageData();

		entity = new HttpEntity<String>(notificationJsonData, headers);
		
		//resposne = restTemplate.postForObject(fcmNotificationUrl, entity, String.class);
		RestTemplate restTemplate = new RestTemplate();
		resposne = restTemplate.postForObject("https://fcm.googleapis.com/fcm/send", entity, String.class);
		JSONObject responseJson = new JSONObject(resposne);

		log.info("Resposne is : " + responseJson);
		
		return responseJson.toString();

	}

	private static String getNotificationMessageData()
	{
		//log.info("inside  getNotificationMessageData()");
		
		JSONObject json = new JSONObject();
		/*json.put("to", "/topics/event");
		JSONObject info = new JSONObject();
		info.put("title", "Windchim Event Notification");
		info.put("body", "Dear User, Windchim shool welcomes you.");
		info.put("eventtype", "Mother day Event");
		info.put("eventid","1");
		json.put("data", info);*/
		
		/*json.put("to", "/topics/promotion");
		JSONObject info = new JSONObject();
		info.put("title", "Windchim Summer Camp Notification");
		info.put("body", "Dear User, Windchim shool welcomes you, we are offering best child care services");
		info.put("eventtype", "event");
		info.put("eventid","1");
		json.put("data", info);*/
		
		
		//json.put("to", "/topics/promotion");
		json.put("to", "e2CBKea8fhI:APA91bFLl3lSs6JoIbGwqmFg6vpFIxHz8Z_E3QX-SllG1mkf6ICH8K0-4kHkYhxVxSJyYa3eWLt928TPU-xfBj2wzTug34EWvxFDggxhbyAPIOwHls3wiW-OUctGOxgrMrZ2JgjF5-Ke");
		JSONObject info = new JSONObject();
		info.put("title", "Windchim Promotion notification");
		info.put("body", "Windchim General Notification");
		json.put("data", info);
		//info.put("eventid","1");
		
		

		System.out.println("Json is : " + json);
		
		
		
		return json.toString();
	}

public static void main(String[] args) 
{
	HttpHeaders headers = new HttpHeaders();
	headers.setContentType(MediaType.APPLICATION_JSON);
	headers.set("Authorization", "key=" + "AIzaSyAXe2R_vTDEpNxWqrA3zgB2pshtyqBrUIY");
	//AIzaSyDQfg-IDr5s8QReG14oH21X4qpZR4Ar958
	// AIzaSyAXe2R_vTDEpNxWqrA3zgB2pshtyqBrUIY
	String notificationJsonData = getNotificationMessageData();

	HttpEntity<String> entity = new HttpEntity<String>(notificationJsonData, headers);
	
	//resposne = restTemplate.postForObject(fcmNotificationUrl, entity, String.class);
	RestTemplate restTemplate = new RestTemplate();
	String resposne = restTemplate.postForObject("https://fcm.googleapis.com/fcm/send", entity, String.class);
	JSONObject responseJson = new JSONObject(resposne);

	System.out.println("Resposne is : " + responseJson);
	
	
}
}
