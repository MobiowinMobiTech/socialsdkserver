package com.mobiowin.windchim.dao;

import java.sql.Timestamp;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.mobiowin.windchim.bean.DeviceDetailBean;
import com.mobiowin.windchim.bean.StudentHomeworkMaster;
import com.mobiowin.windchim.bean.StudentNotificationBean;
import com.mobiowin.windchim.bean.StudentProfileBean;
import com.mobiowin.windchim.bean.StudentRegistrationBean;
import com.mobiowin.windchim.commons.ApplicationConstant;
import com.mobiowin.windchim.test.DateUtility;

@Repository("studentCoreHelperDao")
@Component
public class StudentCoreHelperDao implements IStudentCoreHelperDao {

	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private SessionFactory sessionFactory;

	Session session = null;
	Transaction transaction = null;

	public List<StudentRegistrationBean> validateLogin(StudentRegistrationBean registrationBean) {
		log.info("Inside StudentCoreHelperDao/validateLogin()");

		StringBuilder loginQueryBuilder = null;
		List<StudentRegistrationBean> loginList = null;
		try {
			loginQueryBuilder = new StringBuilder();
			loginQueryBuilder.append("from StudentRegistrationBean ");
			loginQueryBuilder.append("where enrollmentId =:enrollmentId ");
			loginQueryBuilder.append("and ( fatherNo = :password ");
			loginQueryBuilder.append("or motherNo = :password ");
			loginQueryBuilder.append("or password = :password) ");

			Query query = sessionFactory.openSession().createQuery(loginQueryBuilder.toString());
			query.setParameter("enrollmentId", registrationBean.getEnrollmentId());
			query.setParameter("password", registrationBean.getPassword());

			loginList = query.list();

			log.info("loginList : " + loginList.size());

			return loginList;
		} catch (HibernateException e) {
			e.printStackTrace();
			log.error("Hibernate Exception in org login validation : " + e.getMessage());
			return loginList;
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception in org login validation : " + e.getMessage());
			return loginList;
		}
	}

	public List<StudentProfileBean> fetchStudentProfile(StudentProfileBean studentProfileBean) {

		log.info("Inside CoreOrgHelperDao/isOrgProfileExist()");

		StringBuilder studentProfileQueryBuilder = new StringBuilder();
		studentProfileQueryBuilder.append("from StudentProfileBean ");

		StringBuilder studentProfileCheckQuery = getStudentProfileQuery(studentProfileQueryBuilder);

		List<StudentProfileBean> studentProfileList = null;

		log.info("Student Profile Check Query is : " + studentProfileCheckQuery.toString());

		try {
			Query query = sessionFactory.openSession().createQuery(studentProfileCheckQuery.toString());
			query.setParameter("enrollmentId", studentProfileBean.getEnrollmentId());
			query.setParameter("branchId", studentProfileBean.getBranchId());
			query.setParameter("deleteFlag", studentProfileBean.getDeleteFlag());

			studentProfileList = query.list();

			log.info("Registered student profile List is : " + studentProfileList.size());

			return studentProfileList;
		} catch (HibernateException e) {
			log.error("Hibernate exception in fetchStudentProfile() : " + e.getMessage());
			e.printStackTrace();
			return studentProfileList;
		} catch (Exception ex) {
			log.error("Hibernate exception in fetchStudentProfile() : " + ex.getMessage());
			ex.printStackTrace();
			return studentProfileList;
		}
	}

	private StringBuilder getStudentProfileQuery(StringBuilder studentProfileQueryBuilder) {
		studentProfileQueryBuilder.append("where enrollmentId = :enrollmentId ");
		studentProfileQueryBuilder.append("and branchId = :branchId ");
		studentProfileQueryBuilder.append("and deleteFlag = :deleteFlag ");
		return studentProfileQueryBuilder;
	}

	public boolean isUserExist(StudentNotificationBean studentNotificationBean) {
		log.info("Inside StudentCoreHelperDao/isUserExist()");

		StringBuilder userCheckQueryBuilder = new StringBuilder();
		userCheckQueryBuilder.append("from StudentNotificationBean ");

		StringBuilder userCheckQuery = getUserCheckQuery(userCheckQueryBuilder);

		log.info("userCheckQuery is : " + userCheckQuery);

		try {
			Query query = sessionFactory.openSession().createQuery(userCheckQuery.toString());
			query.setParameter("deviceId", studentNotificationBean.getDeviceId());
			query.setParameter("enrollmentId", studentNotificationBean.getEnrollmentId());
			query.setParameter("branchId", studentNotificationBean.getBranchId());
			query.setParameter("className", studentNotificationBean.getClassName());
			query.setParameter("deleteFlag", studentNotificationBean.getDeleteFlag());

			List<DeviceDetailBean> deviceDeviceList = query.list();

			log.info("DeviceList is : " + deviceDeviceList.size());

			if (deviceDeviceList.size() > 0) {
				return true;
			}

			return false;
		} catch (HibernateException e) {
			log.error("Hibernate exception in isUserExist() : " + e.getMessage());
			e.printStackTrace();
			return false;
		} catch (Exception ex) {
			log.error("Hibernate exception in isUserExist() : " + ex.getMessage());
			ex.printStackTrace();
			return false;
		}
	}

	private StringBuilder getUserCheckQuery(StringBuilder userCheckQueryBuilder) {
		userCheckQueryBuilder.append("where deviceId = :deviceId ");
		userCheckQueryBuilder.append("and enrollmentId =:enrollmentId ");
		userCheckQueryBuilder.append("and branchId =:branchId ");
		userCheckQueryBuilder.append("and className =:className ");
		userCheckQueryBuilder.append("and deleteFlag =:deleteFlag");
		return userCheckQueryBuilder;
	}

	public String submitUser(StudentNotificationBean studentNotificationBean) {
		log.info("Inside StudentCoreHelperDao/submitUser()");

		log.info("StudentNotificationBean : " + studentNotificationBean);

		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			session.save(studentNotificationBean);
			session.flush();
			transaction.commit();

			return ApplicationConstant.TRUE;
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
			log.error("Exception in submitUser : " + e.getMessage(), e.getCause());
			return ApplicationConstant.FALSE;
		} catch (Exception ex) {
			transaction.rollback();
			ex.printStackTrace();
			log.error("Exception in submitUser : " + ex.getMessage(), ex.getCause());
			return ApplicationConstant.FALSE;
		}
	}

	public String updateUser(StudentNotificationBean studentNotificationBean) {
		log.info("Inside StudentCoreHelperDao/updateUser()");

		StringBuilder deviceQueryBuilder = null;
		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			deviceQueryBuilder = new StringBuilder();
			deviceQueryBuilder.append("update StudentNotificationBean ");
			deviceQueryBuilder = fetchDeviceUpdateBuilder(deviceQueryBuilder);

			log.info("student Notification Bean is : " + studentNotificationBean);
			log.info("device Detail Bean query is : " + deviceQueryBuilder.toString());

			Query query = session.createQuery(deviceQueryBuilder.toString());

			query.setParameter("notificationId", studentNotificationBean.getNotificationId());
			query.setParameter("modifiedBy", studentNotificationBean.getModifiedBy());
			query.setParameter("modifyDt", studentNotificationBean.getModifyDt());
			query.setParameter("deviceId", studentNotificationBean.getDeviceId());
			query.setParameter("enrollmentId", studentNotificationBean.getEnrollmentId());
			query.setParameter("branchId", studentNotificationBean.getBranchId());
			query.setParameter("className", studentNotificationBean.getClassName());
			query.setParameter("deleteFlag", studentNotificationBean.getDeleteFlag());

			int updateStatus = query.executeUpdate();

			log.info("Device details Status : " + updateStatus);

			session.flush();
			transaction.commit();

			return ApplicationConstant.TRUE;
		} catch (Exception e) {
			log.error("Exception in updating notification details : " + e.getMessage(), e.getCause());
			e.printStackTrace();

			return ApplicationConstant.FALSE;

		}
	}

	private StringBuilder fetchDeviceUpdateBuilder(StringBuilder deviceQueryBuilder) {
		deviceQueryBuilder.append("set notificationId = :notificationId ,");
		deviceQueryBuilder.append("modifiedBy = :modifiedBy,");
		deviceQueryBuilder.append("modifyDt = :modifyDt ");
		deviceQueryBuilder.append("where deviceId = :deviceId ");
		deviceQueryBuilder.append("and enrollmentId =:enrollmentId ");
		deviceQueryBuilder.append("and branchId =:branchId ");
		deviceQueryBuilder.append("and className =:className ");
		deviceQueryBuilder.append("and deleteFlag =:deleteFlag ");
		
		return deviceQueryBuilder;
	}

	public List<StudentHomeworkMaster> syncHomeworkById(StudentHomeworkMaster studentHomeworkMaster) {

		log.info("Inside StudentCoreHelperDao/syncHomeworkById()");

		List<StudentHomeworkMaster> responseList = null;
		StringBuilder homeworkSyncByIdQueryBuilder = new StringBuilder();
		homeworkSyncByIdQueryBuilder.append("from StudentHomeworkMaster ");
		homeworkSyncByIdQueryBuilder.append("where homeworkId = :homeworkId ");
		homeworkSyncByIdQueryBuilder.append("and deleteFlag =:deleteFlag ");

		
		
		log.info("homeworkSyncByIdQueryBuilder is : " + homeworkSyncByIdQueryBuilder);

		try {
			Query query = sessionFactory.openSession().createQuery(homeworkSyncByIdQueryBuilder.toString());
			query.setParameter("homeworkId", studentHomeworkMaster.getHomeworkId());
			query.setParameter("deleteFlag", studentHomeworkMaster.getDeleteFlag());
			responseList = query.list();

			log.info(" responseList  is : " + responseList.size());

			return responseList;
		} catch (HibernateException e) {
			log.error("Hibernate exception in syncHomeworkById() : " + e.getMessage());
			e.printStackTrace();
			return responseList;
		} catch (Exception ex) {
			log.error("Hibernate exception in syncHomeworkById() : " + ex.getMessage());
			ex.printStackTrace();
			return responseList;
		}
	
	}

	public List<StudentHomeworkMaster> syncHomeworkList(StudentHomeworkMaster studentHomeworkMaster, String lastSyncDate) {

		log.info("Inside StudentCoreHelperDao/syncHomeworkList()");

		List<StudentHomeworkMaster> responseList = null;
		StringBuilder homeworkSyncQueryBuilder = new StringBuilder();
		homeworkSyncQueryBuilder.append("from StudentHomeworkMaster ");


		if (lastSyncDate.equals("0"))
		{
			homeworkSyncQueryBuilder = getEventSyncQuery(homeworkSyncQueryBuilder);
		} else {
			homeworkSyncQueryBuilder = getEventIncrementalSyncQuery(homeworkSyncQueryBuilder);
		}
		
		log.info("eventSyncQueryBuilder is : " + homeworkSyncQueryBuilder);

		try {
			Query query = sessionFactory.openSession().createQuery(homeworkSyncQueryBuilder.toString());
			
			if (lastSyncDate.equals("0")) 
			{
				query.setParameter("branchId", studentHomeworkMaster.getBranchId());
				query.setParameter("className", studentHomeworkMaster.getClassName());
				query.setParameter("deleteFlag", studentHomeworkMaster.getDeleteFlag());
			}
			else {
				query.setParameter("branchId", studentHomeworkMaster.getBranchId());
				query.setParameter("className", studentHomeworkMaster.getClassName());
				query.setParameter("createDt", Timestamp.valueOf(DateUtility.syncDateparser(lastSyncDate)));
				query.setParameter("modifyDt", Timestamp.valueOf(DateUtility.syncDateparser(lastSyncDate)));
				query.setParameter("deleteFlag", studentHomeworkMaster.getDeleteFlag());

			}
			

			responseList = query.list();

			log.info(" responseList is : " + responseList);

			return responseList;
		} catch (HibernateException e) {
			log.error("Hibernate exception in syncHomeworkList() : " + e.getMessage());
			e.printStackTrace();
			return responseList;
		} catch (Exception ex) {
			log.error("Hibernate exception in syncHomeworkList() : " + ex.getMessage());
			ex.printStackTrace();
			return responseList;
		}
	
	}

	private StringBuilder getEventIncrementalSyncQuery(StringBuilder homeworkSyncQueryBuilder) {
		homeworkSyncQueryBuilder.append("where  ");
		homeworkSyncQueryBuilder.append("branchId =:branchId ");
		homeworkSyncQueryBuilder.append("and className =:className ");
		homeworkSyncQueryBuilder.append("and createDt > :createDt ");
		homeworkSyncQueryBuilder.append("or modifyDt > :modifyDt ");
		homeworkSyncQueryBuilder.append("and deleteFlag =:deleteFlag");
		return homeworkSyncQueryBuilder;
	}

	private StringBuilder getEventSyncQuery(StringBuilder homeworkSyncQueryBuilder) {
		homeworkSyncQueryBuilder.append("where ");
		homeworkSyncQueryBuilder.append("branchId =:branchId ");
		homeworkSyncQueryBuilder.append("and className =:className ");
		homeworkSyncQueryBuilder.append("and deleteFlag =:deleteFlag ");
		return homeworkSyncQueryBuilder;
	}

}
