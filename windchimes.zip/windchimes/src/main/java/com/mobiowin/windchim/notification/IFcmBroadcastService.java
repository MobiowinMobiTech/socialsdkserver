package com.mobiowin.windchim.notification;

import java.util.HashMap;

public interface IFcmBroadcastService {

	void sendBroadcastNotification(HashMap<String, String> notificationDetailMap);

	void sendGeneralBroadcastNotification(HashMap<String, String> notificationDataMap);

	void setEventNotification(HashMap<String, String> notificationDataMap);

}
