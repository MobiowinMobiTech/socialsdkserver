package com.mobiowin.windchim.notification;

import java.util.HashMap;
import java.util.List;

import com.mobiowin.windchim.bean.StudentNotificationBean;

public interface IFcmBroadcastService {

	void sendBroadcastNotification(HashMap<String, String> notificationDetailMap);

	void sendGeneralBroadcastNotification(HashMap<String, String> notificationDataMap);

	void setEventNotification(HashMap<String, String> notificationDataMap);

	void sendHomeWorkNotification(List<StudentNotificationBean> studentHwNotificataionList, HashMap<String, String> dataMap);

}
