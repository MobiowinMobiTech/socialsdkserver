package com.mobiowin.windchim.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "student_register_master", catalog = "windchimp")
public class StudentRegistrationBean implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private String id;
	
	@Column(name = "enrollment_id")
	private String enrollmentId;
	
	@Column(name = "branch_id")
	private String branchId;
	
	@Column(name = "class_name")
	private String className;
	
	@Column(name = "father_no")
	private String fatherNo;

	@Column(name = "mother_no")
	private String motherNo;
	
	@Column(name = "password")
	private String password;
	
	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_dt")
	private Date createDt;

	@Column(name = "modified_by")
	private String modifiedBy;

	@Column(name = "modified_dt")
	private Date modifyDt;

	@Column(name = "del_flag")
	private String deleteFlag;
	
	

	public StudentRegistrationBean() {
		super();
	}



	public StudentRegistrationBean(String id, String enrollmentId, String branchId, String className, String fatherNo,
			String motherNo, String password, String createdBy, Date createDt, String modifiedBy, Date modifyDt,
			String deleteFlag) {
		super();
		this.id = id;
		this.enrollmentId = enrollmentId;
		this.branchId = branchId;
		this.className = className;
		this.fatherNo = fatherNo;
		this.motherNo = motherNo;
		this.password = password;
		this.createdBy = createdBy;
		this.createDt = createDt;
		this.modifiedBy = modifiedBy;
		this.modifyDt = modifyDt;
		this.deleteFlag = deleteFlag;
	}



	public String getId() {
		return id;
	}



	public void setId(String id) {
		this.id = id;
	}



	public String getEnrollmentId() {
		return enrollmentId;
	}



	public void setEnrollmentId(String enrollmentId) {
		this.enrollmentId = enrollmentId;
	}



	public String getBranchId() {
		return branchId;
	}



	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}



	public String getClassName() {
		return className;
	}



	public void setClassName(String className) {
		this.className = className;
	}



	public String getFatherNo() {
		return fatherNo;
	}



	public void setFatherNo(String fatherNo) {
		this.fatherNo = fatherNo;
	}



	public String getMotherNo() {
		return motherNo;
	}



	public void setMotherNo(String motherNo) {
		this.motherNo = motherNo;
	}



	public String getPassword() {
		return password;
	}



	public void setPassword(String password) {
		this.password = password;
	}



	public String getCreatedBy() {
		return createdBy;
	}



	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}



	public Date getCreateDt() {
		return createDt;
	}



	public void setCreateDt(Date createDt) {
		this.createDt = createDt;
	}



	public String getModifiedBy() {
		return modifiedBy;
	}



	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}



	public Date getModifyDt() {
		return modifyDt;
	}



	public void setModifyDt(Date modifyDt) {
		this.modifyDt = modifyDt;
	}



	public String getDeleteFlag() {
		return deleteFlag;
	}



	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}



	@Override
	public String toString() {
		return "StudentRegistrationBean [id=" + id + ", enrollmentId=" + enrollmentId + ", branchId=" + branchId
				+ ", className=" + className + ", fatherNo=" + fatherNo + ", motherNo=" + motherNo + ", password="
				+ password + ", createdBy=" + createdBy + ", createDt=" + createDt + ", modifiedBy=" + modifiedBy
				+ ", modifyDt=" + modifyDt + ", deleteFlag=" + deleteFlag + "]";
	}
	
	

	
	
	
	
}
