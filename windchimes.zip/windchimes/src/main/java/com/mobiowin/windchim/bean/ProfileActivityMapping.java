
package com.mobiowin.windchim.bean;

import java.io.Serializable;

public class ProfileActivityMapping implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String profileCode;
	
	private String activityCode;

	public String getProfileCode()
	{
		return profileCode;
	}

	public void setProfileCode(String profileCode)
	{
		this.profileCode = profileCode;
	}

	public String getActivityCode()
	{
		return activityCode;
	}

	public void setActivityCode(String activityCode)
	{
		this.activityCode = activityCode;
	}
	
	

}
