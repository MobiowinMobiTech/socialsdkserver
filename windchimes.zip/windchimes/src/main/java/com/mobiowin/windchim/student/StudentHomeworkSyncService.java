package com.mobiowin.windchim.student;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.windchim.commons.ApplicationConstant;
import com.mobiowin.windchim.messaging.IMessageService;
import com.mobiowin.windchim.service.student.IStudentHelperService;

@Service("studentHomeworkSyncService")
@Component
public class StudentHomeworkSyncService implements IMessageService{

	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private IStudentHelperService studentCoreHelperService;
	
	public Message<String> execute(Message<String> message) {
		log.info("Inside StudentHomeworkSyncService/execute()");

		String jsonData = message.getPayload();

		Map<String, Object> messageHeaders = message.getHeaders();

		JSONObject userDataJson = null;
		JSONObject userDatadetailJson = null;
		
		String userId = null;
		String branchId = null;
		String className = null;
		String lastSyncDate = null;

		String response = null;
		HashMap<String, String> studentNotificationDetailMap = null;

		try {
			
			userDataJson = new JSONObject(jsonData);
			userDatadetailJson = userDataJson.getJSONObject(ApplicationConstant.DATA);

			log.info("Last sync date " + userDatadetailJson.getString(ApplicationConstant.LAST_SYNC_DATE));

			if (userDatadetailJson.has(ApplicationConstant.LAST_SYNC_DATE)) {
				lastSyncDate = userDatadetailJson.getString(ApplicationConstant.LAST_SYNC_DATE);
			}
			
			if (userDatadetailJson.has(ApplicationConstant.FLASH_USER_ID)) {
				userId = userDatadetailJson.getString(ApplicationConstant.FLASH_USER_ID);
			}

			if (userDatadetailJson.has(ApplicationConstant.BRANCH_ID)) {
				branchId = userDatadetailJson.getString(ApplicationConstant.BRANCH_ID);
			}

			if (userDatadetailJson.has(ApplicationConstant.CLASS_NAME)) {
				className = userDatadetailJson.getString(ApplicationConstant.CLASS_NAME);
			}

			

			if (log.isInfoEnabled()) {
				log.info("messageHeaders is : " + messageHeaders);
				log.info("FLASH_USER_ID is : " + userId);
				log.info("BRANCH_ID is : " + branchId);
				log.info("ClassName is : " + className);
				
			}

			studentNotificationDetailMap = getStudentDataMap(userId, branchId, className,lastSyncDate);

			response = studentCoreHelperService.syncStudentHomeworkData(studentNotificationDetailMap);

			return MessageBuilder.withPayload(response).build();

		} catch (Exception e) {
			log.error("Exception in NotiicationSyncService/execute() : " + e.getMessage());
			return null;
		}
	}

	private HashMap<String, String> getStudentDataMap(String userId, String branchId, String className,
			String lastSyncDate) {
		
		HashMap<String, String> reqDataMap = new HashMap<String, String>();
		reqDataMap.put(ApplicationConstant.BRANCH_ID, branchId);
		reqDataMap.put(ApplicationConstant.LAST_SYNC_DATE, lastSyncDate);
		reqDataMap.put(ApplicationConstant.CLASS_NAME, className);
		reqDataMap.put(ApplicationConstant.FLASH_USER_ID, userId);

		return reqDataMap;
	}

}
