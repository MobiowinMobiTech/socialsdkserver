package com.mobiowin.windchim.service.student;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.windchim.bean.StudentHomeworkMaster;
import com.mobiowin.windchim.bean.StudentNotificationBean;
import com.mobiowin.windchim.bean.StudentProfileBean;
import com.mobiowin.windchim.bean.StudentRegistrationBean;
import com.mobiowin.windchim.commons.ApplicationConstant;
import com.mobiowin.windchim.commons.MessageUtility;
import com.mobiowin.windchim.dao.IStudentCoreHelperDao;
import com.mobiowin.windchim.test.DateUtility;

@Service("studentCoreHelperService")
@Component
public class StudentHelperService implements IStudentHelperService {
	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private IStudentCoreHelperDao studentCoreHelperDao;

	public String validateLogin(HashMap<String, String> loginReqDataMap) {
		log.info("Inside StudentHelperService/validateLogin()");

		StudentRegistrationBean registrationBean = null;
		StudentProfileBean studentProfileBean = null;
		List<StudentRegistrationBean> registeredStudentList = null;
		List<StudentProfileBean> studentProfileList = null;
		HashMap<String, Object> dataMap = null;

		if (null != loginReqDataMap) {
			registrationBean = new StudentRegistrationBean();
			registrationBean.setBranchId(loginReqDataMap.get(ApplicationConstant.BRANCH_ID));
			registrationBean.setEnrollmentId(loginReqDataMap.get(ApplicationConstant.FLASH_USER_ID));
			registrationBean.setPassword(loginReqDataMap.get(ApplicationConstant.FLASH_PASSWORD));
			registrationBean.setDeleteFlag(ApplicationConstant.DEL_FLAG);

			log.info("Student registration bean is : " + registrationBean);
		}

		registeredStudentList = studentCoreHelperDao.validateLogin(registrationBean);

		if (registeredStudentList.size() > 0 && registeredStudentList.size() < 2) {
			studentProfileBean = new StudentProfileBean();
			studentProfileBean.setEnrollmentId(registrationBean.getEnrollmentId());
			studentProfileBean.setBranchId(registrationBean.getBranchId());
			studentProfileBean.setDeleteFlag(ApplicationConstant.DEL_FLAG);

			log.info("Student profile bean is : " + studentProfileBean);

			studentProfileList = studentCoreHelperDao.fetchStudentProfile(studentProfileBean);

			log.info("Student Profile List : " + studentProfileList.size());

			if (registeredStudentList.size() > 0 && registeredStudentList.size() < 2)
			{
				dataMap = new HashMap<String, Object>();
				dataMap.put(ApplicationConstant.STUDENT_PROFILE_LIST, studentProfileList);

				return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));
			}
			else
				return MessageUtility.createErrorMessage("Kinldy check login credentials !!!");
			
		} else {
			return MessageUtility.createErrorMessage("Kinldy check login credentials !!!");
		}

	}

	public String submitDeviceDetails(HashMap<String, String> studentNotificationDetailMap) {
		log.info("Inside StudentHelperService/submitDeviceDetails()");

		StudentNotificationBean studentNotificationBean = null;
		boolean isUserExist = false;
		String response = null;
		HashMap<String, Object> dataMap = null;

		if (null != studentNotificationDetailMap) {
			studentNotificationBean = new StudentNotificationBean();
			studentNotificationBean.setImeiNo(studentNotificationDetailMap.get(ApplicationConstant.IMEI_NO));
			studentNotificationBean.setDeviceId(studentNotificationDetailMap.get(ApplicationConstant.DEVICE_ID));
			studentNotificationBean
					.setEnrollmentId(studentNotificationDetailMap.get(ApplicationConstant.FLASH_USER_ID));
			studentNotificationBean.setBranchId(studentNotificationDetailMap.get(ApplicationConstant.BRANCH_ID));
			studentNotificationBean.setClassName(studentNotificationDetailMap.get(ApplicationConstant.CLASS_NAME));
			studentNotificationBean
					.setNotificationId(studentNotificationDetailMap.get(ApplicationConstant.NOTIFICATION_ID));
			studentNotificationBean.setCreatedBy(ApplicationConstant.SYSTEM_CREATED_BY);
			studentNotificationBean.setCreateDt(DateUtility.getTimeStamp());
			studentNotificationBean.setDeleteFlag(ApplicationConstant.DEL_FLAG);
		}

		isUserExist = studentCoreHelperDao.isUserExist(studentNotificationBean);

		if (!isUserExist) {
			response = studentCoreHelperDao.submitUser(studentNotificationBean);

			if (response.equals(ApplicationConstant.TRUE)) {
				dataMap = new HashMap<String, Object>();

				return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));
			}
		} else {
			studentNotificationBean.setModifiedBy(ApplicationConstant.SYSTEM_MODIFIED_BY);
			studentNotificationBean.setModifyDt(DateUtility.getTimeStamp());

			response = studentCoreHelperDao.updateUser(studentNotificationBean);

			if (response.equals(ApplicationConstant.TRUE)) {
				dataMap = new HashMap<String, Object>();

				return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));
			}
		}
		return MessageUtility.createErrorMessage("Process failed due to technical issue!!! Kindly try after sometime");

	}

	public String syncStudentHomeworkData(HashMap<String, String> studentNotificationDetailMap) {

		log.info("Inside StudentHelperService/syncStudentHomeworkData()");

		StudentHomeworkMaster studentHomeworkMaster = null;
		HashMap<String, Object> dataMap = null;
		List<StudentHomeworkMaster> homeworkList = null;

		log.info("studentNotificationDetailMap : " + studentNotificationDetailMap);

		if (null != studentNotificationDetailMap
				&& null != studentNotificationDetailMap.get(ApplicationConstant.HOMEWORK_ID)
				&& !studentNotificationDetailMap.get(ApplicationConstant.HOMEWORK_ID)
						.equals(ApplicationConstant.EMPTY_STRING)) {
			studentHomeworkMaster = new StudentHomeworkMaster();
			studentHomeworkMaster.setHomeworkId(studentNotificationDetailMap.get(ApplicationConstant.HOMEWORK_ID));
			studentHomeworkMaster.setDeleteFlag(ApplicationConstant.DEL_FLAG);

			homeworkList = studentCoreHelperDao.syncHomeworkById(studentHomeworkMaster);

			dataMap = new HashMap<String, Object>();
			dataMap.put(ApplicationConstant.HOMEWORK_LIST, homeworkList);
			return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));

		} else if (null != studentNotificationDetailMap) {
			studentHomeworkMaster = new StudentHomeworkMaster();
			studentHomeworkMaster.setBranchId(studentNotificationDetailMap.get(ApplicationConstant.BRANCH_ID));
			studentHomeworkMaster.setClassName(studentNotificationDetailMap.get(ApplicationConstant.CLASS_NAME));
			studentHomeworkMaster.setDeleteFlag(ApplicationConstant.DEL_FLAG);

			homeworkList = studentCoreHelperDao.syncHomeworkList(studentHomeworkMaster,
					studentNotificationDetailMap.get(ApplicationConstant.LAST_SYNC_DATE));

			if (null != homeworkList) {
				

				dataMap = new HashMap<String, Object>();
				dataMap.put(ApplicationConstant.HOMEWORK_LIST, homeworkList);
				dataMap.put(ApplicationConstant.LAST_SYNC_DATE, DateUtility.getTimeStamp());
				return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));

			}
		}

		else {
			return MessageUtility
					.createErrorMessage("Some issues while fetching event data for you, Kindly try after some time!!!");
		}

		return MessageUtility
				.createErrorMessage("Some issues while fetching event data for you, Kindly try after some time!!!");

	}

	public String syncStudentTTkData(HashMap<String, String> studentNotificationDetailMap) {
		// TODO Auto-generated method stub
		return null;
	}

}
