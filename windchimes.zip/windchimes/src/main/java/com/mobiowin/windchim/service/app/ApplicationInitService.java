package com.mobiowin.windchim.service.app;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.windchim.commons.ApplicationConstant;
import com.mobiowin.windchim.messaging.IMessageService;
import com.mobiowin.windchim.service.helper.IAppSyncHelperServie;


@Service("appInitInitService")
@Component
public class ApplicationInitService implements IMessageService{

	private Log log = LogFactory.getLog(this.getClass());
	
	@Autowired
	private IAppSyncHelperServie appSyncService;
	
	public Message<String> execute(Message<String> message) 
	{
		log.info("Inside ApplicationInitService/execute()");
		
		String jsonData = message.getPayload();

		Map<String, Object> messageHeaders = message.getHeaders();

		JSONObject reqDataJson = null;
		JSONObject dataJson = null;
		
		String latitude = null;
		String lastSyncdate = null;
		String longitude = null;
		String response = null;

		try {
			reqDataJson = new JSONObject(jsonData);
			dataJson = reqDataJson.getJSONObject(ApplicationConstant.DATA);

			if (dataJson.has(ApplicationConstant.USER_LATITUDE)) {
				longitude = dataJson.getString(ApplicationConstant.USER_LATITUDE);
			}

			if (dataJson.has(ApplicationConstant.USER_LONGITUDE)) {
				longitude = dataJson.getString(ApplicationConstant.USER_LONGITUDE);
			}

			if (dataJson.has(ApplicationConstant.LAST_SYNC_DATE)) {
				lastSyncdate = dataJson.getString(ApplicationConstant.LAST_SYNC_DATE);
			}
			
			

			if (log.isInfoEnabled()) {
				log.info("Data is : " + dataJson);
				log.info("Message Headers : " + messageHeaders);
				log.info("LAST_SYNC_DATE is : " + lastSyncdate);
				log.info("USER_LATITUDE : " + latitude);
				log.info("USER_LONGITUDE : " + longitude);
			}

			HashMap<String, String> reqDataMap = getReqDataMap(lastSyncdate,latitude,longitude);

			log.info("reqDataMap :" + reqDataMap);

			response = appSyncService.appConfigSync(reqDataMap);

			return MessageBuilder.withPayload(response).build();

		} catch (Exception ex) {
			log.error("Exception in IndLoginService/execute() " + ex.getMessage(), ex.getCause());

		}
		return null;
		
	}

	private HashMap<String, String> getReqDataMap(String lastSyncDate, String latitude, String longitude) {
		
		HashMap<String, String> reqDataMap = new HashMap<String, String>();

		reqDataMap.put(ApplicationConstant.USER_LATITUDE, latitude);
		reqDataMap.put(ApplicationConstant.USER_LONGITUDE, longitude);
		reqDataMap.put(ApplicationConstant.LAST_SYNC_DATE, lastSyncDate);

		return reqDataMap;
	}

}
