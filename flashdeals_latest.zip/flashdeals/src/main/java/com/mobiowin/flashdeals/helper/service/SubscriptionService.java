package com.mobiowin.flashdeals.helper.service;

import java.util.HashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.flashdeals.bean.MerchantProfileBean;
import com.mobiowin.flashdeals.commons.ApplicationConstant;
import com.mobiowin.flashdeals.commons.FlashUtility;
import com.mobiowin.flashdeals.dao.IProfileSyncDao;

@Service("subscriptionService")
@Component
public class SubscriptionService implements ISubscriptionService
{
	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private IProfileSyncDao profileSyncDao;
	
	public String submitsubscriptionModel(HashMap<String, Object> requestDataMap) 
	{
		log.info("Inside SubscriptionService/submitsubscriptionModel()");
		
		MerchantProfileBean merchantSubscriptionBean = new MerchantProfileBean();
		merchantSubscriptionBean.setMerchantId(String.valueOf(requestDataMap.get(ApplicationConstant.MERCHANT_ID)));
		merchantSubscriptionBean.setSubscriptionModel(String.valueOf(requestDataMap.get(ApplicationConstant.SUBSCRIPTION_MODEL)));
		
		String updateStatus = profileSyncDao.updateSubscriptionModel(merchantSubscriptionBean);
		
		if(updateStatus.equals(ApplicationConstant.SUCCESS))
		{
			return FlashUtility.createSuccessMessage("Subcription updated successfully");
		}
		else
		{
			return FlashUtility.createErrorMessage("Subscription not updated succesfully, kindly try after some time");
		}
		
	}

	public String validateMerchantSubscription(HashMap<String, String> reqDataMap) 
	{
		log.info("Inside validateMerchantSubscription()");
		
		MerchantProfileBean merchantProfileBean = new MerchantProfileBean();
		merchantProfileBean.setMerchantId(reqDataMap.get(ApplicationConstant.MERCHANT_ID));
		
		List<MerchantProfileBean> merchantProfileList = profileSyncDao.getMerchantProfile(merchantProfileBean);
		
		return null;
	}

}
