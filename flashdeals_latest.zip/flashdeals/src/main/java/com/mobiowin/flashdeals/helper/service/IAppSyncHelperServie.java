package com.mobiowin.flashdeals.helper.service;

import java.util.HashMap;

public interface IAppSyncHelperServie {

	String syncApplciationData();

	boolean checkAppversion(HashMap<String, String> appReqDataMap);

	String generateSuccessResponse();

	String generateErrorResponse();

}
