package com.mobiowin.flashdeals.dao;

import java.util.HashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.mobiowin.flashdeals.bean.MerchantProfileBean;
import com.mobiowin.flashdeals.commons.ApplicationConstant;

@Repository("profileSyncDao")
@Component
public class ProfileSyncDao implements IProfileSyncDao
{
	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private SessionFactory sessionFactory;
	
	Session session = null;
	Transaction transaction = null;
	
	@SuppressWarnings("rawtypes")
	public List<MerchantProfileBean> fetchMerchantProfile(
			MerchantProfileBean merchantProfileBean) {
		
		log.info("Inside ProfileSyncDao/fetchMerchantProfile()");
		
		StringBuilder fetchMerchantProfileQueryBuilder = new StringBuilder();
		fetchMerchantProfileQueryBuilder.append("from MerchantProfileBean ");
		
		StringBuilder fetchMechantProfileQuery = fetchMerchantProfileQuery(fetchMerchantProfileQueryBuilder);
		
		log.info("fetchMechantProfileQuery is : " + fetchMechantProfileQuery.toString());
		
		Query query = sessionFactory.openSession().createQuery(fetchMechantProfileQuery.toString());
		query.setParameter("merchantId", merchantProfileBean.getMerchantId());
		query.setParameter("deleteFlag", merchantProfileBean.getDeleteFlag());
		
		List<MerchantProfileBean> regMerchantList = query.list();
		
		log.info("Register merchant list is : " + regMerchantList);
		
		return regMerchantList;
	}

	
	private StringBuilder fetchMerchantProfileQuery(StringBuilder fetchMerchantProfileQueryBuilder) 
	{
		fetchMerchantProfileQueryBuilder.append("where merchantId = :merchantId and deleteFlag =:deleteFlag");
		return fetchMerchantProfileQueryBuilder;
	}


	public String updateMerchantProfile(MerchantProfileBean merchantProfileBean) 
	{
		log.info("Inside ProfileSyncDao/updateMerchantProfile()");
		
		StringBuilder profileUpdateQueryBuilder = null;
		try 
		{
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			
			profileUpdateQueryBuilder = new StringBuilder();
			profileUpdateQueryBuilder.append("update MerchantProfileBean ");
			profileUpdateQueryBuilder = fetchProfileUpdateBuilder(profileUpdateQueryBuilder);
			
			log.info("MerchantProfileBean is : " + merchantProfileBean);
			log.info("Merchant profile update query is : " + profileUpdateQueryBuilder.toString());
			
			Query query=session.createQuery(profileUpdateQueryBuilder.toString());
			query.setParameter("firstName", merchantProfileBean.getFirstName());
			query.setParameter("lastName", merchantProfileBean.getLastName());
			query.setParameter("brandName", merchantProfileBean.getBrandName());
			query.setParameter("brandCategory", merchantProfileBean.getBrandCategory());
			query.setParameter("dpImage", merchantProfileBean.getDpImage());
			query.setParameter("merchantId", merchantProfileBean.getMerchantId());
			
			int merchantProfileUpdateStatus = query.executeUpdate();
			
			log.info("Merchant Profile Update Status : " + merchantProfileUpdateStatus);
			
			session.flush();
			transaction.commit();
			
			return ApplicationConstant.SUCCESS;
		}
		catch (Exception e) 
		{
			log.error("Exception in updating merchant profile : " + e.getMessage(),e.getCause());
			e.printStackTrace();
			return ApplicationConstant.FAILURE;
			
		}
	}
	
	

	
	private StringBuilder fetchProfileUpdateBuilder(StringBuilder profileUpdateQueryBuilder) 
	{
		
		
		profileUpdateQueryBuilder.append("set firstName = :firstName,");
		profileUpdateQueryBuilder.append(" lastName = :lastName,");
		profileUpdateQueryBuilder.append(" brandName = :brandName,");
		profileUpdateQueryBuilder.append(" brandCategory = :brandCategory,");
		profileUpdateQueryBuilder.append(" dpImage = :dpImage");
		profileUpdateQueryBuilder.append(" where merchantId = :merchantId");
		
		
		return profileUpdateQueryBuilder;
	}


	public String fetchMerchantId(HashMap<String, String> merchantDataMap)
	{
		/*
		 * 
		 * */
		return null;
	}

	
	@SuppressWarnings("rawtypes")
	public List<MerchantProfileBean> fetchMerchantProfile(String merchantId) 
	{
		log.info("Inside ProfileSyncDao/fetchMerchantProfile()");
		
		StringBuilder fetchMerchantProfileQueryBuilder = new StringBuilder();
		fetchMerchantProfileQueryBuilder.append("from MerchantProfileBean ");
		
		StringBuilder fetchMechantProfileQuery = fetchMerchantProfileQuery(fetchMerchantProfileQueryBuilder);
		
		log.info("fetchMechantProfileQuery is : " + fetchMechantProfileQuery.toString());
		
		Query query = sessionFactory.openSession().createQuery(fetchMechantProfileQuery.toString());
		query.setParameter("merchantId", merchantId);
		query.setParameter("deleteFlag", ApplicationConstant.DEL_FLAG);
		
		List<MerchantProfileBean> merchantProfileList = query.list();
		
		log.info("merchantProfileList : " + merchantProfileList);
		
		return merchantProfileList;
	}


	public String createMerchantProfile(MerchantProfileBean merchantProfileBean) 
	{
		log.info("Inside ProfilesyncDao / createMerchantProfile()");
		
		try 
		{
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			session.save(merchantProfileBean);
			session.flush();
			transaction.commit();

			return ApplicationConstant.SUCCESS;
		}
		catch (HibernateException e) 
		{
			transaction.rollback();
			e.printStackTrace();
			log.error("Exception in registerMerchant : " + e.getMessage(), e.getCause());
			return ApplicationConstant.FAILURE;
		}
		catch (Exception ex) 
		{
			transaction.rollback();
			ex.printStackTrace();
			log.error("Exception in registerMerchant : " + ex.getMessage(), ex.getCause());
			return ApplicationConstant.FAILURE;
		}
	}


	public String updateSubscriptionModel(MerchantProfileBean merchantSubscriptionBean) 
	{
		StringBuilder subscriptionUpdateQueryBuilder = null;
		
		try
		{
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			
			subscriptionUpdateQueryBuilder = new StringBuilder();
			subscriptionUpdateQueryBuilder.append("update MerchantProfileBean ");
			subscriptionUpdateQueryBuilder = fetchsubscriptionUpdateBuilder(subscriptionUpdateQueryBuilder);
			
			log.info("subscriptionUpdateQueryBuilder query is : " + subscriptionUpdateQueryBuilder.toString());
			
			Query query=session.createQuery(subscriptionUpdateQueryBuilder.toString());
			query.setParameter("subscriptionModel", merchantSubscriptionBean.getSubscriptionModel());
			query.setParameter("merchantId", merchantSubscriptionBean.getMerchantId());
			
			int merchantProfileUpdateStatus = query.executeUpdate();
			
			log.info("Merchant Profile Update Status : " + merchantProfileUpdateStatus);
			
			session.flush();
			transaction.commit();
			
			return ApplicationConstant.SUCCESS;
		}
		catch(Exception ex)
		{
			log.error("Exception in updating merchant profile : " + ex.getMessage(),ex.getCause());
			ex.printStackTrace();
			return ApplicationConstant.FAILURE;
		}
		
	}


	private StringBuilder fetchsubscriptionUpdateBuilder(StringBuilder subscriptionUpdateQueryBuilder) 
	{
		subscriptionUpdateQueryBuilder.append(" set subscriptionModel = :subscriptionModel");
		subscriptionUpdateQueryBuilder.append(" where merchantId = :merchantId");
		
		
		return subscriptionUpdateQueryBuilder;
		
	}


	public List<MerchantProfileBean> getMerchantProfile(MerchantProfileBean merchantProfileBean) {
		log.info("Inside getMerchantProfile()");
		
		StringBuilder fetchMerchantProfileQueryBuilder = new StringBuilder();
		fetchMerchantProfileQueryBuilder.append("from MerchantProfileBean ");
		
		StringBuilder fetchMechantProfileQuery = fetchMerchantProfileQuery(fetchMerchantProfileQueryBuilder);
		
		log.info("fetchMechantProfileQuery is : " + fetchMechantProfileQuery.toString());
		
		Query query = sessionFactory.openSession().createQuery(fetchMechantProfileQuery.toString());
		query.setParameter("merchantId", merchantProfileBean.getMerchantId());
		query.setParameter("deleteFlag", ApplicationConstant.DEL_FLAG);
		
		List<MerchantProfileBean> merchantList = query.list();
		
		log.info("merchant profile list is : " + merchantList);
		
		return merchantList;
		
	}

}
