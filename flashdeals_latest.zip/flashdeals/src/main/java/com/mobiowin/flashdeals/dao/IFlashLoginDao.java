package com.mobiowin.flashdeals.dao;

import java.util.List;

import com.mobiowin.flashdeals.bean.MerchantLoginBean;
import com.mobiowin.flashdeals.bean.MerchantRegistrationBean;

public interface IFlashLoginDao {

	String validateLogin(MerchantRegistrationBean merchantRegistrationBean);

	String validateMerchant(MerchantLoginBean merchantLoginBean);

	List<MerchantLoginBean> getMerchantData(MerchantLoginBean merchantLoginBean);

}
