package com.mobiowin.flashdeals.helper.service;

import java.util.HashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.flashdeals.commons.ApplicationConstant;
import com.mobiowin.flashdeals.commons.FlashUtility;
import com.mobiowin.flashdeals.dao.IOtpValidatiorDao;

@Service("otpValidateService")
@Component
public class OtpValidatiorHelperService implements IOtpValidatiorService
{
	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private IOtpValidatiorDao otpValidateDao;
	
	
	public String validateCustomerOtp(HashMap<String, String> dataMap) 
	{
		log.info("Inside OtpValidatiorService/validateCustomerOtp()");
		
		String isValidate = otpValidateDao.validateOtp(dataMap);
		
		if(isValidate.equals(ApplicationConstant.SUCCESS))
		{
			return FlashUtility.createSuccessMessage();
		}
		else
		{
			return FlashUtility.createErrorMessage("Send Again");
		}
		
	}

}
