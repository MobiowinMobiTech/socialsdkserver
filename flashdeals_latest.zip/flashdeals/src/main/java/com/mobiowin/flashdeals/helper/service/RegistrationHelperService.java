package com.mobiowin.flashdeals.helper.service;

import java.util.HashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.flashdeals.bean.CustomerRegistrationBean;
import com.mobiowin.flashdeals.bean.MerchantRegistrationBean;
import com.mobiowin.flashdeals.commons.ApplicationConstant;
import com.mobiowin.flashdeals.commons.FlashIdGeneratorUtility;
import com.mobiowin.flashdeals.commons.FlashOtpUtil;
import com.mobiowin.flashdeals.commons.FlashUtility;
import com.mobiowin.flashdeals.dao.IRegistrationDao;

@Service("registrationHelperService")
@Component
public class RegistrationHelperService implements IRegistrationHelperService{

	private Log log = LogFactory.getLog(this.getClass());
	
	@Autowired
	private IRegistrationDao registrationDao;
	
	@Autowired
	private SendOtpOnMailService sendOtpOnMailService;
	
	boolean isOtpSend = true;
	
	
	
	public String registerCustomer(HashMap<String, String> dataMap) 
	{
		log.info("Inside RegistrationHelperService/registerCustomer()");
		
		log.info("Data Map is : " + dataMap);
		
		CustomerRegistrationBean registrationBean = new CustomerRegistrationBean();
		
		registrationBean.setMobileNo(dataMap.get(ApplicationConstant.MOBILE_NO));
		registrationBean.setImeiNo(dataMap.get(ApplicationConstant.IMEI_NO));
		
		String registerCustomer = registrationDao.registerCustomer(registrationBean);
		
		if(registerCustomer.equals(ApplicationConstant.TRUE))
		{
			String customerOtp = FlashOtpUtil.generateOtp();
			
			registrationBean.setOtp(customerOtp);
			
			//boolean isOtpSend = sendOtpOnMailService.sendOtpOnMailService(registrationBean);
			
			isOtpSend = true;
			
			if(isOtpSend)
			{
				return FlashUtility.createSuccessMessage();
			}
			else
			{
				return FlashUtility.createErrorMessage();
			}
		}
		
		return FlashUtility.createErrorMessage();
	}

	
	public String registerMerchant(HashMap<String, String> merchantDataMap)
	{
		log.info("Inside RegistrationHelperService/registerMerchant");
		
		String customerOtp = null;
		
		MerchantRegistrationBean merchantRegistrationBean = new MerchantRegistrationBean();
		merchantRegistrationBean.setMobileNo(merchantDataMap.get(ApplicationConstant.MOBILE_NO));
		merchantRegistrationBean.setEmailId(merchantDataMap.get(ApplicationConstant.EMAIL_ID));
		merchantRegistrationBean.setImeiNo(merchantDataMap.get(ApplicationConstant.IMEI_NO));
		merchantRegistrationBean.setPassword(merchantDataMap.get(ApplicationConstant.FLASH_PASSWORD));
		merchantRegistrationBean.setCreatedBy(ApplicationConstant.SYSTEM_CREATED_BY);
		merchantRegistrationBean.setModifiedBy(ApplicationConstant.SYSTEM_MODIFIED_BY);
		merchantRegistrationBean.setDeleteFlag(ApplicationConstant.DEL_FLAG);
		
		customerOtp = FlashOtpUtil.generateOtp();
		
		merchantRegistrationBean.setOtp(customerOtp);
		
		String merchantId = FlashIdGeneratorUtility.generateMerchantId(merchantDataMap);
		
		merchantRegistrationBean.setMerchantId(merchantId);
		
		String registerMerchant = registrationDao.registerMerchant(merchantRegistrationBean);
		
		if(registerMerchant.equals(ApplicationConstant.TRUE))
		{
			//String customerOtp = FlashOtpUtil.generateOtp();
			
			merchantRegistrationBean.setOtp(customerOtp);
			
			//boolean isOtpSend = sendOtpOnMailService.sendOtpOnMailService(registrationBean);
			
			isOtpSend = true;

			HashMap<String,Object> dataMap = new HashMap<String,Object>();
			//List<HashMap<String,Object>> dataMapList = new ArrayList<HashMap<String,Object>>();
			
			if(isOtpSend)
			{
				dataMap.put(ApplicationConstant.MERCHANT_ID, merchantId);
				dataMap.put(ApplicationConstant.FLASH_CUST_OTP, customerOtp);
				return FlashUtility.createJSONFromMap(FlashUtility.createSuccessResponseMessage(dataMap));
			}
			else
			{
				return FlashUtility.createErrorMessage();
			}
		}
		
		return FlashUtility.createErrorMessage();
		
		
	}

	
	public boolean isExistingMerchant(HashMap<String, String> merchantDataMap) 
	{
		log.info("Inside RegistrationHelperService/isExistingMerchant");
		
		MerchantRegistrationBean merchantRegistrationBean = new MerchantRegistrationBean();
		merchantRegistrationBean.setMobileNo(merchantDataMap.get(ApplicationConstant.MOBILE_NO));
		merchantRegistrationBean.setEmailId(merchantDataMap.get(ApplicationConstant.EMAIL_ID));
		
		String registerMerchant = registrationDao.isExistingMerchantDao(merchantRegistrationBean);
		
		if(registerMerchant.equals(ApplicationConstant.TRUE))
		{
			return true;
		}
		
		return false;
	}

	
	public String existingMerchantRes()
	{
		log.info("Inside RegistrationHelperService/isExistingMerchant");
		
		return FlashUtility.createErrorMessage("MailId/MobileNo already registered. Kindly Login");
	}


	public String fetchMerchantId(HashMap<String, String> merchantDataMap) 
	{
		log.info("RegistrationHelperService/isExistingMerchant()");
		
		MerchantRegistrationBean merchantRegistrationBean = new MerchantRegistrationBean();
		merchantRegistrationBean.setMobileNo(merchantDataMap.get(ApplicationConstant.FLASH_USER_ID));
		
		String merchantId = registrationDao.fetchMerchantById(merchantRegistrationBean);
		
		return merchantId;
	}

}
