package com.mobiowin.flashdeals.fcm;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.mobiowin.flashdeals.commons.ApplicationConstant;

@Service("fcmIntegrationService")
@Component
public class FCMIntegrationService implements IFCMIntegrationService 
{
	private Log log = LogFactory.getLog(this.getClass());
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private @Resource
	Map<String, String> notificationUATConfig;

	//String FMCurl = "https://fcm.googleapis.com/fcm/send";    
	
	String fcmServerAuthKey = null;
	String fcmNotificationUrl = null;
	HttpEntity<String> entity  = null;
	String notificationJsonData = null;
	String resposne = null;

	public void sendFcmNotificationMessage() 
	{
		
		fcmServerAuthKey  = String.valueOf(notificationUATConfig.get(ApplicationConstant.FCM_SERVER_AUTH_KEY));
		fcmNotificationUrl = String.valueOf(notificationUATConfig.get(ApplicationConstant.FCM_NOTIFICATION_URL));
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("Authorization","key="+fcmServerAuthKey);
		
		notificationJsonData = getNotificationMessageData();
		
		entity = new HttpEntity<String>(notificationJsonData,headers);
		
		
		resposne = restTemplate.postForObject(fcmNotificationUrl, entity, String.class);
		JSONObject responseJson = new JSONObject(resposne);
		
		log.info("Resposne is : " + responseJson);
		
	}

	private String getNotificationMessageData()
	{
		log.info("inside  getNotificationMessageData()");
		String userID = "f0cVoU42pQ4:APA91bFV39MGPeRxoVcyaBsnIyor4mDL6ZfCHrXxs9R_tnoB3HxRSP8RuoBcqb6vSqUdGEoLKeat5M4LkXfot5a2zrKkxOznChSUnSPui9QymQTTbje7WMfnzUeRfhf6dkVtGzh-Bzmt";
		JSONObject json = new JSONObject();
		json.put("to",userID.trim());
		JSONObject info = new JSONObject();
		info.put("title", "UOTM Test");   // Notification title
		info.put("body", "Testing 123"); // Notification body
		json.put("notification", info);
		
		return json.toString();
	}
	
	

}
