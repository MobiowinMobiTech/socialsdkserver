package com.mobiowin.flashdeals.dao;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.mobiowin.flashdeals.bean.NotificationIdBean;
import com.mobiowin.flashdeals.commons.ApplicationConstant;

@Repository("flashMiscDao")
@Component
public class FlashMiscDao implements IFlashMiscDao 
{
	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private SessionFactory sessionFactory;
	
	Session session = null;
	Transaction transaction = null;
	
	public boolean isNotificationIdExiting(NotificationIdBean notificationIdBean) 
	{
		log.info("FlashMiscDao/isNotificationIdExiting()");
		
		StringBuilder notificationIdCheckQueryBuilder = new StringBuilder();
		notificationIdCheckQueryBuilder.append("from NotificationIdBean ");

		StringBuilder mechantStoreCheckQueryBuilder = getNotificationIdChkQuery(notificationIdCheckQueryBuilder);

		log.info("Mechant Store Check Query is : " + mechantStoreCheckQueryBuilder.toString());
		
		Query query = sessionFactory.openSession().createQuery(mechantStoreCheckQueryBuilder.toString());
		query.setParameter("userId", notificationIdBean.getUserId());
		query.setParameter("deleteFlag", notificationIdBean.getDeleteFlag());
		query.setParameter("entity", notificationIdBean.getEntity());

		List<NotificationIdBean> notificationIdList = query.list();

		log.info("Notification id list for user : " + notificationIdList);

		if (notificationIdList.size() > 0) 
		{
			return true;
		}

		return false;
		
	}

	private StringBuilder getNotificationIdChkQuery(StringBuilder notificationIdCheckQueryBuilder) {
		notificationIdCheckQueryBuilder.append("where userId = :userId ");
		notificationIdCheckQueryBuilder.append("and deleteFlag = :deleteFlag ");
		notificationIdCheckQueryBuilder.append("and entity = :entity ");
		return notificationIdCheckQueryBuilder;
	}

	public String updateNotificationId(NotificationIdBean notificationIdBean) 
	{
		log.info("FlashMiscDao/updateNotificationId()");
		
		StringBuilder notificationIdUpdateQueryBuilder = null;
		
		try 
		{
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			
			notificationIdUpdateQueryBuilder = new StringBuilder();
			notificationIdUpdateQueryBuilder.append("update NotificationIdBean ");
			notificationIdUpdateQueryBuilder = fetchNotificationIdUpdateBuilder(notificationIdUpdateQueryBuilder);
			
			log.info("Notification bean is : " + notificationIdBean);
			log.info("Notification  id update query is : " + notificationIdUpdateQueryBuilder.toString());
			
			Query query=session.createQuery(notificationIdUpdateQueryBuilder.toString());
			query.setParameter("notificationId", notificationIdBean.getNotificationId());
			query.setParameter("userId", notificationIdBean.getUserId());
			query.setParameter("deleteFlag", notificationIdBean.getDeleteFlag());
			query.setParameter("entity", notificationIdBean.getEntity());
			
			int notificationUpdateStatus = query.executeUpdate();
			
			log.info("Notification id Update Status : " + notificationUpdateStatus);
			
			session.flush();
			transaction.commit();
			
			return ApplicationConstant.SUCCESS;
		}
		catch (Exception e) 
		{
			log.error("Exception in updating merchant profile : " + e.getMessage(),e.getCause());
			e.printStackTrace();
			
			if(null != session)
			{
				session.flush();
				transaction.rollback();
			}
			return ApplicationConstant.FAILURE;
			
		}
		
	}

	private StringBuilder fetchNotificationIdUpdateBuilder(StringBuilder notificationIdUpdateQueryBuilder) 
	{
		notificationIdUpdateQueryBuilder.append(" set notificationId = :notificationId");
		notificationIdUpdateQueryBuilder.append(" where userId = :userId");
		notificationIdUpdateQueryBuilder.append(" and deleteFlag = :deleteFlag");
		notificationIdUpdateQueryBuilder.append(" and entity = :entity");
		
		return notificationIdUpdateQueryBuilder;
	}

	public String insertNotificationId(NotificationIdBean notificationIdBean) 
	{
		log.info("FlashMiscDao/insertNotificationId()");
		
		try 
		{
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			session.save(notificationIdBean);
			session.flush();
			transaction.commit();

			return ApplicationConstant.SUCCESS;
		}
		catch (HibernateException e) 
		{
			session.flush();
			transaction.rollback();
			e.printStackTrace();
			log.error("Exception in insertNotificationId : " + e.getMessage(), e.getCause());
			return ApplicationConstant.FAILURE;
		}
		catch (Exception ex) 
		{
			session.flush();
			transaction.rollback();
			ex.printStackTrace();
			log.error("Exception in insertNotificationId : " + ex.getMessage(), ex.getCause());
			return ApplicationConstant.FAILURE;
		}
		
		
	}
	
	

}
