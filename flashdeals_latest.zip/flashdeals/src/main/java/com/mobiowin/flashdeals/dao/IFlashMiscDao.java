package com.mobiowin.flashdeals.dao;

import com.mobiowin.flashdeals.bean.NotificationIdBean;

public interface IFlashMiscDao {

	boolean isNotificationIdExiting(NotificationIdBean notificationIdBean);

	String updateNotificationId(NotificationIdBean notificationIdBean);

	String insertNotificationId(NotificationIdBean notificationIdBean);

}
