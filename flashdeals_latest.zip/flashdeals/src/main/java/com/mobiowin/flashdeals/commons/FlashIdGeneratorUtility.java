package com.mobiowin.flashdeals.commons;

import java.util.HashMap;

public class FlashIdGeneratorUtility
{
	public static String generateMerchantId(HashMap<String, String> merchantDataMap) 
	{
		
		String mobileNo = merchantDataMap.get(ApplicationConstant.MOBILE_NO);
		mobileNo = mobileNo.substring(5, 10);
		StringBuilder merchantIdBuilder = new StringBuilder();
		merchantIdBuilder.append("Flash");
		merchantIdBuilder.append(mobileNo);
		return merchantIdBuilder.toString();
	}

	public static String generateMerchantDealId(HashMap<String, Object> dealDataMap) 
	{
		StringBuilder dealIdbuilder = new StringBuilder();
		dealIdbuilder.append(String.valueOf(dealDataMap.get(ApplicationConstant.MERCHANT_ID)));
		dealIdbuilder.append("_");
		dealIdbuilder.append(String.valueOf(dealDataMap.get(ApplicationConstant.MERCHANT_DEAL_STORE_ID)));
		dealIdbuilder.append("_");
		dealIdbuilder.append(getSystemNanoTime());
		return dealIdbuilder.toString();
	}

	public static String generateMerchantStoreId(HashMap<String, Object> requestDataMap) 
	{
		StringBuilder storeIdbuilder = new StringBuilder();
		storeIdbuilder.append(String.valueOf(requestDataMap.get(ApplicationConstant.MERCHANT_ID)));
		storeIdbuilder.append("_");
		storeIdbuilder.append(getSystemNanoTime());
		return storeIdbuilder.toString();
	}

	private static String getSystemNanoTime()
	{
		String nanoTime = String.valueOf(System.nanoTime());
		nanoTime = nanoTime.substring(nanoTime.length()-4, nanoTime.length());
		return nanoTime;
	}


}
