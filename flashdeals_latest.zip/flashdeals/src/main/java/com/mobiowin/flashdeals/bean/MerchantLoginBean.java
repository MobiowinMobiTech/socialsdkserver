package com.mobiowin.flashdeals.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "merchant_login", catalog = "flashdeals")
public class MerchantLoginBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "merchant_id")
	private String userID;

	@Column(name = "password")
	private String password;

	@Column(name = "otp")
	private String otp;

	public MerchantLoginBean(int id, String userID, String password, String otp) {
		super();
		this.id = id;
		this.userID = userID;
		this.password = password;
		this.otp = otp;
	}

	public MerchantLoginBean() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getOtp() {
		return otp;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

	@Override
	public String toString() {
		return "MerchantLoginBean [id=" + id + ", userID=" + userID + ", password=" + password + ", otp=" + otp + "]";
	}

}
