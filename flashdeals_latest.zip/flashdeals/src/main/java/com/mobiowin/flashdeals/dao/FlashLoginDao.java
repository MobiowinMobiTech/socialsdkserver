package com.mobiowin.flashdeals.dao;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.mobiowin.flashdeals.bean.MerchantLoginBean;
import com.mobiowin.flashdeals.bean.MerchantRegistrationBean;
import com.mobiowin.flashdeals.commons.ApplicationConstant;

@Repository("flashLoginDao")
@Component
public class FlashLoginDao implements IFlashLoginDao {

	private Log log = LogFactory.getLog(this.getClass());
	
	@Autowired
	private SessionFactory sessionFactory;

	public String validateLogin(MerchantRegistrationBean merchantRegistrationBean) {
		
		log.info("Inside FlashLoginDao/validateLogin()");

		log.info("merchantRegistrationBean : " + merchantRegistrationBean);
		
		
		String merchantLoginQuery  = "from MerchantRegistrationBean where mobileNo = :mobileNo or emailId = :mobileNo and password =:password";

		
		Query query  = sessionFactory.openSession().createQuery(merchantLoginQuery);
		query.setParameter("mobileNo", merchantRegistrationBean.getMobileNo());
		query.setParameter("password", merchantRegistrationBean.getPassword());
		
		List<MerchantRegistrationBean> merchantLoginList = query.list();
		
		log.info("merchantLoginList : " + merchantLoginList);
		
		if(merchantLoginList.size() < 1)
		{
			return ApplicationConstant.FALSE;
		}
		
		return ApplicationConstant.TRUE;
	}

	public String validateMerchant(MerchantLoginBean merchantLoginBean) {
		/*
		 * Validate merchant userId
		 * 
		 * select count(1) from flash_merchant_master where mobileno = userID or
		 * emailId = userId
		 * 
		 */

		if (merchantLoginBean.getUserID().equals("7709642004") || merchantLoginBean.getUserID().equals("a@g.com")) {
			return ApplicationConstant.TRUE;
		}

		return null;
	}

	public List<MerchantLoginBean> getMerchantData(MerchantLoginBean merchantLoginBean) {
		log.info("Inside FlashLoginDao/validateLogin()");

		/*
		 * Validate merchant userId
		 * 
		 * select mobileno from flash_merchant_master where mobileno = userID or
		 * emailId = userId and password = passowrd
		 * 
		 */
		return null;
	}

}
