package com.mobiowin.flashdeals.geo;

import java.util.HashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.flashdeals.commons.ApplicationConstant;

@Service("flashGeoFencingService")
@Component
public class FlashGeoFencingService 
{
	private Log log = LogFactory.getLog(this.getClass());
	
	public boolean isInRadius(float lat1, float lng1, float lat2,
			float lng2, int radius)
	{
		log.info("Inside FlashGeoFencingService/distFrom()...");

		// Earth Radius in meters
		double earthRadius = 6371000;
		double dLat = Math.toRadians(lat2 - lat1);
		double dLng = Math.toRadians(lng2 - lng1);
		double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
				+ Math.cos(Math.toRadians(lat1))
				* Math.cos(Math.toRadians(lat2)) * Math.sin(dLng / 2)
				* Math.sin(dLng / 2);
		double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
		float dist = (float) (earthRadius * c);

		log.info("Distance from company center is : " + dist/1000);
		//0.9308092

		if (dist > radius)
		{
			System.out.println("Not in radius");
			return false;
		} 
		else
		{
			System.out.println("In radius");
			return true;
		}

	}
	
	/*public boolean checkEmployeePresence(
			HashMap<String, String> officeLocatationDataMap,
			HashMap<String, String> dataValidatorMap)
	{
		log.info("Inside LBASDistanceCalcService/distFrom()...");

		boolean isPresent = distFrom(
				Float.parseFloat(officeLocatationDataMap.get(ApplicationConstant.COMP_LATITUDE)),
				Float.parseFloat(officeLocatationDataMap.get(ApplicationConstant.COMP_LONGITUDE)),
				Float.parseFloat(dataValidatorMap.get(ApplicationConstant.EMP_LATITUDE)),
				Float.parseFloat(dataValidatorMap.get(ApplicationConstant.EMP_LONGITUDE)),
				Integer.parseInt(officeLocatationDataMap
						.get(ApplicationConstant.COMP_ROXIMITY_RADIUS)));
		
		

		log.info("isPresent : " + isPresent);
		
		return true;
	}*/
	
	public static void main(String[] args)
	{

		FlashGeoFencingService geoFencing = new FlashGeoFencingService();
		
		geoFencing.isInRadius((float) -33.867625,
				(float) 151.210274, (float) -33.868625, (float) 151.220274, 1000);
	}

}
