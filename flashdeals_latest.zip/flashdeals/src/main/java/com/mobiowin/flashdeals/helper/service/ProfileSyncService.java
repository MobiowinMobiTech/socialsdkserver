package com.mobiowin.flashdeals.helper.service;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.imageio.ImageIO;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.flashdeals.bean.MerchantProfileBean;
import com.mobiowin.flashdeals.commons.ApplicationConstant;
import com.mobiowin.flashdeals.commons.FlashUtility;
import com.mobiowin.flashdeals.dao.IProfileSyncDao;
import com.sun.org.apache.xerces.internal.impl.dv.util.Base64;

@Service("profileSyncService")
@Component
public class ProfileSyncService implements IProfileSyncService
{
	private Log log = LogFactory.getLog(this.getClass());
	
	@Autowired
	private IProfileSyncDao profileSyncDao;
	
	@Autowired
	private FlashImageUrlService flashImageService;
	
	@Autowired
	private @Resource
	Map<String, List<String>> merchantImageConfig;
	
	@Autowired
	private @Resource
	Map<String, List<String>> flashImageConfig;

	
	public String updateMerchantProfile(HashMap<String, String> merchantProfileDataMap) 
	{
		log.info("ProfileSyncService/updateMerchantProfile()");
		
		String profileImgPath = null;
		String updateStatus = null;
		
		MerchantProfileBean merchantProfileBean = new MerchantProfileBean();
		merchantProfileBean.setMobileNo(merchantProfileDataMap.get(ApplicationConstant.MOBILE_NO));
		merchantProfileBean.setMerchantId(merchantProfileDataMap.get(ApplicationConstant.MERCHANT_ID));
		merchantProfileBean.setBrandCategory(merchantProfileDataMap.get(ApplicationConstant.BRAND_CATEGORY));
		merchantProfileBean.setBrandName(merchantProfileDataMap.get(ApplicationConstant.BRAND_NAME));
		merchantProfileBean.setFirstName(merchantProfileDataMap.get(ApplicationConstant.FIRST_NAME));
		merchantProfileBean.setLastName(merchantProfileDataMap.get(ApplicationConstant.LAST_NAME));
		merchantProfileBean.setMerchantType(merchantProfileDataMap.get(ApplicationConstant.MERCHANT_TYPE));
		merchantProfileBean.setCity(merchantProfileDataMap.get(ApplicationConstant.CITY));
		merchantProfileBean.setState(merchantProfileDataMap.get(ApplicationConstant.STATE));
		merchantProfileBean.setCountry(merchantProfileDataMap.get(ApplicationConstant.COUNTRY));
		merchantProfileBean.setPinCode(merchantProfileDataMap.get(ApplicationConstant.PINCODE));
		merchantProfileBean.setSubscriptionModel(ApplicationConstant.BASIC_MODEL);
		merchantProfileBean.setDeleteFlag(ApplicationConstant.DEL_FLAG);
		
		
		
		log.info("Display Image is : " + merchantProfileDataMap.get(ApplicationConstant.DISPLAY_IMAGE));
		
		if(merchantProfileDataMap.get(ApplicationConstant.DISPLAY_IMAGE) != null && !merchantProfileDataMap.get(ApplicationConstant.DISPLAY_IMAGE).equalsIgnoreCase(ApplicationConstant.EMPTY_STRING))
		{
			profileImgPath = saveMerhantProfileImage(merchantProfileDataMap);
		}
		
		merchantProfileBean.setDpImage(profileImgPath);
		
		List<MerchantProfileBean> merchantProfileList = profileSyncDao.fetchMerchantProfile(merchantProfileBean);
		
		if(null != merchantProfileList && merchantProfileList.size() > 0)
		{
			MerchantProfileBean updateMerchantProfileBean = merchantProfileList.get(0);
			updateMerchantProfileBean.setBrandCategory(merchantProfileDataMap.get(ApplicationConstant.BRAND_CATEGORY));
			updateMerchantProfileBean.setBrandName(merchantProfileDataMap.get(ApplicationConstant.BRAND_NAME));
			updateMerchantProfileBean.setFirstName(merchantProfileDataMap.get(ApplicationConstant.FIRST_NAME));
			updateMerchantProfileBean.setLastName(merchantProfileDataMap.get(ApplicationConstant.LAST_NAME));
			updateMerchantProfileBean.setMerchantType(merchantProfileDataMap.get(ApplicationConstant.MERCHANT_TYPE));
			updateMerchantProfileBean.setMerchantId(merchantProfileDataMap.get(ApplicationConstant.MERCHANT_ID));
			/*merchantProfileList.get(0).setCity(merchantProfileDataMap.get(ApplicationConstant.CITY));
			merchantProfileList.get(0).setState(merchantProfileDataMap.get(ApplicationConstant.STATE));
			merchantProfileList.get(0).setCountry(merchantProfileDataMap.get(ApplicationConstant.COUNTRY));
			merchantProfileList.get(0).setPinCode(merchantProfileDataMap.get(ApplicationConstant.PINCODE));*/
			updateMerchantProfileBean.setDpImage(profileImgPath);
			
			updateStatus = profileSyncDao.updateMerchantProfile(updateMerchantProfileBean); 
		}
		else
		{
			updateStatus = profileSyncDao.createMerchantProfile(merchantProfileBean);
		}
		
		/*Map<String,String> imageUrlMap = flashImageService.getImageUrl(merchantProfileDataMap.get(ApplicationConstant.MERCHANT_ID));
		String promoCodeImageUrl = imageUrlMap.get("BusinessUrl");
		String geeniUrl = imageUrlMap.get("GeeniUrl");
		
		log.info("promoCodeImageUrl : " +promoCodeImageUrl);
		log.info("geeniUrl : " + geeniUrl);*/
			
		//updateStatus = profileSyncDao.updateMerchantProfile(merchantProfileList.get(0));
		
		log.info("Update status is :" + updateStatus);
		
		if(updateStatus.equalsIgnoreCase(ApplicationConstant.SUCCESS))
		{
			return FlashUtility.createSuccessMessage("Profile uploaded successfully");
		}
		
		return FlashUtility.createErrorMessage();
	}

	private String saveMerhantProfileImage(HashMap<String, String> merchantProfileDataMap) 
	{
		log.info("Inside ProfileSyncService/saveMerhantProfileImage()");
		
		List<String> imaBasePathList = (List<String>) flashImageConfig.get("IMG_PATH_DIR");
		String destDirName = imaBasePathList.get(1).trim(); 
		String dpImgPath = null;
		String merchantProfileImgUrl = null;
		
		try
		{
			byte[] bytearray = Base64.decode(merchantProfileDataMap.get(ApplicationConstant.DISPLAY_IMAGE));
			BufferedImage imag=ImageIO.read(new ByteArrayInputStream(bytearray));
			String merchantDealImgName = getImageName(merchantProfileDataMap.get(ApplicationConstant.MERCHANT_ID));
			ImageIO.write(imag, "jpg", new File(destDirName,merchantDealImgName));
			dpImgPath = destDirName+merchantDealImgName; 
			log.info("DealImgPath is : " + dpImgPath);
			
			Map<String,String> imageUrlMap = flashImageService.getMerchantProfileImgUrl(merchantDealImgName);
			merchantProfileImgUrl = imageUrlMap.get("MerchantProfileImgLink");
			
			log.info("store image url : " +merchantProfileImgUrl);
			
			return merchantProfileImgUrl;
		} 
		catch (IOException e) 
		{
			log.error("Exception in saving deal image : " + e.getMessage());
			e.printStackTrace();
		}
		
		return merchantProfileImgUrl;
	}

	private String getImageName(String merchantId)
	{
		
		log.info("Inside ProfileSyncService/getImageName()");
		
		StringBuilder dpImgNameBuilder = new StringBuilder();
		dpImgNameBuilder.append(merchantId);
		dpImgNameBuilder.append(".jpg");
		return dpImgNameBuilder.toString();
	}

	
	public String fetchMerchantId(HashMap<String, String> merchantDataMap) 
	{
		log.info("Inside ProfileSyncService/fetchMerchantId()");
		
		String merchantId = profileSyncDao.fetchMerchantId(merchantDataMap);
		
		return merchantId;
	}

	
	public List<MerchantProfileBean> fetchMerchantProfileData(String merchantId) 
	{
		log.info("Inside ProfileSyncService/fetchMerchantProfileData()");
		
		List<MerchantProfileBean> merchantProfileList = profileSyncDao.fetchMerchantProfile(merchantId);
		
		return merchantProfileList;
	}

}
