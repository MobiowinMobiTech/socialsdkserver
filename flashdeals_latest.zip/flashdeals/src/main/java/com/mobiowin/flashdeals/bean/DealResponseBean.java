package com.mobiowin.flashdeals.bean;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "deal_response_master", catalog = "flashdeals")
public class DealResponseBean implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@Column(name = "deal_code")
	private String dealCode;
	
	@Column(name = "deal_category")
	private String dealCategory;
	
	@Column(name = "deal_title")
	private String dealTitle;
	
	@Column(name = "deal_discription")
	private String dealDiscription;
	
	@Column(name = "merchant_name")
	private String merchatName;
	
	@Column(name = "store_location")
	private String storeLocation;
	
	@Column(name = "merchant_discription")
	private String merchantDiscription;
	
	@Column(name = "merchant_city")
	private String merchantCity;
	
	@Column(name = "merchant_state")
	private String merchantState;
	
	@Column(name = "merchant_country")
	private String merchantCountry;
	
	@Column(name = "merchant_pincode")
	private String merchantPin;
	
	@Column(name = "deal_expiry")
	private String dealExpiry;
	
	@Column(name = "deal_radius")
	private String dealStatus;
	
	@Column(name = "deal_img")
	private String dealImg;
	
	@Column(name = "deal_img_list")
	private List<String> dealImgList;
	
	
	
	
	public DealResponseBean(int id, String dealCode, String dealCategory, String dealTitle, String dealDiscription,
			String merchatName, String storeLocation, String merchantDiscription, String merchantCity,
			String merchantState, String merchantCountry, String merchantPin, String dealExpiry, String dealStatus,
			String dealImg, List<String> dealImgList) {
		super();
		this.id = id;
		this.dealCode = dealCode;
		this.dealCategory = dealCategory;
		this.dealTitle = dealTitle;
		this.dealDiscription = dealDiscription;
		this.merchatName = merchatName;
		this.storeLocation = storeLocation;
		this.merchantDiscription = merchantDiscription;
		this.merchantCity = merchantCity;
		this.merchantState = merchantState;
		this.merchantCountry = merchantCountry;
		this.merchantPin = merchantPin;
		this.dealExpiry = dealExpiry;
		this.dealStatus = dealStatus;
		this.dealImg = dealImg;
		this.dealImgList = dealImgList;
	}
	
	
	public DealResponseBean() {
		super();
	}


	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDealCode() {
		return dealCode;
	}
	public void setDealCode(String dealCode) {
		this.dealCode = dealCode;
	}
	public String getDealCategory() {
		return dealCategory;
	}
	public void setDealCategory(String dealCategory) {
		this.dealCategory = dealCategory;
	}
	public String getDealTitle() {
		return dealTitle;
	}
	public void setDealTitle(String dealTitle) {
		this.dealTitle = dealTitle;
	}
	public String getDealDiscription() {
		return dealDiscription;
	}
	public void setDealDiscription(String dealDiscription) {
		this.dealDiscription = dealDiscription;
	}
	public String getMerchatName() {
		return merchatName;
	}
	public void setMerchatName(String merchatName) {
		this.merchatName = merchatName;
	}
	
	public String getMerchantDiscription() {
		return merchantDiscription;
	}
	public void setMerchantDiscription(String merchantDiscription) {
		this.merchantDiscription = merchantDiscription;
	}
	public String getMerchantCity() {
		return merchantCity;
	}
	public void setMerchantCity(String merchantCity) {
		this.merchantCity = merchantCity;
	}
	public String getMerchantState() {
		return merchantState;
	}
	public void setMerchantState(String merchantState) {
		this.merchantState = merchantState;
	}
	public String getMerchantCountry() {
		return merchantCountry;
	}
	public void setMerchantCountry(String merchantCountry) {
		this.merchantCountry = merchantCountry;
	}
	public String getMerchantPin() {
		return merchantPin;
	}
	public void setMerchantPin(String merchantPin) {
		this.merchantPin = merchantPin;
	}
	public String getDealExpiry() {
		return dealExpiry;
	}
	public void setDealExpiry(String dealExpiry) {
		this.dealExpiry = dealExpiry;
	}
	public String getDealStatus() {
		return dealStatus;
	}
	public void setDealStatus(String dealStatus) {
		this.dealStatus = dealStatus;
	}
	public String getDealImg() {
		return dealImg;
	}
	public void setDealImg(String dealImg) {
		this.dealImg = dealImg;
	}
	public String getStoreLocation() {
		return storeLocation;
	}
	public void setStoreLocation(String storeLocation) {
		this.storeLocation = storeLocation;
	}
	@Override
	public String toString() {
		return "DealResponseBean [id=" + id + ", dealCode=" + dealCode
				+ ", dealCategory=" + dealCategory + ", dealTitle=" + dealTitle
				+ ", dealDiscription=" + dealDiscription + ", merchatName="
				+ merchatName + ", storeLocation=" + storeLocation
				+ ", merchantDiscription=" + merchantDiscription
				+ ", merchantCity=" + merchantCity + ", merchantState="
				+ merchantState + ", merchantCountry=" + merchantCountry
				+ ", merchantPin=" + merchantPin + ", dealExpiry=" + dealExpiry
				+ ", dealStatus=" + dealStatus + ", dealImg=" + dealImg + "]";
	}
	
	
	
	
	
	
	
	
	
}
