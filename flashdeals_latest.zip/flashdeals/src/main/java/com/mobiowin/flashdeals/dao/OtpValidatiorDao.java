package com.mobiowin.flashdeals.dao;

import java.util.HashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.mobiowin.flashdeals.commons.ApplicationConstant;


@Repository("otpValidateDao")
@Component
public class OtpValidatiorDao implements IOtpValidatiorDao
{

	private Log log = LogFactory.getLog(this.getClass());
	
	
	public String validateOtp(HashMap<String, String> dataMap) 
	{
		log.info("inside OtpValidatiorDao/validateOtp()");
		
		/*
		 * select otp from customerOtpMaster where datamap.get(cust_otp) = 
		 * Select max(cust_otp) from customerOtpMaster where imei_no = dataMap.get(Imeino)
		 * 
		 * */
		if(dataMap.get(ApplicationConstant.FLASH_CUST_OTP).equals("11111"))
		{
			return "success";
		}
		else
		{
			return "failure";
		}
		
	}
	

}
