/*package com.cmss.lbas.geo.util;

import java.util.HashMap;

import org.apache.log4j.Logger;

import com.cmss.lbas.commons.ApplicationConstant;

public class LBASDistanceCalcService
{

	private static Logger log = Logger.getLogger(LBASDistanceCalcService.class);

	
	 * Algorthim to check location with in a certain radius.
	 
	
	public static boolean distFrom(float lat1, float lng1, float lat2,
			float lng2, int radius)
	{
		log.info("Inside LBASDistanceCalcService/distFrom()...");

		// Earth Radius in meters
		double earthRadius = 6371000;
		double dLat = Math.toRadians(lat2 - lat1);
		double dLng = Math.toRadians(lng2 - lng1);
		double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
				+ Math.cos(Math.toRadians(lat1))
				* Math.cos(Math.toRadians(lat2)) * Math.sin(dLng / 2)
				* Math.sin(dLng / 2);
		double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
		float dist = (float) (earthRadius * c);

		log.info("Distance from company center is : " + dist);

		if (dist > radius)
		{
			return false;
		} else
		{
			return true;
		}

	}

	
	 * For Tesing lat / long -33.868625,151.210274
	 

	public static void main(String[] args)
	{

		LBASDistanceCalcService.distFrom((float) -33.868625,
				(float) 151.210274, (float) -33.869725, (float) 151.220274, 10);
	}

	public static boolean checkEmployeePresence(
			HashMap<String, String> officeLocatationDataMap,
			HashMap<String, String> dataValidatorMap)
	{
		log.info("Inside LBASDistanceCalcService/distFrom()...");

		boolean isPresent = distFrom(
				Float.parseFloat(officeLocatationDataMap.get(ApplicationConstant.COMP_LATITUDE)),
				Float.parseFloat(officeLocatationDataMap.get(ApplicationConstant.COMP_LONGITUDE)),
				Float.parseFloat(dataValidatorMap.get(ApplicationConstant.EMP_LATITUDE)),
				Float.parseFloat(dataValidatorMap.get(ApplicationConstant.EMP_LONGITUDE)),
				Integer.parseInt(officeLocatationDataMap
						.get(ApplicationConstant.COMP_ROXIMITY_RADIUS)));
		
		

		log.info("isPresent : " + isPresent);
		
		return true;
	}
}
*/