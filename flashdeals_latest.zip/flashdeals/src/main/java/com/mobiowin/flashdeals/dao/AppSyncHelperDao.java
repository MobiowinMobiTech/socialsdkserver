package com.mobiowin.flashdeals.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.mobiowin.flashdeals.bean.CategoryBean;
import com.mobiowin.flashdeals.bean.SliderDealBean;

@Repository("appSyncDao")
@Component
public class AppSyncHelperDao implements IAppSyncHelperDao{

	private Log log = LogFactory.getLog(this.getClass());
	
	
	
	public List<SliderDealBean> fetchSliderImageData() 
	{
		log.info("Inside AppSyncHelperDao/fetchSliderImageData()");
		
		/*
		 * select * from slider_deal_master
		 * where app_name = 'flash' and del_flag = 'Y'
		 * */
		
		SliderDealBean sliderDealBean = new SliderDealBean();
		sliderDealBean.setId(1);
		sliderDealBean.setDealCode("Flash2004");
		sliderDealBean.setDealDiscription("Flash Sale");
		sliderDealBean.setDealImagePath("http://localhost:8080/FlashDeals/FlashImageServlet?entity=slider&img=Flash42004");
		sliderDealBean.setDel_flag("F");
		

		SliderDealBean sliderDealBean1 = new SliderDealBean();
		sliderDealBean1.setId(2);
		sliderDealBean1.setDealCode("Flash2005");
		sliderDealBean1.setDealDiscription("Flash Sale");
		sliderDealBean1.setDealImagePath("http://localhost:8080/FlashDeals/FlashImageServlet?entity=slider&img=Flash42004");
		sliderDealBean1.setDel_flag("F");
		
		ArrayList<SliderDealBean> sliderDealList = new ArrayList<SliderDealBean>();
		sliderDealList.add(sliderDealBean);
		sliderDealList.add(sliderDealBean1);
		
		return sliderDealList;
	}

	
	public List<CategoryBean> fetchCategoryData()
	{
		log.info("Inside AppSyncHelperDao/fetchCategoryData()");
		
		/*
		 * select * from category_master
		 * where app_name = 'flash' and del_flag = 'Y'
		 * */
		
		CategoryBean categoryBean = new CategoryBean();
		categoryBean.setId(1);
		categoryBean.setCategoryCode("Food");
		categoryBean.setCategoryDiscription("Flash Sale");
		categoryBean.setCategoryImgPath("http://localhost:8080/FlashDeals/FlashImageServlet?entity=category&img=Flash42004");
		categoryBean.setDeleteFlag("F");
		

		CategoryBean categoryBean1 = new CategoryBean();
		categoryBean1.setId(2);
		categoryBean1.setCategoryCode("Fashion");
		categoryBean1.setCategoryDiscription("Dummy Sale");
		categoryBean1.setCategoryImgPath("http://localhost:8080/FlashDeals/FlashImageServlet?entity=category&img=Flash42004");
		categoryBean1.setDeleteFlag("F");
		
		CategoryBean categoryBean2 = new CategoryBean();
		categoryBean2.setId(3);
		categoryBean2.setCategoryCode("Electronic");
		categoryBean2.setCategoryDiscription("Electronic And Appliance");
		categoryBean2.setCategoryImgPath("http://localhost:8080/FlashDeals/FlashImageServlet?entity=category&img=Flash42004");
		categoryBean2.setDeleteFlag("F");
		
		CategoryBean categoryBean3 = new CategoryBean();
		categoryBean3.setId(4);
		categoryBean3.setCategoryCode("Health");
		categoryBean3.setCategoryDiscription("Health & Fitness");
		categoryBean3.setCategoryImgPath("http://localhost:8080/FlashDeals/FlashImageServlet?entity=category&img=Flash42004");
		categoryBean3.setDeleteFlag("F");
		
		ArrayList<CategoryBean> categoryDataList = new ArrayList<CategoryBean>();
		categoryDataList.add(categoryBean);
		categoryDataList.add(categoryBean1);
		categoryDataList.add(categoryBean2);
		categoryDataList.add(categoryBean3);
		
		return categoryDataList;
	}

	
	public boolean validateAppVersion(HashMap<String, String> appReqDataMap) 
	{
		log.info("Inside AppSyncHelperDao/validateAppVersion()");
		
		/*
		 * select count(1) from 
		 * */
		
		return false;
	}

}
