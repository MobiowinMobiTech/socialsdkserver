package com.mobiowin.flashdeals.merchant.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.flashdeals.commons.ApplicationConstant;
import com.mobiowin.flashdeals.helper.service.IDealSyncHelperService;
import com.mobiowin.flashdeals.messaging.IFlashService;

@Service("merchantDealService")
@Component
public class MerchantDealService implements IFlashService {

	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private IDealSyncHelperService dealSyncHelperService;

	public Message<String> execute(Message<String> message) {
		log.info("Inside MerchantDealService/execute");

		String jsonData = message.getPayload();

		Map<String, Object> messageHeaders = message.getHeaders();

		JSONObject merchantDealJson = null;
		JSONObject merchantDealDataJson = null;
		JSONArray merchantDealImgArray = null;

		String imeiNo = null;
		String merchantId = null;
		String dealName = null;
		String dealCategory = null;
		String dealDiscription = null;
		String dealImage = null;
		String dealStartTime = null;
		String dealEndTime = null;
		String dealRadius = null;
		String dealStoreId = null;
		String dealId = null;
		String latitude = null;
		String longitude = null;
		String storeName = null;
		String isExclusive = null;
		
		

		try {
			merchantDealJson = new JSONObject(jsonData);
			merchantDealDataJson = merchantDealJson
					.getJSONObject(ApplicationConstant.DATA);

			if (merchantDealDataJson.has(ApplicationConstant.MERCHANT_ID)) {
				merchantId = String.valueOf(merchantDealDataJson
						.getString(ApplicationConstant.MERCHANT_ID));
			}

			if (merchantDealDataJson.has(ApplicationConstant.IMEI_NO)) {
				imeiNo = merchantDealDataJson
						.getString(ApplicationConstant.IMEI_NO);
			}

			if (merchantDealDataJson
					.has(ApplicationConstant.MERCHANT_DEAL_NAME)) {
				dealName = merchantDealDataJson
						.getString(ApplicationConstant.MERCHANT_DEAL_NAME);
			}

			if (merchantDealDataJson
					.has(ApplicationConstant.MERCHANT_DEAL_CATEGORY)) {
				dealCategory = merchantDealDataJson
						.getString(ApplicationConstant.MERCHANT_DEAL_CATEGORY);
			}

			if (merchantDealDataJson
					.has(ApplicationConstant.MERCHANT_DEAL_DISCRIPTION)) {
				dealDiscription = merchantDealDataJson
						.getString(ApplicationConstant.MERCHANT_DEAL_DISCRIPTION);
			}

			if (merchantDealDataJson
					.has(ApplicationConstant.MERCHANT_DEAL_IMAGE)
					&& (merchantDealDataJson
							.getString(ApplicationConstant.MERCHANT_DEAL_IMAGE) != null || merchantDealDataJson
							.getString(ApplicationConstant.MERCHANT_DEAL_IMAGE)
							.equals(ApplicationConstant.EMPTY_STRING)))
			{
				dealImage = merchantDealDataJson
						.getString(ApplicationConstant.MERCHANT_DEAL_IMAGE);
			}

			if (merchantDealDataJson
					.has(ApplicationConstant.MERCHANT_DEAL_START_TIME)) {
				dealStartTime = merchantDealDataJson
						.getString(ApplicationConstant.MERCHANT_DEAL_START_TIME);
			}

			if (merchantDealDataJson
					.has(ApplicationConstant.MERCHANT_DEAL_END_TIME)) {
				dealEndTime = merchantDealDataJson
						.getString(ApplicationConstant.MERCHANT_DEAL_END_TIME);
			}

			if (merchantDealDataJson
					.has(ApplicationConstant.MERCHANT_DEAL_RADIUS)) {
				dealRadius = String.valueOf(merchantDealDataJson
						.getString(ApplicationConstant.MERCHANT_DEAL_RADIUS));
			}

			if (merchantDealDataJson
					.has(ApplicationConstant.MERCHANT_DEAL_STORE_ID)) {
				dealStoreId = String.valueOf(merchantDealDataJson
						.getString(ApplicationConstant.MERCHANT_DEAL_STORE_ID));
			}
			
			if (merchantDealDataJson
					.has(ApplicationConstant.MERCHANT_DEAL_STORE_ID)) {
				dealStoreId = String.valueOf(merchantDealDataJson
						.getString(ApplicationConstant.MERCHANT_DEAL_STORE_ID));
			}
			
			if (merchantDealDataJson.has(ApplicationConstant.USER_LATITUDE))
		    {
				latitude = merchantDealDataJson
						.getString(ApplicationConstant.USER_LATITUDE);
			}
			
			if (merchantDealDataJson.has(ApplicationConstant.USER_LONGITUDE))
		    {
				longitude = merchantDealDataJson
						.getString(ApplicationConstant.USER_LONGITUDE);
			}
			
			
			if (merchantDealDataJson.has(ApplicationConstant.STORE_NAME))
		    {
				storeName = merchantDealDataJson
						.getString(ApplicationConstant.STORE_NAME);
			}
			
			if (merchantDealDataJson.has(ApplicationConstant.DEAL_ID))
		    {
				dealId = merchantDealDataJson
						.getString(ApplicationConstant.DEAL_ID);
			}
			
			if (merchantDealDataJson.has(ApplicationConstant.IS_EXCLUSIVE))
		    {
				isExclusive = merchantDealDataJson
						.getString(ApplicationConstant.IS_EXCLUSIVE);
			}

			if (log.isInfoEnabled()) {
				log.info("Message headers : " + messageHeaders);
				log.info("Deal Name : " + dealName);
				log.info("Deal diacription : " + dealDiscription);
				log.info("Deal Category : " + dealCategory);
				log.info("Merchant id is : " + merchantId);
				log.info("Merchant imei no : " + imeiNo);
				log.info("Deal Start time : " + dealStartTime);
				log.info("Deal End Time : " + dealEndTime);
				//log.info("Deal Image is : " + dealImage);
				log.info("Store id is : " + dealStoreId);
				log.info("Deal Radisu is :" + dealRadius);
				log.info("Store latitude is :" + latitude);
				log.info("Store longitude is :" + longitude);
				log.info("Store name is :" + storeName);
				log.info("Deal id is :" + dealId);
				log.info("Is Exclusive:" + isExclusive);
				
			}

			HashMap<String, Object> dealDataMap = getDealDataMap(imeiNo,
					merchantId, dealName, dealDiscription, dealCategory,
					dealImage, dealStartTime, dealEndTime, dealRadius,
					dealStoreId,latitude,longitude,storeName,dealId,isExclusive);

			String response = dealSyncHelperService.submitMerchantDeal(dealDataMap);

			return MessageBuilder.withPayload(response).build();

		} 
		catch (Exception ex) 
		{
			log.error("Exception in MerchantDealService/execute()" + ex.getMessage());
		}

		return null;
	}

	private HashMap<String, Object> getDealDataMap(String imeiNo,
			String merchantId, String dealName, String dealDiscription,
			String dealCategory, String dealImage, String dealStartTime,
			String dealEndTime, String dealRadius, String dealStoreId, String latitude, String longitude, String storeName, String dealId, String isExclusive) {
		HashMap<String, Object> dealDataMap = new HashMap<String, Object>();
		dealDataMap.put(ApplicationConstant.IMEI_NO, imeiNo);
		dealDataMap.put(ApplicationConstant.MERCHANT_ID, merchantId);
		dealDataMap.put(ApplicationConstant.MERCHANT_DEAL_NAME, dealName);
		dealDataMap.put(ApplicationConstant.MERCHANT_DEAL_CATEGORY,
				dealCategory);
		dealDataMap.put(ApplicationConstant.MERCHANT_DEAL_DISCRIPTION,
				dealDiscription);
		dealDataMap.put(ApplicationConstant.MERCHANT_DEAL_IMAGE, dealImage);
		dealDataMap.put(ApplicationConstant.MERCHANT_DEAL_START_TIME,
				dealStartTime);
		dealDataMap
				.put(ApplicationConstant.MERCHANT_DEAL_END_TIME, dealEndTime);
		dealDataMap.put(ApplicationConstant.MERCHANT_DEAL_RADIUS, dealRadius);
		dealDataMap
				.put(ApplicationConstant.MERCHANT_DEAL_STORE_ID, dealStoreId);
		dealDataMap.put(ApplicationConstant.USER_LATITUDE, latitude);
		dealDataMap.put(ApplicationConstant.USER_LONGITUDE, longitude);
		dealDataMap.put(ApplicationConstant.STORE_NAME, storeName);
		dealDataMap.put(ApplicationConstant.DEAL_ID, dealId);
		dealDataMap.put(ApplicationConstant.IS_EXCLUSIVE, isExclusive);

		return dealDataMap;
	}

}
