package com.mobiowin.flashdeals.customer.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.flashdeals.commons.ApplicationConstant;
import com.mobiowin.flashdeals.helper.service.IDealSyncHelperService;
import com.mobiowin.flashdeals.messaging.IFlashService;

@Service("customerDealSyncService")
@Component
public class DealSyncService implements IFlashService
{
	private Log log = LogFactory.getLog(this.getClass());
	
	@Autowired
	private IDealSyncHelperService dealSyncHelperService;
	
	
	public Message<String> execute(Message<String> message) 
	{
		log.info("inside DealSyncService/execute()");
		
		String jsonData = message.getPayload();

		Map<String, Object> messageHeaders = message.getHeaders();

		JSONObject customerDataJson = null;
		JSONObject customerLocationDataJson = null;
		String latitude = null;
		String imeiNo = null;
		String longitude = null;
		String dealRadius = null;
		

		try {
			customerDataJson = new JSONObject(jsonData);
			customerLocationDataJson = customerDataJson.getJSONObject(ApplicationConstant.DATA);

			if (customerLocationDataJson.has(ApplicationConstant.USER_LATITUDE))
		    {
				latitude = customerLocationDataJson
						.getString(ApplicationConstant.USER_LATITUDE);
			}
			
			if (customerLocationDataJson.has(ApplicationConstant.USER_LONGITUDE))
		    {
				longitude = customerLocationDataJson
						.getString(ApplicationConstant.USER_LONGITUDE);
			}

			if (customerLocationDataJson.has(ApplicationConstant.IMEI_NO))
			{
				imeiNo = customerLocationDataJson
						.getString(ApplicationConstant.IMEI_NO);
			}
			
			if (customerLocationDataJson.has(ApplicationConstant.DEAL_RADIUS))
			{
				dealRadius = customerLocationDataJson
						.getString(ApplicationConstant.DEAL_RADIUS);
			}
			
			if(log.isInfoEnabled())
			{
				log.info("customerDataJson : " + customerDataJson);
				log.info("Message Headers : " + messageHeaders);
				log.info("Customer latitude is : " + latitude);
				log.info("Customer longitude is : " + longitude);
				log.info("Customer imei no is : " + imeiNo);
				log.info("Deal radius is : " + dealRadius);
			}
			
			HashMap<String,String> dataMap = getDataMap(latitude,longitude,imeiNo,dealRadius);
			
			String registerResponse = dealSyncHelperService.syncCustomerDealData(dataMap);
			
			return MessageBuilder.withPayload(registerResponse).build();

		} catch (Exception ex)
		{
			log.error("Exception in RegistrationService/execute() " + ex.getMessage(),ex.getCause());

		}

		return null;
	}
	
	private HashMap<String, String> getDataMap(String latitude, String longitude, String imeiNo, String dealRadius)
	{
		HashMap<String,String> dataMap = new HashMap<String, String>();
		dataMap.put(ApplicationConstant.USER_LATITUDE, latitude);
		dataMap.put(ApplicationConstant.USER_LONGITUDE, longitude);
		dataMap.put(ApplicationConstant.IMEI_NO, imeiNo);
		dataMap.put(ApplicationConstant.DEAL_RADIUS, dealRadius);
		return dataMap;
	}

}
