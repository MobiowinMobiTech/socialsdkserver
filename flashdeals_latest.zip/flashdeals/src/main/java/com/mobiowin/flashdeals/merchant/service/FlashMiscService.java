package com.mobiowin.flashdeals.merchant.service;

import java.util.Date;
import java.util.HashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.flashdeals.bean.NotificationIdBean;
import com.mobiowin.flashdeals.commons.ApplicationConstant;
import com.mobiowin.flashdeals.dao.IFlashMiscDao;

@Service("flashMiscService")
@Component
public class FlashMiscService implements IFlashMiscService
{
	private Log log = LogFactory.getLog(this.getClass());
	
	@Autowired
	private IFlashMiscDao flashMiscDao;

	public String submitNotificationDetails(HashMap<String, String> notificationDataMap) 
	{
		
		log.info("Inside FlashMiscService/submitNotificationDetails()");
		
		NotificationIdBean notificationIdBean = null;
		String resultStatus = null;
		
		if(null != notificationDataMap)
		{
			notificationIdBean = new NotificationIdBean();
			notificationIdBean.setUserId(notificationDataMap.get(ApplicationConstant.FLASH_USER_ID));
			notificationIdBean.setEntity(notificationDataMap.get(ApplicationConstant.ENTITY));
			notificationIdBean.setOsVersion(notificationDataMap.get(ApplicationConstant.OS_VERSION));
			notificationIdBean.setOsType(notificationDataMap.get(ApplicationConstant.OS_TYPE));
			notificationIdBean.setNotificationId(notificationDataMap.get(ApplicationConstant.NOTIFICATION_ID));
			notificationIdBean.setCreatedBy(notificationDataMap.get(ApplicationConstant.SYSTEM_CREATED_BY));
			notificationIdBean.setCreateDt(new Date());
			notificationIdBean.setModifiedBy(notificationDataMap.get(ApplicationConstant.SYSTEM_MODIFIED_BY));
			notificationIdBean.setModifyDt(new Date());
			notificationIdBean.setDeleteFlag(ApplicationConstant.DEL_FLAG);
		}
		
		boolean isExisting =  flashMiscDao.isNotificationIdExiting(notificationIdBean);
		
		if(isExisting)
		{
			resultStatus = flashMiscDao.updateNotificationId(notificationIdBean);
			
			log.info("Update notification result is : " + resultStatus);
		} 
		else
		{
			resultStatus = flashMiscDao.insertNotificationId(notificationIdBean);
			
			log.info("insert notification result is : " + resultStatus);
		}
		
		return null;
	}

}
