package com.mobiowin.flashdeals.dao;

import java.util.HashMap;
import java.util.List;

import com.mobiowin.flashdeals.bean.CategoryBean;
import com.mobiowin.flashdeals.bean.SliderDealBean;

public interface IAppSyncHelperDao {

	List<SliderDealBean> fetchSliderImageData();

	List<CategoryBean> fetchCategoryData();

	boolean validateAppVersion(HashMap<String, String> appReqDataMap);

}
