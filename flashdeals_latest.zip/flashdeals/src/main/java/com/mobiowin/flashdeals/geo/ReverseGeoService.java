package com.mobiowin.flashdeals.geo;

import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

@Service("reverseGeoService")
@Component
public class ReverseGeoService
{
	private Log log  = LogFactory.getLog(this.getClass());
	
	public String getUserLocallyDetails(String latitude,String longitude)
	{
		log.info("Inside ReverseGeoService/getAddress()......");
		log.info("Latitude longitude is : " + latitude+","+longitude);
		
		String address = null;
		String gURL = "http://maps.google.com/maps/api/geocode/xml?latlng=" + latitude +","+longitude + "&sensor=true";
		
		log.info("Fianl URL  is : " + gURL);
		
		try
		{
			DocumentBuilderFactory df = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = df.newDocumentBuilder();
			Document dom = db.parse(gURL);
			Element docEl = dom.getDocumentElement();
			NodeList nl = docEl.getElementsByTagName("result");
			
			if (nl != null && nl.getLength() > 0)
			{
				address = ((Element) nl.item(0))
						.getElementsByTagName("formatted_address").item(0)
						.getTextContent();
				log.info("Address : " + address);
				System.out.println("Address : " + address);
				/*for (int i = 0; i < nl.getLength(); i++)
				{
					String temp = ((Element) nl.item(i)).getElementsByTagName("formatted_address").item(0)
							.getTextContent();
					
					System.out.println("Temp is : " + temp);
				}*/
				
				getDetailedAddress(address);
			}
		} catch (Exception ex)
		{
			address = "Err";
		}
		
		log.info("Address is :" + address);
		return address;
	}

	private void getDetailedAddress(String address) 
	{
		String[] addressArray = address.split(",");
		
		System.out.println("addressArray : " + addressArray.length);
		
		 List<String> itemList = new ArrayList<String>();
		 
	      for (String item : addressArray) 
	      {
	         itemList.add(item);
	      }
	      
	      for(String str : itemList)
	      {
	    	  System.out.println(" <  > : " + str);
	      }
	      System.out.println(itemList.size());
		
		
				
				
		
		
		
	}

	/*public String getAddress(String lat, String lon)
	{
		return getUserLocallyDetails(lat + "," + lon);
	}

	public String getAddress(double lat, double lon)
	{
		return getAddress("" + lat, "" + lon);
	}*/
	
	public static void main(String[] args) 
	{
		ReverseGeoService geoService = new ReverseGeoService();
		geoService.getUserLocallyDetails("19.197840","72.827690");
		//geoService.getUserLocallyDetails("19.131331","72.12312321");
		
	}
	
	//19.197840,72.827690
	//D-11, Shri Sevantilal Khandwala Marg, Asmita Jyoti Housing Society, Malad West, Mumbai, Maharashtra 400095, India
	//Marot - Yazman - BWP Rd, Chak 277/H.R Sharqi, Pakistan
	//Sopariwala Sadan, Nani Chipwad, Gopipura, Surat, Gujarat 395003, India
	//Unnamed Road, Kareli, Gujarat 391810, India

}
	
	

