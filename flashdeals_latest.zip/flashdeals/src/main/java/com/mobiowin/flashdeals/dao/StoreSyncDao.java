package com.mobiowin.flashdeals.dao;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.mobiowin.flashdeals.bean.MerchantStoreBean;
import com.mobiowin.flashdeals.commons.ApplicationConstant;

@Repository("storeSyncDao")
@Component
public class StoreSyncDao implements IStoreSyncDao {

	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private SessionFactory sessionFactory;

	Session session = null;
	Transaction transaction = null;

	public boolean isStoreExist(MerchantStoreBean merchantStoreBean)
	{
		log.info("Inside StoreSyncDao/isStoreExist()");

		log.info("Merchant store bean is : " + merchantStoreBean);

		StringBuilder merchantStoreCheckQueryBuilder = new StringBuilder();
		merchantStoreCheckQueryBuilder.append("from MerchantStoreBean ");

		StringBuilder mechantStoreCheckQuery = getMerchantStoreChkQuery(merchantStoreCheckQueryBuilder);

		Query query = sessionFactory.openSession().createQuery(mechantStoreCheckQuery.toString());
		query.setParameter("storeId", merchantStoreBean.getStoreId());
		query.setParameter("merchantId", merchantStoreBean.getMerchantId());

		List<MerchantStoreBean> merchantStoreList = query.list();

		log.info("Merchant store list : " + merchantStoreList);

		if (merchantStoreList.size() > 0) 
		{
			return true;
		}

		return false;
	}

	private StringBuilder getMerchantStoreChkQuery(StringBuilder merchantStoreCheckQueryBuilder) 
	{
		merchantStoreCheckQueryBuilder.append("where storeId = :storeId and merchantId =:merchantId");
		return merchantStoreCheckQueryBuilder;
		
	}

	public String tagStoreLocation(MerchantStoreBean merchantStoreBean) 
	{
		log.info("Inside StoreSyncDao/tagStoreLocation()");

		try 
		{
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			session.save(merchantStoreBean);
			session.flush();
			transaction.commit();

			return ApplicationConstant.SUCCESS;
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
			log.error("Exception in registerMerchant : " + e.getMessage(), e.getCause());
			return ApplicationConstant.FAILURE;
		} catch (Exception ex) {
			transaction.rollback();
			ex.printStackTrace();
			log.error("Exception in registerMerchant : " + ex.getMessage(), ex.getCause());
			return ApplicationConstant.FAILURE;
		}

	}

	public List<MerchantStoreBean> fetchStoreDetails(MerchantStoreBean merchantStoreBean)
	{
		log.info("Inside StoreSyncDao/fetchStoreDetails()");

		List<MerchantStoreBean> merchantStoreList  = null;
		StringBuilder fetchMerchantProfileQueryBuilder = new StringBuilder();
		fetchMerchantProfileQueryBuilder.append("from MerchantStoreBean ");
		
		StringBuilder fetchMechantStoreQuery = fetchMerchantStoreQueryBuilder(fetchMerchantProfileQueryBuilder);
		
		log.info("fetchMechantProfileQuery is : " + fetchMechantStoreQuery.toString());
		
		try 
		{
			Query query = sessionFactory.openSession().createQuery(fetchMechantStoreQuery.toString());
			query.setParameter("merchantId", merchantStoreBean.getMerchantId());
			query.setParameter("deleteFlag", ApplicationConstant.DEL_FLAG);
			
			merchantStoreList = query.list();
			
			log.info("Merchant Store List is  : " + merchantStoreList.size());
			
			return merchantStoreList;
		}
		catch (HibernateException e) 
		{
			log.error("hibernate exception in store sync : " + e.getMessage(),e.getCause());
			e.printStackTrace();
			return merchantStoreList;
		}
		catch(Exception ex)
		{
			log.error("Exception in fetchStoreDetails() : " + ex.getMessage(),ex.getCause());
			ex.printStackTrace();
			return merchantStoreList;
		}
		
	}

	private StringBuilder fetchMerchantStoreQueryBuilder(StringBuilder fetchMerchantStoreQueryBuilder) 
	{
		fetchMerchantStoreQueryBuilder.append("where merchantId = :merchantId and deleteFlag =:deleteFlag");
		return fetchMerchantStoreQueryBuilder;
		
	}

	public String updateMerchantStoreDetails(MerchantStoreBean merchantStoreBean)
	{
		log.info("Inside StoreSyncDao/storeUpdateStatus()");

		StringBuilder storeUpdateQueryBuilder = null;
		try 
		{
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			
			storeUpdateQueryBuilder = new StringBuilder();
			storeUpdateQueryBuilder.append("update MerchantStoreBean ");
			storeUpdateQueryBuilder = fetchStoreUpdateBuilder(storeUpdateQueryBuilder);
			
			log.info("Merchant Store Bean is : " + merchantStoreBean);
			log.info("Merchant Store update query is : " + storeUpdateQueryBuilder.toString());
			
			Query query=session.createQuery(storeUpdateQueryBuilder.toString());
			query.setParameter("storeDiscription", merchantStoreBean.getStoreDiscription());
			query.setParameter("storeCategory", merchantStoreBean.getStoreCategory());
			query.setParameter("img_1", merchantStoreBean.getStoreImage1());
			query.setParameter("img_2", merchantStoreBean.getStoreImage2());
			query.setParameter("img_3", merchantStoreBean.getStoreImage3());
			query.setParameter("img_4", merchantStoreBean.getStoreImage4());
			query.setParameter("deleteFlag", merchantStoreBean.getDeleteFlag());
			query.setParameter("merchantId", merchantStoreBean.getMerchantId());
			query.setParameter("storeId", merchantStoreBean.getStoreId());
			
			int merchantStoreUpdateStatus = query.executeUpdate();
			
			log.info("Merchant store Update Status : " + merchantStoreUpdateStatus);
			
			session.flush();
			transaction.commit();
			
			return ApplicationConstant.SUCCESS;
		}
		catch (Exception e) 
		{
			log.error("Exception in updating merchant profile : " + e.getMessage(),e.getCause());
			e.printStackTrace();
			
			return ApplicationConstant.FAILURE;
			
		}
		
	}

	private StringBuilder fetchStoreUpdateBuilder(StringBuilder storeUpdateQueryBuilder) 
	{
		log.info("Inside fetchStoreUpdateBuilder()");
		
		storeUpdateQueryBuilder.append("set storeDiscription = :storeDiscription,");
		storeUpdateQueryBuilder.append(" storeCategory = :storeCategory,");
		storeUpdateQueryBuilder.append(" img_1 = :img_1,");
		storeUpdateQueryBuilder.append(" img_2 = :img_2,");
		storeUpdateQueryBuilder.append(" img_3 = :img_3,");
		storeUpdateQueryBuilder.append(" img_4 = :img_4,");
		storeUpdateQueryBuilder.append(" deleteFlag = :deleteFlag ");
		storeUpdateQueryBuilder.append(" where merchantId = :merchantId");
		storeUpdateQueryBuilder.append(" and storeId = :storeId");
		
		
		return storeUpdateQueryBuilder;
	}

}
