package com.mobiowin.flashdeals.messaging;

import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.flashdeals.commons.ApplicationConstant;

@Service("messageReceiver")
@Component
public class FlashMessageReceiver implements IFlashMessageReceiver {

	private Log log = LogFactory.getLog(getClass());

	public Message<String> recieve(Message<String> message) {

		log.info("Inside SimpleMessageReceiver / recieve().....");

		try {
			Map<String, Object> messageHeader = message.getHeaders();

			String messageData = message.getPayload();
			JSONObject messageObj = new JSONObject(messageData);
			String entity = (String) messageObj.get(ApplicationConstant.ENTITY);

			if (log.isInfoEnabled()) {
				log.info("Request Message header is ------------ > " + messageHeader);
				log.info("Request Message entity is ------------ > " + entity);
			}

			return MessageBuilder.withPayload(message.getPayload()).copyHeaders(message.getHeaders())
					.setHeader(ApplicationConstant.ENTITY, entity).build();

		} catch (JSONException e) {
			log.error("Exception in JSON Message building ..... " + e.getMessage(), e.getCause());
			e.printStackTrace();
			return null;
		} catch (Exception ex) {
			log.error("Exception in GeeniMessageReciever / recieve() " + ex.getMessage(), ex.getCause());
			return null;
		}

	}

}
