package com.mobiowin.flashdeals.test;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import com.sun.org.apache.xerces.internal.impl.dv.util.Base64;

public class ImageSyncTest
{
	public static void main(String[] args) throws IOException
	{
		String srcDirName="/home/raman/Projects/flash.deals/images/";
		ByteArrayOutputStream baos=new ByteArrayOutputStream(1000);
		BufferedImage img=ImageIO.read(new File(srcDirName,"test.jpg"));
		ImageIO.write(img, "jpg", baos);
		baos.flush();
 
		String base64String=Base64.encode(baos.toByteArray());
		System.out.println("base64String : " + base64String);
		baos.close();
		
		/*String destDirName="D:/flash.deals/test/dest";
		byte[] bytearray = Base64.decode(base64String);
 
		BufferedImage imag=ImageIO.read(new ByteArrayInputStream(bytearray));
		ImageIO.write(imag, "jpg", new File(destDirName,"test.jpg"));
		System.out.println("File write to server successfully");*/
	}
}
