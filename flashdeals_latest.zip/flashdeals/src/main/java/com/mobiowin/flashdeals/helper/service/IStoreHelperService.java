package com.mobiowin.flashdeals.helper.service;

import java.util.HashMap;

public interface IStoreHelperService {

	String tagMerchantStore(HashMap<String, Object> requestDataMap);

	String fetchStoreDetails(HashMap<String, String> requestDataMap);

}
