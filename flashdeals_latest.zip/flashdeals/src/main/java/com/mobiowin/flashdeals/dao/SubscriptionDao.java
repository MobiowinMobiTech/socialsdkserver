package com.mobiowin.flashdeals.dao;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class SubscriptionDao implements ISubscriptionDao
{
	private Log log = LogFactory.getLog(this.getClass());
	
	

}
