package com.mobiowin.flashdeals.merchant.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.flashdeals.commons.ApplicationConstant;
import com.mobiowin.flashdeals.helper.service.IStoreHelperService;
import com.mobiowin.flashdeals.messaging.IFlashService;

@Service("merchantStoreSyncService")
@Component
public class MerchantStoreSyncService implements IFlashService
{
	private Log log =LogFactory.getLog(this.getClass());
	
	@Autowired
	private IStoreHelperService storeService;

	public Message<String> execute(Message<String> message)
	{
		log.info("inside MerchantStoreSyncService/execute()");
		
		String jsonData = message.getPayload();

		Map<String, Object> messageHeaders = message.getHeaders();

		JSONObject merchantStoreJson = null;
		JSONObject merchantStoreDataJson = null;
		
		String imeiNo = null;
		String merchantId = null;
		
		try
		{
			merchantStoreJson = new JSONObject(jsonData);
			merchantStoreDataJson = merchantStoreJson.getJSONObject(ApplicationConstant.DATA);
			
			if (merchantStoreDataJson.has(ApplicationConstant.MERCHANT_ID))
		    {
				merchantId = String.valueOf(merchantStoreDataJson
						.getString(ApplicationConstant.MERCHANT_ID));
			}
			
			if (merchantStoreDataJson.has(ApplicationConstant.IMEI_NO))
		    {
				imeiNo = merchantStoreDataJson
						.getString(ApplicationConstant.IMEI_NO);
			}
			
			if(log.isInfoEnabled())
			{
				log.info("Message headers is  : " + messageHeaders);
				log.info("Merchant Id is  : " + merchantId);
				log.info("imei no : " + imeiNo);
				
			}
			
			HashMap<String,String> requestDataMap = getRequestDataMap(merchantId,imeiNo);
			
			String response = storeService.fetchStoreDetails(requestDataMap);
			
			return MessageBuilder.withPayload(response).build();
			
		} 
		catch (JSONException e) 
		{
			log.error("Exception in parsing json " + e.getMessage());
			e.printStackTrace();
		}
		
		return null;
	}

	private HashMap<String, String> getRequestDataMap(String merchantId,
			String imeiNo)
	{
		HashMap<String,String> storeDataMap = new HashMap<String,String>();
		storeDataMap.put(ApplicationConstant.IMEI_NO, imeiNo);
		storeDataMap.put(ApplicationConstant.MERCHANT_ID, merchantId);
		return storeDataMap;
	}

}
