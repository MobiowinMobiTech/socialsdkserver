package com.mobiowin.flashdeals.helper.service;

import java.util.HashMap;
import java.util.List;

import com.mobiowin.flashdeals.bean.MerchantProfileBean;

public interface IProfileSyncService {

	String updateMerchantProfile(HashMap<String, String> merchantProfileDataMap);

	String fetchMerchantId(HashMap<String, String> merchantDataMap);

	List<MerchantProfileBean> fetchMerchantProfileData(String merchantId);

}
