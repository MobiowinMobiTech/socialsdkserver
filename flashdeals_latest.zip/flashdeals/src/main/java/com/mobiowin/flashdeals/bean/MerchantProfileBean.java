package com.mobiowin.flashdeals.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "merchant_profile_master", catalog = "flashdeals")
public class MerchantProfileBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "merchant_id")
	private String merchantId;

	@Column(name = "first_name")
	private String firstName;

	@Column(name = "last_name")
	private String lastName;

	@Column(name = "brand_name")
	private String brandName;

	@Column(name = "brand_category")
	private String brandCategory;

	@Column(name = "city")
	private String city;

	@Column(name = "state")
	private String state;

	@Column(name = "country")
	private String country;

	@Column(name = "pincode")
	private String pinCode;

	@Column(name = "profile_img")
	private String dpImage;

	@Column(name = "mobile_no")
	private String mobileNo;

	@Column(name = "merchant_type")
	private String merchantType;

	@Column(name = "subscription_model")
	private String subscriptionModel;

	@Column(name = "created_by")
	private String createdBy;
	@Column(name = "created_dt")
	private Date createDt;
	@Column(name = "modified_by")
	private String modifiedBy;
	@Column(name = "modified_dt")
	private Date modifyDt;
	@Column(name = "del_flag")
	private String deleteFlag;

	public MerchantProfileBean() {
		super();
	}

	public MerchantProfileBean(int id, String merchantId, String firstName, String lastName, String brandName,
			String brandCategory, String city, String state, String country, String pinCode, String dpImage,
			String mobileNo, String merchantType, String subscriptionModel, String createdBy, Date createDt,
			String modifiedBy, Date modifyDt, String deleteFlag) {
		super();
		this.id = id;
		this.merchantId = merchantId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.brandName = brandName;
		this.brandCategory = brandCategory;
		this.city = city;
		this.state = state;
		this.country = country;
		this.pinCode = pinCode;
		this.dpImage = dpImage;
		this.mobileNo = mobileNo;
		this.merchantType = merchantType;
		this.subscriptionModel = subscriptionModel;
		this.createdBy = createdBy;
		this.createDt = createDt;
		this.modifiedBy = modifiedBy;
		this.modifyDt = modifyDt;
		this.deleteFlag = deleteFlag;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getBrandName() {
		return brandName;
	}

	public void setBrandName(String brandName) {
		this.brandName = brandName;
	}

	public String getBrandCategory() {
		return brandCategory;
	}

	public void setBrandCategory(String brandCategory) {
		this.brandCategory = brandCategory;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	public String getDpImage() {
		return dpImage;
	}

	public void setDpImage(String dpImage) {
		this.dpImage = dpImage;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getMerchantType() {
		return merchantType;
	}

	public void setMerchantType(String merchantType) {
		this.merchantType = merchantType;
	}

	public String getSubscriptionModel() {
		return subscriptionModel;
	}

	public void setSubscriptionModel(String subscriptionModel) {
		this.subscriptionModel = subscriptionModel;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Date createDt) {
		this.createDt = createDt;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifyDt() {
		return modifyDt;
	}

	public void setModifyDt(Date modifyDt) {
		this.modifyDt = modifyDt;
	}

	public String getDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}

	@Override
	public String toString() {
		return "MerchantProfileBean [id=" + id + ", merchantId=" + merchantId + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", brandName=" + brandName + ", brandCategory=" + brandCategory + ", city="
				+ city + ", state=" + state + ", country=" + country + ", pinCode=" + pinCode + ", dpImage=" + dpImage
				+ ", mobileNo=" + mobileNo + ", merchantType=" + merchantType + ", subscriptionModel="
				+ subscriptionModel + ", createdBy=" + createdBy + ", createDt=" + createDt + ", modifiedBy="
				+ modifiedBy + ", modifyDt=" + modifyDt + ", deleteFlag=" + deleteFlag + "]";
	}
	
	

}
