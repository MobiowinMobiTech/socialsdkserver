package com.mobiowin.flashdeals.customer.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.flashdeals.messaging.IFlashService;

@Service("customerDataSyncService")
@Component
public class DataSyncService implements IFlashService {

	private Log log = LogFactory.getLog(this.getClass());

	
	public Message<String> execute(Message<String> message)
	{
		log.info("Inside DataSyncService/execute()");
		
		return null;
	}
}
