package com.mobiowin.flashdeals.dao;

public interface ISubscriptionDao {

}
