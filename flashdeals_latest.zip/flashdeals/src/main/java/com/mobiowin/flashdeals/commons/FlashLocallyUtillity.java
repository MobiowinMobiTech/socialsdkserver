package com.mobiowin.flashdeals.commons;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FlashLocallyUtillity {

	public static ArrayList<String> getUserDetailMap(String userLocallyData) {
		
		
		
		String[] locallyArr =  userLocallyData.split(",");
		ArrayList<String> localAddressList = new ArrayList<String>(Arrays.asList(locallyArr));
		
		System.out.println("localAddressList : " + localAddressList);
		System.out.println("localAddressList : " + localAddressList.size());
		
		ArrayList<String> resList = new ArrayList<String>(localAddressList.subList(localAddressList.size()-3, localAddressList.size()));
		System.out.println("resList " + resList);
		
		
		return resList;
	}
	
	public static void main(String[] args) 
	{
		
		String dummyData = "Sopariwala Sadan, Nani Chipwad, Gopipura, Surat, Gujarat 395003, India";
		FlashLocallyUtillity.getUserDetailMap(dummyData);
	}

	public static List<String> getLocaleLocationList(ArrayList<String> userLocationList)
	{
		String[] localeLocation = userLocationList.get(1).trim().split("\\s+");
		
		return Arrays.asList(localeLocation);
	}

}
