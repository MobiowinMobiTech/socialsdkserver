package com.mobiowin.flashdeals.merchant.service;

import java.util.HashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.flashdeals.commons.ApplicationConstant;
import com.mobiowin.flashdeals.messaging.IFlashService;

@Service("subscriptionValidationService")
@Component
public class SubscriptionValidationService implements IFlashService{

	private Log log = LogFactory.getLog(this.getClass());
	
	public Message<String> execute(Message<String> message)
	{
		log.info("Inside SubscriptionValidationService/execute()");
		
		String jsonData = message.getPayload();
		JSONObject merchantJson = null;
		JSONObject merchantDataJson = null;
		
		String merchantId = null;
		
		try 
		{
			merchantJson = new JSONObject(jsonData);
			merchantDataJson = merchantJson.getJSONObject(ApplicationConstant.DATA);
			
			if (merchantDataJson.has(ApplicationConstant.MERCHANT_ID)) {
				merchantId = String.valueOf(merchantDataJson
						.getString(ApplicationConstant.MERCHANT_ID));
			}
			
			if(log.isInfoEnabled())
			{
				log.info("Merchant id is : " + merchantId);
			}
		}
		catch(Exception ex)
		{
			log.error("Exception in SubscriptionValidationService/execute : " + ex.getMessage(),ex.getCause());
		}
		
		HashMap<String, String> dataMap = getRequestDataMap(merchantId);
		
		return MessageBuilder.withPayload(message.getPayload()).copyHeaders(message.getHeaders())
				.setHeader(ApplicationConstant.ENTITY, "").setHeader(ApplicationConstant.TYPE, "").build();

	}

	private HashMap<String, String> getRequestDataMap(String merchantId) 
	{
		HashMap<String, String> dealDataMap = new HashMap<String, String>();
		
		dealDataMap.put(ApplicationConstant.MERCHANT_ID, merchantId);
		return dealDataMap;
	}

}
