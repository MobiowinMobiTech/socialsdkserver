package com.mobiowin.flashdeals.customer.service;

import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.flashdeals.messaging.IFlashService;

@Service("customerProfileSyncChannel")
@Component
public class ProfileSync implements IFlashService{

	
	public Message<String> execute(Message<String> message) {
		// TODO Auto-generated method stub
		return null;
	}

}
