package com.mobiowin.flashdeals.helper.service;

import java.util.HashMap;

public interface ISubscriptionService {

	String submitsubscriptionModel(HashMap<String, Object> requestDataMap);

	String validateMerchantSubscription(HashMap<String, String> reqDataMap);

}
