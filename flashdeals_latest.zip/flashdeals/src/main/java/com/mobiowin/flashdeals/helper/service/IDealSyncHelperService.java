package com.mobiowin.flashdeals.helper.service;

import java.util.HashMap;

public interface IDealSyncHelperService {

	String syncCustomerDealData(HashMap<String, String> dataMap);

	String submitMerchantDeal(HashMap<String, Object> dealDataMap);

	String fetchMerchantDealDetails(HashMap<String, String> requestDataMap);

}
