package com.mobiowin.flashdeals.dao;

import java.util.HashMap;

public interface IOtpValidatiorDao {

	String validateOtp(HashMap<String, String> dataMap);

}
