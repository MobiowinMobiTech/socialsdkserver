package com.mobiowin.flashdeals.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "customer_master", catalog = "flashdeals")
public class CustomerRegistrationBean extends StatndradBean implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@Column(name = "mobile_no")
	private String mobileNo;
	
	@Column(name = "imei_no")
	private String imeiNo;
	
	@Column(name = "otp")
	private String otp;
	
	@Column(name = "mail_id")
	private String mailId;

	public CustomerRegistrationBean(int id, String mobileNo, String imeiNo, String otp, String mailId) {
		super();
		this.id = id;
		this.mobileNo = mobileNo;
		this.imeiNo = imeiNo;
		this.otp = otp;
		this.mailId = mailId;
	}

	public CustomerRegistrationBean() {
		super();
	}
	
	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getImeiNo() {
		return imeiNo;
	}

	public void setImeiNo(String imeiNo) {
		this.imeiNo = imeiNo;
	}

	public String getOtp() {
		return otp;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

	public String getMailId() {
		return mailId;
	}

	public void setMailId(String mailId) {
		this.mailId = mailId;
	}

	@Override
	public String toString() {
		return "CustomerRegistrationBean [id=" + id + ", mobileNo=" + mobileNo + ", imeiNo=" + imeiNo + ", otp=" + otp
				+ ", mailId=" + mailId + "]";
	}
	
	
	
	
	
	
}
