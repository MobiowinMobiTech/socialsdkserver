package com.mobiowin.flashdeals.helper.service;

import java.util.HashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.flashdeals.bean.MerchantLoginBean;
import com.mobiowin.flashdeals.bean.MerchantProfileBean;
import com.mobiowin.flashdeals.bean.MerchantRegistrationBean;
import com.mobiowin.flashdeals.commons.ApplicationConstant;
import com.mobiowin.flashdeals.commons.FlashOtpUtil;
import com.mobiowin.flashdeals.commons.FlashUtility;
import com.mobiowin.flashdeals.dao.IFlashLoginDao;

@Service("loginHelperService")
@Component
public class LoginHelperService implements ILoginHelperService {
	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private IFlashLoginDao flashLoginDao;
	
	@Autowired
	private IProfileSyncService profileSyncService;
	
	@Autowired
	private IRegistrationHelperService registrationHelperService;

	public boolean validateLogin(HashMap<String, String> merchantDataMap) {
		log.info("Inside LoginHelperService/validateLogin() ");
		
		MerchantRegistrationBean merchantRegistrationBean = new MerchantRegistrationBean();
		merchantRegistrationBean.setMobileNo(merchantDataMap.get(ApplicationConstant.FLASH_USER_ID));
		merchantRegistrationBean.setPassword(merchantDataMap.get(ApplicationConstant.FLASH_PASSWORD));
		
		log.info("merchantLoginBean : " + merchantRegistrationBean);

		String isValidMerchant = flashLoginDao.validateLogin(merchantRegistrationBean);
		
		log.info("isValidMerchant : " + isValidMerchant);

		if (isValidMerchant.equals(ApplicationConstant.TRUE)) 
		{
			return true;
		}

		return false;
	}

	
	public String generateSuccessResponse(HashMap<String, String> merchantDataMap) 
	{
		log.info("Inside LoginHelperService/generateSuccessResponse()");
		
		String merchantId = registrationHelperService.fetchMerchantId(merchantDataMap);
		
		List<MerchantProfileBean> merchantProfileList = profileSyncService.fetchMerchantProfileData(merchantId);
		
		log.info("merchantProfileList size : " + merchantProfileList.size());
		
		HashMap<String,Object> dataMap = new HashMap<String,Object>();
		
		if(merchantProfileList != null && merchantProfileList.size() > 0)
		{
			
			dataMap.put(ApplicationConstant.MERCHANT_PROFILE, merchantProfileList);
			return FlashUtility.createJSONFromMap(FlashUtility.createSuccessResponseMessage(dataMap));
		}
		
		return FlashUtility.createSuccessMessage();

	}

	
	public String generateErrorResponse() 
	{
		log.info("Inside LoginHelperService/generateSuccessResponse()");

		return FlashUtility.createErrorMessage("Invalid Login credentials");
	}

	
	public boolean validateMerchant(HashMap<String, String> merchantDataMap) 
	{
		log.info("Inside LoginHelperService/validateMerchant() ");

		MerchantLoginBean merchantLoginBean = new MerchantLoginBean();
		merchantLoginBean.setUserID(merchantDataMap
				.get(ApplicationConstant.FLASH_USER_ID));
		
		String isValidMerchant = flashLoginDao.validateMerchant(merchantLoginBean);

		if (isValidMerchant.equals(ApplicationConstant.TRUE))
		{
			//merchantLoginBean.setOtp(FlashOtpUtil.generateOtp());
			return true;
		}

		return false;
	}

	
	public String generateOtpSuccessResponse(HashMap<String, String> merchantDataMap) 
	{
		log.info("Inside LoginHelperService/generateOtpSuccessResponse()");
		
		String otp = FlashOtpUtil.generateOtp();
		
		log.info("Generated otp is :" + otp);
		/*
		 * Send otp to merchant mobile no
		 * */
		return FlashUtility.createSuccessMessage();
	}

}
