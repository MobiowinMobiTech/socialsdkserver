package com.mobiowin.flashdeals.commons;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;

public class FlashOtpUtil 
{

	public static String generateOtp() 
	{
		StringBuilder generatedToken = new StringBuilder();
		try 
		{
			SecureRandom number = SecureRandom.getInstance("SHA1PRNG");
			for (int i = 0; i < 6; i++) 
			{
				generatedToken.append(number.nextInt(9));
			}
		}
		catch (NoSuchAlgorithmException e) 
		{
			e.printStackTrace();
		}
		//System.out.println("generatedToken " + generatedToken.toString());
		return generatedToken.toString();
	}
	
	public static void main(String[] args) {
		FlashOtpUtil.generateOtp();
	}
	

}
