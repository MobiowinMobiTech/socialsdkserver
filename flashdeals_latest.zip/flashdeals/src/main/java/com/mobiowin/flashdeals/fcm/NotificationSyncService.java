package com.mobiowin.flashdeals.fcm;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.flashdeals.commons.ApplicationConstant;
import com.mobiowin.flashdeals.merchant.service.IFlashMiscService;
import com.mobiowin.flashdeals.messaging.IFlashService;

@Service("notificationSyncService")
@Component
public class NotificationSyncService implements IFlashService 
{
	private Log log = LogFactory.getLog(this.getClass());
	
	@Autowired
	private IFlashMiscService flashMiscService;

	public Message<String> execute(Message<String> message) 
	{
		log.info("Inside NotificationSyncService/execute()");
		
		String jsonData = message.getPayload();

		Map<String, Object> messageHeaders = message.getHeaders();
		

		JSONObject notificationReqJson = null;
		JSONObject notificationDataJson = null;
		String messageData = message.getPayload();
		
		String entity = null;
		String userId = null;
		String notificationId = null;
		String osType = null;
		String osVeriosn = null;
		String response = null;
		
		try
		{
			JSONObject messageObj = new JSONObject(messageData);
			entity = (String) messageObj.get(ApplicationConstant.ENTITY);
		
			notificationReqJson = new JSONObject(jsonData);
			notificationDataJson = notificationReqJson.getJSONObject(ApplicationConstant.DATA);
			
			if (notificationDataJson.has(ApplicationConstant.FLASH_USER_ID))
		    {
				userId = String.valueOf(notificationDataJson
						.getString(ApplicationConstant.FLASH_USER_ID));
			}
			
			if (notificationDataJson.has(ApplicationConstant.NOTIFICATION_ID))
		    {
				notificationId = String.valueOf(notificationDataJson
						.getString(ApplicationConstant.NOTIFICATION_ID));
			}
			
			if (notificationDataJson.has(ApplicationConstant.OS_TYPE))
		    {
				osType = String.valueOf(notificationDataJson
						.getString(ApplicationConstant.OS_TYPE));
			}
			
			if (notificationDataJson.has(ApplicationConstant.OS_VERSION))
		    {
				osVeriosn = String.valueOf(notificationDataJson
						.getString(ApplicationConstant.OS_VERSION));
			}
			
			if(log.isInfoEnabled())
			{
				log.info("userId is : " + userId);
				log.info("notificationId is : " + notificationId);
				log.info("osType is : " + osType);
				log.info("osVeriosn is : " + osVeriosn);
				log.info("entity is : " + entity);
				
			}
			
		}
		catch(Exception ex)
		{
			log.error("Exception in NotificationSyncService/execute() : " + ex.getMessage());
		}
		
		HashMap<String,String> notificationDataMap = getNotificationIdDataMap(userId,notificationId,osType,osVeriosn,entity);
		
		response = flashMiscService.submitNotificationDetails(notificationDataMap);
		
		return MessageBuilder.withPayload(response).build();
		
	}

	private HashMap<String, String> getNotificationIdDataMap(String userId, String notificationId, String osType,
			String osVeriosn, String entity)
	{
		HashMap<String,String> notificationDataMap = new HashMap<String,String>();
		notificationDataMap.put(ApplicationConstant.ENTITY, entity);
		notificationDataMap.put(ApplicationConstant.FLASH_USER_ID, userId);
		notificationDataMap.put(ApplicationConstant.NOTIFICATION_ID, notificationId);
		notificationDataMap.put(ApplicationConstant.OS_TYPE, osType);
		notificationDataMap.put(ApplicationConstant.OS_VERSION, osVeriosn);
		
		return notificationDataMap;
	}
	
	
}
