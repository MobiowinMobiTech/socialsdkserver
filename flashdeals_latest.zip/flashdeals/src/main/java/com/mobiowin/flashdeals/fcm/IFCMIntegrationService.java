package com.mobiowin.flashdeals.fcm;

public interface IFCMIntegrationService {

	void sendFcmNotificationMessage();

}
