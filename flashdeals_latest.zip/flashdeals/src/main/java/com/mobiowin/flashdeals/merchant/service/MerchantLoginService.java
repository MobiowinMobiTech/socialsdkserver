package com.mobiowin.flashdeals.merchant.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.flashdeals.commons.ApplicationConstant;
import com.mobiowin.flashdeals.helper.service.ILoginHelperService;
import com.mobiowin.flashdeals.messaging.IFlashService;

@Service("merchantLoginService")
@Component
public class MerchantLoginService implements IFlashService
{

	private Log log = LogFactory.getLog(this.getClass());
	
	@Autowired
	private ILoginHelperService loginHelperService;
	
	public Message<String> execute(Message<String> message) 
	{
		log.info("Inside MerchantLoginService / execute()");
		
		String jsonData = message.getPayload();

		Map<String, Object> messageHeaders = message.getHeaders();

		JSONObject merchantDataJson = null;
		JSONObject merchantLoginDataJson = null;
		String userId = null;
		String imeiNo = null;
		String password = null;
		String response = null;

		try 
		{
			merchantDataJson = new JSONObject(jsonData);
			merchantLoginDataJson = merchantDataJson.getJSONObject(ApplicationConstant.DATA);

			if (merchantLoginDataJson.has(ApplicationConstant.FLASH_USER_ID))
		    {
				userId = merchantLoginDataJson
						.getString(ApplicationConstant.FLASH_USER_ID);
			}

			if (merchantLoginDataJson.has(ApplicationConstant.IMEI_NO))
			{
				imeiNo = merchantLoginDataJson
						.getString(ApplicationConstant.IMEI_NO);
			}
			
			if (merchantLoginDataJson.has(ApplicationConstant.FLASH_PASSWORD))
			{
				password = merchantLoginDataJson
						.getString(ApplicationConstant.FLASH_PASSWORD);
			}
			
			if(log.isInfoEnabled())
			{
				log.info("Merchant Data is : " + merchantLoginDataJson);
				log.info("Message Headers : " + messageHeaders);
				log.info("Merchant userid is : " + userId);
				log.info("Merchant imei no is : " + imeiNo);
				log.info("Merchant password no is : " + password);
			}
			
			HashMap<String,String> merchantDataMap = merchantLoginDataMap(userId,imeiNo,password);
			
			log.info("merchantDataMap :"+ merchantDataMap);
			
			boolean isExistingMerchant = loginHelperService.validateLogin(merchantDataMap);
			
			if(isExistingMerchant)
			{
				response = loginHelperService.generateSuccessResponse(merchantDataMap);
				
			}
			else
			{
				response = loginHelperService.generateErrorResponse();
			}
			
			return MessageBuilder.withPayload(response).build();

		} catch (Exception ex)
		{
			log.error("Exception in RegistrationService/execute() " + ex.getMessage(),ex.getCause());

		}
		return null;
	}

	private HashMap<String, String> merchantLoginDataMap(String userId,
			String imeiNo, String password) {
		HashMap<String,String> merchantLoginDataMap = new HashMap<String, String>();
		merchantLoginDataMap.put(ApplicationConstant.FLASH_USER_ID, userId);
		merchantLoginDataMap.put(ApplicationConstant.IMEI_NO, imeiNo);
		merchantLoginDataMap.put(ApplicationConstant.FLASH_PASSWORD, password);
		
		return merchantLoginDataMap;
		
	}
	

}
