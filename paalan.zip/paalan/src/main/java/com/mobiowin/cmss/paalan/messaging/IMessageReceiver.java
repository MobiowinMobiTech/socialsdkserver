package com.mobiowin.cmss.paalan.messaging;

import org.springframework.messaging.Message;

public interface IMessageReceiver {
	public Message<String> recieve(Message<String> message);
}
