package com.mobiowin.cmss.paalan.service.ind;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.cmss.paalan.commons.ApplicationConstant;
import com.mobiowin.cmss.paalan.messaging.IMessageService;
import com.mobiowin.cmss.paalan.service.helper.ICoreIndHelperService;

@Service("indProfileService")
@Component
public class IndProfileService implements IMessageService {

	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private ICoreIndHelperService indCoreHelperService;

	public Message<String> execute(Message<String> message) {
		log.info("Inside IndProfileService/execute()");

		String jsonData = message.getPayload();

		Map<String, Object> messageHeaders = message.getHeaders();

		JSONObject reqDataJson = null;
		JSONObject profileDataJson = null;

		String memberId = null;
		String imeiNo = null;
		String isNewsLetter = null;
		String dpImgLink = null;
		String response = null;
		HashMap<String, String> profileReqDataMap = null;

		try {
			reqDataJson = new JSONObject(jsonData);
			profileDataJson = reqDataJson.getJSONObject(ApplicationConstant.DATA);

			if (profileDataJson.has(ApplicationConstant.MEMBER_ID)) {
				memberId = profileDataJson.getString(ApplicationConstant.MEMBER_ID);
			}

			if (profileDataJson.has(ApplicationConstant.IMEI_NO)) {
				imeiNo = profileDataJson.getString(ApplicationConstant.IMEI_NO);
			}

			if (profileDataJson.has(ApplicationConstant.IS_NEWS_LETTER)) {
				isNewsLetter = profileDataJson.getString(ApplicationConstant.IS_NEWS_LETTER);
			}

			if (profileDataJson.has(ApplicationConstant.DISPLAY_IMAGE)) {
				dpImgLink = profileDataJson.getString(ApplicationConstant.DISPLAY_IMAGE);
			}

			if (log.isInfoEnabled()) {
				log.info("Message Headers is : " + messageHeaders);
				log.info("IMEI no is : " + imeiNo);
				log.info("Is News Letter is : " + isNewsLetter);
			}

			profileReqDataMap = getProfileDataMap(memberId, imeiNo, isNewsLetter, dpImgLink);

			response = indCoreHelperService.updateProfile(profileReqDataMap);

			return MessageBuilder.withPayload(response).build();

		} catch (Exception ex) {
			log.error("Exception in OrgProfileService/execute() " + ex.getMessage(), ex.getCause());

		}

		return null;

	}

	private HashMap<String, String> getProfileDataMap(String memberId, String imeiNo, String isNewsLetter,
			String dpImgLink) {
		HashMap<String, String> profileReqDataMap = new HashMap<String, String>();
		profileReqDataMap.put(ApplicationConstant.MEMBER_ID, memberId);
		profileReqDataMap.put(ApplicationConstant.IMEI_NO, imeiNo);
		profileReqDataMap.put(ApplicationConstant.IS_NEWS_LETTER, isNewsLetter);
		profileReqDataMap.put(ApplicationConstant.DISPLAY_IMAGE, dpImgLink);

		return profileReqDataMap;

	}

}
