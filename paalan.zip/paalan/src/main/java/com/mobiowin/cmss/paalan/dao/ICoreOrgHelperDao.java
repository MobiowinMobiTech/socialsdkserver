package com.mobiowin.cmss.paalan.dao;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;

import com.mobiowin.cmss.paalan.bean.OrgAchievementBean;
import com.mobiowin.cmss.paalan.bean.OrgEventBean;
import com.mobiowin.cmss.paalan.bean.OrgProfileBean;
import com.mobiowin.cmss.paalan.bean.OrgRegistrationBean;
import com.mobiowin.cmss.paalan.bean.OrgRequestBean;

public interface ICoreOrgHelperDao {

	boolean isOrgExist(OrgRegistrationBean orgRegistrationBean);

	String registerOrg(OrgRegistrationBean orgRegistrationBean);

	List<OrgRegistrationBean> validateLogin(OrgRegistrationBean orgRegistrationBean);

	List<OrgProfileBean> fetchOrgProfile(OrgProfileBean orgProfileBean);

	String submitOrgProfile(OrgProfileBean orgProfileBean);

	String updateOrgProfile(OrgProfileBean orgProfileBean);

	String createEvent(OrgEventBean orgEventBean);

	String updateEvent(OrgEventBean orgEventBean);

	String deleteEvent(OrgEventBean orgEventBean);

	List<OrgEventBean> syncEvent(OrgEventBean orgEventBean, String lastSyncDate);

	String createAchievement(OrgAchievementBean orgAchievementBean);

	String updateAchievement(OrgAchievementBean orgAchievementBean);

	List<OrgAchievementBean> syncAchievement(OrgAchievementBean orgAchievementBean, String string);

	String deleteAchievement(OrgAchievementBean orgAchievementBean);

	String createRequest(OrgRequestBean orgRequestBean);

	List<OrgRequestBean> syncRequest(OrgRequestBean orgRequestBean, String lastSyncDate);

	String deleteRequest(OrgRequestBean orgRequestBean);

	String updateRequest(OrgRequestBean orgRequestBean);

	String insertProfile(OrgProfileBean orgProfileBean);

	List<OrgRegistrationBean> validateUserId(OrgRegistrationBean orgRegistrationBean);

	String updatePassword(OrgRegistrationBean orgRegistrationBean);

	List<Object> fetchNotificationRecord(HashMap<String, Object> dbRequestMap);

}
