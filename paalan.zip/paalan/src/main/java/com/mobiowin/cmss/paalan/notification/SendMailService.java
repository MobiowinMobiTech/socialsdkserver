package com.mobiowin.cmss.paalan.notification;

import java.util.HashMap;

import javax.mail.internet.MimeMessage;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.cmss.paalan.bean.OrgRegistrationBean;
import com.mobiowin.cmss.paalan.commons.ApplicationConstant;



@Service("sendMailService")
@Component
public class SendMailService {
private Log log = LogFactory.getLog(this.getClass());
	
	@Autowired
	private JavaMailSender mailSender;
	
	@Autowired
	private SimpleMailMessage simpleMailMessage;
	
	public JavaMailSender getMailSender()
	{
		return mailSender;
	}

	public SimpleMailMessage getSimpleMailMessage()
	{
		return simpleMailMessage;
	}
	public void setMailSender(JavaMailSender mailSender)
	{
		this.mailSender = mailSender;
	}
	public void setSimpleMailMessage(SimpleMailMessage simpleMailMessage)
	{
		this.simpleMailMessage = simpleMailMessage;
	}
	
	@Async
	public void sendMailService(HashMap<String, String> reqDataMap, OrgRegistrationBean orgRegistrationBean) 
	{
		log.info("Inside SendOtpOnMailService/sendOtpOnMailService...");
		
		MimeMessage message = mailSender.createMimeMessage();
		
		try
		{
			MimeMessageHelper helper = new MimeMessageHelper(message, true);

			helper.setFrom(simpleMailMessage.getFrom());
			helper.setTo(orgRegistrationBean.getEmailId());
			helper.setSubject(simpleMailMessage.getSubject() + " " + "Paalan Forgot Password");
			helper.setText(String.format(simpleMailMessage.getText(), orgRegistrationBean.getName(), reqDataMap.get(ApplicationConstant.FLASH_CUST_OTP)), true);
			
			mailSender.send(message);
			
			
		} 
		catch (Exception e)
		{
			log.error("Exception in sending mail ...." + e.getMessage());
		}
		
	}
}
