package com.mobiowin.cmss.paalan.service.org;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.cmss.paalan.commons.ApplicationConstant;
import com.mobiowin.cmss.paalan.messaging.IMessageService;
import com.mobiowin.cmss.paalan.service.helper.ICoreOrgHelperService;

@Service("orgEventSyncService")
@Component
public class OrgEventSyncService implements IMessageService {

	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private ICoreOrgHelperService orgCoreHelperService;

	public Message<String> execute(Message<String> message) {
		log.info("Inside OrgEventSyncService/execute()");

		String jsonData = message.getPayload();

		Map<String, Object> messageHeaders = message.getHeaders();

		JSONObject dataJson = null;
		JSONObject reqDataJson = null;

		String orgId = null;
		String response = null;
		String lastSyncDate = null;

		HashMap<String, String> reqDataMap = null;

		try {
			dataJson = new JSONObject(jsonData);
			reqDataJson = dataJson.getJSONObject(ApplicationConstant.DATA);

			if (reqDataJson.has(ApplicationConstant.ORG_ID)) {
				orgId = reqDataJson.getString(ApplicationConstant.ORG_ID);
			}
			
			log.info("Last sync date " + reqDataJson.getString(ApplicationConstant.LAST_SYNC_DATE));
			
			if (reqDataJson.has(ApplicationConstant.LAST_SYNC_DATE)) {
				lastSyncDate = reqDataJson.getString(ApplicationConstant.LAST_SYNC_DATE);
			}

			if (log.isInfoEnabled()) {
				log.info("Message Headers is : " + messageHeaders);
				log.info("ORG_ID is : " + orgId);
				log.info("LAST_SYNC_DATE is : " + lastSyncDate);
				//log.info("" + Timestamp.valueOf(lastSyncDate));

			}

			reqDataMap = getReqDataMap(orgId,lastSyncDate);

			response = orgCoreHelperService.syncOrgEvent(reqDataMap);

			return MessageBuilder.withPayload(response).build();

		} catch (Exception ex) {
			log.error("Exception in OrgProfileService/execute() " + ex.getMessage(), ex.getCause());

		}

		return null;

	}

	private HashMap<String, String> getReqDataMap(String orgId,String lastSyncDate) {

		HashMap<String, String> reqDataMap = new HashMap<String, String>();

		reqDataMap.put(ApplicationConstant.ORG_ID, orgId);
		reqDataMap.put(ApplicationConstant.LAST_SYNC_DATE, lastSyncDate);

		return reqDataMap;
	}
}
