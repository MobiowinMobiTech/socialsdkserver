package com.mobiowin.cmss.paalan.service.helper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.cmss.paalan.bean.OrgAchievementBean;
import com.mobiowin.cmss.paalan.bean.OrgEventBean;
import com.mobiowin.cmss.paalan.bean.OrgProfileBean;
import com.mobiowin.cmss.paalan.bean.OrgRegistrationBean;
import com.mobiowin.cmss.paalan.bean.OrgRequestBean;
import com.mobiowin.cmss.paalan.commons.ApplicationConstant;
import com.mobiowin.cmss.paalan.commons.IdGeneratorUtility;
import com.mobiowin.cmss.paalan.commons.MessageUtility;
import com.mobiowin.cmss.paalan.dao.ICoreOrgHelperDao;
import com.mobiowin.cmss.paalan.image.ImageUrlService;
import com.mobiowin.cmss.paalan.notification.IFcmPeerNotificationService;
import com.mobiowin.cmss.paalan.notification.IFCMIntegrationService;
import com.mobiowin.cmss.paalan.notification.IFcmBroadcastService;
import com.mobiowin.cmss.paalan.notification.SendMailService;
import com.mobiowin.cmss.paalan.test.DateUtility;

@Service("orgCoreHelperService")
@Component
public class CoreOrgHelperService implements ICoreOrgHelperService {
	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private ICoreOrgHelperDao coreOrgHelperDao;

	@Autowired
	private ImageUrlService imageService;

	@Autowired
	private IFCMIntegrationService fcmIntegrationService;

	@Autowired
	private IFcmPeerNotificationService fcmPeerNotificationService;
	
	@Autowired
	private IFcmBroadcastService fcmBroadcastService;

	@Autowired
	private @Resource Map<String, String> notificationConfig;

	@Autowired
	private @Resource Map<String, String> notificationMessageConfig;

	@Autowired
	private SendMailService sendMailService;

	public String isExistingOrg(HashMap<String, String> orgRegistrationDataMap) {
		log.info("Inside CoreOrgHelperService/isExistingOrg()");

		OrgRegistrationBean orgRegistrationBean = null;
		OrgProfileBean orgProfileBean = null;
		String response = null;
		String profileResponse = null;
		HashMap<String, Object> dataMap = null;
		HashMap<String, String> notificationDataMap = null;
		StringBuilder addressbuilder = null;

		boolean isOrgExist = false;

		if (null != orgRegistrationDataMap) {
			orgRegistrationBean = new OrgRegistrationBean();
			orgRegistrationBean.setName(orgRegistrationDataMap.get(ApplicationConstant.NAME));
			orgRegistrationBean.setOrgId(IdGeneratorUtility.generateOrgId(orgRegistrationDataMap));
			orgRegistrationBean.setMobileNo(orgRegistrationDataMap.get(ApplicationConstant.MOBILE_NO));
			orgRegistrationBean.setEmailId(orgRegistrationDataMap.get(ApplicationConstant.EMAIL_ID));
			orgRegistrationBean.setPassword(orgRegistrationDataMap.get(ApplicationConstant.PASSWORD));
			orgRegistrationBean.setNotificationId(orgRegistrationDataMap.get(ApplicationConstant.NOTIFICATION_ID));
			orgRegistrationBean.setDeviceId(orgRegistrationDataMap.get(ApplicationConstant.DEVICE_ID));
			orgRegistrationBean.setAddress(orgRegistrationDataMap.get(ApplicationConstant.ADDRESS));
			orgRegistrationBean.setState(orgRegistrationDataMap.get(ApplicationConstant.STATE));
			orgRegistrationBean.setCity(orgRegistrationDataMap.get(ApplicationConstant.CITY));
			orgRegistrationBean.setPincode(orgRegistrationDataMap.get(ApplicationConstant.PIN_CODE));
			orgRegistrationBean.setCountry(orgRegistrationDataMap.get(ApplicationConstant.COUNTRY));
			orgRegistrationBean.setCreatedBy(ApplicationConstant.SYSTEM_CREATED_BY);
			orgRegistrationBean.setModifiedBy(ApplicationConstant.SYSTEM_MODIFIED_BY);
			orgRegistrationBean.setDeleteFlag(ApplicationConstant.DEL_FLAG);

		}

		log.info("orgRegistrationBean : " + orgRegistrationBean);

		isOrgExist = coreOrgHelperDao.isOrgExist(orgRegistrationBean);

		log.info("Is Orgnazation already exist : " + isOrgExist);

		if (!isOrgExist) {
			response = coreOrgHelperDao.registerOrg(orgRegistrationBean);

			addressbuilder = new StringBuilder();
			orgProfileBean = new OrgProfileBean();

			orgProfileBean.setOrgId(orgRegistrationBean.getOrgId());
			orgProfileBean.setName(orgRegistrationBean.getName());

			addressbuilder.append(orgRegistrationBean.getAddress());
			addressbuilder.append(ApplicationConstant.FIELD_APPENDER);
			addressbuilder.append(orgRegistrationBean.getCity());
			addressbuilder.append(ApplicationConstant.FIELD_APPENDER);
			addressbuilder.append(orgRegistrationBean.getState());
			addressbuilder.append(ApplicationConstant.FIELD_APPENDER);
			addressbuilder.append(orgRegistrationBean.getPincode());
			addressbuilder.append(ApplicationConstant.FIELD_APPENDER);
			addressbuilder.append(orgRegistrationBean.getCountry());

			orgProfileBean.setAddress(addressbuilder.toString());
			orgProfileBean.setEmailId(orgRegistrationBean.getEmailId());
			orgProfileBean.setMobileNo(orgRegistrationBean.getMobileNo());
			orgProfileBean.setCreatedBy(ApplicationConstant.SYSTEM_CREATED_BY);
			orgProfileBean.setModifiedBy(ApplicationConstant.SYSTEM_MODIFIED_BY);
			orgProfileBean.setDeleteFlag(ApplicationConstant.DEL_FLAG);

			log.info("Response is : " + response);

			if (response.equals(ApplicationConstant.TRUE)) {
				profileResponse = coreOrgHelperDao.insertProfile(orgProfileBean);

				log.info("profile response is : " + profileResponse);

				if (response.equals(ApplicationConstant.TRUE)) {
					dataMap = new HashMap<String, Object>();

					dataMap.put(ApplicationConstant.ORG_ID, orgRegistrationBean.getOrgId());

					notificationDataMap = new HashMap<String, String>();
					notificationDataMap.put(ApplicationConstant.NAME, orgRegistrationBean.getName());
					notificationDataMap.put(ApplicationConstant.ORG_ID, orgRegistrationBean.getOrgId());
					notificationDataMap.put(ApplicationConstant.NOTIFICATION_ID,
							orgRegistrationBean.getNotificationId());
					notificationDataMap.put(ApplicationConstant.NOTIFICATION_TYPE,
							ApplicationConstant.ORG_REGISTRATION);

					//fcmIntegrationService.sendFcmNotificationMessage(notificationDataMap);

					return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));
				} else {
					return MessageUtility
							.createErrorMessage("Process failed due to technical issue!!! Kindly try after sometime");

				}
			}
		} else {
			return MessageUtility.createErrorMessage("Orgnazation already registered with Paalan, Kindly login!!!");

		}

		return MessageUtility.createErrorMessage();
	}

	public String registerOrg(HashMap<String, String> orgRegistrationDataMap) {
		log.info("Inside CoreOrgHelperService/registerOrg()");

		return null;
	}

	public String validateOrgLogin(HashMap<String, String> loginReqDataMap) {
		log.info("Inside CoreOrgHelperService/validateOrgLogin()");

		OrgRegistrationBean orgRegistrationBean = null;
		OrgProfileBean orgProfileBean = null;

		HashMap<String, Object> dataMap = null;
		List<OrgProfileBean> profileList = null;

		if (null != loginReqDataMap) {
			orgRegistrationBean = new OrgRegistrationBean();
			orgRegistrationBean.setMobileNo(loginReqDataMap.get(ApplicationConstant.FLASH_USER_ID));
			orgRegistrationBean.setPassword(loginReqDataMap.get(ApplicationConstant.FLASH_PASSWORD));

			log.info("orgRegistrationBean : " + orgRegistrationBean);

		}

		List<OrgRegistrationBean> registeredOrgList = coreOrgHelperDao.validateLogin(orgRegistrationBean);

		if (registeredOrgList.size() > 0 && registeredOrgList.size() < 2) {
			orgProfileBean = new OrgProfileBean();
			orgProfileBean.setOrgId(registeredOrgList.get(0).getOrgId());

			profileList = coreOrgHelperDao.fetchOrgProfile(orgProfileBean);

			dataMap = new HashMap<String, Object>();
			dataMap.put("orgregdata", registeredOrgList);
			dataMap.put("orgprofiledata", profileList);
			return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));
		} else {
			return MessageUtility.createErrorMessage("Kinldy check login credentials !!!");
		}

	}

	public String updateOrgProfile(HashMap<String, String> orgRegistrationDataMap) {
		log.info("Inside CoreOrgHelperService/updateOrgProfile()");

		OrgProfileBean orgProfileBean = null;

		String profileImgPath = null;
		String dbResponse = null;
		HashMap<String, Object> dataMap = null;

		log.info("orgRegistrationDataMap : " + orgRegistrationDataMap);

		if (null != orgRegistrationDataMap) {

			if (orgRegistrationDataMap.get(ApplicationConstant.DISPLAY_IMAGE) != null && !orgRegistrationDataMap
					.get(ApplicationConstant.DISPLAY_IMAGE).equalsIgnoreCase(ApplicationConstant.EMPTY_STRING)) {

				orgRegistrationDataMap.put(ApplicationConstant.USER_TYPE, ApplicationConstant.ORG_ENTITY);
				profileImgPath = imageService.saveDisplayImage(orgRegistrationDataMap);

				log.info("profile image path is : " + profileImgPath);
			}

			orgProfileBean = new OrgProfileBean();
			orgProfileBean.setOrgId(orgRegistrationDataMap.get(ApplicationConstant.ORG_ID));
			orgProfileBean.setRole(orgRegistrationDataMap.get(ApplicationConstant.ROLE));
			orgProfileBean.setImeiNo(orgRegistrationDataMap.get(ApplicationConstant.IMEI_NO));
			orgProfileBean.setIsNewsLetter(orgRegistrationDataMap.get(ApplicationConstant.IS_NEWS_LETTER));
			orgProfileBean.setIsGovtRegister(orgRegistrationDataMap.get(ApplicationConstant.IS_GOV_REGISTERED));
			orgProfileBean.setRegistrationNo(orgRegistrationDataMap.get(ApplicationConstant.GOVT_REGISTRATION_NO));
			orgProfileBean.setDpImgLink(profileImgPath);
			orgProfileBean.setFbLink(orgRegistrationDataMap.get(ApplicationConstant.FB_LINK));
			orgProfileBean.setLinkedinLink(orgRegistrationDataMap.get(ApplicationConstant.LINKEDIN_LINK));
			orgProfileBean.setWebsiteLink(orgRegistrationDataMap.get(ApplicationConstant.WEBSITE_LINK));
			orgProfileBean.setTwitterLink(orgRegistrationDataMap.get(ApplicationConstant.TWITTER_LINK));
			orgProfileBean.setPresenceArea(orgRegistrationDataMap.get(ApplicationConstant.PRESENCE_AREA));
			orgProfileBean.setCreatedBy(ApplicationConstant.SYSTEM_CREATED_BY);
			orgProfileBean.setModifiedBy(ApplicationConstant.SYSTEM_MODIFIED_BY);
			orgProfileBean.setDeleteFlag(ApplicationConstant.DEL_FLAG);
		}

		List<OrgProfileBean> profileList = coreOrgHelperDao.fetchOrgProfile(orgProfileBean);

		if (profileList.size() == 0) {
			dbResponse = coreOrgHelperDao.submitOrgProfile(orgProfileBean);

			if (dbResponse.equals(ApplicationConstant.TRUE)) {
				dataMap = new HashMap<String, Object>();
				dataMap.put(ApplicationConstant.ORG_ID, orgProfileBean.getOrgId());
				dataMap.put(ApplicationConstant.ROLE, orgProfileBean.getRole());
				dataMap.put(ApplicationConstant.IS_GOV_REGISTERED, orgProfileBean.getIsGovtRegister());
				dataMap.put(ApplicationConstant.GOVT_REGISTRATION_NO, orgProfileBean.getRegistrationNo());
				dataMap.put(ApplicationConstant.DISPLAY_IMAGE, orgProfileBean.getDpImgLink());
				dataMap.put(ApplicationConstant.FB_LINK, orgProfileBean.getFbLink());
				dataMap.put(ApplicationConstant.TWITTER_LINK, orgProfileBean.getTwitterLink());
				dataMap.put(ApplicationConstant.LINKEDIN_LINK, orgProfileBean.getLinkedinLink());
				dataMap.put(ApplicationConstant.WEBSITE_LINK, orgProfileBean.getWebsiteLink());
				dataMap.put(ApplicationConstant.PRESENCE_AREA, orgProfileBean.getPresenceArea());

				return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));

			}
		} else {
			dbResponse = coreOrgHelperDao.updateOrgProfile(orgProfileBean);

			if (dbResponse.equals(ApplicationConstant.TRUE)) {
				dataMap = new HashMap<String, Object>();
				dataMap.put(ApplicationConstant.ORG_ID, orgProfileBean.getOrgId());
				dataMap.put(ApplicationConstant.ROLE, orgProfileBean.getRole());
				dataMap.put(ApplicationConstant.IS_GOV_REGISTERED, orgProfileBean.getIsGovtRegister());
				dataMap.put(ApplicationConstant.GOVT_REGISTRATION_NO, orgProfileBean.getRegistrationNo());
				dataMap.put(ApplicationConstant.DISPLAY_IMAGE, orgProfileBean.getDpImgLink());
				dataMap.put(ApplicationConstant.FB_LINK, orgProfileBean.getFbLink());
				dataMap.put(ApplicationConstant.TWITTER_LINK, orgProfileBean.getTwitterLink());
				dataMap.put(ApplicationConstant.LINKEDIN_LINK, orgProfileBean.getLinkedinLink());
				dataMap.put(ApplicationConstant.WEBSITE_LINK, orgProfileBean.getWebsiteLink());
				dataMap.put(ApplicationConstant.PRESENCE_AREA, orgProfileBean.getPresenceArea());

				return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));

			}
		}

		return MessageUtility.createErrorMessage("Profile cannot be updated,Kindly try after some time!!!");
	}

	public String createOrgEvent(HashMap<String, String> reqDataMap) {
		log.info("Inside CoreOrgHelperService/createOrgEvent()");

		OrgEventBean orgEventBean = null;
		String eventId = null;
		String dbResponse = null;
		HashMap<String, Object> dataMap = null;
		HashMap<String, String> notificationDetailMap = null;

		log.info("orgRegistrationDataMap : " + reqDataMap);

		if (null != reqDataMap) {
			eventId = IdGeneratorUtility.generateEventId(reqDataMap);

			orgEventBean = new OrgEventBean();

			orgEventBean.setOrgId(reqDataMap.get(ApplicationConstant.ORG_ID));
			orgEventBean.setOrgName(reqDataMap.get(ApplicationConstant.NAME));
			orgEventBean.setEventId(eventId);
			orgEventBean.setTitle(reqDataMap.get(ApplicationConstant.TITLE));
			orgEventBean.setSubTitle(reqDataMap.get(ApplicationConstant.SUB_TITLE));
			orgEventBean.setDiscription(reqDataMap.get(ApplicationConstant.DISCRIPTION));
			orgEventBean.setLocation(reqDataMap.get(ApplicationConstant.LOCATION));
			orgEventBean.setCategory(reqDataMap.get(ApplicationConstant.CATEGORY));
			orgEventBean.setStartDt(reqDataMap.get(ApplicationConstant.START_DATE));
			orgEventBean.setEndDt(reqDataMap.get(ApplicationConstant.END_DATE));
			orgEventBean.setOthers(reqDataMap.get(ApplicationConstant.OTHERS));
			orgEventBean.setCreatedBy(ApplicationConstant.SYSTEM_CREATED_BY);
			orgEventBean.setCreateDt(DateUtility.getTimeStamp());
			orgEventBean.setDeleteFlag(ApplicationConstant.DEL_FLAG);

		}

		if (log.isInfoEnabled()) {
			log.info("orgEventBean : " + orgEventBean);
		}

		dbResponse = coreOrgHelperDao.createEvent(orgEventBean);

		if (dbResponse.equals(ApplicationConstant.TRUE)) {
			dataMap = new HashMap<String, Object>();
			dataMap.put(ApplicationConstant.EVENT_ID, eventId);

			notificationDetailMap = new HashMap<String, String>();
			notificationDetailMap.put(ApplicationConstant.NOTIFICATION_TYPE, ApplicationConstant.EVENT_TYPE);
			notificationDetailMap.put(ApplicationConstant.ORG_ID, orgEventBean.getOrgId());
			notificationDetailMap.put(ApplicationConstant.NAME, orgEventBean.getOrgName());
			notificationDetailMap.put(ApplicationConstant.EVENT_ID, orgEventBean.getEventId());
			notificationDetailMap.put(ApplicationConstant.TITLE, orgEventBean.getTitle());
			notificationDetailMap.put(ApplicationConstant.LOCATION, orgEventBean.getLocation());
			notificationDetailMap.put(ApplicationConstant.DISCRIPTION, orgEventBean.getDiscription());
			notificationDetailMap.put(ApplicationConstant.NOTIFICATION_ID,
					reqDataMap.get(ApplicationConstant.NOTIFICATION_ID));
			//fcmPeerNotificationService.sendPeerToPeerNotification(notificationDetailMap);
			fcmBroadcastService.sendBroadcastNotification(notificationDetailMap);
			

			return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));
		} else {
			return MessageUtility
					.createErrorMessage("Some issues while creating event for you, Kindly create again!!!");
		}

	}

	public String updateOrgEvent(HashMap<String, String> reqDataMap) {

		log.info("Inside CoreOrgHelperService/updateOrgEvent()");

		OrgEventBean orgEventBean = null;
		String dbResponse = null;
		HashMap<String, Object> dataMap = null;

		log.info("orgRegistrationDataMap : " + reqDataMap);

		if (null != reqDataMap) {

			orgEventBean = new OrgEventBean();

			orgEventBean.setOrgId(reqDataMap.get(ApplicationConstant.ORG_ID));
			orgEventBean.setEventId(reqDataMap.get(ApplicationConstant.EVENT_ID));
			orgEventBean.setTitle(reqDataMap.get(ApplicationConstant.TITLE));
			orgEventBean.setSubTitle(reqDataMap.get(ApplicationConstant.SUB_TITLE));
			orgEventBean.setDiscription(reqDataMap.get(ApplicationConstant.DISCRIPTION));
			orgEventBean.setLocation(reqDataMap.get(ApplicationConstant.LOCATION));
			orgEventBean.setCategory(reqDataMap.get(ApplicationConstant.CATEGORY));
			orgEventBean.setStartDt(reqDataMap.get(ApplicationConstant.START_DATE));
			orgEventBean.setEndDt(reqDataMap.get(ApplicationConstant.END_DATE));
			orgEventBean.setOthers(reqDataMap.get(ApplicationConstant.OTHERS));
			orgEventBean.setModifiedBy(ApplicationConstant.SYSTEM_MODIFIED_BY);
			orgEventBean.setModifyDt(DateUtility.getTimeStamp());
			orgEventBean.setDeleteFlag(ApplicationConstant.DEL_FLAG);

		}

		log.info("orgEventBean : " + orgEventBean);

		dbResponse = coreOrgHelperDao.updateEvent(orgEventBean);

		if (dbResponse.equals(ApplicationConstant.TRUE)) {
			dataMap = new HashMap<String, Object>();
			return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));
		} else {
			return MessageUtility
					.createErrorMessage("Some issues while updating event for you, Kindly update again!!!");
		}
	}

	public String deleteOrgEvent(HashMap<String, String> reqDataMap) {

		log.info("Inside CoreOrgHelperService/deleteOrgEvent()");

		OrgEventBean orgEventBean = null;
		String dbResponse = null;
		HashMap<String, Object> dataMap = null;

		log.info("orgRegistrationDataMap : " + reqDataMap);

		if (null != reqDataMap) {
			orgEventBean = new OrgEventBean();

			orgEventBean.setOrgId(reqDataMap.get(ApplicationConstant.ORG_ID));
			orgEventBean.setEventId(reqDataMap.get(ApplicationConstant.EVENT_ID));
			orgEventBean.setModifiedBy(ApplicationConstant.SYSTEM_MODIFIED_BY);
			orgEventBean.setModifyDt(DateUtility.getTimeStamp());
			orgEventBean.setDeleteFlag(ApplicationConstant.ACTIVE_DEL_FLAG);
		}

		log.info("orgEventBean : " + orgEventBean);

		dbResponse = coreOrgHelperDao.deleteEvent(orgEventBean);

		if (dbResponse.equals(ApplicationConstant.TRUE)) {
			dataMap = new HashMap<String, Object>();
			return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));
		} else {
			return MessageUtility
					.createErrorMessage("Some issues while Deleting event for you, Kindly update again!!!");
		}
	}

	public String syncOrgEvent(HashMap<String, String> reqDataMap) {
		log.info("Inside CoreOrgHelperService/syncOrgEvent()");

		OrgEventBean orgEventBean = null;
		HashMap<String, Object> dataMap = null;
		List<OrgEventBean> orgEventList = null;
		log.info("orgRegistrationDataMap : " + reqDataMap);

		if (null != reqDataMap) {
			orgEventBean = new OrgEventBean();

			orgEventBean.setOrgId(String.valueOf(reqDataMap.get(ApplicationConstant.ORG_ID)));
			orgEventBean.setDeleteFlag(ApplicationConstant.DEL_FLAG);
		}

		log.info("orgEventBean : " + orgEventBean);
		log.info("reqDataMap : " + reqDataMap);

		orgEventList = coreOrgHelperDao.syncEvent(orgEventBean, reqDataMap.get(ApplicationConstant.LAST_SYNC_DATE));

		if (null != orgEventList) {
			dataMap = new HashMap<String, Object>();
			dataMap.put(ApplicationConstant.EVENT_LIST, orgEventList);
			dataMap.put(ApplicationConstant.LAST_SYNC_DATE, DateUtility.getTimeStamp());
			return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));

		} else {
			return MessageUtility
					.createErrorMessage("Some issues while fetching event data for you, Kindly try after some time!!!");
		}
	}

	public String createOrgAchievement(HashMap<String, Object> reqDataMap) {
		log.info("Inside CoreOrgHelperService/createOrgAchievement()");

		OrgAchievementBean orgAchievementBean = null;
		String dbResponse = null;
		HashMap<String, Object> dataMap = null;
		ArrayList<String> imagePathList = null;
		ArrayList<String> imageList = null;
		ArrayList<String> responseImgUrlList = null;
		HashMap<String, String> notificationDetailMap = null;

		log.info("orgRegistrationDataMap : " + reqDataMap);

		if (null != reqDataMap) {

			orgAchievementBean = new OrgAchievementBean();

			orgAchievementBean.setOrgId(String.valueOf(reqDataMap.get(ApplicationConstant.ORG_ID)));
			orgAchievementBean.setOrgName(String.valueOf(reqDataMap.get(ApplicationConstant.NAME)));
			orgAchievementBean.setAchievementId(IdGeneratorUtility.generateAchievementId(reqDataMap));
			orgAchievementBean.setTitle(String.valueOf(reqDataMap.get(ApplicationConstant.TITLE)));
			orgAchievementBean.setSubTitle(String.valueOf(reqDataMap.get(ApplicationConstant.SUB_TITLE)));
			orgAchievementBean.setDiscription(String.valueOf(reqDataMap.get(ApplicationConstant.DISCRIPTION)));
			imageList = (ArrayList<String>) reqDataMap.get(ApplicationConstant.ORG_ACHIEVEMENT_IMG);
			responseImgUrlList = new ArrayList<String>();
			if (null != imageList && imageList.size() > 0) {

				imagePathList = imageService.saveAcievementImage(reqDataMap);
				log.info("achievement image path is : " + imagePathList);

				if (imagePathList.size() == 1) {
					log.info("case 1");
					orgAchievementBean.setImage1(imagePathList.get(0));

					responseImgUrlList.add(orgAchievementBean.getImage1());
				}

				if (imagePathList.size() == 2) {
					log.info("case 2");
					orgAchievementBean.setImage1(imagePathList.get(0));
					orgAchievementBean.setImage2(imagePathList.get(1));

					responseImgUrlList.add(orgAchievementBean.getImage1());
					responseImgUrlList.add(orgAchievementBean.getImage2());
				}
				if (imagePathList.size() == 3) {
					log.info("case 3");
					orgAchievementBean.setImage1(imagePathList.get(0));
					orgAchievementBean.setImage2(imagePathList.get(1));
					orgAchievementBean.setImage3(imagePathList.get(2));

					responseImgUrlList.add(orgAchievementBean.getImage1());
					responseImgUrlList.add(orgAchievementBean.getImage2());
					responseImgUrlList.add(orgAchievementBean.getImage3());
				}

				if (imagePathList.size() == 4) {
					log.info("case 4");
					orgAchievementBean.setImage1(imagePathList.get(0));
					orgAchievementBean.setImage2(imagePathList.get(1));
					orgAchievementBean.setImage3(imagePathList.get(2));
					orgAchievementBean.setImage4(imagePathList.get(3));

					responseImgUrlList.add(orgAchievementBean.getImage1());
					responseImgUrlList.add(orgAchievementBean.getImage2());
					responseImgUrlList.add(orgAchievementBean.getImage3());
					responseImgUrlList.add(orgAchievementBean.getImage4());

				}

			}

			orgAchievementBean.setCreatedBy(ApplicationConstant.SYSTEM_CREATED_BY);
			orgAchievementBean.setCreateDt(DateUtility.getTimeStamp());
			orgAchievementBean.setDeleteFlag(ApplicationConstant.DEL_FLAG);

		}

		log.info("orgAchievementBean : " + orgAchievementBean);

		dbResponse = coreOrgHelperDao.createAchievement(orgAchievementBean);

		if (dbResponse.equals(ApplicationConstant.TRUE)) {

			dataMap = new HashMap<String, Object>();
			dataMap.put(ApplicationConstant.ACHIEVEMENT_ID, orgAchievementBean.getAchievementId());
			dataMap.put(ApplicationConstant.ORG_ACHIEVEMENT_IMG, responseImgUrlList);
			
			notificationDetailMap = new HashMap<String, String>();
			notificationDetailMap.put(ApplicationConstant.NOTIFICATION_TYPE, ApplicationConstant.ACHIEVEMENT_TYPE);
			notificationDetailMap.put(ApplicationConstant.ORG_ID, orgAchievementBean.getOrgId());
			notificationDetailMap.put(ApplicationConstant.NAME, orgAchievementBean.getOrgName());
			notificationDetailMap.put(ApplicationConstant.ACHIEVEMENT_ID, orgAchievementBean.getAchievementId());
			notificationDetailMap.put(ApplicationConstant.TITLE, orgAchievementBean.getTitle());
			notificationDetailMap.put(ApplicationConstant.DISCRIPTION, orgAchievementBean.getDiscription());
			notificationDetailMap.put(ApplicationConstant.NOTIFICATION_ID,String.valueOf(reqDataMap.get(ApplicationConstant.NOTIFICATION_ID)));
			//fcmPeerNotificationService.sendPeerToPeerNotification(notificationDetailMap);
			fcmBroadcastService.sendBroadcastNotification(notificationDetailMap);
			
			
			
			return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));
		} else {
			return MessageUtility
					.createErrorMessage("Some issues while creating Achievement for you, Kindly create again!!!");
		}
	}

	public String updateOrgAchievement(HashMap<String, Object> reqDataMap) {
		log.info("Inside CoreOrgHelperService/updateOrgAchievement()");

		OrgAchievementBean orgAchievementBean = null;
		String dbResponse = null;
		HashMap<String, Object> dataMap = null;
		ArrayList<String> imagePathList = null;
		ArrayList<String> imageList = null;
		ArrayList<String> responseImgUrlList = null;

		log.info("orgRegistrationDataMap : " + reqDataMap);

		if (null != reqDataMap) {

			orgAchievementBean = new OrgAchievementBean();

			orgAchievementBean.setOrgId(String.valueOf(reqDataMap.get(ApplicationConstant.ORG_ID)));
			orgAchievementBean.setAchievementId(String.valueOf(reqDataMap.get(ApplicationConstant.ACHIEVEMENT_ID)));
			orgAchievementBean.setTitle(String.valueOf(reqDataMap.get(ApplicationConstant.TITLE)));
			orgAchievementBean.setSubTitle(String.valueOf(reqDataMap.get(ApplicationConstant.SUB_TITLE)));
			orgAchievementBean.setDiscription(String.valueOf(reqDataMap.get(ApplicationConstant.DISCRIPTION)));
			imageList = (ArrayList<String>) reqDataMap.get(ApplicationConstant.ORG_ACHIEVEMENT_IMG);

			responseImgUrlList = new ArrayList<String>();
			if (null != imageList && imageList.size() > 0) {

				imagePathList = imageService.saveAcievementImage(reqDataMap);
				log.info("achievement image path is : " + imagePathList);

				if (imagePathList.size() == 1) {
					log.info("case 1");
					orgAchievementBean.setImage1(imagePathList.get(0));

					responseImgUrlList.add(orgAchievementBean.getImage1());
				}

				if (imagePathList.size() == 2) {
					log.info("case 2");
					orgAchievementBean.setImage1(imagePathList.get(0));
					orgAchievementBean.setImage2(imagePathList.get(1));

					responseImgUrlList.add(orgAchievementBean.getImage1());
					responseImgUrlList.add(orgAchievementBean.getImage2());
				}
				if (imagePathList.size() == 3) {
					log.info("case 3");
					orgAchievementBean.setImage1(imagePathList.get(0));
					orgAchievementBean.setImage2(imagePathList.get(1));
					orgAchievementBean.setImage3(imagePathList.get(2));

					responseImgUrlList.add(orgAchievementBean.getImage1());
					responseImgUrlList.add(orgAchievementBean.getImage2());
					responseImgUrlList.add(orgAchievementBean.getImage3());
				}

				if (imagePathList.size() == 4) {
					log.info("case 4");
					orgAchievementBean.setImage1(imagePathList.get(0));
					orgAchievementBean.setImage2(imagePathList.get(1));
					orgAchievementBean.setImage3(imagePathList.get(2));
					orgAchievementBean.setImage4(imagePathList.get(3));

					responseImgUrlList.add(orgAchievementBean.getImage1());
					responseImgUrlList.add(orgAchievementBean.getImage2());
					responseImgUrlList.add(orgAchievementBean.getImage3());
					responseImgUrlList.add(orgAchievementBean.getImage4());

				}
			}

			orgAchievementBean.setModifiedBy(ApplicationConstant.SYSTEM_MODIFIED_BY);
			orgAchievementBean.setModifyDt(DateUtility.getTimeStamp());
			orgAchievementBean.setDeleteFlag(ApplicationConstant.DEL_FLAG);

		}

		log.info("orgAchievementBean : " + orgAchievementBean);

		dbResponse = coreOrgHelperDao.updateAchievement(orgAchievementBean);

		if (dbResponse.equals(ApplicationConstant.TRUE)) {

			dataMap = new HashMap<String, Object>();
			dataMap.put(ApplicationConstant.ACHIEVEMENT_ID, orgAchievementBean.getAchievementId());
			dataMap.put(ApplicationConstant.ORG_ACHIEVEMENT_IMG, responseImgUrlList);
			return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));
		} else {
			return MessageUtility
					.createErrorMessage("Some issues while updating Achievement for you, Kindly create again!!!");
		}
	}

	public String syncOrgAchievement(HashMap<String, String> reqDataMap) {
		log.info("Inside CoreOrgHelperService/syncOrgAchievement()");

		OrgAchievementBean orgAchievementBean = null;
		HashMap<String, Object> dataMap = null;
		List<OrgAchievementBean> orgAchievementList = null;

		log.info("orgRegistrationDataMap : " + reqDataMap);

		if (null != reqDataMap) {
			orgAchievementBean = new OrgAchievementBean();

			orgAchievementBean.setOrgId(String.valueOf(reqDataMap.get(ApplicationConstant.ORG_ID)));
			orgAchievementBean.setDeleteFlag(ApplicationConstant.DEL_FLAG);
		}

		log.info("orgAchievementBean : " + orgAchievementBean);

		orgAchievementList = coreOrgHelperDao.syncAchievement(orgAchievementBean,
				reqDataMap.get(ApplicationConstant.LAST_SYNC_DATE));

		if (null != orgAchievementList) {
			dataMap = new HashMap<String, Object>();
			dataMap.put(ApplicationConstant.ORG_LIST, orgAchievementList);
			// System.out.println(DateUtility.getTimeStamp());
			dataMap.put(ApplicationConstant.LAST_SYNC_DATE, DateUtility.getTimeStamp());
			return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));

		} else {
			return MessageUtility.createErrorMessage(
					"Some issues while Sync Achievement data for you, Kindly try after some time!!!");
		}
	}

	public String deleteOrgAchievement(HashMap<String, Object> reqDataMap) {
		log.info("Inside CoreOrgHelperService/deleteOrgAchievement()");

		OrgAchievementBean orgAchievementBean = null;
		String dbResponse = null;
		HashMap<String, Object> dataMap = null;

		log.info("orgRegistrationDataMap : " + reqDataMap);

		if (null != reqDataMap) {
			orgAchievementBean = new OrgAchievementBean();

			orgAchievementBean.setOrgId(String.valueOf(reqDataMap.get(ApplicationConstant.ORG_ID)));
			orgAchievementBean.setAchievementId((String.valueOf(reqDataMap.get(ApplicationConstant.ACHIEVEMENT_ID))));
			orgAchievementBean.setModifiedBy(ApplicationConstant.SYSTEM_MODIFIED_BY);
			orgAchievementBean.setModifyDt(DateUtility.getTimeStamp());
			orgAchievementBean.setDeleteFlag(ApplicationConstant.ACTIVE_DEL_FLAG);
		}

		log.info("orgAchievementBean : " + orgAchievementBean);

		dbResponse = coreOrgHelperDao.deleteAchievement(orgAchievementBean);

		if (dbResponse.equals(ApplicationConstant.TRUE)) {
			dataMap = new HashMap<String, Object>();
			return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));
		} else {
			return MessageUtility
					.createErrorMessage("Some issues while Deleting Achievement for you, Kindly try again!!!");
		}
	}

	public String createOrgRequest(HashMap<String, String> reqDataMap) {
		log.info("Inside CoreOrgHelperService/createOrgRequest()");

		OrgRequestBean orgRequestBean = null;
		String requestId = null;
		String dbResponse = null;
		HashMap<String, Object> dataMap = null;
		HashMap<String, String> notificationDetailMap = null;

		log.info("orgRequestDataMap : " + reqDataMap);

		if (null != reqDataMap) {
			requestId = IdGeneratorUtility.generateRequestId(reqDataMap);

			orgRequestBean = new OrgRequestBean();

			orgRequestBean.setOrgId(reqDataMap.get(ApplicationConstant.ORG_ID));
			orgRequestBean.setOrgName(reqDataMap.get(ApplicationConstant.NAME));
			orgRequestBean.setRequestId(requestId);
			orgRequestBean.setTitle(reqDataMap.get(ApplicationConstant.TITLE));
			orgRequestBean.setSubTitle(reqDataMap.get(ApplicationConstant.SUB_TITLE));
			orgRequestBean.setDiscription(reqDataMap.get(ApplicationConstant.DISCRIPTION));
			orgRequestBean.setLocation(reqDataMap.get(ApplicationConstant.LOCATION));
			orgRequestBean.setOthers(reqDataMap.get(ApplicationConstant.OTHERS));
			orgRequestBean.setCreatedBy(ApplicationConstant.SYSTEM_CREATED_BY);
			orgRequestBean.setCreateDt(DateUtility.getTimeStamp());
			orgRequestBean.setDeleteFlag(ApplicationConstant.DEL_FLAG);

		}

		log.info("orgRequestBean : " + orgRequestBean);

		dbResponse = coreOrgHelperDao.createRequest(orgRequestBean);

		if (dbResponse.equals(ApplicationConstant.TRUE)) {
			dataMap = new HashMap<String, Object>();
			dataMap.put(ApplicationConstant.REQUEST_ID, requestId);
			
			notificationDetailMap = new HashMap<String, String>();
			notificationDetailMap.put(ApplicationConstant.NOTIFICATION_TYPE, ApplicationConstant.REQUEST_TYPE);
			notificationDetailMap.put(ApplicationConstant.NAME, orgRequestBean.getOrgName());
			notificationDetailMap.put(ApplicationConstant.ORG_ID, orgRequestBean.getOrgId());
			notificationDetailMap.put(ApplicationConstant.REQUEST_ID, orgRequestBean.getRequestId());
			notificationDetailMap.put(ApplicationConstant.TITLE, orgRequestBean.getTitle());
			notificationDetailMap.put(ApplicationConstant.DISCRIPTION, orgRequestBean.getDiscription());
			notificationDetailMap.put(ApplicationConstant.NOTIFICATION_ID,String.valueOf(reqDataMap.get(ApplicationConstant.NOTIFICATION_ID)));
			//fcmPeerNotificationService.sendPeerToPeerNotification(notificationDetailMap);
			
			
			fcmBroadcastService.sendBroadcastNotification(notificationDetailMap);
			
			
			return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));
		} else {
			return MessageUtility
					.createErrorMessage("Some issues while creating request for you, Kindly create again!!!");
		}
	}

	public String syncOrgRequest(HashMap<String, String> reqDataMap) {
		log.info("Inside CoreOrgHelperService/syncOrgRequest()");

		OrgRequestBean orgRequestBean = null;
		HashMap<String, Object> dataMap = null;
		List<OrgRequestBean> orgRequestList = null;

		log.info("org request Data Map : " + reqDataMap);

		if (null != reqDataMap) {
			orgRequestBean = new OrgRequestBean();

			orgRequestBean.setOrgId(String.valueOf(reqDataMap.get(ApplicationConstant.ORG_ID)));
			orgRequestBean.setDeleteFlag(ApplicationConstant.DEL_FLAG);
		}

		log.info("orgRequestBean : " + orgRequestBean);

		orgRequestList = coreOrgHelperDao.syncRequest(orgRequestBean,
				reqDataMap.get(ApplicationConstant.LAST_SYNC_DATE));

		if (null != orgRequestList) {
			dataMap = new HashMap<String, Object>();
			dataMap.put(ApplicationConstant.ORG_REQ_LIST, orgRequestList);
			dataMap.put(ApplicationConstant.LAST_SYNC_DATE, DateUtility.getTimeStamp());
			return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));

		} else {
			return MessageUtility
					.createErrorMessage("Some issues while Sync Request data for you, Kindly try after some time!!!");
		}
	}

	public String deleteOrgRequest(HashMap<String, Object> reqDataMap) {
		log.info("Inside CoreOrgHelperService/deleteOrgRequest()");

		OrgRequestBean orgRequestBean = null;
		String dbResponse = null;
		HashMap<String, Object> dataMap = null;

		log.info("org Request DataMap : " + reqDataMap);

		if (null != reqDataMap) {
			orgRequestBean = new OrgRequestBean();

			orgRequestBean.setOrgId(String.valueOf(reqDataMap.get(ApplicationConstant.ORG_ID)));
			orgRequestBean.setRequestId((String.valueOf(reqDataMap.get(ApplicationConstant.REQUEST_ID))));
			orgRequestBean.setModifiedBy(ApplicationConstant.SYSTEM_MODIFIED_BY);
			orgRequestBean.setModifyDt(DateUtility.getTimeStamp());
			orgRequestBean.setDeleteFlag(ApplicationConstant.ACTIVE_DEL_FLAG);
		}

		log.info("orgRequestBean : " + orgRequestBean);

		dbResponse = coreOrgHelperDao.deleteRequest(orgRequestBean);

		if (dbResponse.equals(ApplicationConstant.TRUE)) {
			dataMap = new HashMap<String, Object>();
			return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));
		} else {
			return MessageUtility.createErrorMessage("Some issues while Deleting Request for you, Kindly try again!!!");
		}
	}

	public String updateOrgRequest(HashMap<String, Object> reqDataMap) {
		log.info("Inside CoreOrgHelperService/updateOrgRequest()");

		OrgRequestBean orgRequestBean = null;
		String dbResponse = null;
		HashMap<String, Object> dataMap = null;

		log.info("orgRegistrationDataMap : " + reqDataMap);

		if (null != reqDataMap) {

			orgRequestBean = new OrgRequestBean();

			orgRequestBean.setOrgId(String.valueOf(reqDataMap.get(ApplicationConstant.ORG_ID)));
			orgRequestBean.setRequestId(String.valueOf(reqDataMap.get(ApplicationConstant.REQUEST_ID)));
			orgRequestBean.setTitle(String.valueOf(reqDataMap.get(ApplicationConstant.TITLE)));
			orgRequestBean.setSubTitle(String.valueOf(reqDataMap.get(ApplicationConstant.SUB_TITLE)));
			orgRequestBean.setDiscription(String.valueOf(reqDataMap.get(ApplicationConstant.DISCRIPTION)));
			orgRequestBean.setModifiedBy(ApplicationConstant.SYSTEM_MODIFIED_BY);
			orgRequestBean.setModifyDt(DateUtility.getTimeStamp());
			orgRequestBean.setDeleteFlag(ApplicationConstant.DEL_FLAG);

		}

		log.info("orgRequestBean : " + orgRequestBean);

		dbResponse = coreOrgHelperDao.updateRequest(orgRequestBean);

		if (dbResponse.equals(ApplicationConstant.TRUE)) {

			dataMap = new HashMap<String, Object>();
			dataMap.put(ApplicationConstant.REQUEST_ID, orgRequestBean.getRequestId());
			return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));
		} else {
			return MessageUtility
					.createErrorMessage("Some issues while updating Request for you, Kindly create again!!!");
		}
	}

	public String fetchOrgProfile(HashMap<String, String> reqDataMap) {
		log.info("Inside CoreOrgHelperService/fetchOrgProfile()");

		OrgProfileBean orgProfileBean = null;
		HashMap<String, Object> dataMap = null;
		List<OrgProfileBean> orgProfileList = null;

		if (null != reqDataMap) {
			orgProfileBean = new OrgProfileBean();
			orgProfileBean.setOrgId(reqDataMap.get(ApplicationConstant.ORG_ID));

			orgProfileList = coreOrgHelperDao.fetchOrgProfile(orgProfileBean);

			if (orgProfileList.size() > 0 && orgProfileList.size() < 2) {
				dataMap = new HashMap<String, Object>();
				dataMap.put(ApplicationConstant.ORG_PROFILE_LIST, orgProfileList);
				return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));
			} else {
				dataMap = new HashMap<String, Object>();
				return MessageUtility.createErrorMessage(
						"Some issues while fetching orgnazation profile for you, Kindly check after some time!!!");
			}
		}
		return MessageUtility
				.createErrorMessage("Some issues while processing your request, Kindly check after some time!!!");

	}

	public String forgotPassword(HashMap<String, String> reqDataMap) {
		log.info("Inside CoreOrgHelperService/forgotPassword()");

		OrgRegistrationBean orgRegistrationBean = null;

		HashMap<String, Object> dataMap = null;

		if (null != reqDataMap) {
			orgRegistrationBean = new OrgRegistrationBean();
			orgRegistrationBean.setMobileNo(reqDataMap.get(ApplicationConstant.FLASH_USER_ID));

			log.info("orgRegistrationBean : " + orgRegistrationBean);

		}

		List<OrgRegistrationBean> registeredOrgList = coreOrgHelperDao.validateUserId(orgRegistrationBean);

		if (registeredOrgList.size() == 0) {
			return MessageUtility
					.createErrorMessage("Mobile no / Email id not associiated with Paalan, Kinldy register with us.");
		} else if (registeredOrgList.size() > 0 && registeredOrgList.size() < 2) {
			dataMap = new HashMap<String, Object>();

			String otp = IdGeneratorUtility.generateOtp();
			reqDataMap.put(ApplicationConstant.FLASH_CUST_OTP, otp);

			sendMailService.sendMailService(reqDataMap, registeredOrgList.get(0));

			dataMap.put(ApplicationConstant.FLASH_CUST_OTP, otp);

			return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));
		} else {
			return MessageUtility.createErrorMessage("Kinldy check login credentials !!!");
		}
	}

	public String updatePassword(HashMap<String, String> reqDataMap) {
		log.info("Inside CoreOrgHelperService/updatePassword()");

		OrgRegistrationBean orgRegistrationBean = null;
		String dbResponse = null;
		HashMap<String, Object> dataMap = null;

		if (null != reqDataMap) {
			orgRegistrationBean = new OrgRegistrationBean();
			orgRegistrationBean.setMobileNo(reqDataMap.get(ApplicationConstant.FLASH_USER_ID));
			orgRegistrationBean.setPassword(reqDataMap.get(ApplicationConstant.FLASH_PASSWORD));
			orgRegistrationBean.setModifiedBy(ApplicationConstant.SYSTEM_MODIFIED_BY);
			orgRegistrationBean.setModifyDt(DateUtility.getTimeStamp());

			log.info("orgRegistrationBean : " + orgRegistrationBean);

		}

		dbResponse = coreOrgHelperDao.updatePassword(orgRegistrationBean);

		if (dbResponse.equals(ApplicationConstant.TRUE)) {

			dataMap = new HashMap<String, Object>();
			return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));
		} else {
			return MessageUtility
					.createErrorMessage("Some issues while updating Password for you, Kindly create again!!!");
		}

		
	}

	public String syncOrgRecord(HashMap<String, String> reqDataMap) 
	{
		log.info("Inside CoreOrgHelperService/syncOrgRequest()");

		OrgRequestBean orgRequestBean = null;
		OrgEventBean orgEventBean = null;
		OrgAchievementBean achievementBean = null;
		
		HashMap<String,Object> dbRequestMap = null;
		
		HashMap<String, Object> dataMap = null;
		List<Object> orgRecordList = null;

		log.info("org request Data Map : " + reqDataMap);

		if (null != reqDataMap)
		{
			dbRequestMap = new HashMap<String, Object>();
			
			if(reqDataMap.get(ApplicationConstant.NOTIFICATION_TYPE).equals(ApplicationConstant.EVENT_TYPE))
			{
				orgEventBean = new OrgEventBean();
				orgEventBean.setOrgId(reqDataMap.get(ApplicationConstant.ORG_ID));
				orgEventBean.setEventId(reqDataMap.get(ApplicationConstant.RECORD_ID));
				orgEventBean.setDeleteFlag(ApplicationConstant.DEL_FLAG);
				
				dbRequestMap.put(ApplicationConstant.RECORD_TYPE, orgEventBean);
				
			}
			
			if(reqDataMap.get(ApplicationConstant.NOTIFICATION_TYPE).equals(ApplicationConstant.REQUEST_TYPE))
			{
				orgRequestBean = new OrgRequestBean();
				orgRequestBean.setOrgId(reqDataMap.get(ApplicationConstant.ORG_ID));
				orgRequestBean.setRequestId(reqDataMap.get(ApplicationConstant.RECORD_ID));
				orgRequestBean.setDeleteFlag(ApplicationConstant.DEL_FLAG);
				
				dbRequestMap.put(ApplicationConstant.RECORD_TYPE, orgRequestBean);
			}
			
			if(reqDataMap.get(ApplicationConstant.NOTIFICATION_TYPE).equals(ApplicationConstant.ACHIEVEMENT_TYPE))
			{
				achievementBean = new OrgAchievementBean();
				achievementBean.setOrgId(reqDataMap.get(ApplicationConstant.ORG_ID));
				achievementBean.setAchievementId(reqDataMap.get(ApplicationConstant.RECORD_ID));
				achievementBean.setDeleteFlag(ApplicationConstant.DEL_FLAG);
				
				dbRequestMap.put(ApplicationConstant.RECORD_TYPE, achievementBean);
			}
			
			dbRequestMap.put(ApplicationConstant.ORG_ID, reqDataMap.get(ApplicationConstant.ORG_ID));
			dbRequestMap.put(ApplicationConstant.RECORD_ID, reqDataMap.get(ApplicationConstant.RECORD_ID));
		}
		
		
		
		orgRecordList = coreOrgHelperDao.fetchNotificationRecord(dbRequestMap);

		if (null != orgRecordList)
		{
			dataMap = new HashMap<String, Object>();
			dataMap.put(ApplicationConstant.ORG_REC_LIST, orgRecordList);
			return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));

		} else {
			return MessageUtility
					.createErrorMessage("Some issues while Sync Request data for you, Kindly try after some time!!!");
		}
	}

}
