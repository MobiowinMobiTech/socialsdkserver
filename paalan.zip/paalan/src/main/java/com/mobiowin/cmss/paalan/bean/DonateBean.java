package com.mobiowin.cmss.paalan.bean;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "paalan_donate_master", catalog = "paalan")
public class DonateBean implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private String id;
	
	@Column(name = "name")
	private String name;
	
	@Column(name = "email_id")
	private String emailId;
	
	@Column(name = "mobile_no")
	private String mobileNo;
	
	@Column(name = "message")
	private String message;
	
	@Column(name = "category")
	private String category;
	
	@Column(name = "address")
	private String address;
	
	@Column(name = "request_date")
	private Timestamp requestDate;
	
	@Column(name = "collection_mode")
	private String collectionMode;
	
	@Column(name = "free_text1")
	private String freeText1;
	
	@Column(name = "free_text2")
	private String freeText2;
	
	@Column(name = "free_text3")
	private String freeText3;
	

	@Column(name = "free_text4")
	private String freeText4;
	
	@Column(name = "donate_item_img")
	private String img;
	
	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_dt")
	private Date createDt;

	@Column(name = "modified_by")
	private String modifiedBy;

	@Column(name = "modified_dt")
	private Date modifyDt;

	@Column(name = "del_flag")
	private String deleteFlag;

	public DonateBean() {
		super();
	}

	public DonateBean(String id, String name, String emailId, String mobileNo, String message, String category,
			String address, Timestamp requestDate, String collectionMode, String freeText1, String freeText2,
			String freeText3, String freeText4, String createdBy, Date createDt, String modifiedBy, Date modifyDt,
			String deleteFlag,String img) {
		super();
		this.id = id;
		this.name = name;
		this.emailId = emailId;
		this.mobileNo = mobileNo;
		this.message = message;
		this.category = category;
		this.address = address;
		this.requestDate = requestDate;
		this.collectionMode = collectionMode;
		this.freeText1 = freeText1;
		this.freeText2 = freeText2;
		this.freeText3 = freeText3;
		this.freeText4 = freeText4;
		this.img = img;
		this.createdBy = createdBy;
		this.createDt = createDt;
		this.modifiedBy = modifiedBy;
		this.modifyDt = modifyDt;
		this.deleteFlag = deleteFlag;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Timestamp getRequestDate() {
		return requestDate;
	}

	public void setRequestDate(Timestamp requestDate) {
		this.requestDate = requestDate;
	}

	public String getCollectionMode() {
		return collectionMode;
	}

	public void setCollectionMode(String collectionMode) {
		this.collectionMode = collectionMode;
	}

	public String getFreeText1() {
		return freeText1;
	}

	public void setFreeText1(String freeText1) {
		this.freeText1 = freeText1;
	}

	public String getFreeText2() {
		return freeText2;
	}

	public void setFreeText2(String freeText2) {
		this.freeText2 = freeText2;
	}

	public String getFreeText3() {
		return freeText3;
	}

	public void setFreeText3(String freeText3) {
		this.freeText3 = freeText3;
	}

	public String getFreeText4() {
		return freeText4;
	}

	public void setFreeText4(String freeText4) {
		this.freeText4 = freeText4;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Date createDt) {
		this.createDt = createDt;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifyDt() {
		return modifyDt;
	}

	public void setModifyDt(Date modifyDt) {
		this.modifyDt = modifyDt;
	}

	public String getDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}
	
	

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}

	@Override
	public String toString() {
		return "DonateBean [id=" + id + ", name=" + name + ", emailId=" + emailId + ", mobileNo=" + mobileNo
				+ ", message=" + message + ", category=" + category + ", address=" + address + ", requestDate="
				+ requestDate + ", collectionMode=" + collectionMode + ", freeText1=" + freeText1 + ", freeText2="
				+ freeText2 + ", freeText3=" + freeText3 + ", freeText4=" + freeText4 + ", img=" + img + ", createdBy="
				+ createdBy + ", createDt=" + createDt + ", modifiedBy=" + modifiedBy + ", modifyDt=" + modifyDt
				+ ", deleteFlag=" + deleteFlag + "]";
	}
	
	

}
