package com.mobiowin.cmss.paalan.commons;

import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.codehaus.jackson.map.ObjectMapper;

public class MessageUtility {

	private static ObjectMapper objectMapper = new ObjectMapper();

	@SuppressWarnings("rawtypes")
	public static String createJSONFromMap(Map dataMap)
	{
		try
		{
			ByteArrayOutputStream baos = new ByteArrayOutputStream();

			objectMapper.writeValue(baos, dataMap);

			return baos.toString();
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}
	
	public static void main(String[] args) {
		
		HashMap<String,String> resMap = new HashMap<String, String>();
		resMap.put("id","101431596021671174718");
		resMap.put("name","Shailendra");
		
		System.out.println( "<--------------->" + MessageUtility.createJSONFromMap(resMap));
	}

	public static String createErrorMessage() 
	{
		
		try
		{
			Map<String,Object> errorMap = new HashMap<String,Object>();
			List<Map<String,Object>> lists = new LinkedList<Map<String,Object>>();

			errorMap.put(ApplicationConstant.STATUS, ApplicationConstant.ERROR);
			errorMap.put(ApplicationConstant.MESSAGE, "Some Thing Goes Bad..... Please Try After Some Time");
			errorMap.put(ApplicationConstant.DATA, lists);

			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			objectMapper.writeValue(baos, errorMap);

			return baos.toString();
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}
	
	
	
	public static String createSuccessMessage() 
	{
		
		try
		{
			Map<String,Object> errorMap = new HashMap<String,Object>();
			List<Map<String,Object>> lists = new LinkedList<Map<String,Object>>();

			errorMap.put(ApplicationConstant.STATUS, ApplicationConstant.SUCCESS);
			errorMap.put(ApplicationConstant.MESSAGE, String.valueOf(System.currentTimeMillis()));
			errorMap.put(ApplicationConstant.DATA, lists);

			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			objectMapper.writeValue(baos, errorMap);

			return baos.toString();
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}
	
	public static HashMap<String, Object> createSuccessResponseMessage(HashMap<String, Object> leaveResponseMapList) {

		HashMap<String, Object> dataMap = new HashMap<String, Object>();
		List<Map<String, Object>> lists = new LinkedList<Map<String, Object>>();
		lists.add(leaveResponseMapList);

		dataMap.put(ApplicationConstant.STATUS, ApplicationConstant.SUCCESS);
		dataMap.put(ApplicationConstant.MESSAGE,
				String.valueOf(System.currentTimeMillis()));
		dataMap.put(ApplicationConstant.DATA, lists);

		return dataMap;
	}
	
	@SuppressWarnings("rawtypes")
	public static HashMap<String,Object> createResponseMessage(final List<HashMap> dataMapList)
	{
		HashMap<String,Object> dataMap = new HashMap<String,Object>();

		dataMap.put("status", "success");
		
		if (CollectionUtils.isEmpty(dataMapList))
		{
			dataMap.put("message", "Data submitted successfully");
		}
		
		else
		{
			dataMap.put("message", "");
		}
		
		dataMap.put("data", dataMapList);

		return dataMap;
	}
	
	public static String createErrorMessage(String errMsg)
	{
		try
		{
			Map<String, Object> errorMap = new HashMap<String, Object>();
			Map<String,Object> errMsgMap = new HashMap<String, Object>();
			errMsgMap.put(ApplicationConstant.ERR_MSG, errMsg);
			
			List<Map<String, Object>> lists = new LinkedList<Map<String, Object>>();

			lists.add(errMsgMap);
			
			errorMap.put(ApplicationConstant.STATUS, ApplicationConstant.ERROR);
			errorMap.put(ApplicationConstant.MESSAGE,String.valueOf(System.currentTimeMillis()));
			errorMap.put(ApplicationConstant.DATA, lists);

			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			objectMapper.writeValue(baos, errorMap);

			return baos.toString();
		} catch (Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}
	
	public static String createSuccessMessage(String successMsg)
	{
		try
		{
			Map<String, Object> successResMap = new HashMap<String, Object>();
			Map<String,Object> successResMsgMap = new HashMap<String, Object>();
			successResMsgMap.put(ApplicationConstant.SUCCESS_MESSAGE, successMsg);
			
			List<Map<String, Object>> lists = new LinkedList<Map<String, Object>>();

			lists.add(successResMsgMap);
			
			successResMap.put(ApplicationConstant.STATUS, ApplicationConstant.SUCCESS);
			successResMap.put(ApplicationConstant.MESSAGE,String.valueOf(System.currentTimeMillis()));
			successResMap.put(ApplicationConstant.DATA, lists);

			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			objectMapper.writeValue(baos, successResMap);

			return baos.toString();
			
		} catch (Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}

}
