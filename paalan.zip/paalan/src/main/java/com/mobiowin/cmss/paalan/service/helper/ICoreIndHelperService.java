package com.mobiowin.cmss.paalan.service.helper;

import java.util.HashMap;

public interface ICoreIndHelperService {

	String isExistingInd(HashMap<String, String> registrationDataMap);

	//String validateOrgLogin(HashMap<String, String> loginReqDataMap);

	String updateProfile(HashMap<String, String> profileReqDataMap);

	String validateIndLogin(HashMap<String, String> loginReqDataMap);

	String submitMessage(HashMap<String, String> reqDataMap);

	String submitDonaterequest(HashMap<String, String> reqDataMap);

	

}
