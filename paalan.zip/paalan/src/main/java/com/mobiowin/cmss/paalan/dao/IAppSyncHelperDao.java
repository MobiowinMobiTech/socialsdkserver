package com.mobiowin.cmss.paalan.dao;

import java.util.HashMap;
import java.util.List;

import com.mobiowin.cmss.paalan.bean.BroadcastMasterBean;
import com.mobiowin.cmss.paalan.bean.DeviceDetailBean;
import com.mobiowin.cmss.paalan.bean.ScreenMasterBean;
import com.mobiowin.cmss.paalan.bean.SliderMasterBean;

public interface IAppSyncHelperDao {

	boolean validateAppVersion(HashMap<String, String> appReqDataMap);

	List<SliderMasterBean> syncAppBanner(String string);

	List<ScreenMasterBean> syncScreen(String string);

	List<BroadcastMasterBean> syncBroadcastTopic(String string);

	boolean isUserExist(DeviceDetailBean deviceDetailBean);

	String submitUser(DeviceDetailBean deviceDetailBean);

	String updateUser(DeviceDetailBean deviceDetailBean);

}
