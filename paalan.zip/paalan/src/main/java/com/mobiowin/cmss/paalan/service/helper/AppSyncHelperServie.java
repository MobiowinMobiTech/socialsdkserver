package com.mobiowin.cmss.paalan.service.helper;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.cmss.paalan.bean.BroadcastMasterBean;
import com.mobiowin.cmss.paalan.bean.DeviceDetailBean;
import com.mobiowin.cmss.paalan.bean.ScreenMasterBean;
import com.mobiowin.cmss.paalan.bean.SliderMasterBean;
import com.mobiowin.cmss.paalan.commons.ApplicationConstant;
import com.mobiowin.cmss.paalan.commons.MessageUtility;
import com.mobiowin.cmss.paalan.dao.IAppSyncHelperDao;
import com.mobiowin.cmss.paalan.test.DateUtility;

@Service("appSyncService")
@Component
public class AppSyncHelperServie implements IAppSyncHelperServie {
	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private IAppSyncHelperDao appSyncDao;

	@Autowired
	private @Resource Map<String, String> Paalan;

	public boolean checkAppversion(HashMap<String, String> appReqDataMap) {
		log.info("AppSyncHelperServie/checkAppversion()");

		String appVersion = (String) Paalan.get("version");

		log.info("App version is : " + appVersion);

		boolean isValidVersion = false;

		if (appVersion.endsWith(appReqDataMap.get(ApplicationConstant.APP_VERSION))) {
			isValidVersion = true;
		}

		return isValidVersion;
	}

	public String generateSuccessResponse() {
		HashMap<String, Object> appVersioResMap = null;
		appVersioResMap = new HashMap<String, Object>();
		String response = MessageUtility
				.createJSONFromMap(MessageUtility.createSuccessResponseMessage(appVersioResMap));
		return response;
	}

	public String syncApplciationData() {
		// TODO Auto-generated method stub
		return null;
	}

	public String generateErrorResponse() {
		// TODO Auto-generated method stub
		return null;
	}

	public String submitDeviceDetails(HashMap<String, String> deviceDetailMap) {
		log.info("Inside AppSyncHelperServie/submitDeviceDetails");

		DeviceDetailBean deviceDetailBean = null;
		boolean isUserExist = false;
		String response = null;
		HashMap<String, Object> dataMap = null;

		if (null != deviceDetailMap) {
			deviceDetailBean = new DeviceDetailBean();
			deviceDetailBean.setImeiNo(deviceDetailMap.get(ApplicationConstant.IMEI_NO));
			deviceDetailBean.setDeviceId(deviceDetailMap.get(ApplicationConstant.DEVICE_ID));
			deviceDetailBean.setDeviceModel(deviceDetailMap.get(ApplicationConstant.DEVICE_MODEL));
			deviceDetailBean.setOsVersion(deviceDetailMap.get(ApplicationConstant.OS_VERSION));
			deviceDetailBean.setNotificationId(deviceDetailMap.get(ApplicationConstant.NOTIFICATION_ID));
			deviceDetailBean.setCreatedBy(ApplicationConstant.SYSTEM_CREATED_BY);
			deviceDetailBean.setCreateDt(DateUtility.getTimeStamp());
			deviceDetailBean.setDeleteFlag(ApplicationConstant.DEL_FLAG);
		}

		isUserExist = appSyncDao.isUserExist(deviceDetailBean);

		if (!isUserExist)
		{
			response = appSyncDao.submitUser(deviceDetailBean);

			if (response.equals(ApplicationConstant.TRUE))
			{
				dataMap = new HashMap<String, Object>();

				return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));
			}
		}
		else
		{
			deviceDetailBean.setModifiedBy(ApplicationConstant.SYSTEM_MODIFIED_BY);
			deviceDetailBean.setModifyDt(DateUtility.getTimeStamp());
			
			response = appSyncDao.updateUser(deviceDetailBean);
			
			if (response.equals(ApplicationConstant.TRUE))
			{
				dataMap = new HashMap<String, Object>();

				return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));
			}
		}
		return MessageUtility.createErrorMessage("Process failed due to technical issue!!! Kindly try after sometime");

	}

	public String appConfigSync(HashMap<String, String> reqDataMap) {

		log.info("Inside AppSyncHelperServie/appConfigSync()");
		HashMap<String, Object> dataMap = null;
		List<SliderMasterBean> sliderMasterList = null;
		List<ScreenMasterBean> screenMasterList = null;
		List<BroadcastMasterBean> broadcastTopicMasterList = null;

		log.info("orgRegistrationDataMap : " + reqDataMap);

		sliderMasterList = appSyncDao.syncAppBanner(reqDataMap.get(ApplicationConstant.LAST_SYNC_DATE));
		screenMasterList = appSyncDao.syncScreen(reqDataMap.get(ApplicationConstant.LAST_SYNC_DATE));
		broadcastTopicMasterList = appSyncDao.syncBroadcastTopic(reqDataMap.get(ApplicationConstant.LAST_SYNC_DATE));

		if (null != sliderMasterList && null != screenMasterList && null != broadcastTopicMasterList) {
			dataMap = new HashMap<String, Object>();
			dataMap.put(ApplicationConstant.BANNER_LIST, sliderMasterList);
			dataMap.put(ApplicationConstant.SCREEN_LIST, screenMasterList);
			dataMap.put(ApplicationConstant.BROADCAST_TOPIC_LIST, broadcastTopicMasterList);
			dataMap.put(ApplicationConstant.LAST_SYNC_DATE, DateUtility.getTimeStamp());
			return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));

		} else {
			return MessageUtility
					.createErrorMessage("Some issues while Sync App data for you, Kindly try after some time!!!");
		}

	}

}
