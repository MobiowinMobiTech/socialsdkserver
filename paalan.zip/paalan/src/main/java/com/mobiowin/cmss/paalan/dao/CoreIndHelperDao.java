package com.mobiowin.cmss.paalan.dao;

import java.sql.Timestamp;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.mobiowin.cmss.paalan.bean.ConnectBean;
import com.mobiowin.cmss.paalan.bean.DonateBean;
import com.mobiowin.cmss.paalan.bean.IndProfileBean;
import com.mobiowin.cmss.paalan.bean.IndRegistrationBean;
import com.mobiowin.cmss.paalan.bean.OrgAchievementBean;
import com.mobiowin.cmss.paalan.bean.OrgEventBean;
import com.mobiowin.cmss.paalan.bean.OrgProfileBean;
import com.mobiowin.cmss.paalan.bean.OrgRegistrationBean;
import com.mobiowin.cmss.paalan.bean.OrgRequestBean;
import com.mobiowin.cmss.paalan.commons.ApplicationConstant;
import com.mobiowin.cmss.paalan.test.DateUtility;

@Repository("coreIndHelperDao")
@Component
public class CoreIndHelperDao implements ICoreIndHelperDao {

	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private SessionFactory sessionFactory;

	Session session = null;
	Transaction transaction = null;

	public boolean isAlreadyExist(IndRegistrationBean indRegistrationBean) {
		log.info("Inside CoreIndHelperDao/isAlreadyExist()");

		StringBuilder checkQueryBuilder = new StringBuilder();
		checkQueryBuilder.append("from IndRegistrationBean ");

		StringBuilder orgCheckQuery = getIndCheckQuery(checkQueryBuilder);

		log.info("orgCheckQuery is : " + orgCheckQuery);

		try {
			Query query = sessionFactory.openSession().createQuery(orgCheckQuery.toString());
			query.setParameter("emailId", indRegistrationBean.getEmailId());
			query.setParameter("mobileNo", indRegistrationBean.getMobileNo());

			List<IndRegistrationBean> regIndividualList = query.list();

			log.info("Registered ind List is : " + regIndividualList.size());

			if (regIndividualList.size() > 0) {
				return true;
			}

			return false;
		} catch (HibernateException e) {
			log.error("Hibernate exception in isOrgExist() : " + e.getMessage());
			e.printStackTrace();
			return false;
		} catch (Exception ex) {
			log.error("Hibernate exception in isOrgExist() : " + ex.getMessage());
			ex.printStackTrace();
			return false;
		}
	}

	private StringBuilder getIndCheckQuery(StringBuilder checkQueryBuilder) {
		checkQueryBuilder.append("where emailId = :emailId or mobileNo =:mobileNo");
		return checkQueryBuilder;
	}

	public String registerIndividual(IndRegistrationBean indRegistrationBean) {
		log.info("Inside CoreIndHelperDao/registerIndividual()");

		log.info("indRegistrationBean : " + indRegistrationBean);

		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			session.save(indRegistrationBean);
			session.flush();
			transaction.commit();

			return ApplicationConstant.TRUE;
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
			log.error("Exception in registerIndividual : " + e.getMessage(), e.getCause());
			return ApplicationConstant.FALSE;
		} catch (Exception ex) {
			transaction.rollback();
			ex.printStackTrace();
			log.error("Exception in registerIndividual : " + ex.getMessage(), ex.getCause());
			return ApplicationConstant.FALSE;
		}
	}

	public boolean validateLogin(IndRegistrationBean indRegistrationBean) {
		log.info("Inside CoreIndHelperDao/validateLogin()");

		log.info("indRegistrationBean : " + indRegistrationBean);

		String loginQuery = "from IndRegistrationBean where password =:password and mobileNo = :mobileNo or emailId = :mobileNo";

		Query query = sessionFactory.openSession().createQuery(loginQuery);
		query.setParameter("mobileNo", indRegistrationBean.getMobileNo());
		query.setParameter("password", indRegistrationBean.getPassword());

		List<IndRegistrationBean> loginList = query.list();

		log.info("loginList : " + loginList.size());

		if (loginList.size() > 0 && loginList.size() < 2) {
			return true;
		}

		return false;
	}

	public boolean isProfileExist(IndProfileBean indProfileBean) {
		log.info("Inside CoreIndHelperDao/isProfileExist()");

		StringBuilder orgCheckQueryBuilder = new StringBuilder();
		orgCheckQueryBuilder.append("from IndProfileBean ");

		StringBuilder profileCheckQuery = getProfileCheckQuery(orgCheckQueryBuilder);

		log.info("profileCheckQuery is : " + profileCheckQuery.toString());

		try {
			Query query = sessionFactory.openSession().createQuery(profileCheckQuery.toString());
			query.setParameter("memberId", indProfileBean.getMemberId());

			List<IndProfileBean> profileList = query.list();

			log.info("Registered profile List is : " + profileList.size());

			if (profileList.size() == 0) {
				return true;
			}

			return false;
		} catch (HibernateException e) {
			log.error("Hibernate exception in isProfileExist() : " + e.getMessage());
			e.printStackTrace();
			return false;
		} catch (Exception ex) {
			log.error("Exception in isProfileExist() : " + ex.getMessage());
			ex.printStackTrace();
			return false;
		}
	}

	private StringBuilder getProfileCheckQuery(StringBuilder checkQueryBuilder) {
		checkQueryBuilder.append("where memberId = :memberId ");
		return checkQueryBuilder;
	}

	public String submitProfile(IndProfileBean indProfileBean) {
		log.info("Inside CoreIndHelperDao/submitProfile()");

		log.info("Profile Bean : " + indProfileBean);

		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			session.save(indProfileBean);
			session.flush();
			transaction.commit();

			return ApplicationConstant.TRUE;
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
			log.error("Exception in submitProfile : " + e.getMessage(), e.getCause());
			return ApplicationConstant.FALSE;
		} catch (Exception ex) {
			transaction.rollback();
			ex.printStackTrace();
			log.error("Exception in submitProfile : " + ex.getMessage(), ex.getCause());
			return ApplicationConstant.FALSE;
		}
	}

	public String updateProfile(IndProfileBean indProfileBean) {
		log.info("Inside CoreIndHelperDao/updateProfile()");

		StringBuilder profileQueryBuilder = null;
		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			profileQueryBuilder = new StringBuilder();
			profileQueryBuilder.append("update IndProfileBean ");
			profileQueryBuilder = fetchUpdateBuilder(profileQueryBuilder);

			log.info("Profile Bean is : " + indProfileBean);
			log.info("Profile update query is : " + profileQueryBuilder.toString());

			Query query = session.createQuery(profileQueryBuilder.toString());
			query.setParameter("dpImgLink", indProfileBean.getDpImgLink());
			query.setParameter("memberId", indProfileBean.getMemberId());

			int updateStatus = query.executeUpdate();

			log.info("Merchant store Update Status : " + updateStatus);

			session.flush();
			transaction.commit();

			return ApplicationConstant.TRUE;
		} catch (Exception e) {
			log.error("Exception in updating profile : " + e.getMessage(), e.getCause());
			e.printStackTrace();

			return ApplicationConstant.FALSE;

		}
	}

	private StringBuilder fetchUpdateBuilder(StringBuilder profileQueryBuilder) {
		profileQueryBuilder.append("set ");
		profileQueryBuilder.append("dpImgLink=:dpImgLink, ");
		profileQueryBuilder.append("where memberId=:memberId ");
		return profileQueryBuilder;
	}

	public List<OrgEventBean> fetchEventDetailsByLocation(IndRegistrationBean indRegistrationBean,String lastSyncDate) {
		log.info("Inside CoreIndHelperDao/fetchEventDetailsByLocation()");

		List<OrgEventBean> orgEventList = null;
		StringBuilder orgEventFindByLocationQuery = null;
		StringBuilder orgEventByLocationQueryBuilder = new StringBuilder();
		orgEventByLocationQueryBuilder.append("from OrgEventBean ");

		log.info("indRegistrationBean : " + indRegistrationBean);
		
		if (lastSyncDate.equals("0"))
		{
			orgEventFindByLocationQuery = getInfoByLocationSyncQuery(orgEventByLocationQueryBuilder);
		} else {
			orgEventFindByLocationQuery = getInfoByLocationIncrementalSyncQuery(orgEventByLocationQueryBuilder);
		}


		log.info("orgEventByLocationQueryBuilder is : " + orgEventByLocationQueryBuilder);

		try {
			Query query = sessionFactory.openSession().createQuery(orgEventFindByLocationQuery.toString());
			query.setParameter("location", indRegistrationBean.getCity());
			
			if (lastSyncDate.equals("0")) 
			{
				query.setParameter("deleteFlag", indRegistrationBean.getDeleteFlag());
			}
			else 
			{
				query.setParameter("createDt", Timestamp.valueOf(DateUtility.syncDateparser(lastSyncDate)));
				query.setParameter("modifyDt", Timestamp.valueOf(DateUtility.syncDateparser(lastSyncDate)));
				query.setParameter("deleteFlag", indRegistrationBean.getDeleteFlag());

			}

			orgEventList = query.list();

			log.info("Org event List is : " + orgEventList.size());

			return orgEventList;
		} catch (HibernateException e) {
			log.error("Hibernate exception in syncEvent() : " + e.getMessage());
			e.printStackTrace();
			return orgEventList;
		} catch (Exception ex) {
			log.error("Hibernate exception in syncEvent() : " + ex.getMessage());
			ex.printStackTrace();
			return orgEventList;
		}

	}

	private StringBuilder getInfoByLocationIncrementalSyncQuery(StringBuilder orgEventByLocationQueryBuilder) {
		orgEventByLocationQueryBuilder.append("where location = :location ");
		orgEventByLocationQueryBuilder.append("and createDt > :createDt ");
		orgEventByLocationQueryBuilder.append("or modifyDt > :modifyDt ");
		orgEventByLocationQueryBuilder.append("and deleteFlag =:deleteFlag");
		return orgEventByLocationQueryBuilder;
	}

	private StringBuilder getInfoByLocationSyncQuery(StringBuilder orgEventByLocationQueryBuilder) {
		orgEventByLocationQueryBuilder.append("where location = :location and deleteFlag =:deleteFlag");
		return orgEventByLocationQueryBuilder;

	}

	public List<OrgRequestBean> fetchSocialrequestByLocation(IndRegistrationBean indRegistrationBean,String lastSyncDate) {
		log.info("Inside CoreIndHelperDao/fetchSocialrequestByLocation()");

		List<OrgRequestBean> orgRequestList = null;
		StringBuilder orgRequestFindByLocationQuery = null;
		StringBuilder orgRequestByLocationQueryBuilder = new StringBuilder();
		orgRequestByLocationQueryBuilder.append("from OrgRequestBean ");

		log.info("indRegistrationBean : " + indRegistrationBean);
		
		if (lastSyncDate.equals("0"))
		{
			orgRequestFindByLocationQuery = getInfoByLocationSyncQuery(orgRequestByLocationQueryBuilder);
		} else {
			orgRequestFindByLocationQuery = getInfoByLocationIncrementalSyncQuery(orgRequestByLocationQueryBuilder);
		}
		
		

		log.info("orgRequestFindByLocationQuery is : " + orgRequestFindByLocationQuery);

		try {
			Query query = sessionFactory.openSession().createQuery(orgRequestFindByLocationQuery.toString());
			query.setParameter("location", indRegistrationBean.getCity());
			
			if (lastSyncDate.equals("0")) 
			{
				query.setParameter("deleteFlag", indRegistrationBean.getDeleteFlag());
			}
			else 
			{
				query.setParameter("createDt", Timestamp.valueOf(DateUtility.syncDateparser(lastSyncDate)));
				query.setParameter("modifyDt", Timestamp.valueOf(DateUtility.syncDateparser(lastSyncDate)));
				query.setParameter("deleteFlag", indRegistrationBean.getDeleteFlag());

			}

			orgRequestList = query.list();

			log.info("Org request List is : " + orgRequestList.size());

			return orgRequestList;
		} catch (HibernateException e) {
			log.error("Hibernate exception in fetchSocialrequestByLocation() : " + e.getMessage());
			e.printStackTrace();
			return orgRequestList;
		} catch (Exception ex) {
			log.error("Hibernate exception in fetchSocialrequestByLocation() : " + ex.getMessage());
			ex.printStackTrace();
			return orgRequestList;
		}
	}

	public List<OrgRegistrationBean> fetchSocialGroupsByLocation(IndRegistrationBean indRegistrationBean,String lastSyncDate) {
		log.info("Inside CoreIndHelperDao/fetchSocialGroupsByLocation()");

		List<OrgRegistrationBean> orgGroupList = null;
		StringBuilder orgGroupsFindByLocationQuery = null;
		StringBuilder orgRequestByLocationQueryBuilder = new StringBuilder();
		orgRequestByLocationQueryBuilder.append("from OrgRegistrationBean ");

		log.info("indRegistrationBean : " + indRegistrationBean);

		if (lastSyncDate.equals("0"))
		{
			orgGroupsFindByLocationQuery = getSocailGroupsByLocationSyncQuery(orgRequestByLocationQueryBuilder);
		} else {
			orgGroupsFindByLocationQuery = getSocailGroupsByLocationIncrementalSyncQuery(orgRequestByLocationQueryBuilder);
		}
		

		log.info("orgGroupsFindByLocationQuery is : " + orgGroupsFindByLocationQuery);

		try {
			Query query = sessionFactory.openSession().createQuery(orgGroupsFindByLocationQuery.toString());
			query.setParameter("city", indRegistrationBean.getCity());
			
			if (lastSyncDate.equals("0")) 
			{
				query.setParameter("deleteFlag", indRegistrationBean.getDeleteFlag());
			}
			else 
			{
				query.setParameter("createDt", Timestamp.valueOf(DateUtility.syncDateparser(lastSyncDate)));
				query.setParameter("modifyDt", Timestamp.valueOf(DateUtility.syncDateparser(lastSyncDate)));
				query.setParameter("deleteFlag", indRegistrationBean.getDeleteFlag());

			}

			orgGroupList = query.list();

			log.info("Org group List is : " + orgGroupList.size());

			return orgGroupList;
		} catch (HibernateException e) {
			log.error("Hibernate exception in fetchSocialGroupsByLocation() : " + e.getMessage());
			e.printStackTrace();
			return orgGroupList;
		} catch (Exception ex) {
			log.error("Hibernate exception in fetchSocialGroupsByLocation() : " + ex.getMessage());
			ex.printStackTrace();
			return orgGroupList;
		}
	}

	private StringBuilder getSocailGroupsByLocationIncrementalSyncQuery(StringBuilder orgRequestByLocationQueryBuilder) 
	{
		orgRequestByLocationQueryBuilder.append("where city = :city ");
		orgRequestByLocationQueryBuilder.append("and createDt > :createDt ");
		orgRequestByLocationQueryBuilder.append("or modifyDt > :modifyDt ");
		orgRequestByLocationQueryBuilder.append("and deleteFlag =:deleteFlag");
		return orgRequestByLocationQueryBuilder;
		
		
	}

	private StringBuilder getSocailGroupsByLocationSyncQuery(StringBuilder orgRequestByLocationQueryBuilder) 
	{
		orgRequestByLocationQueryBuilder.append("where city = :city and deleteFlag =:deleteFlag");
		return orgRequestByLocationQueryBuilder;
	}

	public List<OrgProfileBean> fetchSocialGroupProfile(List<String> locallySocialGroupList,String lastSyncDate) {
		
		log.info("Inside CoreIndHelperDao/fetchSocialGroupProfile()");

		List<OrgProfileBean> orgGroupList = null;
		StringBuilder orgGroupsProfileFindByLocationQuery = new StringBuilder();
		orgGroupsProfileFindByLocationQuery.append("from OrgProfileBean ");

		log.info("locallySocialGroupList : " + locallySocialGroupList);

		StringBuilder orgGroupsProfileFindByLocationQueryBuilder = getSocailGroupsProfileByLocationQuery(orgGroupsProfileFindByLocationQuery);

		log.info("orgGroupsProfileFindByLocationQuery is : " + orgGroupsProfileFindByLocationQueryBuilder);

		try {
			Query query = sessionFactory.openSession().createQuery(orgGroupsProfileFindByLocationQueryBuilder.toString());
			query.setParameter("orgId", locallySocialGroupList);
			query.setParameter("deleteFlag", ApplicationConstant.DEL_FLAG);

			orgGroupList = query.list();

			log.info("Org group profile List is : " + orgGroupList.size());

			return orgGroupList;
		} catch (HibernateException e) {
			log.error("Hibernate exception in fetchSocialGroupProfile() : " + e.getMessage());
			e.printStackTrace();
			return orgGroupList;
		} catch (Exception ex) {
			log.error("Hibernate exception in fetchSocialGroupProfile() : " + ex.getMessage());
			ex.printStackTrace();
			return orgGroupList;
		}
	}

	private StringBuilder getSocailGroupsProfileByLocationQuery(StringBuilder orgGroupsProfileFindByLocationQuery) {
		orgGroupsProfileFindByLocationQuery.append("where orgId in (:orgId) and deleteFlag =:deleteFlag");
		return orgGroupsProfileFindByLocationQuery;
	}

	public List<OrgAchievementBean> fetchOrgAchivementLocally(List<String> orgIdList,String lastSyncDate) 
	{
		
		log.info("Inside CoreIndHelperDao/fetchOrgAchivementLocally()");

		List<OrgAchievementBean> orgAchievementList = null;
		StringBuilder orgAcievementByIdQueryBuilder = null;
		StringBuilder orgAcievementByIdQuery = new StringBuilder();
		orgAcievementByIdQuery.append("from OrgAchievementBean ");

		log.info("orgIdList : " + orgIdList);
		
		if (lastSyncDate.equals("0"))
		{
			orgAcievementByIdQueryBuilder = getOrgAcievementByIdSyncQuery(orgAcievementByIdQuery);
		} else {
			orgAcievementByIdQueryBuilder = getOrgAcievementByIdIncrementalSyncQuery(orgAcievementByIdQuery);
		}

		

		log.info("orgAcievementByIdQueryBuilder is : " + orgAcievementByIdQueryBuilder);

		try {
			Query query = sessionFactory.openSession().createQuery(orgAcievementByIdQueryBuilder.toString());
			query.setParameter("orgId", orgIdList);
			
			if (lastSyncDate.equals("0")) 
			{
				query.setParameter("deleteFlag", ApplicationConstant.DEL_FLAG);
			}
			else {
				query.setParameter("createDt", Timestamp.valueOf(DateUtility.syncDateparser(lastSyncDate)));
				query.setParameter("modifyDt", Timestamp.valueOf(DateUtility.syncDateparser(lastSyncDate)));
				query.setParameter("deleteFlag",ApplicationConstant.DEL_FLAG);

			}

			orgAchievementList = query.list();

			log.info("Org group profile List is : " + orgAchievementList.size());

			return orgAchievementList;
		} catch (HibernateException e) {
			log.error("Hibernate exception in fetchSocialGroupProfile() : " + e.getMessage());
			e.printStackTrace();
			return orgAchievementList;
		} catch (Exception ex) {
			log.error("Hibernate exception in fetchSocialGroupProfile() : " + ex.getMessage());
			ex.printStackTrace();
			return orgAchievementList;
		}
	}

	private StringBuilder getOrgAcievementByIdIncrementalSyncQuery(StringBuilder orgAcievementByIdQuery) {
		orgAcievementByIdQuery.append("where orgId in (:orgId) ");
		orgAcievementByIdQuery.append("and createDt > :createDt ");
		orgAcievementByIdQuery.append("or modifyDt > :modifyDt ");
		orgAcievementByIdQuery.append("and deleteFlag =:deleteFlag");
		return orgAcievementByIdQuery;
	}

	private StringBuilder getOrgAcievementByIdSyncQuery(StringBuilder orgAcievementByIdQuery) 
	{
		orgAcievementByIdQuery.append("where orgId in (:orgId) and deleteFlag =:deleteFlag");
		return orgAcievementByIdQuery;
		
	}

	public String submitMessage(ConnectBean connectBean) {
		log.info("Inside submitMessage/submitProfile()");

		log.info("connect Bean : " + connectBean);

		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			session.save(connectBean);
			session.flush();
			transaction.commit();

			return ApplicationConstant.TRUE;
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
			log.error("Exception in submitProfile : " + e.getMessage(), e.getCause());
			return ApplicationConstant.FALSE;
		} catch (Exception ex) {
			transaction.rollback();
			ex.printStackTrace();
			log.error("Exception in submitProfile : " + ex.getMessage(), ex.getCause());
			return ApplicationConstant.FALSE;
		}
		
	}

	public String submitDonationReq(DonateBean donateBean) {
		log.info("Inside submitMessage/submitDonationReq()");

		log.info("donate Bean : " + donateBean);

		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			session.save(donateBean);
			session.flush();
			transaction.commit();

			return ApplicationConstant.TRUE;
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
			log.error("Exception in submitDonationReq : " + e.getMessage(), e.getCause());
			return ApplicationConstant.FALSE;
		} catch (Exception ex) {
			transaction.rollback();
			ex.printStackTrace();
			log.error("Exception in submitDonationReq : " + ex.getMessage(), ex.getCause());
			return ApplicationConstant.FALSE;
		}
	}

}
