package com.mobiowin.cmss.paalan.service.helper;

import java.util.HashMap;

public interface ICoreOrgHelperService {

	String isExistingOrg(HashMap<String, String> orgRegistrationDataMap);

	String registerOrg(HashMap<String, String> orgRegistrationDataMap);

	String validateOrgLogin(HashMap<String, String> loginReqDataMap);

	String updateOrgProfile(HashMap<String, String> orgRegistrationDataMap);

	String createOrgEvent(HashMap<String, String> reqDataMap);

	String updateOrgEvent(HashMap<String, String> reqDataMap);

	String deleteOrgEvent(HashMap<String, String> reqDataMap);

	String syncOrgEvent(HashMap<String,String> reqDataMap);

	String createOrgAchievement(HashMap<String, Object> reqDataMap);

	String updateOrgAchievement(HashMap<String, Object> reqDataMap);

	String syncOrgAchievement(HashMap<String,String> reqDataMap);

	String deleteOrgAchievement(HashMap<String, Object> reqDataMap);

	String createOrgRequest(HashMap<String, String> reqDataMap);

	String syncOrgRequest(HashMap<String,String> reqDataMap);

	String deleteOrgRequest(HashMap<String, Object> reqDataMap);

	String updateOrgRequest(HashMap<String, Object> reqDataMap);

	String fetchOrgProfile(HashMap<String, String> reqDataMap);

	String forgotPassword(HashMap<String, String> reqDataMap);

	String updatePassword(HashMap<String, String> reqDataMap);

	String syncOrgRecord(HashMap<String, String> reqDataMap);

	

}
