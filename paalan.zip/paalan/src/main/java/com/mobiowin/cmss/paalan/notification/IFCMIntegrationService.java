package com.mobiowin.cmss.paalan.notification;

import java.util.HashMap;

public interface IFCMIntegrationService {

	String sendFcmNotificationMessage(HashMap<String, String> notificationDataMap);
}
