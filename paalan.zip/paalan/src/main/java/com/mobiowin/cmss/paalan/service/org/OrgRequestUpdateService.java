package com.mobiowin.cmss.paalan.service.org;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.mobiowin.cmss.paalan.commons.ApplicationConstant;
import com.mobiowin.cmss.paalan.messaging.IMessageService;
import com.mobiowin.cmss.paalan.service.helper.ICoreOrgHelperService;

@Service("orgRequestUpdateService")
@Repository
public class OrgRequestUpdateService implements IMessageService {
	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private ICoreOrgHelperService orgCoreHelperService;

	public Message<String> execute(Message<String> message) {
		log.info("Inside OrgRequestUpdateService/execute()");

		String jsonData = message.getPayload();

		Map<String, Object> messageHeaders = message.getHeaders();

		JSONObject dataJson = null;
		JSONObject reqDataJson = null;
		

		String orgId = null;
		String requestId = null;
		String title = null;
		String subTitle = null;
		String discription = null;
		String others = null;
		String response = null;

		HashMap<String, Object> reqDataMap = null;

		try {
			dataJson = new JSONObject(jsonData);
			reqDataJson = dataJson.getJSONObject(ApplicationConstant.DATA);

			if (reqDataJson.has(ApplicationConstant.ORG_ID)) {
				orgId = reqDataJson.getString(ApplicationConstant.ORG_ID);
			}

			if (reqDataJson.has(ApplicationConstant.REQUEST_ID)) {
				requestId = reqDataJson.getString(ApplicationConstant.REQUEST_ID);
			}

			if (reqDataJson.has(ApplicationConstant.TITLE)) {
				title = reqDataJson.getString(ApplicationConstant.TITLE);
			}

			if (reqDataJson.has(ApplicationConstant.SUB_TITLE)) {
				subTitle = reqDataJson.getString(ApplicationConstant.SUB_TITLE);
			}

			if (reqDataJson.has(ApplicationConstant.DISCRIPTION)) {
				discription = reqDataJson.getString(ApplicationConstant.DISCRIPTION);
			}

			if (reqDataJson.has(ApplicationConstant.OTHERS)) {
				others = reqDataJson.getString(ApplicationConstant.OTHERS);
			}

			if (log.isInfoEnabled()) {
				log.info("Message Headers is : " + messageHeaders);
				log.info("ORG_ID is : " + orgId);
				log.info("REQUEST_ID is : " + requestId);
				log.info("TITLE is : " + title);
				log.info("SUB_TITLE is : " + subTitle);
				log.info("OTHERS is : " + others);
			}

			reqDataMap = getReqDataMap(orgId, requestId, title, subTitle, others, discription);

			response = orgCoreHelperService.updateOrgRequest(reqDataMap);

			return MessageBuilder.withPayload(response).build();

		} catch (Exception ex) {
			log.error("Exception in OrgRequestUpdateService/execute() " + ex.getMessage(), ex.getCause());

		}

		return null;
	}

	private HashMap<String, Object> getReqDataMap(String orgId, String requestId, String title, String subTitle,
			String others, String discription) {
		HashMap<String, Object> reqDataMap = new HashMap<String, Object>();

		reqDataMap.put(ApplicationConstant.ORG_ID, orgId);
		reqDataMap.put(ApplicationConstant.REQUEST_ID, requestId);
		reqDataMap.put(ApplicationConstant.TITLE, title);
		reqDataMap.put(ApplicationConstant.SUB_TITLE, subTitle);
		reqDataMap.put(ApplicationConstant.OTHERS, others);
		reqDataMap.put(ApplicationConstant.DISCRIPTION, discription);

		return reqDataMap;

	}
}
