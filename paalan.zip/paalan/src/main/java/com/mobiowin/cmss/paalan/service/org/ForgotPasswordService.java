package com.mobiowin.cmss.paalan.service.org;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.cmss.paalan.commons.ApplicationConstant;
import com.mobiowin.cmss.paalan.messaging.IMessageService;
import com.mobiowin.cmss.paalan.service.helper.ICoreOrgHelperService;

@Service("forgotPasswordService")
@Component
public class ForgotPasswordService implements IMessageService{

	private Log log = LogFactory.getLog(this.getClass());
	
	@Autowired
	private ICoreOrgHelperService orgCoreHelperService;
	
	public Message<String> execute(Message<String> message) 
	{
		log.info("Inside ForgotPasswordService/execute()");

		String jsonData = message.getPayload();

		Map<String, Object> messageHeaders = message.getHeaders();

		JSONObject dataJson = null;
		JSONObject reqDataJson = null;

		String userId = null;

		String response = null;

		HashMap<String, String> reqDataMap = null;

		try {
			dataJson = new JSONObject(jsonData);
			reqDataJson = dataJson.getJSONObject(ApplicationConstant.DATA);

			if (reqDataJson.has(ApplicationConstant.FLASH_USER_ID)) {
				userId = reqDataJson.getString(ApplicationConstant.FLASH_USER_ID);
			}


			if (log.isInfoEnabled()) 
			{
				log.info("Message Headers is : " + messageHeaders);
				log.info("FLASH_USER_ID is : " + userId);
			}

			reqDataMap = getReqDataMap(userId);

			response = orgCoreHelperService.forgotPassword(reqDataMap);

			return MessageBuilder.withPayload(response).build();

		} catch (Exception ex) {
			log.error("Exception in OrgProfileService/execute() " + ex.getMessage(), ex.getCause());

		}

		return null;
	}

	private HashMap<String, String> getReqDataMap(String userId) {
		HashMap<String, String> reqDataMap = new HashMap<String, String>();

		reqDataMap.put(ApplicationConstant.FLASH_USER_ID, userId);

		return reqDataMap;

	}
}
