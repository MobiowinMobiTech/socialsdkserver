package com.mobiowin.cmss.paalan.service.ind;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.cmss.paalan.commons.ApplicationConstant;
import com.mobiowin.cmss.paalan.messaging.IMessageService;
import com.mobiowin.cmss.paalan.service.helper.ICoreIndHelperService;

@Service("indLoginService")
@Component
public class IndLoginService implements IMessageService {

	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private ICoreIndHelperService indCoreHelperService;

	public Message<String> execute(Message<String> message) {
		log.info("Inside OrgLoginService/execute()");

		String jsonData = message.getPayload();

		Map<String, Object> messageHeaders = message.getHeaders();

		JSONObject reqDataJson = null;
		JSONObject loginDataJson = null;
		/*String userId = null;
		String password = null;*/
		String imeiNo = null;
		String latitude = null;
		String longitude = null;
		String response = null;
		String lastSyncDate = null;
		HashMap<String, String> loginReqDataMap = null;

		try {
			reqDataJson = new JSONObject(jsonData);
			loginDataJson = reqDataJson.getJSONObject(ApplicationConstant.DATA);

			/* 
			 * Logic change to remove individual login
			 * @Date 31-Jan-2017
			 * @Author Raman
			 */
			
			/*if (loginDataJson.has(ApplicationConstant.FLASH_USER_ID)) {
				userId = loginDataJson.getString(ApplicationConstant.FLASH_USER_ID);
			}

			

			if (loginDataJson.has(ApplicationConstant.FLASH_PASSWORD)) {
				password = loginDataJson.getString(ApplicationConstant.FLASH_PASSWORD);
			}*/
			
			if (loginDataJson.has(ApplicationConstant.IMEI_NO)) {
				imeiNo = loginDataJson.getString(ApplicationConstant.IMEI_NO);
			}
			
			if (loginDataJson.has(ApplicationConstant.USER_LATITUDE)) {
				latitude = loginDataJson.getString(ApplicationConstant.USER_LATITUDE);
			}
			
			if (loginDataJson.has(ApplicationConstant.USER_LONGITUDE)) {
				longitude = loginDataJson.getString(ApplicationConstant.USER_LONGITUDE);
			}
			
			if (loginDataJson.has(ApplicationConstant.LAST_SYNC_DATE)) {
				lastSyncDate = loginDataJson.getString(ApplicationConstant.LAST_SYNC_DATE);
				lastSyncDate = "0";
			}

			if (log.isInfoEnabled()) {
				log.info("Data is : " + loginDataJson);
				log.info("Message Headers : " + messageHeaders);
				/*log.info("userid is : " + userId);
				log.info("imei no is : " + imeiNo);
				log.info("password no is : " + password);*/
				log.info("USER_LATITUDE : " + latitude);
				log.info("USER_LONGITUDE : " + longitude);
				log.info("LAST_SYNC_DATE is : " + lastSyncDate);
			}

			//HashMap<String, String> loginReqDataMap = loginReqDataMap(userId, imeiNo, password,latitude,longitude);
			
			loginReqDataMap = loginReqDataMap(latitude,longitude,lastSyncDate,imeiNo);

			log.info("loginReqDataMap :" + loginReqDataMap);

			response = indCoreHelperService.validateIndLogin(loginReqDataMap);

			return MessageBuilder.withPayload(response).build();

		} catch (Exception ex) {
			log.error("Exception in IndLoginService/execute() " + ex.getMessage(), ex.getCause());

		}
		return null;
	}

	private HashMap<String, String> loginReqDataMap(String latitude, String longitude,String lastSyncDate,String imeiNo) {
		HashMap<String, String> loginReqDataMap = new HashMap<String, String>();
		/*loginReqDataMap.put(ApplicationConstant.FLASH_USER_ID, userId);
		
		loginReqDataMap.put(ApplicationConstant.FLASH_PASSWORD, password);*/
		loginReqDataMap.put(ApplicationConstant.IMEI_NO, imeiNo);
		loginReqDataMap.put(ApplicationConstant.USER_LATITUDE, latitude);
		loginReqDataMap.put(ApplicationConstant.USER_LONGITUDE, longitude);
		loginReqDataMap.put(ApplicationConstant.LAST_SYNC_DATE, lastSyncDate);

		return loginReqDataMap;
	}
}
