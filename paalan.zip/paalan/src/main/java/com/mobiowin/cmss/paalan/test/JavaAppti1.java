/*package com.mobiowin.cmss.paalan.test;

public class JavaAppti1 {

	

	public static void main(String[] args) {
	
		String result = JavaAppti1.getOutput();
		System.out.println("Result is : " + result);
	}

	private static String getOutput() 
	{
		try 
		{
			int i = 10/0;
			return "1";
			
		}
		catch(ArithmeticException aex)
		{
			return "2";
		}
		catch (Exception e) 
		{
			return "3";
		}
		finally 
		{
			return "4";
		}
		
		return "5";
	}
	
	
}

*/