package com.mobiowin.cmss.paalan.service.org;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.cmss.paalan.commons.ApplicationConstant;
import com.mobiowin.cmss.paalan.messaging.IMessageService;
import com.mobiowin.cmss.paalan.service.helper.ICoreOrgHelperService;


@Service("orgLoginService")
@Component
public class OrgLoginService implements IMessageService{

	private Log log = LogFactory.getLog(this.getClass());
	
	@Autowired
	private ICoreOrgHelperService orgCoreHelperService;
	
	public Message<String> execute(Message<String> message) 
	{
		log.info("Inside OrgLoginService/execute()");
		
		String jsonData = message.getPayload();

		Map<String, Object> messageHeaders = message.getHeaders();

		JSONObject reqDataJson = null;
		JSONObject loginDataJson = null;
		String userId = null;
		String imeiNo = null;
		String password = null;
		String response = null;

		try 
		{
			reqDataJson = new JSONObject(jsonData);
			loginDataJson = reqDataJson.getJSONObject(ApplicationConstant.DATA);

			if (loginDataJson.has(ApplicationConstant.FLASH_USER_ID))
		    {
				userId = loginDataJson
						.getString(ApplicationConstant.FLASH_USER_ID);
			}

			if (loginDataJson.has(ApplicationConstant.IMEI_NO))
			{
				imeiNo = loginDataJson
						.getString(ApplicationConstant.IMEI_NO);
			}
			
			if (loginDataJson.has(ApplicationConstant.FLASH_PASSWORD))
			{
				password = loginDataJson
						.getString(ApplicationConstant.FLASH_PASSWORD);
			}
			
			if(log.isInfoEnabled())
			{
				log.info("Merchant Data is : " + loginDataJson);
				log.info("Message Headers : " + messageHeaders);
				log.info("Merchant userid is : " + userId);
				log.info("Merchant imei no is : " + imeiNo);
				log.info("Merchant password no is : " + password);
			}
			
			HashMap<String,String> loginReqDataMap = loginReqDataMap(userId,imeiNo,password);
			
			log.info("loginReqDataMap :"+ loginReqDataMap);
			
			response = orgCoreHelperService.validateOrgLogin(loginReqDataMap);
			
			return MessageBuilder.withPayload(response).build();

		} catch (Exception ex)
		{
			log.error("Exception in OrgLoginService/execute() " + ex.getMessage(),ex.getCause());

		}
		return null;
	}

	private HashMap<String, String> loginReqDataMap(String userId, String imeiNo, String password) {
		HashMap<String,String> loginReqDataMap = new HashMap<String, String>();
		loginReqDataMap.put(ApplicationConstant.FLASH_USER_ID, userId);
		loginReqDataMap.put(ApplicationConstant.IMEI_NO, imeiNo);
		loginReqDataMap.put(ApplicationConstant.FLASH_PASSWORD, password);
		
		return loginReqDataMap;
	}

}
