package com.mobiowin.cmss.paalan.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ind_profile_master", catalog = "paalan")
public class IndProfileBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private String id;

	@Column(name = "member_id")
	private String memberId;

	@Column(name = "imei_no")
	private String imeiNo;

	@Column(name = "is_newsletter")
	private String isNewsLetter;

	@Column(name = "dp_img_link")
	private String dpImgLink;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_dt")
	private Date createDt;

	@Column(name = "modified_by")
	private String modifiedBy;

	@Column(name = "modified_dt")
	private Date modifyDt;

	@Column(name = "del_flag")
	private String deleteFlag;

	public IndProfileBean() {
		super();
	}

	public IndProfileBean(String id, String memberId, String imeiNo, String isNewsLetter, String dpImgLink,
			String createdBy, Date createDt, String modifiedBy, Date modifyDt, String deleteFlag) {
		super();
		this.id = id;
		this.memberId = memberId;
		this.imeiNo = imeiNo;
		this.isNewsLetter = isNewsLetter;
		this.dpImgLink = dpImgLink;
		this.createdBy = createdBy;
		this.createDt = createDt;
		this.modifiedBy = modifiedBy;
		this.modifyDt = modifyDt;
		this.deleteFlag = deleteFlag;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getMemberId() {
		return memberId;
	}

	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}

	public String getImeiNo() {
		return imeiNo;
	}

	public void setImeiNo(String imeiNo) {
		this.imeiNo = imeiNo;
	}

	public String getIsNewsLetter() {
		return isNewsLetter;
	}

	public void setIsNewsLetter(String isNewsLetter) {
		this.isNewsLetter = isNewsLetter;
	}

	public String getDpImgLink() {
		return dpImgLink;
	}

	public void setDpImgLink(String dpImgLink) {
		this.dpImgLink = dpImgLink;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Date createDt) {
		this.createDt = createDt;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifyDt() {
		return modifyDt;
	}

	public void setModifyDt(Date modifyDt) {
		this.modifyDt = modifyDt;
	}

	public String getDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}

	@Override
	public String toString() {
		return "IndProfileBean [id=" + id + ", memberId=" + memberId + ", imeiNo=" + imeiNo + ", isNewsLetter="
				+ isNewsLetter + ", dpImgLink=" + dpImgLink + ", createdBy=" + createdBy + ", createDt=" + createDt
				+ ", modifiedBy=" + modifiedBy + ", modifyDt=" + modifyDt + ", deleteFlag=" + deleteFlag + "]";
	}
	
	
	
}
