package com.mobiowin.cmss.paalan.geo;

public interface IGeoService {

}
