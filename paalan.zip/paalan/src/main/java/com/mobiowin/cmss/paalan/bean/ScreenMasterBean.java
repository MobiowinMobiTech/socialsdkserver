package com.mobiowin.cmss.paalan.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "welcome_screen_master", catalog = "paalan")
public class ScreenMasterBean implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private String id;

	@Column(name = "screen_id")
	private String screenId;

	@Column(name = "screen_name")
	private String screenName;

	@Column(name = "screen_img_link")
	private String screenImgLink;

	@Column(name = "screen_seq")
	private String screenSeq;
	
	@Column(name = "screen_text")
	private String screenTxt;

	@Column(name = "text1")
	private String freeText1;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_dt")
	private Date createDt;

	@Column(name = "modified_by")
	private String modifiedBy;

	@Column(name = "modified_dt")
	private Date modifyDt;

	@Column(name = "del_flag")
	private String deleteFlag;

	public ScreenMasterBean() {
		super();
	}

	

	public ScreenMasterBean(String id, String screenId, String screenName, String screenImgLink, String screenSeq,
			String screenTxt, String freeText1, String createdBy, Date createDt, String modifiedBy, Date modifyDt,
			String deleteFlag) {
		super();
		this.id = id;
		this.screenId = screenId;
		this.screenName = screenName;
		this.screenImgLink = screenImgLink;
		this.screenSeq = screenSeq;
		this.screenTxt = screenTxt;
		this.freeText1 = freeText1;
		this.createdBy = createdBy;
		this.createDt = createDt;
		this.modifiedBy = modifiedBy;
		this.modifyDt = modifyDt;
		this.deleteFlag = deleteFlag;
	}



	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getScreenId() {
		return screenId;
	}

	public void setScreenId(String screenId) {
		this.screenId = screenId;
	}

	public String getScreenName() {
		return screenName;
	}

	public void setScreenName(String screenName) {
		this.screenName = screenName;
	}

	public String getScreenImgLink() {
		return screenImgLink;
	}

	public void setScreenImgLink(String screenImgLink) {
		this.screenImgLink = screenImgLink;
	}

	public String getScreenSeq() {
		return screenSeq;
	}

	public void setScreenSeq(String screenSeq) {
		this.screenSeq = screenSeq;
	}

	public String getFreeText1() {
		return freeText1;
	}

	public void setFreeText1(String freeText1) {
		this.freeText1 = freeText1;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Date createDt) {
		this.createDt = createDt;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifyDt() {
		return modifyDt;
	}

	public void setModifyDt(Date modifyDt) {
		this.modifyDt = modifyDt;
	}

	public String getDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}

	
	
	public String getScreenTxt() {
		return screenTxt;
	}



	public void setScreenTxt(String screenTxt) {
		this.screenTxt = screenTxt;
	}



	@Override
	public String toString() {
		return "ScreenMasterBean [id=" + id + ", screenId=" + screenId + ", screenName=" + screenName
				+ ", screenImgLink=" + screenImgLink + ", screenSeq=" + screenSeq + ", screenTxt=" + screenTxt
				+ ", freeText1=" + freeText1 + ", createdBy=" + createdBy + ", createDt=" + createDt + ", modifiedBy="
				+ modifiedBy + ", modifyDt=" + modifyDt + ", deleteFlag=" + deleteFlag + "]";
	}



	

}
