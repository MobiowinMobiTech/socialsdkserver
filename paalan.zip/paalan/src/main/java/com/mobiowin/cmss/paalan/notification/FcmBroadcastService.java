package com.mobiowin.cmss.paalan.notification;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.mobiowin.cmss.paalan.commons.ApplicationConstant;

@Service("fcmBroadcastService")
@Component
public class FcmBroadcastService implements IFcmBroadcastService {

	private Log log  = LogFactory.getLog(this.getClass());
	
	@Autowired
	private RestTemplate restTemplate;
	
	@Autowired
	private @Resource Map<String, String> eventconfig;
	
	@Autowired
	private @Resource Map<String, String> achievementconfig;
	
	@Autowired
	private @Resource Map<String, String> requestconfig;
	
	@Autowired
	private @Resource Map<String, String> notificationConfig;
	
	String fcmServerAuthKey = null;
	String fcmNotificationUrl = null;
	
	@Async
	public void sendBroadcastNotification(HashMap<String, String> notificationDetailMap) {
		log.info("Inside FCMBroadcastService / sendBroadcastNotification()");
		
		if(null != notificationDetailMap)
		{
			log.info("notificationDetailMap -------------- > : " + notificationDetailMap);
			
			if(notificationDetailMap.get(ApplicationConstant.NOTIFICATION_TYPE).equals(ApplicationConstant.EVENT_TYPE))
			{
				
				
				String message = String.format(String.valueOf(eventconfig.get(ApplicationConstant.BROADCAST_MESSAGE)), 
						notificationDetailMap.get(ApplicationConstant.TITLE),notificationDetailMap.get(ApplicationConstant.NAME),notificationDetailMap.get(ApplicationConstant.LOCATION));
				
				log.info("Message is : " + message);
				
				notificationDetailMap.put(ApplicationConstant.BROADCAST_TOPIC_NAME, eventconfig.get(ApplicationConstant.BROADCAST_TOPIC_NAME));
				notificationDetailMap.put(ApplicationConstant.MESSAGE, message);
				notificationDetailMap.put(ApplicationConstant.NOTIFICATION_TYPE, ApplicationConstant.EVENT_TYPE);
				notificationDetailMap.put(ApplicationConstant.RECORD_ID, notificationDetailMap.get(ApplicationConstant.EVENT_ID));
				notificationDetailMap.put(ApplicationConstant.ORG_ID, notificationDetailMap.get(ApplicationConstant.ORG_ID));
				notificationDetailMap.put(ApplicationConstant.TITLE, eventconfig.get(ApplicationConstant.TITLE));
				
				log.info(" Notification Detail Map  " + notificationDetailMap);
			}
			
			if(notificationDetailMap.get(ApplicationConstant.NOTIFICATION_TYPE).equals(ApplicationConstant.ACHIEVEMENT_TYPE))
			{
				String message = String.format(String.valueOf(achievementconfig.get(ApplicationConstant.BROADCAST_MESSAGE)), 
						notificationDetailMap.get(ApplicationConstant.NAME),notificationDetailMap.get(ApplicationConstant.TITLE));
				
				notificationDetailMap.put(ApplicationConstant.BROADCAST_TOPIC_NAME, achievementconfig.get(ApplicationConstant.BROADCAST_TOPIC_NAME));
				notificationDetailMap.put(ApplicationConstant.MESSAGE, message);
				notificationDetailMap.put(ApplicationConstant.NOTIFICATION_TYPE, ApplicationConstant.ACHIEVEMENT_TYPE);
				notificationDetailMap.put(ApplicationConstant.ORG_ID, notificationDetailMap.get(ApplicationConstant.ORG_ID));
				notificationDetailMap.put(ApplicationConstant.RECORD_ID, notificationDetailMap.get(ApplicationConstant.ACHIEVEMENT_ID));
				
				log.info("Message is : " + message);
				
				notificationDetailMap.put(ApplicationConstant.TITLE, notificationDetailMap.get(ApplicationConstant.TITLE));
				
				
				log.info(" Notification Detail Map  " + notificationDetailMap);
			}
			
			if(notificationDetailMap.get(ApplicationConstant.NOTIFICATION_TYPE).equals(ApplicationConstant.REQUEST_TYPE))
			{
				String message = String.format(String.valueOf(requestconfig.get(ApplicationConstant.BROADCAST_MESSAGE)), 
						notificationDetailMap.get(ApplicationConstant.NAME),notificationDetailMap.get(ApplicationConstant.TITLE));
				
				notificationDetailMap.put(ApplicationConstant.MESSAGE, message);
				notificationDetailMap.put(ApplicationConstant.NOTIFICATION_TYPE, ApplicationConstant.REQUEST_TYPE);
				notificationDetailMap.put(ApplicationConstant.ORG_ID, notificationDetailMap.get(ApplicationConstant.ORG_ID));
				notificationDetailMap.put(ApplicationConstant.RECORD_ID, notificationDetailMap.get(ApplicationConstant.REQUEST_ID));
				notificationDetailMap.put(ApplicationConstant.BROADCAST_TOPIC_NAME, requestconfig.get(ApplicationConstant.BROADCAST_TOPIC_NAME));
				log.info("Message is : " + message);
				
				notificationDetailMap.put(ApplicationConstant.TITLE, notificationDetailMap.get(ApplicationConstant.TITLE));
				
				
				log.info(" Notification Detail Map  " + notificationDetailMap);
			}
		}
		
		sendNotification(notificationDetailMap);
		
	}

	private void sendNotification(HashMap<String, String> notificationDetailMap)
	{
		
		try {
			fcmServerAuthKey = String.valueOf(notificationConfig.get("serverkey"));
			fcmNotificationUrl = String.valueOf(notificationConfig.get("fcmurl"));
			
			
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			headers.set("Authorization", "key=" + fcmServerAuthKey);

			String notificationJsonData = getNotificationMessageData(notificationDetailMap);

			HttpEntity<String> entity = new HttpEntity<String>(notificationJsonData, headers);
			RestTemplate restTemplate = new RestTemplate();
			String resposne = restTemplate.postForObject(fcmNotificationUrl, entity, String.class);
			JSONObject responseJson = new JSONObject(resposne);

			
			log.info("Resposne is : " + responseJson);
		} catch (RestClientException e) 
		{
			log.error("Restclient exception is : " + e.getMessage());
			e.printStackTrace();
		} catch (JSONException e) {
			log.error("Exception in json parsing : " + e.getMessage());
			e.printStackTrace();
		}
		catch(Exception ex)
		{
			log.error("Exception in sendNotification : " + ex.getMessage());
		}
		
		
	}

	private String getNotificationMessageData(HashMap<String, String> notificationDetailMap) {
		
		JSONObject notificationJson = new JSONObject();
		notificationJson.put("to", notificationDetailMap.get(ApplicationConstant.BROADCAST_TOPIC_NAME));
		JSONObject info = new JSONObject();
		info.put(ApplicationConstant.TITLE, notificationDetailMap.get(ApplicationConstant.TITLE));
		info.put("body", notificationDetailMap.get(ApplicationConstant.MESSAGE));
		info.put(ApplicationConstant.NOTIFICATION_ENTITY, notificationDetailMap.get(ApplicationConstant.NOTIFICATION_TYPE));
		info.put(ApplicationConstant.NOTIFICATION_TYPE, ApplicationConstant.BROADCAST_MESSAGE);
		info.put(ApplicationConstant.ORG_ID, notificationDetailMap.get(ApplicationConstant.ORG_ID));
		info.put(ApplicationConstant.RECORD_ID, notificationDetailMap.get(ApplicationConstant.RECORD_ID));
		notificationJson.put("data", info);

		if(log.isInfoEnabled())
		{
			log.info("Notification json is : " + info);
			log.info("Notification json is : " + notificationJson);
		}
		
		return notificationJson.toString();
	}

}
