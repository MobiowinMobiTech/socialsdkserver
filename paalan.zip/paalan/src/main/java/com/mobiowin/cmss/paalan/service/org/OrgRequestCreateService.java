package com.mobiowin.cmss.paalan.service.org;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.cmss.paalan.commons.ApplicationConstant;
import com.mobiowin.cmss.paalan.messaging.IMessageService;
import com.mobiowin.cmss.paalan.service.helper.ICoreOrgHelperService;

@Service("orgRequestCreateService")
@Component
public class OrgRequestCreateService implements IMessageService{

	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private ICoreOrgHelperService orgCoreHelperService;

	public Message<String> execute(Message<String> message) {
		log.info("Inside OrgRequestCreateService/execute()");

		String jsonData = message.getPayload();

		Map<String, Object> messageHeaders = message.getHeaders();

		JSONObject dataJson = null;
		JSONObject reqDataJson = null;

		String orgId = null;
		String orgName = null;
		String requestId = null;
		String title = null;
		String subTitle = null;
		String discription = null;
		String location = null;
		String others = null;
		String response = null;
		String notificationId = null;

		HashMap<String, String> reqDataMap = null;

		try {
			dataJson = new JSONObject(jsonData);
			reqDataJson = dataJson.getJSONObject(ApplicationConstant.DATA);

			if (reqDataJson.has(ApplicationConstant.ORG_ID)) {
				orgId = reqDataJson.getString(ApplicationConstant.ORG_ID);
			}
			
			if (reqDataJson.has(ApplicationConstant.NAME)) {
				orgName = reqDataJson.getString(ApplicationConstant.NAME);
			}

			if (reqDataJson.has(ApplicationConstant.REQUEST_ID)) {
				requestId = reqDataJson.getString(ApplicationConstant.REQUEST_ID);
			}

			if (reqDataJson.has(ApplicationConstant.TITLE)) {
				title = reqDataJson.getString(ApplicationConstant.TITLE);
			}

			if (reqDataJson.has(ApplicationConstant.SUB_TITLE)) {
				subTitle = reqDataJson.getString(ApplicationConstant.SUB_TITLE);
			}
			
			if (reqDataJson.has(ApplicationConstant.DISCRIPTION)) {
				discription = reqDataJson.getString(ApplicationConstant.DISCRIPTION);
			}
			
			if (reqDataJson.has(ApplicationConstant.LOCATION)) {
				location = reqDataJson.getString(ApplicationConstant.LOCATION);
			}

			if (reqDataJson.has(ApplicationConstant.OTHERS)) {
				others = reqDataJson.getString(ApplicationConstant.OTHERS);
			}
			
			if (reqDataJson.has(ApplicationConstant.NOTIFICATION_ID)) {
				notificationId = reqDataJson.getString(ApplicationConstant.NOTIFICATION_ID);
			}

			if (log.isInfoEnabled()) {
				log.info("Message Headers is : " + messageHeaders);
				log.info("ORG_ID is : " + orgId);
				log.info("NAME is : " + orgName);
				log.info("REQUEST_ID is : " + requestId);
				log.info("TITLE is : " + title);
				log.info("SUB_TITLE is : " + subTitle);
				log.info("LOCATION is : " + location);
				log.info("OTHERS is : " + others);
				log.info("NOTIFICATION_ID is : " + notificationId);
			}

			reqDataMap = getReqDataMap(orgId, requestId, title, subTitle, location, others,discription,orgName,notificationId);

			response = orgCoreHelperService.createOrgRequest(reqDataMap);

			return MessageBuilder.withPayload(response).build();

		} catch (Exception ex) {
			log.error("Exception in OrgProfileService/execute() " + ex.getMessage(), ex.getCause());

		}

		return null;

	}

	private HashMap<String, String> getReqDataMap(String orgId, String requestId, String title, String subTitle,
			 String location, String others, String discription,String orgName, String notificationId) {
		
		HashMap<String,String> reqDataMap = new HashMap<String, String>();
		
		reqDataMap.put(ApplicationConstant.ORG_ID, orgId);
		reqDataMap.put(ApplicationConstant.NAME, orgName);
		reqDataMap.put(ApplicationConstant.REQUEST_ID, requestId);
		reqDataMap.put(ApplicationConstant.TITLE, title);
		reqDataMap.put(ApplicationConstant.SUB_TITLE, subTitle);
		reqDataMap.put(ApplicationConstant.LOCATION, location);
		reqDataMap.put(ApplicationConstant.OTHERS, others);
		reqDataMap.put(ApplicationConstant.DISCRIPTION, discription);
		reqDataMap.put(ApplicationConstant.NOTIFICATION_ID, notificationId);
		
		return reqDataMap;
	}
}
