package com.mobiowin.cmss.paalan.service.ind;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.cmss.paalan.commons.ApplicationConstant;
import com.mobiowin.cmss.paalan.messaging.IMessageService;
import com.mobiowin.cmss.paalan.service.helper.ICoreIndHelperService;

@Service("indRegistrationService")
@Component
public class IndRegistrationService implements IMessageService{

	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private ICoreIndHelperService indCoreHelperService;
	
	public Message<String> execute(Message<String> message) {
		log.info("Inside OrgRegistrationService/execute()");

		String jsonData = message.getPayload();

		Map<String, Object> messageHeaders = message.getHeaders();

		JSONObject dataJson = null;
		JSONObject registrationDataJson = null;

		String name = null;
		String mobileNo = null;
		String imeiNo = null;
		String password = null;
		String emailId = null;
		String deviceId = null;
		String notificationId = null;
		String latitude = null;
		String longitude = null;
		String response = null;
		
		HashMap<String, String> registrationDataMap = null;

		try {
			dataJson = new JSONObject(jsonData);
			registrationDataJson = dataJson.getJSONObject(ApplicationConstant.DATA);

			if (registrationDataJson.has(ApplicationConstant.NAME)) {
				name = registrationDataJson.getString(ApplicationConstant.NAME);
			}

			if (registrationDataJson.has(ApplicationConstant.MOBILE_NO)) {
				mobileNo = registrationDataJson.getString(ApplicationConstant.MOBILE_NO);
			}

			if (registrationDataJson.has(ApplicationConstant.IMEI_NO)) {
				imeiNo = registrationDataJson.getString(ApplicationConstant.IMEI_NO);
			}

			if (registrationDataJson.has(ApplicationConstant.PASSWORD)) {
				password = registrationDataJson.getString(ApplicationConstant.PASSWORD);
			}

			if (registrationDataJson.has(ApplicationConstant.EMAIL_ID)) {
				emailId = registrationDataJson.getString(ApplicationConstant.EMAIL_ID);
			}
			
			if (registrationDataJson.has(ApplicationConstant.NOTIFICATION_ID)) {
				notificationId = registrationDataJson.getString(ApplicationConstant.NOTIFICATION_ID);
			}
			
			if (registrationDataJson.has(ApplicationConstant.DEVICE_ID)) {
				deviceId = registrationDataJson.getString(ApplicationConstant.DEVICE_ID);
			}
			
			if (registrationDataJson.has(ApplicationConstant.USER_LATITUDE)) {
				latitude = registrationDataJson.getString(ApplicationConstant.USER_LATITUDE);
			}
			
			if (registrationDataJson.has(ApplicationConstant.USER_LONGITUDE))
			{
				longitude = registrationDataJson.getString(ApplicationConstant.USER_LONGITUDE);
			}
			

			if (log.isInfoEnabled()) {
				log.info("Message Headers is : " + messageHeaders);
				log.info("Orgnization name is : " + name);
				log.info("Mobile no is : " + mobileNo);
				log.info("email id is : " + emailId);
				log.info("imei no is :" + imeiNo);
				log.info("Password is : " + password);
				log.info("Device id is : " + deviceId);
				log.info("notification id is : " + notificationId);
				log.info("USER_LATITUDE is : " + latitude);
				log.info("USER_LONGITUDE is : " + longitude);

			}

			registrationDataMap = getRegDataMap(name, mobileNo, emailId, imeiNo, password,deviceId,notificationId,longitude,latitude);

			response = indCoreHelperService.isExistingInd(registrationDataMap);

			return MessageBuilder.withPayload(response).build();

		} catch (Exception ex) {
			log.error("Exception in RegistrationService/execute() " + ex.getMessage(), ex.getCause());

		}

		return null;
	}

	private HashMap<String, String> getRegDataMap(String name, String mobileNo, String emailId, String imeiNo,
			String password, String deviceId, String notificationId, String longitude, String latitude) {
		HashMap<String, String> regDataMap = new HashMap<String, String>();
		regDataMap.put(ApplicationConstant.NAME, name);
		regDataMap.put(ApplicationConstant.MOBILE_NO, mobileNo);
		regDataMap.put(ApplicationConstant.EMAIL_ID, emailId);
		regDataMap.put(ApplicationConstant.IMEI_NO, imeiNo);
		regDataMap.put(ApplicationConstant.PASSWORD, password);
		regDataMap.put(ApplicationConstant.DEVICE_ID, deviceId);
		regDataMap.put(ApplicationConstant.NOTIFICATION_ID, notificationId);
		regDataMap.put(ApplicationConstant.USER_LATITUDE, latitude);
		regDataMap.put(ApplicationConstant.USER_LONGITUDE, longitude);

		return regDataMap;
		
	}

	

}
