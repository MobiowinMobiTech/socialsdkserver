package com.mobiowin.cmss.paalan.service.org;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.cmss.paalan.commons.ApplicationConstant;
import com.mobiowin.cmss.paalan.messaging.IMessageService;
import com.mobiowin.cmss.paalan.service.helper.ICoreOrgHelperService;

@Service("updatePasswordService")
@Component
public class OrgUpdatePasswordService implements IMessageService{

	private Log log = LogFactory.getLog(this.getClass());
	
	@Autowired
	private ICoreOrgHelperService orgCoreHelperService;
	
	public Message<String> execute(Message<String> message) 
	{
		log.info("Inside OrgUpdatePasswordService/execute()");

		String jsonData = message.getPayload();

		Map<String, Object> messageHeaders = message.getHeaders();

		JSONObject dataJson = null;
		JSONObject reqDataJson = null;

		String userId = null;
		String password = null;

		String response = null;

		HashMap<String, String> reqDataMap = null;

		try {
			dataJson = new JSONObject(jsonData);
			reqDataJson = dataJson.getJSONObject(ApplicationConstant.DATA);

			if (reqDataJson.has(ApplicationConstant.FLASH_USER_ID)) {
				userId = reqDataJson.getString(ApplicationConstant.FLASH_USER_ID);
			}
			
			if (reqDataJson.has(ApplicationConstant.FLASH_PASSWORD)) {
				password = reqDataJson.getString(ApplicationConstant.FLASH_PASSWORD);
			}


			if (log.isInfoEnabled()) 
			{
				log.info("Message Headers is : " + messageHeaders);
				log.info("FLASH_USER_ID is : " + userId);
				log.info("FLASH_PASSWORD is : " + password);
			}

			reqDataMap = getReqDataMap(userId,password);

			response = orgCoreHelperService.updatePassword(reqDataMap);

			return MessageBuilder.withPayload(response).build();

		} catch (Exception ex)
		{
			log.error("Exception in OrgProfileService/execute() " + ex.getMessage(), ex.getCause());
			response = "Technical issue occurs, Kindly come back after some time";
			return MessageBuilder.withPayload(response).build();
		}

		
	}

	private HashMap<String, String> getReqDataMap(String userId, String password) {
		HashMap<String, String> reqDataMap = new HashMap<String, String>();

		reqDataMap.put(ApplicationConstant.FLASH_USER_ID, userId);
		reqDataMap.put(ApplicationConstant.FLASH_PASSWORD, password);

		return reqDataMap;

	}
}