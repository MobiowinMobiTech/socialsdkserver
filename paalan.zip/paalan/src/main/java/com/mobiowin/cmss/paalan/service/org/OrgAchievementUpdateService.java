package com.mobiowin.cmss.paalan.service.org;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.cmss.paalan.commons.ApplicationConstant;
import com.mobiowin.cmss.paalan.messaging.IMessageService;
import com.mobiowin.cmss.paalan.service.helper.ICoreOrgHelperService;

@Service("orgAchievementUpdateService")
@Component
public class OrgAchievementUpdateService implements IMessageService
{
	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private ICoreOrgHelperService orgCoreHelperService;

	public Message<String> execute(Message<String> message) {
		log.info("Inside orgAchievementUpdateService/execute()");

		String jsonData = message.getPayload();

		Map<String, Object> messageHeaders = message.getHeaders();

		JSONObject dataJson = null;
		JSONObject reqDataJson = null;
		JSONArray imgArray = null;

		String orgId = null;
		String achievementId = null;
		String title = null;
		String subTitle = null;
		String discription = null;
		List<String> imgList = null;
		String others = null;
		String response = null;

		HashMap<String, Object> reqDataMap = null;

		try {
			dataJson = new JSONObject(jsonData);
			reqDataJson = dataJson.getJSONObject(ApplicationConstant.DATA);

			if (reqDataJson.has(ApplicationConstant.ORG_ID)) {
				orgId = reqDataJson.getString(ApplicationConstant.ORG_ID);
			}

			if (reqDataJson.has(ApplicationConstant.ACHIEVEMENT_ID)) {
				achievementId = reqDataJson.getString(ApplicationConstant.ACHIEVEMENT_ID);
			}

			if (reqDataJson.has(ApplicationConstant.TITLE)) {
				title = reqDataJson.getString(ApplicationConstant.TITLE);
			}

			if (reqDataJson.has(ApplicationConstant.SUB_TITLE)) {
				subTitle = reqDataJson.getString(ApplicationConstant.SUB_TITLE);
			}
			
			if (reqDataJson.has(ApplicationConstant.DISCRIPTION)) {
				discription = reqDataJson.getString(ApplicationConstant.DISCRIPTION);
			}

			if (reqDataJson.has(ApplicationConstant.OTHERS)) {
				others = reqDataJson.getString(ApplicationConstant.OTHERS);
			}
			
			if (reqDataJson.has(ApplicationConstant.ORG_ACHIEVEMENT_IMG)) 
			{
				imgArray = reqDataJson.getJSONArray(ApplicationConstant.ORG_ACHIEVEMENT_IMG);
				imgList = new ArrayList<String>();

				for (int i = 0; i < imgArray.length(); i++) 
				{
					if (null != imgArray.getJSONObject(i).getString("img") && !imgArray
							.getJSONObject(i).getString("img").equalsIgnoreCase(ApplicationConstant.EMPTY_STRING)) 
					{
						imgList.add(imgArray.getJSONObject(i).getString("img"));
					}
				}
			}

			if (log.isInfoEnabled()) {
				log.info("Message Headers is : " + messageHeaders);
				log.info("ORG_ID is : " + orgId);
				log.info("ACHIEVEMENT_ID is : " + achievementId);
				log.info("TITLE is : " + title);
				log.info("SUB_TITLE is : " + subTitle);
				log.info("OTHERS is : " + others);
				log.info("ORG_ACHIEVEMENT_IMG is : " + imgList.size());
			}

			reqDataMap = getReqDataMap(orgId, achievementId, title, subTitle, others,discription,imgList);

			response = orgCoreHelperService.updateOrgAchievement(reqDataMap);

			return MessageBuilder.withPayload(response).build();

		} catch (Exception ex) {
			log.error("Exception in OrgProfileService/execute() " + ex.getMessage(), ex.getCause());

		}

		return null;
	}
	
	private HashMap<String, Object> getReqDataMap(String orgId, String achievementId, String title, String subTitle,
			String others, String discription, List<String> imgList) {
		HashMap<String, Object> reqDataMap = new HashMap<String, Object>();

		reqDataMap.put(ApplicationConstant.ORG_ID, orgId);
		reqDataMap.put(ApplicationConstant.ACHIEVEMENT_ID, achievementId);
		reqDataMap.put(ApplicationConstant.TITLE, title);
		reqDataMap.put(ApplicationConstant.SUB_TITLE, subTitle);
		reqDataMap.put(ApplicationConstant.OTHERS, others);
		reqDataMap.put(ApplicationConstant.DISCRIPTION, discription);
		reqDataMap.put(ApplicationConstant.ORG_ACHIEVEMENT_IMG, imgList);

		return reqDataMap;

	}

}
