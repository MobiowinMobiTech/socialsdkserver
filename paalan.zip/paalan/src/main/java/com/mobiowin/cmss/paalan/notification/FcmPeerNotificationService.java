package com.mobiowin.cmss.paalan.notification;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.mobiowin.cmss.paalan.commons.ApplicationConstant;

@Service("fcmPeerNotificationService")
@Component
public class FcmPeerNotificationService implements IFcmPeerNotificationService {

	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private @Resource Map<String, String> eventconfig;

	@Autowired
	private @Resource Map<String, String> achievementconfig;

	@Autowired
	private @Resource Map<String, String> requestconfig;

	@Autowired
	private @Resource Map<String, String> notificationConfig;

	String fcmServerAuthKey = null;
	String fcmNotificationUrl = null;

	@Async
	public void sendPeerToPeerNotification(HashMap<String, String> notificationDetailMap) {

		log.info("Inside FCMBroadcastService / sendBroadcast()");

		if (null != notificationDetailMap) {

			if (notificationDetailMap.get(ApplicationConstant.NOTIFICATION_TYPE)
					.equals(ApplicationConstant.EVENT_TYPE)) {
				// notificationDetailMap.put(ApplicationConstant.BROADCAST_TOPIC_NAME,
				// eventconfig.get(ApplicationConstant.BROADCAST_TOPIC));

				String message = String.format(String.valueOf(eventconfig.get(ApplicationConstant.PEER_MESSAGE)),
						notificationDetailMap.get(ApplicationConstant.NAME),
						notificationDetailMap.get(ApplicationConstant.TITLE));

				notificationDetailMap.put(ApplicationConstant.MESSAGE, message);
				notificationDetailMap.put(ApplicationConstant.NOTIFICATION_TYPE, ApplicationConstant.EVENT_TYPE);

				log.info("Message is : " + message);

				notificationDetailMap.put(ApplicationConstant.TITLE, eventconfig.get(ApplicationConstant.TITLE));

				log.info(" Notification Detail Map  " + notificationDetailMap);
			}

			if (notificationDetailMap.get(ApplicationConstant.NOTIFICATION_TYPE)
					.equals(ApplicationConstant.ACHIEVEMENT_TYPE)) {
				String message = String.format(String.valueOf(achievementconfig.get(ApplicationConstant.PEER_MESSAGE)),
						notificationDetailMap.get(ApplicationConstant.NAME),
						notificationDetailMap.get(ApplicationConstant.TITLE));

				notificationDetailMap.put(ApplicationConstant.MESSAGE, message);
				notificationDetailMap.put(ApplicationConstant.NOTIFICATION_TYPE, ApplicationConstant.ACHIEVEMENT_TYPE);
				log.info("Message is : " + message);

				notificationDetailMap.put(ApplicationConstant.TITLE, achievementconfig.get(ApplicationConstant.TITLE));

				log.info(" Notification Detail Map  " + notificationDetailMap);
			}

			if (notificationDetailMap.get(ApplicationConstant.NOTIFICATION_TYPE)
					.equals(ApplicationConstant.REQUEST_TYPE)) {
				String message = String.format(String.valueOf(requestconfig.get(ApplicationConstant.PEER_MESSAGE)),
						notificationDetailMap.get(ApplicationConstant.NAME),
						notificationDetailMap.get(ApplicationConstant.TITLE));

				notificationDetailMap.put(ApplicationConstant.MESSAGE, message);
				notificationDetailMap.put(ApplicationConstant.NOTIFICATION_TYPE, ApplicationConstant.REQUEST_TYPE);

				log.info("Message is : " + message);

				notificationDetailMap.put(ApplicationConstant.TITLE,
						notificationDetailMap.get(ApplicationConstant.TITLE));

				log.info(" Notification Detail Map  " + notificationDetailMap);
			}
		}

		sendPeerNotificationMessage(notificationDetailMap);
		// sendBroadcastNotification(notificationDetailMap);
	}

	private void sendPeerNotificationMessage(HashMap<String, String> notificationDetailMap) {

		fcmServerAuthKey = String.valueOf(notificationConfig.get("serverkey"));
		fcmNotificationUrl = String.valueOf(notificationConfig.get("fcmurl"));
		System.setProperty("fcm.googleapis.com", "proxy.com");
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("Authorization", "key=" + fcmServerAuthKey);

		String notificationJsonData = getNotificationMessageData(notificationDetailMap);

		HttpEntity<String> entity = new HttpEntity<String>(notificationJsonData, headers);
		RestTemplate restTemplate = new RestTemplate();
		String resposne = restTemplate.postForObject(fcmNotificationUrl, entity, String.class);
		JSONObject responseJson = new JSONObject(resposne);

		System.out.println("Resposne is : " + responseJson);

	}

	private String getNotificationMessageData(HashMap<String, String> notificationDetailMap) {
		JSONObject notificationJson = new JSONObject();
		notificationJson.put("to", notificationDetailMap.get(ApplicationConstant.NOTIFICATION_ID));
		JSONObject info = new JSONObject();
		info.put(ApplicationConstant.TITLE, notificationDetailMap.get(ApplicationConstant.TITLE));
		info.put("body", notificationDetailMap.get(ApplicationConstant.MESSAGE));
		info.put(ApplicationConstant.NOTIFICATION_ENTITY,
				notificationDetailMap.get(ApplicationConstant.NOTIFICATION_TYPE));
		info.put(ApplicationConstant.NOTIFICATION_TYPE, ApplicationConstant.PEER_TO_PEER_NOTIFICATIONS);
		notificationJson.put("data", info);

		if (log.isInfoEnabled()) {
			log.info("Notification json is : " + info);
			log.info("Notification json is : " + notificationJson);
		}

		return notificationJson.toString();

	}

}
