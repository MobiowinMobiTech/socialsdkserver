package com.mobiowin.cmss.paalan.dao;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.mobiowin.cmss.paalan.bean.OrgAchievementBean;
import com.mobiowin.cmss.paalan.bean.OrgEventBean;
import com.mobiowin.cmss.paalan.bean.OrgProfileBean;
import com.mobiowin.cmss.paalan.bean.OrgRegistrationBean;
import com.mobiowin.cmss.paalan.bean.OrgRequestBean;
import com.mobiowin.cmss.paalan.commons.ApplicationConstant;
import com.mobiowin.cmss.paalan.test.DateUtility;

@Repository("coreOrgHelperDao")
@Component
public class CoreOrgHelperDao implements ICoreOrgHelperDao {

	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private SessionFactory sessionFactory;

	Session session = null;
	Transaction transaction = null;

	public boolean isOrgExist(OrgRegistrationBean orgRegistrationBean) {
		log.info("Inside CoreOrgHelperDao/isOrgExist()");

		StringBuilder orgCheckQueryBuilder = new StringBuilder();
		orgCheckQueryBuilder.append("from OrgRegistrationBean ");

		StringBuilder orgCheckQuery = getOrgCheckQuery(orgCheckQueryBuilder);

		log.info("orgCheckQuery is : " + orgCheckQuery);

		try {
			Query query = sessionFactory.openSession().createQuery(orgCheckQuery.toString());
			query.setParameter("emailId", orgRegistrationBean.getEmailId());
			query.setParameter("mobileNo", orgRegistrationBean.getMobileNo());

			List<OrgRegistrationBean> regMerchantList = query.list();

			log.info("Registered Org List is : " + regMerchantList.size());

			if (regMerchantList.size() > 0) {
				return true;
			}

			return false;
		} catch (HibernateException e) {
			log.error("Hibernate exception in isOrgExist() : " + e.getMessage());
			e.printStackTrace();
			return false;
		} catch (Exception ex) {
			log.error("Hibernate exception in isOrgExist() : " + ex.getMessage());
			ex.printStackTrace();
			return false;
		}

	}

	private StringBuilder getOrgCheckQuery(StringBuilder orgCheckQueryBuilder) {
		orgCheckQueryBuilder.append("where emailId = :emailId or mobileNo =:mobileNo");
		return orgCheckQueryBuilder;
	}

	public String registerOrg(OrgRegistrationBean orgRegistrationBean) {
		log.info("Inside CoreOrgHelperDao/registerOrg()");

		log.info("orgRegistrationBean : " + orgRegistrationBean);

		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			session.save(orgRegistrationBean);
			session.flush();
			transaction.commit();

			return ApplicationConstant.TRUE;
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
			log.error("Exception in registerOrg : " + e.getMessage(), e.getCause());
			return ApplicationConstant.FALSE;
		} catch (Exception ex) {
			transaction.rollback();
			ex.printStackTrace();
			log.error("Exception in registerOrg : " + ex.getMessage(), ex.getCause());
			return ApplicationConstant.FALSE;
		}

	}
	
	public String insertProfile(OrgProfileBean orgProfileBean) {
		log.info("Inside CoreOrgHelperDao/registerOrg()");

		log.info("orgProfileBean : " + orgProfileBean);

		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			session.save(orgProfileBean);
			session.flush();
			transaction.commit();

			return ApplicationConstant.TRUE;
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
			log.error("Exception in insertProfile : " + e.getMessage(), e.getCause());
			return ApplicationConstant.FALSE;
		} catch (Exception ex) {
			transaction.rollback();
			ex.printStackTrace();
			log.error("Exception in insertProfile : " + ex.getMessage(), ex.getCause());
			return ApplicationConstant.FALSE;
		}

	}

	public List<OrgRegistrationBean> validateLogin(OrgRegistrationBean orgRegistrationBean) {
		log.info("Inside CoreOrgHelperDao/validateLogin()");

		log.info("OrgRegistrationBean : " + orgRegistrationBean);

		StringBuilder loginQueryBuilder = null;
		List<OrgRegistrationBean> orgLoginList = null;
		try {
			loginQueryBuilder = new StringBuilder();
			loginQueryBuilder.append("from OrgRegistrationBean ");
			loginQueryBuilder.append("where password =:password ");
			loginQueryBuilder.append("and mobileNo = :mobileNo ");
			loginQueryBuilder.append("or emailId = :mobileNo ");

			Query query = sessionFactory.openSession().createQuery(loginQueryBuilder.toString());
			query.setParameter("mobileNo", orgRegistrationBean.getMobileNo());
			query.setParameter("password", orgRegistrationBean.getPassword());

			orgLoginList = query.list();

			log.info("orgLoginList : " + orgLoginList.size());

			return orgLoginList;
		} catch (HibernateException e) {
			e.printStackTrace();
			log.error("Hibernate Exception in org login validation : " + e.getMessage());
			return orgLoginList;
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception in org login validation : " + e.getMessage());
			return orgLoginList;
		}
	}

	public List<OrgProfileBean> fetchOrgProfile(OrgProfileBean orgProfileBean) {
		log.info("Inside CoreOrgHelperDao/isOrgProfileExist()");

		StringBuilder orgCheckQueryBuilder = new StringBuilder();
		orgCheckQueryBuilder.append("from OrgProfileBean ");

		StringBuilder orgProfileCheckQuery = getOrgProfileCheckQuery(orgCheckQueryBuilder);
		List<OrgProfileBean> orgProfileList = null;

		log.info("orgProfileCheckQuery is : " + orgProfileCheckQuery.toString());

		try {
			Query query = sessionFactory.openSession().createQuery(orgProfileCheckQuery.toString());
			query.setParameter("orgId", orgProfileBean.getOrgId());

			orgProfileList = query.list();

			log.info("Registered Org profile List is : " + orgProfileList.size());

			return orgProfileList;
		} catch (HibernateException e) {
			log.error("Hibernate exception in isOrgExist() : " + e.getMessage());
			e.printStackTrace();
			return orgProfileList;
		} catch (Exception ex) {
			log.error("Hibernate exception in isOrgExist() : " + ex.getMessage());
			ex.printStackTrace();
			return orgProfileList;
		}

	}

	private StringBuilder getOrgProfileCheckQuery(StringBuilder orgCheckQueryBuilder) {
		orgCheckQueryBuilder.append("where orgId = :orgId ");
		return orgCheckQueryBuilder;
	}

	public String submitOrgProfile(OrgProfileBean orgProfileBean) {
		log.info("Inside CoreOrgHelperDao/submitOrgProfile()");

		log.info("Org Profile Bean : " + orgProfileBean);

		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			session.save(orgProfileBean);
			session.flush();
			transaction.commit();

			return ApplicationConstant.TRUE;
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
			log.error("Exception in submitOrgProfile : " + e.getMessage(), e.getCause());
			return ApplicationConstant.FALSE;
		} catch (Exception ex) {
			transaction.rollback();
			ex.printStackTrace();
			log.error("Exception in submitOrgProfile : " + ex.getMessage(), ex.getCause());
			return ApplicationConstant.FALSE;
		}
	}

	public String updateOrgProfile(OrgProfileBean orgProfileBean) {
		log.info("Inside CoreOrgHelperDao/updateOrgProfile()");

		StringBuilder orgProfileQueryBuilder = null;
		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			orgProfileQueryBuilder = new StringBuilder();
			orgProfileQueryBuilder.append("update OrgProfileBean ");
			orgProfileQueryBuilder = fetchProfileUpdateBuilder(orgProfileQueryBuilder);

			log.info("Org Profile Bean is : " + orgProfileBean);
			log.info("Org Profile update query is : " + orgProfileQueryBuilder.toString());

			Query query = session.createQuery(orgProfileQueryBuilder.toString());

			query.setParameter("role", orgProfileBean.getRole());
			query.setParameter("dpImgLink", orgProfileBean.getDpImgLink());
			query.setParameter("fbLink", orgProfileBean.getFbLink());
			query.setParameter("linkedinLink", orgProfileBean.getLinkedinLink());
			query.setParameter("twitterLink", orgProfileBean.getTwitterLink());
			query.setParameter("websiteLink", orgProfileBean.getWebsiteLink());
			query.setParameter("deleteFlag", orgProfileBean.getDeleteFlag());
			query.setParameter("isGovtRegister", orgProfileBean.getIsGovtRegister());
			query.setParameter("registrationNo", orgProfileBean.getRegistrationNo());
			query.setParameter("orgId", orgProfileBean.getOrgId());

			int merchantStoreUpdateStatus = query.executeUpdate();

			log.info("Merchant store Update Status : " + merchantStoreUpdateStatus);

			session.flush();
			transaction.commit();

			return ApplicationConstant.TRUE;
		} catch (Exception e) {
			log.error("Exception in updating merchant profile : " + e.getMessage(), e.getCause());
			e.printStackTrace();

			return ApplicationConstant.FALSE;

		}

	}

	private StringBuilder fetchProfileUpdateBuilder(StringBuilder orgProfileQueryBuilder) {
		orgProfileQueryBuilder.append("set role=:role,");
		orgProfileQueryBuilder.append("dpImgLink=:dpImgLink, ");
		orgProfileQueryBuilder.append("fbLink=:fbLink ,");
		orgProfileQueryBuilder.append("linkedinLink=:linkedinLink, ");
		orgProfileQueryBuilder.append("twitterLink=:twitterLink, ");
		orgProfileQueryBuilder.append("websiteLink=:websiteLink, ");
		orgProfileQueryBuilder.append("deleteFlag=:deleteFlag, ");
		orgProfileQueryBuilder.append("isGovtRegister=:isGovtRegister, ");
		orgProfileQueryBuilder.append("registrationNo=:registrationNo ");
		orgProfileQueryBuilder.append("where orgId=:orgId ");

		return orgProfileQueryBuilder;
	}

	public String createEvent(OrgEventBean orgEventBean) {

		log.info("Inside CoreOrgHelperDao/createEvent()");

		log.info("Orgevent Bean is : " + orgEventBean);

		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			session.save(orgEventBean);
			session.flush();
			transaction.commit();

			return ApplicationConstant.TRUE;
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
			log.error("Exception in createEvent : " + e.getMessage(), e.getCause());
			return ApplicationConstant.FALSE;
		} catch (Exception ex) {
			transaction.rollback();
			ex.printStackTrace();
			log.error("Exception in createEvent : " + ex.getMessage(), ex.getCause());
			return ApplicationConstant.FALSE;
		}
	}

	public String updateEvent(OrgEventBean orgEventBean) {
		log.info("Inside CoreOrgHelperDao/updateEvent()");

		StringBuilder eventQueryBuilder = null;
		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			eventQueryBuilder = new StringBuilder();
			eventQueryBuilder.append("update OrgEventBean ");
			eventQueryBuilder = fetchEventUpdateBuilder(eventQueryBuilder);

			log.info("Org event Bean is : " + orgEventBean);
			log.info("Org event update query is : " + eventQueryBuilder.toString());

			Query query = session.createQuery(eventQueryBuilder.toString());

			query.setParameter("title", orgEventBean.getTitle());
			query.setParameter("subTitle", orgEventBean.getSubTitle());
			query.setParameter("discription", orgEventBean.getDiscription());
			query.setParameter("startDt", orgEventBean.getStartDt());
			query.setParameter("endDt", orgEventBean.getEndDt());
			query.setParameter("location", orgEventBean.getLocation());
			query.setParameter("others", orgEventBean.getOthers());
			query.setParameter("modifyDt", orgEventBean.getModifyDt());
			query.setParameter("modifiedBy", orgEventBean.getModifiedBy());
			query.setParameter("orgId", orgEventBean.getOrgId());
			query.setParameter("eventId", orgEventBean.getEventId());

			int updateStatus = query.executeUpdate();

			log.info("Event Update Status : " + updateStatus);

			session.flush();
			transaction.commit();

			return ApplicationConstant.TRUE;
		} catch (Exception e) {
			log.error("Exception in updating event : " + e.getMessage(), e.getCause());
			e.printStackTrace();

			return ApplicationConstant.FALSE;

		}
	}

	private StringBuilder fetchEventUpdateBuilder(StringBuilder eventQueryBuilder) {

		eventQueryBuilder.append("set title=:title,");
		eventQueryBuilder.append("subTitle=:subTitle, ");
		eventQueryBuilder.append("discription=:discription ,");
		eventQueryBuilder.append("startDt=:startDt, ");
		eventQueryBuilder.append("endDt=:endDt, ");
		eventQueryBuilder.append("location=:location, ");
		eventQueryBuilder.append("others=:others, ");
		eventQueryBuilder.append("modifyDt=:modifyDt, ");
		eventQueryBuilder.append("modifiedBy=:modifiedBy ");
		eventQueryBuilder.append("where orgId=:orgId ");
		eventQueryBuilder.append("and eventId=:eventId ");

		return eventQueryBuilder;
	}

	public String deleteEvent(OrgEventBean orgEventBean) {
		log.info("Inside CoreOrgHelperDao/updateEvent()");

		StringBuilder eventQueryBuilder = null;
		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			eventQueryBuilder = new StringBuilder();
			eventQueryBuilder.append("update OrgEventBean ");
			eventQueryBuilder = fetchEventDeleteBuilder(eventQueryBuilder);

			log.info("Org event Bean is : " + orgEventBean);
			log.info("Org event Delete query is : " + eventQueryBuilder.toString());

			Query query = session.createQuery(eventQueryBuilder.toString());

			query.setParameter("modifyDt", orgEventBean.getModifyDt());
			query.setParameter("modifiedBy", orgEventBean.getModifiedBy());
			query.setParameter("deleteFlag", orgEventBean.getDeleteFlag());
			query.setParameter("orgId", orgEventBean.getOrgId());
			query.setParameter("eventId", orgEventBean.getEventId());

			int updateStatus = query.executeUpdate();

			log.info("Event Update Status : " + updateStatus);

			session.flush();
			transaction.commit();

			return ApplicationConstant.TRUE;
		} catch (Exception e) {
			log.error("Exception in deleting event : " + e.getMessage(), e.getCause());
			e.printStackTrace();

			return ApplicationConstant.FALSE;

		}
	}

	private StringBuilder fetchEventDeleteBuilder(StringBuilder eventQueryBuilder) {

		eventQueryBuilder.append("set ");
		eventQueryBuilder.append("modifyDt=:modifyDt, ");
		eventQueryBuilder.append("modifiedBy=:modifiedBy, ");
		eventQueryBuilder.append("deleteFlag=:deleteFlag ");
		eventQueryBuilder.append("where orgId=:orgId ");
		eventQueryBuilder.append("and eventId=:eventId ");

		return eventQueryBuilder;
	}

	public List<OrgEventBean> syncEvent(OrgEventBean orgEventBean, String lastSyncDate) {
		log.info("Inside CoreOrgHelperDao/syncEvent()");

		List<OrgEventBean> orgEventList = null;
		//StringBuilder orgEventSyncQuery = null;
		StringBuilder orgEventSyncQueryBuilder = new StringBuilder();
		orgEventSyncQueryBuilder.append("from OrgEventBean ");


		if (lastSyncDate.equals("0"))
		{
			orgEventSyncQueryBuilder = getOrgEventSyncQuery(orgEventSyncQueryBuilder);
		} else {
			orgEventSyncQueryBuilder = getOrgEventIncrementalSyncQuery(orgEventSyncQueryBuilder);
		}
		
		log.info("orgEventSyncQueryBuilder is : " + orgEventSyncQueryBuilder);

		try {
			Query query = sessionFactory.openSession().createQuery(orgEventSyncQueryBuilder.toString());
			query.setParameter("orgId", orgEventBean.getOrgId());
			
			if (lastSyncDate.equals("0")) 
			{
				query.setParameter("deleteFlag", orgEventBean.getDeleteFlag());
			}
			else {
				query.setParameter("createDt", Timestamp.valueOf(DateUtility.syncDateparser(lastSyncDate)));
				query.setParameter("modifyDt", Timestamp.valueOf(DateUtility.syncDateparser(lastSyncDate)));
				query.setParameter("deleteFlag", orgEventBean.getDeleteFlag());

			}
			

			orgEventList = query.list();

			log.info("Org event List is : " + orgEventList.size());

			return orgEventList;
		} catch (HibernateException e) {
			log.error("Hibernate exception in syncEvent() : " + e.getMessage());
			e.printStackTrace();
			return orgEventList;
		} catch (Exception ex) {
			log.error("Hibernate exception in syncEvent() : " + ex.getMessage());
			ex.printStackTrace();
			return orgEventList;
		}

	}

	private StringBuilder getOrgEventIncrementalSyncQuery(StringBuilder orgEventSyncQueryBuilder) {
		orgEventSyncQueryBuilder.append("where orgId = :orgId ");
		orgEventSyncQueryBuilder.append("and createDt > :createDt ");
		orgEventSyncQueryBuilder.append("or modifyDt > :modifyDt ");
		orgEventSyncQueryBuilder.append("and deleteFlag =:deleteFlag");
		return orgEventSyncQueryBuilder;
	}
	
	private StringBuilder getOrgEventSyncQuery(StringBuilder orgEventSyncQueryBuilder) {
		orgEventSyncQueryBuilder.append("where orgId = :orgId ");
		orgEventSyncQueryBuilder.append("and deleteFlag =:deleteFlag");
		return orgEventSyncQueryBuilder;
	}

	public String createAchievement(OrgAchievementBean orgAchievementBean) {
		log.info("Inside CoreOrgHelperDao/createAchievement()");

		log.info("Orgevent Bean is : " + orgAchievementBean);

		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			session.save(orgAchievementBean);
			session.flush();
			transaction.commit();

			return ApplicationConstant.TRUE;
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
			log.error("Exception in createAchievement : " + e.getMessage(), e.getCause());
			return ApplicationConstant.FALSE;
		} catch (Exception ex) {
			transaction.rollback();
			ex.printStackTrace();
			log.error("Exception in createAchievement : " + ex.getMessage(), ex.getCause());
			return ApplicationConstant.FALSE;
		}
	}

	public String updateAchievement(OrgAchievementBean orgAchievementBean) {
		log.info("Inside CoreOrgHelperDao/updateAchievement()");

		StringBuilder achievementQueryBuilder = null;
		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			achievementQueryBuilder = new StringBuilder();
			achievementQueryBuilder.append("update OrgAchievementBean ");
			achievementQueryBuilder = fetchAchievementUpdateBuilder(achievementQueryBuilder);

			log.info("Org Achievement Bean is : " + orgAchievementBean);
			log.info("Org Achievement update query is : " + achievementQueryBuilder.toString());

			Query query = session.createQuery(achievementQueryBuilder.toString());

			query.setParameter("title", orgAchievementBean.getTitle());
			query.setParameter("subTitle", orgAchievementBean.getSubTitle());
			query.setParameter("discription", orgAchievementBean.getDiscription());
			query.setParameter("image1", orgAchievementBean.getImage1());
			query.setParameter("image2", orgAchievementBean.getImage2());
			query.setParameter("image3", orgAchievementBean.getImage3());
			query.setParameter("image4", orgAchievementBean.getImage4());
			query.setParameter("others", orgAchievementBean.getOthers());
			query.setParameter("modifyDt", orgAchievementBean.getModifyDt());
			query.setParameter("modifiedBy", orgAchievementBean.getModifiedBy());
			query.setParameter("orgId", orgAchievementBean.getOrgId());
			query.setParameter("achievementId", orgAchievementBean.getAchievementId());

			int updateStatus = query.executeUpdate();

			log.info("Achievement Update Status : " + updateStatus);

			session.flush();
			transaction.commit();

			return ApplicationConstant.TRUE;
		} catch (Exception e) {
			log.error("Exception in updating event : " + e.getMessage(), e.getCause());
			e.printStackTrace();

			return ApplicationConstant.FALSE;

		}
	}

	private StringBuilder fetchAchievementUpdateBuilder(StringBuilder achievementQueryBuilder) {
		achievementQueryBuilder.append("set title=:title,");
		achievementQueryBuilder.append("subTitle=:subTitle, ");
		achievementQueryBuilder.append("discription=:discription ,");
		achievementQueryBuilder.append("image1=:image1, ");
		achievementQueryBuilder.append("image2=:image2, ");
		achievementQueryBuilder.append("image3=:image3, ");
		achievementQueryBuilder.append("image4=:image4, ");
		achievementQueryBuilder.append("others=:others, ");
		achievementQueryBuilder.append("modifyDt=:modifyDt, ");
		achievementQueryBuilder.append("modifiedBy=:modifiedBy ");
		achievementQueryBuilder.append("where orgId=:orgId ");
		achievementQueryBuilder.append("and achievementId=:achievementId ");

		return achievementQueryBuilder;
	}

	public List<OrgAchievementBean> syncAchievement(OrgAchievementBean orgAchievementBean, String lastSyncDate) {
		log.info("Inside CoreOrgHelperDao/syncAchievement()");

		List<OrgAchievementBean> orgAchievementList = null;
		StringBuilder orgAchievementSyncQuery = null;
		StringBuilder orgAchievementSyncQueryBuilder = new StringBuilder();
		orgAchievementSyncQueryBuilder.append("from OrgAchievementBean ");

		if (lastSyncDate.equals("0")) {
			orgAchievementSyncQuery = getOrgAchievementSyncQuery(orgAchievementSyncQueryBuilder);
		} else {
			orgAchievementSyncQuery = getOrgAchievementIncrementalSyncQuery(orgAchievementSyncQueryBuilder);
		}

		log.info("orgAchievementSyncQuery is : " + orgAchievementSyncQuery);

		try {
			Query query = sessionFactory.openSession().createQuery(orgAchievementSyncQuery.toString());
			query.setParameter("orgId", orgAchievementBean.getOrgId());

			if (lastSyncDate.equals("0")) {
				query.setParameter("deleteFlag", orgAchievementBean.getDeleteFlag());
			} else {
				query.setParameter("createDt", Timestamp.valueOf(DateUtility.syncDateparser(lastSyncDate)));
				query.setParameter("modifyDt", Timestamp.valueOf(DateUtility.syncDateparser(lastSyncDate)));
				query.setParameter("deleteFlag", orgAchievementBean.getDeleteFlag());

			}

			orgAchievementList = query.list();

			log.info("Org Achievement List is : " + orgAchievementList.size());

			return orgAchievementList;
		} catch (HibernateException e) {
			log.error("Hibernate exception in syncAchievement() : " + e.getMessage());
			e.printStackTrace();
			return orgAchievementList;
		} catch (Exception ex) {
			log.error("Hibernate exception in syncAchievement() : " + ex.getMessage());
			ex.printStackTrace();
			return orgAchievementList;
		}
	}

	private StringBuilder getOrgAchievementSyncQuery(StringBuilder orgAchievementSyncQueryBuilder) {
		orgAchievementSyncQueryBuilder.append("where orgId = :orgId ");
		orgAchievementSyncQueryBuilder.append("and deleteFlag =:deleteFlag");
		return orgAchievementSyncQueryBuilder;
	}

	private StringBuilder getOrgAchievementIncrementalSyncQuery(StringBuilder orgAchievementSyncQueryBuilder) {
		orgAchievementSyncQueryBuilder.append("where orgId = :orgId ");
		orgAchievementSyncQueryBuilder.append("and createDt > :createDt ");
		orgAchievementSyncQueryBuilder.append("or modifyDt > :modifyDt ");
		orgAchievementSyncQueryBuilder.append("and deleteFlag =:deleteFlag");
		return orgAchievementSyncQueryBuilder;
	}

	public String deleteAchievement(OrgAchievementBean orgAchievementBean) {
		log.info("Inside CoreOrgHelperDao/deleteAchievement()");

		StringBuilder achievementQueryBuilder = null;
		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			achievementQueryBuilder = new StringBuilder();
			achievementQueryBuilder.append("update OrgAchievementBean ");
			achievementQueryBuilder = fetchDeleteBuilder(achievementQueryBuilder);

			log.info("Org Achiement Bean is : " + orgAchievementBean);
			log.info("Org Achievement Delete query is : " + achievementQueryBuilder.toString());

			Query query = session.createQuery(achievementQueryBuilder.toString());

			query.setParameter("modifyDt", orgAchievementBean.getModifyDt());
			query.setParameter("modifiedBy", orgAchievementBean.getModifiedBy());
			query.setParameter("deleteFlag", orgAchievementBean.getDeleteFlag());
			query.setParameter("orgId", orgAchievementBean.getOrgId());
			query.setParameter("achievementId", orgAchievementBean.getAchievementId());

			int updateStatus = query.executeUpdate();

			log.info("Achievement Update Status : " + updateStatus);

			session.flush();
			transaction.commit();

			return ApplicationConstant.TRUE;
		} catch (Exception e) {
			log.error("Exception in deleting achievement : " + e.getMessage(), e.getCause());
			e.printStackTrace();

			return ApplicationConstant.FALSE;

		}
	}

	private StringBuilder fetchDeleteBuilder(StringBuilder achievementQueryBuilder) {
		achievementQueryBuilder.append("set ");
		achievementQueryBuilder.append("modifyDt=:modifyDt, ");
		achievementQueryBuilder.append("modifiedBy=:modifiedBy, ");
		achievementQueryBuilder.append("deleteFlag=:deleteFlag ");
		achievementQueryBuilder.append("where orgId=:orgId ");
		achievementQueryBuilder.append("and achievementId=:achievementId ");

		return achievementQueryBuilder;
	}

	public String createRequest(OrgRequestBean orgRequestBean) {
		log.info("Inside CoreOrgHelperDao/createRequest()");

		log.info("Org request Bean is : " + orgRequestBean);

		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			session.save(orgRequestBean);
			session.flush();
			transaction.commit();

			return ApplicationConstant.TRUE;
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
			log.error("Exception in create request : " + e.getMessage(), e.getCause());
			return ApplicationConstant.FALSE;
		} catch (Exception ex) {
			transaction.rollback();
			ex.printStackTrace();
			log.error("Exception in create request : " + ex.getMessage(), ex.getCause());
			return ApplicationConstant.FALSE;
		}
	}

	public List<OrgRequestBean> syncRequest(OrgRequestBean orgRequestBean,String lastSyncDate) {
		log.info("Inside CoreOrgHelperDao/syncAchievement()");

		List<OrgRequestBean> orgRequesttList = null;
		StringBuilder orgRequestSyncQuery = null;
		StringBuilder orgRequestSyncQueryBuilder = new StringBuilder();
		orgRequestSyncQueryBuilder.append("from OrgRequestBean ");

		
		
		if (lastSyncDate.equals("0")) {
			orgRequestSyncQuery = getOrgRequestSyncQuery(orgRequestSyncQueryBuilder);
		} else {
			orgRequestSyncQuery = getOrgRequestIncrementalSyncQuery(orgRequestSyncQueryBuilder);
		}

		log.info("orgRequestSyncQuery is : " + orgRequestSyncQuery);

		try 
		{
			Query query = sessionFactory.openSession().createQuery(orgRequestSyncQuery.toString());
			query.setParameter("orgId", orgRequestBean.getOrgId());
			
			if (lastSyncDate.equals("0")) 
			{
				query.setParameter("deleteFlag", orgRequestBean.getDeleteFlag());
			}
			else
			{
				query.setParameter("createDt", Timestamp.valueOf(DateUtility.syncDateparser(lastSyncDate)));
				query.setParameter("modifyDt", Timestamp.valueOf(DateUtility.syncDateparser(lastSyncDate)));
				query.setParameter("deleteFlag", orgRequestBean.getDeleteFlag());

			}

			orgRequesttList = query.list();

			log.info("Org request List is : " + orgRequesttList.size());

			return orgRequesttList;
		} catch (HibernateException e) {
			log.error("Hibernate exception in syncRequest() : " + e.getMessage());
			e.printStackTrace();
			return orgRequesttList;
		} catch (Exception ex) {
			log.error("Hibernate exception in syncRequest() : " + ex.getMessage());
			ex.printStackTrace();
			return orgRequesttList;
		}
	}

	private StringBuilder getOrgRequestSyncQuery(StringBuilder orgRequestSyncQueryBuilder) {
		orgRequestSyncQueryBuilder.append("where orgId = :orgId ");
		orgRequestSyncQueryBuilder.append("and deleteFlag =:deleteFlag");
		return orgRequestSyncQueryBuilder;
	}

	private StringBuilder getOrgRequestIncrementalSyncQuery(StringBuilder orgRequestSyncQueryBuilder) {
		orgRequestSyncQueryBuilder.append("where orgId = :orgId ");
		orgRequestSyncQueryBuilder.append("and createDt > :createDt ");
		orgRequestSyncQueryBuilder.append("or modifyDt > :modifyDt ");
		orgRequestSyncQueryBuilder.append("and deleteFlag =:deleteFlag");
		return orgRequestSyncQueryBuilder;
	}

	public String deleteRequest(OrgRequestBean orgRequestBean) {

		log.info("Inside CoreOrgHelperDao/deleteRequest()");

		StringBuilder queryBuilder = null;
		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			queryBuilder = new StringBuilder();
			queryBuilder.append("update OrgRequestBean ");
			queryBuilder = fetchDeleteRequestBuilder(queryBuilder);

			log.info("Org request Bean is : " + orgRequestBean);
			log.info("Org request Delete query is : " + queryBuilder.toString());

			Query query = session.createQuery(queryBuilder.toString());

			query.setParameter("modifyDt", orgRequestBean.getModifyDt());
			query.setParameter("modifiedBy", orgRequestBean.getModifiedBy());
			query.setParameter("deleteFlag", orgRequestBean.getDeleteFlag());
			query.setParameter("orgId", orgRequestBean.getOrgId());
			query.setParameter("requestId", orgRequestBean.getRequestId());

			int updateStatus = query.executeUpdate();

			log.info("request Update Status : " + updateStatus);

			session.flush();
			transaction.commit();

			return ApplicationConstant.TRUE;
		} catch (Exception e) {
			log.error("Exception in deleting request : " + e.getMessage(), e.getCause());
			e.printStackTrace();

			return ApplicationConstant.FALSE;

		}
	}

	private StringBuilder fetchDeleteRequestBuilder(StringBuilder queryBuilder) {
		queryBuilder.append("set ");
		queryBuilder.append("modifyDt=:modifyDt, ");
		queryBuilder.append("modifiedBy=:modifiedBy, ");
		queryBuilder.append("deleteFlag=:deleteFlag ");
		queryBuilder.append("where orgId=:orgId ");
		queryBuilder.append("and requestId=:requestId ");

		return queryBuilder;
	}

	public String updateRequest(OrgRequestBean orgRequestBean) {
		log.info("Inside CoreOrgHelperDao/updateRequest()");

		StringBuilder requestQueryBuilder = null;
		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			requestQueryBuilder = new StringBuilder();
			requestQueryBuilder.append("update OrgRequestBean ");
			requestQueryBuilder = fetchRequestUpdateBuilder(requestQueryBuilder);

			log.info("Org Request Bean is : " + orgRequestBean);
			log.info("Org Request update query is : " + requestQueryBuilder.toString());

			Query query = session.createQuery(requestQueryBuilder.toString());

			query.setParameter("title", orgRequestBean.getTitle());
			query.setParameter("subTitle", orgRequestBean.getSubTitle());
			query.setParameter("discription", orgRequestBean.getDiscription());
			query.setParameter("others", orgRequestBean.getOthers());
			query.setParameter("modifyDt", orgRequestBean.getModifyDt());
			query.setParameter("modifiedBy", orgRequestBean.getModifiedBy());
			query.setParameter("orgId", orgRequestBean.getOrgId());
			query.setParameter("requestId", orgRequestBean.getRequestId());

			int updateStatus = query.executeUpdate();

			log.info("Request Update Status : " + updateStatus);

			session.flush();
			transaction.commit();

			return ApplicationConstant.TRUE;
		} catch (Exception e) {
			log.error("Exception in updating request : " + e.getMessage(), e.getCause());
			e.printStackTrace();

			return ApplicationConstant.FALSE;

		}
	}

	private StringBuilder fetchRequestUpdateBuilder(StringBuilder requestQueryBuilder) {
		requestQueryBuilder.append("set title=:title,");
		requestQueryBuilder.append("subTitle=:subTitle, ");
		requestQueryBuilder.append("discription=:discription ,");
		requestQueryBuilder.append("others=:others, ");
		requestQueryBuilder.append("modifyDt=:modifyDt, ");
		requestQueryBuilder.append("modifiedBy=:modifiedBy ");
		requestQueryBuilder.append("where orgId=:orgId ");
		requestQueryBuilder.append("and requestId=:requestId");

		return requestQueryBuilder;
	}

	public List<OrgRegistrationBean> validateUserId(OrgRegistrationBean orgRegistrationBean) {
		log.info("Inside CoreOrgHelperDao/validateUserId()");

		log.info("OrgRegistrationBean : " + orgRegistrationBean);

		StringBuilder loginQueryBuilder = null;
		List<OrgRegistrationBean> orgLoginList = null;
		try {
			loginQueryBuilder = new StringBuilder();
			loginQueryBuilder.append("from OrgRegistrationBean ");
			loginQueryBuilder.append("where mobileNo = :mobileNo ");
			loginQueryBuilder.append("or emailId = :mobileNo ");

			Query query = sessionFactory.openSession().createQuery(loginQueryBuilder.toString());
			query.setParameter("mobileNo", orgRegistrationBean.getMobileNo());

			orgLoginList = query.list();

			log.info("orgLoginList : " + orgLoginList.size());

			return orgLoginList;
		} catch (HibernateException e) {
			e.printStackTrace();
			log.error("Hibernate Exception in org login validation : " + e.getMessage());
			return orgLoginList;
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception in org login validation : " + e.getMessage());
			return orgLoginList;
		}
	}

	public String updatePassword(OrgRegistrationBean orgRegistrationBean) {
		log.info("Inside CoreOrgHelperDao/updatePassword()");

		StringBuilder updateQueryBuilder = null;
		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			updateQueryBuilder = new StringBuilder();
			updateQueryBuilder.append("update OrgRegistrationBean ");
			updateQueryBuilder = fetchPasswordUpdateBuilder(updateQueryBuilder);

			log.info("Org Bean is : " + orgRegistrationBean);
			log.info("Org update query is : " + updateQueryBuilder.toString());

			Query query = session.createQuery(updateQueryBuilder.toString());

			query.setParameter("password", orgRegistrationBean.getPassword());
			query.setParameter("modifyDt", orgRegistrationBean.getModifyDt());
			query.setParameter("modifiedBy", orgRegistrationBean.getModifiedBy());
			query.setParameter("mobileNo", orgRegistrationBean.getMobileNo());

			int updateStatus = query.executeUpdate();

			log.info("Request Update Status : " + updateStatus);

			session.flush();
			transaction.commit();

			return ApplicationConstant.TRUE;
		} catch (Exception e) {
			log.error("Exception in updating request : " + e.getMessage(), e.getCause());
			e.printStackTrace();

			return ApplicationConstant.FALSE;

		}
	}

	private StringBuilder fetchPasswordUpdateBuilder(StringBuilder requestQueryBuilder) 
	{
		requestQueryBuilder.append("set password=:password,");
		requestQueryBuilder.append("modifyDt=:modifyDt, ");
		requestQueryBuilder.append("modifiedBy=:modifiedBy ");
		requestQueryBuilder.append("where mobileNo = :mobileNo ");
		requestQueryBuilder.append("or emailId = :mobileNo ");

		return requestQueryBuilder;
	}

	public List<Object> fetchNotificationRecord(HashMap<String, Object> dbRequestMap) 
	{
		log.info("Inside CoreOrgHelperDao/fetchNotificationRecord()");

		List<Object> orgRecordList = null;
		StringBuilder orgRecordSyncQueryBuilder = new StringBuilder();
		
		
		orgRecordSyncQueryBuilder.append("from ");
		//orgRecordSyncQueryBuilder.append(dbRequestMap.get(ApplicationConstant.RECORD_TYPE));
		
		if(dbRequestMap.get(ApplicationConstant.RECORD_TYPE) instanceof OrgEventBean)
		{
			orgRecordSyncQueryBuilder.append("OrgEventBean ");
			orgRecordSyncQueryBuilder.append("where  eventId = :recordId ");
			orgRecordSyncQueryBuilder = getOrgRecordSyncQuery(orgRecordSyncQueryBuilder);
		}
		
		if(dbRequestMap.get(ApplicationConstant.RECORD_TYPE) instanceof OrgAchievementBean)
		{
			orgRecordSyncQueryBuilder.append("OrgAchievementBean ");
			orgRecordSyncQueryBuilder.append("where  achievementId = :recordId ");
			orgRecordSyncQueryBuilder = getOrgRecordSyncQuery(orgRecordSyncQueryBuilder);
		}
		
		if(dbRequestMap.get(ApplicationConstant.RECORD_TYPE) instanceof OrgRequestBean)
		{
			orgRecordSyncQueryBuilder.append("OrgRequestBean ");
			orgRecordSyncQueryBuilder.append("where  requestId = :recordId ");
			orgRecordSyncQueryBuilder = getOrgRecordSyncQuery(orgRecordSyncQueryBuilder);
		}
		
		
		//orgRecordSyncQueryBuilder = getOrgRecordSyncQuery(orgRecordSyncQueryBuilder);
		

		log.info("orgRecordSyncQueryBuilder is : " + orgRecordSyncQueryBuilder);

		try 
		{
			Query query = sessionFactory.openSession().createQuery(orgRecordSyncQueryBuilder.toString());
			query.setParameter("recordId", dbRequestMap.get(ApplicationConstant.RECORD_ID));
			query.setParameter("orgId", dbRequestMap.get(ApplicationConstant.ORG_ID));
			query.setParameter("deleteFlag", ApplicationConstant.DEL_FLAG);

			orgRecordList = query.list();

			log.info("Org record List is : " + orgRecordList.size());

			return orgRecordList;
		} catch (HibernateException e) {
			log.error("Hibernate exception in fetchNotificationRecord() : " + e.getMessage());
			e.printStackTrace();
			return orgRecordList;
		} catch (Exception ex) {
			log.error("Hibernate exception in fetchNotificationRecord() : " + ex.getMessage());
			ex.printStackTrace();
			return orgRecordList;
		}
	}

	private StringBuilder getOrgRecordSyncQuery(StringBuilder orgRecordSyncQueryBuilder) {
		
		orgRecordSyncQueryBuilder.append("and orgId = :orgId ");
		orgRecordSyncQueryBuilder.append("and deleteFlag = :deleteFlag ");
		
		return orgRecordSyncQueryBuilder;
	}

}
