package com.mobiowin.cmss.paalan.service.org;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.cmss.paalan.commons.ApplicationConstant;
import com.mobiowin.cmss.paalan.messaging.IMessageService;
import com.mobiowin.cmss.paalan.service.helper.ICoreOrgHelperService;

@Service("orgProfileService")
@Component
public class OrgProfileService implements IMessageService{
	
	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private ICoreOrgHelperService orgCoreHelperService;

	public Message<String> execute(Message<String> message) {
		log.info("Inside OrgProfileService/execute()");

		String jsonData = message.getPayload();

		Map<String, Object> messageHeaders = message.getHeaders();

		JSONObject reqDataJson = null;
		JSONObject profileDataJson = null;

		String orgId = null;
		String role = null;
		String imeiNo = null;
		String isNewsLetter = null;
		String isGovtRegister = null;
		String registrationNo = null;
		String dpImgLink = null;
		String fbLink = null;
		String linkedinLink = null;
		String websiteLink = null;
		String twitterLink = null;
		String presenceArea = null;
		String response = null;
		
		HashMap<String, String> orgRegistrationDataMap = null;

		try {
			reqDataJson = new JSONObject(jsonData);
			profileDataJson = reqDataJson.getJSONObject(ApplicationConstant.DATA);

			if (profileDataJson.has(ApplicationConstant.ORG_ID)) {
				orgId = profileDataJson.getString(ApplicationConstant.ORG_ID);
			}
			
			if (profileDataJson.has(ApplicationConstant.ROLE)) {
				role = profileDataJson.getString(ApplicationConstant.ROLE);
			}
			
			if (profileDataJson.has(ApplicationConstant.IMEI_NO)) {
				imeiNo = profileDataJson.getString(ApplicationConstant.IMEI_NO);
			}
			
			if (profileDataJson.has(ApplicationConstant.IS_NEWS_LETTER)) {
				isNewsLetter = profileDataJson.getString(ApplicationConstant.IS_NEWS_LETTER);
			}
			
			if (profileDataJson.has(ApplicationConstant.IS_GOV_REGISTERED)) {
				isGovtRegister = profileDataJson.getString(ApplicationConstant.IS_GOV_REGISTERED);
			}
			
			if (profileDataJson.has(ApplicationConstant.GOVT_REGISTRATION_NO)) {
				registrationNo = profileDataJson.getString(ApplicationConstant.GOVT_REGISTRATION_NO);
			}
			
			if (profileDataJson.has(ApplicationConstant.DISPLAY_IMAGE)) {
				dpImgLink = profileDataJson.getString(ApplicationConstant.DISPLAY_IMAGE);
			}
			
			if (profileDataJson.has(ApplicationConstant.FB_LINK)) {
				fbLink = profileDataJson.getString(ApplicationConstant.FB_LINK);
			}
			
			
			if (profileDataJson.has(ApplicationConstant.LINKEDIN_LINK)) {
				linkedinLink = profileDataJson.getString(ApplicationConstant.LINKEDIN_LINK);
			}
			
			if (profileDataJson.has(ApplicationConstant.WEBSITE_LINK)) {
				websiteLink = profileDataJson.getString(ApplicationConstant.WEBSITE_LINK);
			}
			
			if (profileDataJson.has(ApplicationConstant.TWITTER_LINK)) {
				twitterLink = profileDataJson.getString(ApplicationConstant.TWITTER_LINK);
			}
			
			if (profileDataJson.has(ApplicationConstant.PRESENCE_AREA)) {
				presenceArea = profileDataJson.getString(ApplicationConstant.PRESENCE_AREA);
			}

			

			if (log.isInfoEnabled()) {
				log.info("Message Headers is : " + messageHeaders);
			}

			orgRegistrationDataMap = getOrgProfileDataMap(orgId,role,imeiNo,isNewsLetter,isGovtRegister,registrationNo,dpImgLink,fbLink,twitterLink,linkedinLink,websiteLink,presenceArea);

			response = orgCoreHelperService.updateOrgProfile(orgRegistrationDataMap);

			return MessageBuilder.withPayload(response).build();

		} catch (Exception ex) {
			log.error("Exception in OrgProfileService/execute() " + ex.getMessage(), ex.getCause());

		}

		return null;
		
	}

	private HashMap<String, String> getOrgProfileDataMap(String orgId, String role, String imeiNo, String isNewsLetter,
			String isGovtRegister, String registrationNo, String dpImgLink, String fbLink, String twitterLink,
			String linkedinLink, String websiteLink, String presenceArea)
	{
		HashMap<String,String> orgProfileDataMap = new HashMap<String, String>();
		orgProfileDataMap.put(ApplicationConstant.ORG_ID, orgId);
		orgProfileDataMap.put(ApplicationConstant.ROLE, role);
		orgProfileDataMap.put(ApplicationConstant.IMEI_NO, imeiNo);
		orgProfileDataMap.put(ApplicationConstant.IS_NEWS_LETTER, isNewsLetter);
		orgProfileDataMap.put(ApplicationConstant.IS_GOV_REGISTERED, isGovtRegister);
		orgProfileDataMap.put(ApplicationConstant.GOVT_REGISTRATION_NO, registrationNo);
		orgProfileDataMap.put(ApplicationConstant.DISPLAY_IMAGE, dpImgLink);
		orgProfileDataMap.put(ApplicationConstant.FB_LINK, fbLink);
		orgProfileDataMap.put(ApplicationConstant.TWITTER_LINK, twitterLink);
		orgProfileDataMap.put(ApplicationConstant.LINKEDIN_LINK, linkedinLink);
		orgProfileDataMap.put(ApplicationConstant.WEBSITE_LINK, websiteLink);
		orgProfileDataMap.put(ApplicationConstant.PRESENCE_AREA, presenceArea);
		
		
		return orgProfileDataMap;
	}

}
