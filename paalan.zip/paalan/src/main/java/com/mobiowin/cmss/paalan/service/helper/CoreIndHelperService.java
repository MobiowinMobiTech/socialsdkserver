package com.mobiowin.cmss.paalan.service.helper;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.cmss.paalan.bean.ConnectBean;
import com.mobiowin.cmss.paalan.bean.DonateBean;
import com.mobiowin.cmss.paalan.bean.IndProfileBean;
import com.mobiowin.cmss.paalan.bean.IndRegistrationBean;
import com.mobiowin.cmss.paalan.bean.OrgAchievementBean;
import com.mobiowin.cmss.paalan.bean.OrgEventBean;
import com.mobiowin.cmss.paalan.bean.OrgProfileBean;
import com.mobiowin.cmss.paalan.bean.OrgRegistrationBean;
import com.mobiowin.cmss.paalan.bean.OrgRequestBean;
import com.mobiowin.cmss.paalan.commons.ApplicationConstant;
import com.mobiowin.cmss.paalan.commons.IdGeneratorUtility;
import com.mobiowin.cmss.paalan.commons.MessageUtility;
import com.mobiowin.cmss.paalan.commons.ReverseGeoUtility;
import com.mobiowin.cmss.paalan.dao.ICoreIndHelperDao;
import com.mobiowin.cmss.paalan.image.ImageUrlService;
import com.mobiowin.cmss.paalan.test.DateUtility;

@Service("indCoreHelperService")
@Component
public class CoreIndHelperService implements ICoreIndHelperService {

	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private ICoreIndHelperDao coreIndHelperDao;

	@Autowired
	private ImageUrlService imageService;

	public String isExistingInd(HashMap<String, String> registrationDataMap) {
		log.info("Inside CoreIndHelperService/isExistingOrg()");

		IndRegistrationBean indRegistrationBean = null;
		String response = null;
		HashMap<String, Object> dataMap = null;
		StringBuilder addressBuilder = null;
		String[] subAddress = null;
		boolean isExists = false;

		if (null != registrationDataMap) {
			List<String> userAddressList = ReverseGeoUtility.getReverseGeoDetails(
					registrationDataMap.get(ApplicationConstant.USER_LATITUDE),
					registrationDataMap.get(ApplicationConstant.USER_LONGITUDE));

			indRegistrationBean = new IndRegistrationBean();
			indRegistrationBean.setName(registrationDataMap.get(ApplicationConstant.NAME));
			indRegistrationBean.setMemberId(IdGeneratorUtility.generateOrgId(registrationDataMap));
			indRegistrationBean.setMobileNo(registrationDataMap.get(ApplicationConstant.MOBILE_NO));
			indRegistrationBean.setEmailId(registrationDataMap.get(ApplicationConstant.EMAIL_ID));
			indRegistrationBean.setPassword(registrationDataMap.get(ApplicationConstant.PASSWORD));
			indRegistrationBean.setNotificationId(registrationDataMap.get(ApplicationConstant.NOTIFICATION_ID));
			indRegistrationBean.setDeviceId(registrationDataMap.get(ApplicationConstant.DEVICE_ID));
			if (null != userAddressList) {

				addressBuilder = new StringBuilder();
				for (String str : userAddressList) {
					addressBuilder.append(str);
				}
				indRegistrationBean.setAddress(addressBuilder.toString());
				indRegistrationBean.setCountry(userAddressList.get(userAddressList.size() - 1));

				subAddress = userAddressList.get(userAddressList.size() - 2).trim().split(" ");

				if (null != subAddress) {
					indRegistrationBean.setState(subAddress[0]);
					indRegistrationBean.setPincode(subAddress[1]);
				}

				indRegistrationBean.setState(subAddress[0]);
				indRegistrationBean.setCity(userAddressList.get(userAddressList.size() - 3));

			}
			indRegistrationBean.setCreatedBy(ApplicationConstant.SYSTEM_CREATED_BY);
			indRegistrationBean.setModifiedBy(ApplicationConstant.SYSTEM_MODIFIED_BY);
			indRegistrationBean.setDeleteFlag(ApplicationConstant.DEL_FLAG);
		}

		isExists = coreIndHelperDao.isAlreadyExist(indRegistrationBean);

		log.info("Is individual already exist : " + isExists);

		if (!isExists) {
			response = coreIndHelperDao.registerIndividual(indRegistrationBean);

			log.info("Response is : " + response);

			if (response.equals(ApplicationConstant.TRUE)) {
				dataMap = new HashMap<String, Object>();

				dataMap.put(ApplicationConstant.MEMBER_ID, indRegistrationBean.getMemberId());
				return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));

			}
		} else {
			return MessageUtility.createErrorMessage("User already registered with Paalan, Kindly login!!!");

		}

		return MessageUtility.createErrorMessage();
	}

	public String validateIndLogin(HashMap<String, String> loginReqDataMap) {
		log.info("Inside CoreIndHelperService/validateOrgLogin()");

		IndRegistrationBean indRegistrationBean = null;
		HashMap<String, Object> dataMap = null;
		// boolean isRegisteredOrg = false;
		List<String> addressList = null;
		StringBuilder addressBuilder = null;
		String[] subAddress = null;
		List<OrgEventBean> locallyEventList = null;
		List<OrgRequestBean> locallyRequestList = null;
		List<OrgRegistrationBean> locallySocialGroupList = null;
		List<OrgProfileBean> socialGroupProfileList = null;
		List<OrgAchievementBean> locallyOrgAchivementList = null;
		List<String> orgIdList = null;

		/*
		 * Logic change to remove individual login
		 * 
		 * @Date 31-Jan-2017
		 * 
		 * @Author Raman
		 */

		/*
		 * if (null != loginReqDataMap) { indRegistrationBean = new
		 * IndRegistrationBean();
		 * indRegistrationBean.setMobileNo(loginReqDataMap.get(
		 * ApplicationConstant.FLASH_USER_ID));
		 * indRegistrationBean.setPassword(loginReqDataMap.get(
		 * ApplicationConstant.FLASH_PASSWORD));
		 * 
		 * log.info("indRegistrationBean : " + indRegistrationBean);
		 * 
		 * }
		 */

		// isRegisteredOrg =
		// coreIndHelperDao.validateLogin(indRegistrationBean);

		/*
		 * if (isRegisteredOrg) {
		 */
		dataMap = new HashMap<String, Object>();

		if ((loginReqDataMap.get(ApplicationConstant.USER_LATITUDE) != ApplicationConstant.EMPTY_STRING
				|| null != loginReqDataMap.get(ApplicationConstant.USER_LATITUDE))
				&& loginReqDataMap.get(ApplicationConstant.USER_LONGITUDE) != ApplicationConstant.EMPTY_STRING
				|| null != loginReqDataMap.get(ApplicationConstant.USER_LONGITUDE)) {

			indRegistrationBean = new IndRegistrationBean();

			addressList = ReverseGeoUtility.getReverseGeoDetails(loginReqDataMap.get(ApplicationConstant.USER_LATITUDE),
					loginReqDataMap.get(ApplicationConstant.USER_LONGITUDE));

			if (null != addressList) {

				addressBuilder = new StringBuilder();
				for (String str : addressList) {
					addressBuilder.append(str);
				}
				indRegistrationBean.setAddress(addressBuilder.toString());
				indRegistrationBean.setCountry(addressList.get(addressList.size() - 1).trim());

				subAddress = addressList.get(addressList.size() - 2).trim().split(" ");

				if (null != subAddress) {
					indRegistrationBean.setState(subAddress[0].trim());
					indRegistrationBean.setPincode(subAddress[1].trim());
				}

				indRegistrationBean.setState(subAddress[0].trim());
				indRegistrationBean.setCity(addressList.get(addressList.size() - 3).trim());
				indRegistrationBean.setDeleteFlag(ApplicationConstant.DEL_FLAG);

			}

		}

		locallyEventList = coreIndHelperDao.fetchEventDetailsByLocation(indRegistrationBean,
				loginReqDataMap.get(ApplicationConstant.LAST_SYNC_DATE));
		locallyRequestList = coreIndHelperDao.fetchSocialrequestByLocation(indRegistrationBean,
				loginReqDataMap.get(ApplicationConstant.LAST_SYNC_DATE));
		locallySocialGroupList = coreIndHelperDao.fetchSocialGroupsByLocation(indRegistrationBean,
				loginReqDataMap.get(ApplicationConstant.LAST_SYNC_DATE));

		if (null != locallySocialGroupList && locallySocialGroupList.size() > 0) {
			orgIdList = new ArrayList<String>();

			for (OrgRegistrationBean orgRegistrationBean : locallySocialGroupList) {

				orgIdList.add(orgRegistrationBean.getOrgId());
			}

			socialGroupProfileList = coreIndHelperDao.fetchSocialGroupProfile(orgIdList,
					loginReqDataMap.get(ApplicationConstant.LAST_SYNC_DATE));
			locallyOrgAchivementList = coreIndHelperDao.fetchOrgAchivementLocally(orgIdList,
					loginReqDataMap.get(ApplicationConstant.LAST_SYNC_DATE));

			// dataMap.put(ApplicationConstant.ORG_PROFILE_LIST,
			// socialGroupProfileList);
			// dataMap.put(ApplicationConstant.ORG_ACHIEVEMENT_LIST,
			// locallyOrgAchivementList);
		} else {

			socialGroupProfileList = new ArrayList<OrgProfileBean>();
			locallyOrgAchivementList = new ArrayList<OrgAchievementBean>();
		}

		dataMap.put(ApplicationConstant.ORG_LIST, locallySocialGroupList);
		dataMap.put(ApplicationConstant.EVENT_LIST, locallyEventList);
		dataMap.put(ApplicationConstant.ORG_REQ_LIST, locallyRequestList);
		dataMap.put(ApplicationConstant.ORG_PROFILE_LIST, socialGroupProfileList);
		dataMap.put(ApplicationConstant.ORG_ACHIEVEMENT_LIST, locallyOrgAchivementList);
		dataMap.put(ApplicationConstant.LAST_SYNC_DATE, DateUtility.getTimeStamp());

		return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));
		/*
		 * } else { return MessageUtility.
		 * createErrorMessage("Kinldy check login credentials !!!"); }
		 */
	}

	public String updateProfile(HashMap<String, String> profileReqDataMap) {
		log.info("Inside CoreOrgHelperService/updateProfile()");

		IndProfileBean indProfileBean = null;

		String profileImgPath = null;
		String dbResponse = null;
		HashMap<String, Object> dataMap = null;

		log.info("profileReqDataMap : " + profileReqDataMap);

		if (null != profileReqDataMap) 
		{

			if (profileReqDataMap.get(ApplicationConstant.DISPLAY_IMAGE) != null && !profileReqDataMap
					.get(ApplicationConstant.DISPLAY_IMAGE).equalsIgnoreCase(ApplicationConstant.EMPTY_STRING))
			{
				profileReqDataMap.put(ApplicationConstant.USER_TYPE, ApplicationConstant.IND_ENTITY);
				profileImgPath = imageService.saveDisplayImage(profileReqDataMap);

				log.info("profile image path is : " + profileImgPath);
			}

			indProfileBean = new IndProfileBean();
			indProfileBean.setMemberId(profileReqDataMap.get(ApplicationConstant.MEMBER_ID));
			indProfileBean.setImeiNo(profileReqDataMap.get(ApplicationConstant.IMEI_NO));
			indProfileBean.setIsNewsLetter(profileReqDataMap.get(ApplicationConstant.IS_NEWS_LETTER));
			indProfileBean.setDpImgLink(profileImgPath);
			indProfileBean.setCreatedBy(ApplicationConstant.SYSTEM_CREATED_BY);
			indProfileBean.setModifiedBy(ApplicationConstant.SYSTEM_MODIFIED_BY);
			indProfileBean.setDeleteFlag(ApplicationConstant.DEL_FLAG);
		}

		boolean isProfileExist = coreIndHelperDao.isProfileExist(indProfileBean);

		if (isProfileExist) {
			dbResponse = coreIndHelperDao.submitProfile(indProfileBean);

			if (dbResponse.equals(ApplicationConstant.TRUE)) {
				dataMap = new HashMap<String, Object>();
				dataMap.put(ApplicationConstant.MEMBER_ID, indProfileBean.getMemberId());
				dataMap.put(ApplicationConstant.DISPLAY_IMAGE, indProfileBean.getDpImgLink());

				return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));
			}
		} else {
			dbResponse = coreIndHelperDao.updateProfile(indProfileBean);

			if (dbResponse.equals(ApplicationConstant.TRUE)) {
				dataMap = new HashMap<String, Object>();
				dataMap.put(ApplicationConstant.MEMBER_ID, indProfileBean.getMemberId());
				dataMap.put(ApplicationConstant.DISPLAY_IMAGE, indProfileBean.getDpImgLink());

				return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));

			}
		}

		return MessageUtility.createErrorMessage("Profile cannot be updated,Kindly try after some time!!!");
	}

	public String submitMessage(HashMap<String, String> reqDataMap) {
		log.info("Inside CoreOrgHelperService/submitMessage()");

		ConnectBean connectBean = null;
		String dbResponse = null;
		HashMap<String, Object> dataMap = null;

		if (null != reqDataMap) {
			connectBean = new ConnectBean();
			connectBean.setName(reqDataMap.get(ApplicationConstant.NAME));
			connectBean.setEmailId(reqDataMap.get(ApplicationConstant.EMAIL_ID));
			connectBean.setMobileNo(reqDataMap.get(ApplicationConstant.MOBILE_NO));
			connectBean.setMessage(reqDataMap.get(ApplicationConstant.MESSAGE));
			connectBean.setCreatedBy(ApplicationConstant.SYSTEM_CREATED_BY);
			connectBean.setCreateDt(DateUtility.getTimeStamp());
			connectBean.setModifiedBy(ApplicationConstant.SYSTEM_MODIFIED_BY);
			connectBean.setModifyDt(DateUtility.getTimeStamp());
			connectBean.setDeleteFlag(ApplicationConstant.DEL_FLAG);

			dbResponse = coreIndHelperDao.submitMessage(connectBean);

			if (dbResponse.equals(ApplicationConstant.TRUE)) {

				dataMap = new HashMap<String, Object>();

				return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));
			} else {
				return MessageUtility
						.createErrorMessage("Process failed due to some technical issue,Kindly try after some time!!!");
			}

		}

		return MessageUtility
				.createErrorMessage("Process failed due to some technical issue,Kindly try after some time!!!");
	}

	public String submitDonaterequest(HashMap<String, String> reqDataMap) {
		log.info("Inside CoreOrgHelperService/submitDonaterequest()");

		DonateBean donateBean = null;
		String dbResponse = null;
		HashMap<String, Object> dataMap = null;
		String donateImgPath = null;

		if (null != reqDataMap) 
		{
			
			if (reqDataMap.get(ApplicationConstant.IMAGE_SERVLET_IMAGE_PARAM) != null && !reqDataMap
					.get(ApplicationConstant.IMAGE_SERVLET_IMAGE_PARAM).equalsIgnoreCase(ApplicationConstant.EMPTY_STRING))
			{
				reqDataMap.put(ApplicationConstant.USER_TYPE, ApplicationConstant.DONATE_ENTITY);
				donateImgPath = imageService.saveDonateImage(reqDataMap);

				log.info("Donate image path is : " + donateImgPath);
			}
			
			donateBean = new DonateBean();
			donateBean.setName(reqDataMap.get(ApplicationConstant.NAME));
			donateBean.setEmailId(reqDataMap.get(ApplicationConstant.EMAIL_ID));
			donateBean.setMobileNo(reqDataMap.get(ApplicationConstant.MOBILE_NO));
			donateBean.setMessage(reqDataMap.get(ApplicationConstant.MESSAGE));
			donateBean.setAddress(reqDataMap.get(ApplicationConstant.ADDRESS));
			donateBean.setImg(donateImgPath);
			donateBean.setRequestDate(Timestamp.valueOf(DateUtility.syncDateparser(reqDataMap.get(ApplicationConstant.DATE_REQUEST))));
			donateBean.setCollectionMode(reqDataMap.get(ApplicationConstant.COLLECTION_MODE));
			donateBean.setFreeText1(reqDataMap.get(ApplicationConstant.FREE_TEXT1));
			donateBean.setFreeText2(reqDataMap.get(ApplicationConstant.FREE_TEXT2));
			donateBean.setFreeText3(reqDataMap.get(ApplicationConstant.FREE_TEXT3));
			donateBean.setFreeText4(reqDataMap.get(ApplicationConstant.FREE_TEXT4));
			donateBean.setCategory(reqDataMap.get(ApplicationConstant.CATEGORY));
			donateBean.setCreatedBy(ApplicationConstant.SYSTEM_CREATED_BY);
			donateBean.setCreateDt(DateUtility.getTimeStamp());
			donateBean.setModifiedBy(ApplicationConstant.SYSTEM_MODIFIED_BY);
			donateBean.setModifyDt(DateUtility.getTimeStamp());
			donateBean.setDeleteFlag(ApplicationConstant.DEL_FLAG);

			dbResponse = coreIndHelperDao.submitDonationReq(donateBean);

			if (dbResponse.equals(ApplicationConstant.TRUE)) 
			{
				dataMap = new HashMap<String, Object>();
				if(null != donateBean.getImg())
				{
					dataMap.put(ApplicationConstant.DONATE_IMG, donateBean.getImg());
				}
				return MessageUtility.createJSONFromMap(MessageUtility.createSuccessResponseMessage(dataMap));
			} else {
				return MessageUtility
						.createErrorMessage("Process failed due to some technical issue,Kindly try after some time!!!");
			}

		}

		return MessageUtility
				.createErrorMessage("Process failed due to some technical issue,Kindly try after some time!!!");
	}
}
