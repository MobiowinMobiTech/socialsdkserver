package com.mobiowin.cmss.paalan.service.org;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.cmss.paalan.commons.ApplicationConstant;
import com.mobiowin.cmss.paalan.messaging.IMessageService;
import com.mobiowin.cmss.paalan.service.helper.ICoreOrgHelperService;

@Service("orgEventUpdateService")
@Component
public class OrgEventUpdateService implements IMessageService{

	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private ICoreOrgHelperService orgCoreHelperService;

	public Message<String> execute(Message<String> message) {
		log.info("Inside OrgEventUpdateService/execute()");

		String jsonData = message.getPayload();

		Map<String, Object> messageHeaders = message.getHeaders();

		JSONObject dataJson = null;
		JSONObject reqDataJson = null;

		String orgId = null;
		String eventId = null;
		String title = null;
		String subTitle = null;
		String startDt = null;
		String endDt = null;
		String location = null;
		String discription = null;
		String others = null;
		String response = null;

		HashMap<String, String> reqDataMap = null;

		try {
			dataJson = new JSONObject(jsonData);
			reqDataJson = dataJson.getJSONObject(ApplicationConstant.DATA);

			if (reqDataJson.has(ApplicationConstant.ORG_ID)) {
				orgId = reqDataJson.getString(ApplicationConstant.ORG_ID);
			}

			if (reqDataJson.has(ApplicationConstant.EVENT_ID)) {
				eventId = reqDataJson.getString(ApplicationConstant.EVENT_ID);
			}

			if (reqDataJson.has(ApplicationConstant.DISCRIPTION)) {
				discription = reqDataJson.getString(ApplicationConstant.DISCRIPTION);
			}
			
			if (reqDataJson.has(ApplicationConstant.TITLE)) {
				title = reqDataJson.getString(ApplicationConstant.TITLE);
			}

			if (reqDataJson.has(ApplicationConstant.SUB_TITLE)) {
				subTitle = reqDataJson.getString(ApplicationConstant.SUB_TITLE);
			}

			if (reqDataJson.has(ApplicationConstant.START_DATE)) {
				startDt = reqDataJson.getString(ApplicationConstant.START_DATE);
			}

			if (reqDataJson.has(ApplicationConstant.END_DATE)) {
				endDt = reqDataJson.getString(ApplicationConstant.END_DATE);
			}

			if (reqDataJson.has(ApplicationConstant.LOCATION)) {
				location = reqDataJson.getString(ApplicationConstant.LOCATION);
			}

			if (reqDataJson.has(ApplicationConstant.OTHERS)) {
				others = reqDataJson.getString(ApplicationConstant.OTHERS);
			}

			if (log.isInfoEnabled()) {
				log.info("Message Headers is : " + messageHeaders);
				log.info("ORG_ID is : " + orgId);
				log.info("EVENT_ID is : " + eventId);
				log.info("TITLE is : " + title);
				log.info("DISCRIPTION is : " + discription);
				log.info("SUB_TITLE is : " + subTitle);
				log.info("START_DATE is : " + startDt);
				log.info("END_DATE is : " + endDt);
				log.info("LOCATION is : " + location);
				log.info("OTHERS is : " + others);
			}

			reqDataMap = getReqDataMap(orgId, eventId, title, subTitle, startDt, endDt, location, others,discription);

			response = orgCoreHelperService.updateOrgEvent(reqDataMap);

			return MessageBuilder.withPayload(response).build();

		} catch (Exception ex) {
			log.error("Exception in OrgProfileService/execute() " + ex.getMessage(), ex.getCause());

		}

		return null;

	}
	
	private HashMap<String, String> getReqDataMap(String orgId, String eventId, String title, String subTitle,
			String startDt, String endDt, String location, String others, String discription) {
		
		HashMap<String,String> reqDataMap = new HashMap<String, String>();
		
		reqDataMap.put(ApplicationConstant.ORG_ID, orgId);
		reqDataMap.put(ApplicationConstant.EVENT_ID, eventId);
		reqDataMap.put(ApplicationConstant.TITLE, title);
		reqDataMap.put(ApplicationConstant.SUB_TITLE, subTitle);
		reqDataMap.put(ApplicationConstant.START_DATE, startDt);
		reqDataMap.put(ApplicationConstant.END_DATE, endDt);
		reqDataMap.put(ApplicationConstant.LOCATION, location);
		reqDataMap.put(ApplicationConstant.OTHERS, others);
		reqDataMap.put(ApplicationConstant.DISCRIPTION, discription);
		
		return reqDataMap;
	}

}
