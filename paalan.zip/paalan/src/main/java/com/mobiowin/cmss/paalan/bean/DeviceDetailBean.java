package com.mobiowin.cmss.paalan.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "device_details_master", catalog = "paalan")
public class DeviceDetailBean implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private String id;
	
	@Column(name = "imei_no")
	private String imeiNo;
	
	@Column(name = "device_model")
	private String deviceModel;
	
	@Column(name = "device_id")
	private String deviceId;
	
	
	@Column(name = "os_version")
	private String osVersion;
	
	@Column(name = "notification_id")
	private String notificationId;
	
	@Column(name = "address")
	private String address;
	
	@Column(name = "city")
	private String city;
	
	@Column(name = "state")
	private String state;
	
	@Column(name = "pincode")
	private String pincode;
	
	@Column(name = "country")
	private String country;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_dt")
	private Date createDt;

	@Column(name = "modified_by")
	private String modifiedBy;

	@Column(name = "modified_dt")
	private Date modifyDt;

	@Column(name = "del_flag")
	private String deleteFlag;

	public DeviceDetailBean() {
		super();
	}

	

	public DeviceDetailBean(String id, String imeiNo, String deviceModel, String deviceId, 
			String osVersion, String notificationId, String address, String city, String state, String pincode,
			String country, String createdBy, Date createDt, String modifiedBy, Date modifyDt, String deleteFlag) {
		super();
		this.id = id;
		this.imeiNo = imeiNo;
		this.deviceModel = deviceModel;
		this.deviceId = deviceId;
		
		this.osVersion = osVersion;
		this.notificationId = notificationId;
		this.address = address;
		this.city = city;
		this.state = state;
		this.pincode = pincode;
		this.country = country;
		this.createdBy = createdBy;
		this.createDt = createDt;
		this.modifiedBy = modifiedBy;
		this.modifyDt = modifyDt;
		this.deleteFlag = deleteFlag;
	}



	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDeviceModel() {
		return deviceModel;
	}

	public void setDeviceModel(String deviceModel) {
		this.deviceModel = deviceModel;
	}

	public String getDeviceId() {
		return deviceId;
	}

	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}

	

	public String getOsVersion() {
		return osVersion;
	}

	public void setOsVersion(String osVersion) {
		this.osVersion = osVersion;
	}

	public String getNotificationId() {
		return notificationId;
	}

	public void setNotificationId(String notificationId) {
		this.notificationId = notificationId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPincode() {
		return pincode;
	}

	public void setPincode(String pincode) {
		this.pincode = pincode;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Date createDt) {
		this.createDt = createDt;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifyDt() {
		return modifyDt;
	}

	public void setModifyDt(Date modifyDt) {
		this.modifyDt = modifyDt;
	}

	public String getDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}
	
	

	public String getImeiNo() {
		return imeiNo;
	}



	public void setImeiNo(String imeiNo) {
		this.imeiNo = imeiNo;
	}



	@Override
	public String toString() {
		return "DeviceDetailBean [id=" + id + ", imeiNo=" + imeiNo + ", deviceModel=" + deviceModel + ", deviceId="
				+ deviceId + ", osVersion=" + osVersion + ", notificationId=" + notificationId + ", address=" + address
				+ ", city=" + city + ", state=" + state + ", pincode=" + pincode + ", country=" + country
				+ ", createdBy=" + createdBy + ", createDt=" + createDt + ", modifiedBy=" + modifiedBy + ", modifyDt="
				+ modifyDt + ", deleteFlag=" + deleteFlag + "]";
	}



	


}
