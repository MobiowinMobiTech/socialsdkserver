package com.mobiowin.cmss.paalan.service.org;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.cmss.paalan.commons.ApplicationConstant;
import com.mobiowin.cmss.paalan.messaging.IMessageService;
import com.mobiowin.cmss.paalan.service.helper.ICoreOrgHelperService;

@Service("orgRecordSyncService")
@Component
public class OrgRecordSyncService implements IMessageService {

	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private ICoreOrgHelperService orgCoreHelperService;

	public Message<String> execute(Message<String> message)
	{
		log.info("Inside OrgRecordSyncService/execute()");

		String jsonData = message.getPayload();

		Map<String, Object> messageHeaders = message.getHeaders();

		JSONObject dataJson = null;
		JSONObject reqDataJson = null;

		String orgId = null;
		String recordId = null;
		String notificationType = null;
		String response = null;
		

		HashMap<String, String> reqDataMap = null;

		try {
			dataJson = new JSONObject(jsonData);
			reqDataJson = dataJson.getJSONObject(ApplicationConstant.DATA);

			if (reqDataJson.has(ApplicationConstant.ORG_ID)) {
				orgId = reqDataJson.getString(ApplicationConstant.ORG_ID);
			}
			
			if (reqDataJson.has(ApplicationConstant.RECORD_ID)) {
				recordId = reqDataJson.getString(ApplicationConstant.RECORD_ID);
			}
			
			if (reqDataJson.has(ApplicationConstant.NOTIFICATION_TYPE)) {
				notificationType = reqDataJson.getString(ApplicationConstant.NOTIFICATION_TYPE);
			}
			
			
			

			if (log.isInfoEnabled()) {
				log.info("Message Headers is : " + messageHeaders);
				log.info("ORG_ID is : " + orgId);
				log.info("RECORD_ID is : " + recordId);
				log.info("NOTIFICATION_TYPE is : " + notificationType);
				
				//log.info("" + Timestamp.valueOf(lastSyncDate));

			}

			reqDataMap = getReqDataMap(orgId,recordId,notificationType);

			response = orgCoreHelperService.syncOrgRecord(reqDataMap);

			return MessageBuilder.withPayload(response).build();

		} catch (Exception ex) {
			log.error("Exception in OrgProfileService/execute() " + ex.getMessage(), ex.getCause());

		}

		return null;

	}

	private HashMap<String, String> getReqDataMap(String orgId,String recordId, String notificationType) {

		HashMap<String, String> reqDataMap = new HashMap<String, String>();

		reqDataMap.put(ApplicationConstant.ORG_ID, orgId);
		reqDataMap.put(ApplicationConstant.RECORD_ID, recordId);
		reqDataMap.put(ApplicationConstant.NOTIFICATION_TYPE, notificationType);

		return reqDataMap;
	}
}