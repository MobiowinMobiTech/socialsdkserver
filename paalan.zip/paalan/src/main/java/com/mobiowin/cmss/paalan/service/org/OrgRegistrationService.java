package com.mobiowin.cmss.paalan.service.org;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.cmss.paalan.commons.ApplicationConstant;
import com.mobiowin.cmss.paalan.messaging.IMessageService;
import com.mobiowin.cmss.paalan.service.helper.ICoreOrgHelperService;

@Service("orgRegistrationService")
@Component
public class OrgRegistrationService implements IMessageService {

	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private ICoreOrgHelperService orgCoreHelperService;

	public Message<String> execute(Message<String> message) {
		log.info("Inside OrgRegistrationService/execute()");

		String jsonData = message.getPayload();

		Map<String, Object> messageHeaders = message.getHeaders();

		JSONObject orgDataJson = null;
		JSONObject orgRegistrationDataJson = null;

		String orgName = null;
		String mobileNo = null;
		String imeiNo = null;
		String password = null;
		String emailId = null;
		String deviceId = null;
		String notificationId = null;
		String response = null;
		String address = null;
		String city = null;
		String state = null;
		String pinCode = null;
		String country = null;

		HashMap<String, String> orgRegistrationDataMap = null;

		try {
			orgDataJson = new JSONObject(jsonData);
			orgRegistrationDataJson = orgDataJson.getJSONObject(ApplicationConstant.DATA);

			if (orgRegistrationDataJson.has(ApplicationConstant.NAME)) {
				orgName = orgRegistrationDataJson.getString(ApplicationConstant.NAME);
			}

			if (orgRegistrationDataJson.has(ApplicationConstant.MOBILE_NO)) {
				mobileNo = orgRegistrationDataJson.getString(ApplicationConstant.MOBILE_NO);
			}

			if (orgRegistrationDataJson.has(ApplicationConstant.IMEI_NO)) {
				imeiNo = orgRegistrationDataJson.getString(ApplicationConstant.IMEI_NO);
			}

			if (orgRegistrationDataJson.has(ApplicationConstant.PASSWORD)) {
				password = orgRegistrationDataJson.getString(ApplicationConstant.PASSWORD);
			}

			if (orgRegistrationDataJson.has(ApplicationConstant.EMAIL_ID)) {
				emailId = orgRegistrationDataJson.getString(ApplicationConstant.EMAIL_ID);
			}

			if (orgRegistrationDataJson.has(ApplicationConstant.NOTIFICATION_ID)) {
				notificationId = orgRegistrationDataJson.getString(ApplicationConstant.NOTIFICATION_ID);
			}

			if (orgRegistrationDataJson.has(ApplicationConstant.DEVICE_ID)) {
				deviceId = orgRegistrationDataJson.getString(ApplicationConstant.DEVICE_ID);
			}

			if (orgRegistrationDataJson.has(ApplicationConstant.ADDRESS)) {
				address = orgRegistrationDataJson.getString(ApplicationConstant.ADDRESS);
			}

			if (orgRegistrationDataJson.has(ApplicationConstant.CITY)) {
				city = orgRegistrationDataJson.getString(ApplicationConstant.CITY);
			}

			if (orgRegistrationDataJson.has(ApplicationConstant.STATE)) {
				state = orgRegistrationDataJson.getString(ApplicationConstant.STATE);
			}

			if (orgRegistrationDataJson.has(ApplicationConstant.PIN_CODE)) {
				pinCode = orgRegistrationDataJson.getString(ApplicationConstant.PIN_CODE);
			}

			if (orgRegistrationDataJson.has(ApplicationConstant.COUNTRY)) {
				country = orgRegistrationDataJson.getString(ApplicationConstant.COUNTRY);
			}

			if (log.isInfoEnabled()) {
				log.info("Message Headers is : " + messageHeaders);
				log.info("Orgnization name is : " + orgName);
				log.info("Mobile no is : " + mobileNo);
				log.info("email id is : " + emailId);
				log.info("imei no is :" + imeiNo);
				log.info("Password is : " + password);
				log.info("Device id is : " + deviceId);
				log.info("notification id is : " + notificationId);

			}

			orgRegistrationDataMap = getOrgRegDataMap(orgName, mobileNo, emailId, imeiNo, password, deviceId,
					notificationId, address, city, state, pinCode, country);

			response = orgCoreHelperService.isExistingOrg(orgRegistrationDataMap);

			return MessageBuilder.withPayload(response).build();

		} catch (Exception ex) {
			log.error("Exception in RegistrationService/execute() " + ex.getMessage(), ex.getCause());
			response = "Kindly check request parameter";
			return MessageBuilder.withPayload(response).build();
		}

	}

	private HashMap<String, String> getOrgRegDataMap(String orgName, String mobileNo, String emailId, String imeiNo,
			String password, String deviceId, String notificationId, String address, String city, String state,
			String pinCode, String country) {
		HashMap<String, String> orgRegDataMap = new HashMap<String, String>();
		orgRegDataMap.put(ApplicationConstant.NAME, orgName);
		orgRegDataMap.put(ApplicationConstant.MOBILE_NO, mobileNo);
		orgRegDataMap.put(ApplicationConstant.EMAIL_ID, emailId);
		orgRegDataMap.put(ApplicationConstant.IMEI_NO, imeiNo);
		orgRegDataMap.put(ApplicationConstant.PASSWORD, password);
		orgRegDataMap.put(ApplicationConstant.DEVICE_ID, deviceId);
		orgRegDataMap.put(ApplicationConstant.NOTIFICATION_ID, notificationId);
		orgRegDataMap.put(ApplicationConstant.ADDRESS, address);
		orgRegDataMap.put(ApplicationConstant.CITY, city);
		orgRegDataMap.put(ApplicationConstant.PINCODE, pinCode);
		orgRegDataMap.put(ApplicationConstant.STATE, state);
		orgRegDataMap.put(ApplicationConstant.COUNTRY, country);

		return orgRegDataMap;
	}

}
