package com.mobiowin.cmss.paalan.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "org_profile_master", catalog = "paalan")
public class OrgProfileBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private String id;

	@Column(name = "org_id")
	private String orgId;

	@Column(name = "org_name")
	private String name;

	@Column(name = "mobile_no")
	private String mobileNo;

	@Column(name = "email_id")
	private String emailId;

	@Column(name = "address")
	private String address;

	@Column(name = "role")
	private String role;

	@Column(name = "imei_no")
	private String imeiNo;

	@Column(name = "is_newsletter")
	private String isNewsLetter;

	@Column(name = "is_govt_register")
	private String isGovtRegister;

	@Column(name = "govt_registration_no")
	private String registrationNo;

	@Column(name = "dp_img_link")
	private String dpImgLink;

	@Column(name = "fb_link")
	private String fbLink;

	@Column(name = "linkedin_link")
	private String linkedinLink;

	@Column(name = "website_link")
	private String websiteLink;

	@Column(name = "twitter_link")
	private String twitterLink;

	@Column(name = "presence_area")
	private String presenceArea;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_dt")
	private Date createDt;

	@Column(name = "modified_by")
	private String modifiedBy;

	@Column(name = "modified_dt")
	private Date modifyDt;

	@Column(name = "del_flag")
	private String deleteFlag;

	public OrgProfileBean() {
		super();
	}

	public OrgProfileBean(String id, String orgId, String name, String mobileNo, String emailId, String address,
			String role, String imeiNo, String isNewsLetter, String isGovtRegister, String registrationNo,
			String dpImgLink, String fbLink, String linkedinLink, String websiteLink, String twitterLink,
			String presenceArea, String createdBy, Date createDt, String modifiedBy, Date modifyDt, String deleteFlag) {
		super();
		this.id = id;
		this.orgId = orgId;
		this.name = name;
		this.mobileNo = mobileNo;
		this.emailId = emailId;
		this.address = address;
		this.role = role;
		this.imeiNo = imeiNo;
		this.isNewsLetter = isNewsLetter;
		this.isGovtRegister = isGovtRegister;
		this.registrationNo = registrationNo;
		this.dpImgLink = dpImgLink;
		this.fbLink = fbLink;
		this.linkedinLink = linkedinLink;
		this.websiteLink = websiteLink;
		this.twitterLink = twitterLink;
		this.presenceArea = presenceArea;
		this.createdBy = createdBy;
		this.createDt = createDt;
		this.modifiedBy = modifiedBy;
		this.modifyDt = modifyDt;
		this.deleteFlag = deleteFlag;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getImeiNo() {
		return imeiNo;
	}

	public void setImeiNo(String imeiNo) {
		this.imeiNo = imeiNo;
	}

	public String getIsNewsLetter() {
		return isNewsLetter;
	}

	public void setIsNewsLetter(String isNewsLetter) {
		this.isNewsLetter = isNewsLetter;
	}

	public String getIsGovtRegister() {
		return isGovtRegister;
	}

	public void setIsGovtRegister(String isGovtRegister) {
		this.isGovtRegister = isGovtRegister;
	}

	public String getRegistrationNo() {
		return registrationNo;
	}

	public void setRegistrationNo(String registrationNo) {
		this.registrationNo = registrationNo;
	}

	public String getDpImgLink() {
		return dpImgLink;
	}

	public void setDpImgLink(String dpImgLink) {
		this.dpImgLink = dpImgLink;
	}

	public String getFbLink() {
		return fbLink;
	}

	public void setFbLink(String fbLink) {
		this.fbLink = fbLink;
	}

	public String getLinkedinLink() {
		return linkedinLink;
	}

	public void setLinkedinLink(String linkedinLink) {
		this.linkedinLink = linkedinLink;
	}

	public String getWebsiteLink() {
		return websiteLink;
	}

	public void setWebsiteLink(String websiteLink) {
		this.websiteLink = websiteLink;
	}

	public String getTwitterLink() {
		return twitterLink;
	}

	public void setTwitterLink(String twitterLink) {
		this.twitterLink = twitterLink;
	}

	public String getPresenceArea() {
		return presenceArea;
	}

	public void setPresenceArea(String presenceArea) {
		this.presenceArea = presenceArea;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Date createDt) {
		this.createDt = createDt;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifyDt() {
		return modifyDt;
	}

	public void setModifyDt(Date modifyDt) {
		this.modifyDt = modifyDt;
	}

	public String getDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "OrgProfileBean [id=" + id + ", orgId=" + orgId + ", name=" + name + ", mobileNo=" + mobileNo
				+ ", emailId=" + emailId + ", address=" + address + ", role=" + role + ", imeiNo=" + imeiNo
				+ ", isNewsLetter=" + isNewsLetter + ", isGovtRegister=" + isGovtRegister + ", registrationNo="
				+ registrationNo + ", dpImgLink=" + dpImgLink + ", fbLink=" + fbLink + ", linkedinLink=" + linkedinLink
				+ ", websiteLink=" + websiteLink + ", twitterLink=" + twitterLink + ", presenceArea=" + presenceArea
				+ ", createdBy=" + createdBy + ", createDt=" + createDt + ", modifiedBy=" + modifiedBy + ", modifyDt="
				+ modifyDt + ", deleteFlag=" + deleteFlag + "]";
	}	

}
