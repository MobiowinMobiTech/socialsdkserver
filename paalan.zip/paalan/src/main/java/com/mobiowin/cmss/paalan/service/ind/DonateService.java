package com.mobiowin.cmss.paalan.service.ind;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.cmss.paalan.commons.ApplicationConstant;
import com.mobiowin.cmss.paalan.messaging.IMessageService;
import com.mobiowin.cmss.paalan.service.helper.ICoreIndHelperService;

@Service("donateService")
@Component
public class DonateService implements IMessageService {

	private Log log = LogFactory.getLog(this.getClass());
	
	@Autowired
	private ICoreIndHelperService indCoreHelperService;
	
	public Message<String> execute(Message<String> message) 
	{
		
		log.info("Inside PaalanConnectService/execute()");

		String jsonData = message.getPayload();

		Map<String, Object> messageHeaders = message.getHeaders();

		JSONObject dataJson = null;
		JSONObject reqDataJson = null;

		String name = null;
		String mobileNo = null;
		String email = null;
		String category = null;
		String donateMessage = null;
		String address = null;
		String img = null;
		String collectionMode = null;
		String date = null;
		String freeText2 = null;
		String freeText1 = null;
		String freeText3 = null;
		String freeText4 = null;
		String response = null;

		HashMap<String, String> reqDataMap = null;

		try {
			dataJson = new JSONObject(jsonData);
			reqDataJson = dataJson.getJSONObject(ApplicationConstant.DATA);
  
			if (reqDataJson.has(ApplicationConstant.NAME)) {
				name = reqDataJson.getString(ApplicationConstant.NAME);
			}
			
			if (reqDataJson.has(ApplicationConstant.EMAIL_ID)) {
				email = reqDataJson.getString(ApplicationConstant.EMAIL_ID);
			}
			
			if (reqDataJson.has(ApplicationConstant.MOBILE_NO)) {
				mobileNo = reqDataJson.getString(ApplicationConstant.MOBILE_NO);
			}
			
			if (reqDataJson.has(ApplicationConstant.MESSAGE)) {
				donateMessage = reqDataJson.getString(ApplicationConstant.MESSAGE);
			}
			
			if (reqDataJson.has(ApplicationConstant.CATEGORY)) {
				category = reqDataJson.getString(ApplicationConstant.CATEGORY);
			}
			
			if (reqDataJson.has(ApplicationConstant.ADDRESS)) {
				address = reqDataJson.getString(ApplicationConstant.ADDRESS);
			}
			
			if (reqDataJson.has(ApplicationConstant.IMAGE_SERVLET_IMAGE_PARAM)) {
				img = reqDataJson.getString(ApplicationConstant.IMAGE_SERVLET_IMAGE_PARAM);
			}
			
			if (reqDataJson.has(ApplicationConstant.DATE_REQUEST)) {
				date = reqDataJson.getString(ApplicationConstant.DATE_REQUEST);
			}
			
			if (reqDataJson.has(ApplicationConstant.COLLECTION_MODE)) {
				collectionMode = reqDataJson.getString(ApplicationConstant.COLLECTION_MODE);
			}
			
			if (reqDataJson.has(ApplicationConstant.FREE_TEXT1)) {
				freeText1 = reqDataJson.getString(ApplicationConstant.FREE_TEXT1);
			}
			
			if (reqDataJson.has(ApplicationConstant.FREE_TEXT2)) {
				freeText2 = reqDataJson.getString(ApplicationConstant.FREE_TEXT2);
			}
			
			if (reqDataJson.has(ApplicationConstant.FREE_TEXT3)) {
				freeText3 = reqDataJson.getString(ApplicationConstant.FREE_TEXT3);
			}
			
			if (reqDataJson.has(ApplicationConstant.FREE_TEXT4)) {
				freeText4 = reqDataJson.getString(ApplicationConstant.FREE_TEXT4);
			}

			if (log.isInfoEnabled()) {
				log.info("Message Headers is : " + messageHeaders);
				log.info("NAME is : " + name);
				log.info("EMAIL_ID is : " + email);
				log.info("MOBILE_NO is : " + mobileNo);
				log.info("MESSAGE is : " + donateMessage);
				log.info("CATEGORY is : " + category);
				log.info("ADDRESS is : " + address);
				//log.info("IMAGE_SERVLET_IMAGE_PARAM is : " + donateMessage);
				log.info("DATE_REQUEST is : " + date);
				log.info("COLLECTION_MODE is : " + collectionMode);
				log.info("FREE_TEXT1 is : " + freeText1);
				log.info("FREE_TEXT2 is : " + freeText2);
				log.info("FREE_TEXT3 is : " + freeText3);
				log.info("FREE_TEXT4 is : " + freeText4);
				

			}

			reqDataMap = getReqDataMap(name,email,mobileNo,donateMessage,category,address,date,collectionMode,freeText1,freeText2,freeText3,freeText4,img);

			response = indCoreHelperService.submitDonaterequest(reqDataMap);

			return MessageBuilder.withPayload(response).build();

		} catch (Exception ex) {
			log.error("Exception in OrgProfileService/execute() " + ex.getMessage(), ex.getCause());

		}

		return null;

	}

	private HashMap<String, String> getReqDataMap(String name, String email, String mobileNo, String message, String category, String address, String date, String collectionMode, String freeText1, String freeText2, String freeText3, String freeText4,String img) {

		HashMap<String, String> reqDataMap = new HashMap<String, String>();

		reqDataMap.put(ApplicationConstant.NAME, name);
		reqDataMap.put(ApplicationConstant.EMAIL_ID, email);
		reqDataMap.put(ApplicationConstant.MOBILE_NO, mobileNo);
		reqDataMap.put(ApplicationConstant.MESSAGE, message);
		reqDataMap.put(ApplicationConstant.CATEGORY, category);
		reqDataMap.put(ApplicationConstant.ADDRESS, address);
		reqDataMap.put(ApplicationConstant.DATE_REQUEST, date);
		reqDataMap.put(ApplicationConstant.COLLECTION_MODE, collectionMode);
		reqDataMap.put(ApplicationConstant.FREE_TEXT1, freeText1);
		reqDataMap.put(ApplicationConstant.FREE_TEXT2, freeText2);
		reqDataMap.put(ApplicationConstant.FREE_TEXT3, freeText3);
		reqDataMap.put(ApplicationConstant.FREE_TEXT4, freeText4);
		reqDataMap.put(ApplicationConstant.IMAGE_SERVLET_IMAGE_PARAM, img);
		
		return reqDataMap;
	}

}
