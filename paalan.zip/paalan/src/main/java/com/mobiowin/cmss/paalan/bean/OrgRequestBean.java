package com.mobiowin.cmss.paalan.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "org_social_request_master", catalog = "paalan")
public class OrgRequestBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private String id;

	@Column(name = "org_id")
	private String orgId;

	@Column(name = "org_name")
	private String orgName;

	@Column(name = "request_id")
	private String requestId;

	@Column(name = "request_title")
	private String title;

	@Column(name = "request_sub_title")
	private String subTitle;

	@Column(name = "request_discription")
	private String discription;

	@Column(name = "request_location")
	private String location;

	@Column(name = "others")
	private String others;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_dt")
	private Date createDt;

	@Column(name = "modified_by")
	private String modifiedBy;

	@Column(name = "modified_dt")
	private Date modifyDt;

	@Column(name = "del_flag")
	private String deleteFlag;

	public OrgRequestBean() {
		super();
	}

	public OrgRequestBean(String id, String orgId, String orgName, String requestId, String title, String subTitle,
			String discription, String location, String others, String createdBy, Date createDt, String modifiedBy,
			Date modifyDt, String deleteFlag) {
		super();
		this.id = id;
		this.orgId = orgId;
		this.orgName = orgName;
		this.requestId = requestId;
		this.title = title;
		this.subTitle = subTitle;
		this.discription = discription;
		this.location = location;
		this.others = others;
		this.createdBy = createdBy;
		this.createDt = createDt;
		this.modifiedBy = modifiedBy;
		this.modifyDt = modifyDt;
		this.deleteFlag = deleteFlag;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getOrgId() {
		return orgId;
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getSubTitle() {
		return subTitle;
	}

	public void setSubTitle(String subTitle) {
		this.subTitle = subTitle;
	}

	public String getDiscription() {
		return discription;
	}

	public void setDiscription(String discription) {
		this.discription = discription;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getOthers() {
		return others;
	}

	public void setOthers(String others) {
		this.others = others;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Date createDt) {
		this.createDt = createDt;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifyDt() {
		return modifyDt;
	}

	public void setModifyDt(Date modifyDt) {
		this.modifyDt = modifyDt;
	}

	public String getDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}

	public String getOrgName() {
		return orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	@Override
	public String toString() {
		return "OrgRequestBean [id=" + id + ", orgId=" + orgId + ", orgName=" + orgName + ", requestId=" + requestId
				+ ", title=" + title + ", subTitle=" + subTitle + ", discription=" + discription + ", location="
				+ location + ", others=" + others + ", createdBy=" + createdBy + ", createDt=" + createDt
				+ ", modifiedBy=" + modifiedBy + ", modifyDt=" + modifyDt + ", deleteFlag=" + deleteFlag + "]";
	}

}
