package com.mobiowin.cmss.paalan.dao;

import java.util.List;

import com.mobiowin.cmss.paalan.bean.ConnectBean;
import com.mobiowin.cmss.paalan.bean.DonateBean;
import com.mobiowin.cmss.paalan.bean.IndProfileBean;
import com.mobiowin.cmss.paalan.bean.IndRegistrationBean;
import com.mobiowin.cmss.paalan.bean.OrgAchievementBean;
import com.mobiowin.cmss.paalan.bean.OrgEventBean;
import com.mobiowin.cmss.paalan.bean.OrgProfileBean;
import com.mobiowin.cmss.paalan.bean.OrgRegistrationBean;
import com.mobiowin.cmss.paalan.bean.OrgRequestBean;

public interface ICoreIndHelperDao {

	boolean isAlreadyExist(IndRegistrationBean indRegistrationBean);

	String registerIndividual(IndRegistrationBean indRegistrationBean);

	boolean validateLogin(IndRegistrationBean indRegistrationBean);

	boolean isProfileExist(IndProfileBean indProfileBean);

	String submitProfile(IndProfileBean indProfileBean);

	String updateProfile(IndProfileBean indProfileBean);

	List<OrgEventBean> fetchEventDetailsByLocation(IndRegistrationBean indRegistrationBean, String lastSyncDate);

	List<OrgRequestBean> fetchSocialrequestByLocation(IndRegistrationBean indRegistrationBean, String lastSyncDate);

	List<OrgRegistrationBean> fetchSocialGroupsByLocation(IndRegistrationBean indRegistrationBean, String lastSyncDate);

	List<OrgProfileBean> fetchSocialGroupProfile(List<String> locallySocialGroupList, String lastSyncDate);

	List<OrgAchievementBean> fetchOrgAchivementLocally(List<String> orgIdList, String lastSyncDate);

	String submitMessage(ConnectBean connectBean);

	String submitDonationReq(DonateBean donateBean);

	

}
