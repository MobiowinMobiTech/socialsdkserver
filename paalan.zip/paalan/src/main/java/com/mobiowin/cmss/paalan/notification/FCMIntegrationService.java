package com.mobiowin.cmss.paalan.notification;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.mobiowin.cmss.paalan.commons.ApplicationConstant;

@Service("fcmIntegrationService")
@EnableAsync
@Component
public class FCMIntegrationService implements IFCMIntegrationService{

	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private @Resource Map<String, String> notificationConfig;
	
	@Autowired
	private @Resource Map<String, String> notificationMessageConfig;

	String fcmServerAuthKey = null;
	String fcmNotificationUrl = null;
	HttpEntity<String> entity = null;
	String notificationJsonData = null;
	String resposne = null;

	@Async
	public String sendFcmNotificationMessage(HashMap<String, String> notificationDataMap) 
	{

		fcmServerAuthKey = String.valueOf(notificationConfig.get("serverkey"));
		fcmNotificationUrl = String.valueOf(notificationConfig.get("fcmurl"));

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("Authorization", "key=" + fcmServerAuthKey);
		
		notificationJsonData = getNotificationMessageData(notificationDataMap);

		entity = new HttpEntity<String>(notificationJsonData, headers);
		
		//resposne = restTemplate.postForObject(fcmNotificationUrl, entity, String.class);
		resposne = restTemplate.postForObject("https://fcm.googleapis.com/fcm/send", entity, String.class);
		JSONObject responseJson = new JSONObject(resposne);

		log.info("Resposne is : " + responseJson);
		
		return responseJson.toString();

	}

	private String getNotificationMessageData(HashMap<String, String> notificationDataMap)
	{
		log.info("inside  getNotificationMessageData()");
		
		JSONObject json = new JSONObject();
		json.put("to", notificationDataMap.get(ApplicationConstant.NOTIFICATION_ID).trim());
		JSONObject info = new JSONObject();
		
		info.put("title", "Paalan Test");
		
		log.info("Notification Type : " + notificationMessageConfig.get(notificationDataMap.get(ApplicationConstant.NOTIFICATION_TYPE)));

		info.put("body", String.format(String.valueOf(notificationMessageConfig.get(notificationDataMap.get(ApplicationConstant.NOTIFICATION_TYPE))), notificationDataMap.get(ApplicationConstant.NAME),notificationDataMap.get(ApplicationConstant.ORG_ID)));
		json.put("data", info);

		//log.info("Json is : " + json);
		
		
		
		return json.toString();
	}

/*public static void main(String[] args) 
{
	HttpHeaders headers = new HttpHeaders();
	headers.setContentType(MediaType.APPLICATION_JSON);
	headers.set("Authorization", "key=" + "AIzaSyBotSWOnRtFJTnmSWjXbKPhNBGfKzTeq60");
	
	String notificationJsonData = getNotificationMessageData();

	HttpEntity<String> entity = new HttpEntity<String>(notificationJsonData, headers);
	
	//resposne = restTemplate.postForObject(fcmNotificationUrl, entity, String.class);
	RestTemplate restTemplate = new RestTemplate();
	String resposne = restTemplate.postForObject("https://fcm.googleapis.com/fcm/send", entity, String.class);
	JSONObject responseJson = new JSONObject(resposne);

	System.out.println("Resposne is : " + responseJson);
	
	
}*/
}
