package com.mobiowin.cmss.paalan.test;

import org.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

public class FCMBrodcastTest {

	public static final String SERVER_KEY = "AIzaSyAlfD0UW5U4d-FsXt66rXbs4A0lFL4Q5p8";
	public static final String FCM_URL = "https://fcm.googleapis.com/fcm/send";
	
	public static void main(String[] args) 
	{
		FCMBrodcastTest.sendFcmNotificationMessage();
		
	}
	
	public static String sendFcmNotificationMessage() 
	{

		

		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("Authorization", "key=" + SERVER_KEY);

		String notificationJsonData = getNotificationMessageData();

		HttpEntity<String> entity = new HttpEntity<String>(notificationJsonData, headers);
		RestTemplate restTemplate = new RestTemplate();
		String resposne = restTemplate.postForObject(FCM_URL, entity, String.class);
		JSONObject responseJson = new JSONObject(resposne);

		System.out.println("Resposne is : " + responseJson);
		
		return responseJson.toString();

	}

	private static String getNotificationMessageData()
	{
		JSONObject json = new JSONObject();
		json.put("to","/topics/event");
		json.put("priority", "high");
		JSONObject info = new JSONObject();
		info.put("title", "Paalan Test"); // Notification title
		info.put("body", "Broadcast games notification testing");
		
		json.put("data", info);

		System.out.println("Json is : " + json);
		
		return json.toString();
	}
}
