package com.mobiowin.cmss.paalan.service.org;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.cmss.paalan.commons.ApplicationConstant;
import com.mobiowin.cmss.paalan.messaging.IMessageService;
import com.mobiowin.cmss.paalan.service.helper.ICoreOrgHelperService;

@Service("orgRequestDeleteService")
@Component
public class OrgRequestDeleteService implements IMessageService {

	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private ICoreOrgHelperService orgCoreHelperService;

	public Message<String> execute(Message<String> message) {
		log.info("Inside OrgRequestDeleteService/execute()");

		String jsonData = message.getPayload();

		Map<String, Object> messageHeaders = message.getHeaders();

		JSONObject dataJson = null;
		JSONObject reqDataJson = null;

		String orgId = null;
		String requestId = null;

		String response = null;

		HashMap<String, Object> reqDataMap = null;

		try {
			dataJson = new JSONObject(jsonData);
			reqDataJson = dataJson.getJSONObject(ApplicationConstant.DATA);

			if (reqDataJson.has(ApplicationConstant.ORG_ID)) {
				orgId = reqDataJson.getString(ApplicationConstant.ORG_ID);
			}

			if (reqDataJson.has(ApplicationConstant.REQUEST_ID)) {
				requestId = reqDataJson.getString(ApplicationConstant.REQUEST_ID);
			}

			if (log.isInfoEnabled()) {
				log.info("Message Headers is : " + messageHeaders);
				log.info("ORG_ID is : " + orgId);
				log.info("REQUEST_ID is : " + requestId);

			}

			reqDataMap = getReqDataMap(orgId, requestId);

			response = orgCoreHelperService.deleteOrgRequest(reqDataMap);

			return MessageBuilder.withPayload(response).build();

		} catch (Exception ex) {
			log.error("Exception in OrgRequestDeleteService/execute() " + ex.getMessage(), ex.getCause());

		}

		return null;
	}

	private HashMap<String, Object> getReqDataMap(String orgId, String requestId) {
		HashMap<String, Object> reqDataMap = new HashMap<String, Object>();

		reqDataMap.put(ApplicationConstant.ORG_ID, orgId);
		reqDataMap.put(ApplicationConstant.REQUEST_ID, requestId);

		return reqDataMap;

	}
}
