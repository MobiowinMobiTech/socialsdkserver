package com.mobiowin.cmss.paalan.messaging;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.MessageChannel;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.mobiowin.cmss.paalan.commons.ApplicationConstant;
import com.mobiowin.cmss.paalan.commons.MessageUtility;

public class InboundGateway extends HttpServlet 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Log log = LogFactory.getLog(getClass());

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public InboundGateway() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	@SuppressWarnings("unchecked")
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException 
	{
		ApplicationContext applicationContext = WebApplicationContextUtils
				.getRequiredWebApplicationContext(getServletContext());

		Map<String, String> systemMap = applicationContext.getBean("Paalan", Map.class);

		StringBuilder systemInfo = new StringBuilder("Paalan Server Info : ");

		for (String key : systemMap.keySet()) {
			systemInfo.append("\n").append(key).append(" : ")
					.append(systemMap.get(key));
		}

		systemInfo.append("\n");

		if (log.isInfoEnabled()) {
			log.info("System info is ---------- > " + systemInfo.toString());
		}

		response.getOutputStream().write(systemInfo.toString().getBytes());
	}

	
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		ApplicationContext applicationContext = WebApplicationContextUtils
				.getRequiredWebApplicationContext(getServletContext());

		try 
		{
			HttpSession session = request.getSession();
			String data = readBody(request);
			
			readQueryString(request);
			
			if(null != data)
			{
				if (log.isInfoEnabled()) 
				{
					log.info("Session state is -------- > " + session);
					//log.info("Data is ------------------> " + data);
				}

				MessageChannel testChannel = (MessageChannel) applicationContext
						.getBean(ApplicationConstant.DEVICE_REQUEST_CHANNEL);

				MessageBuilder<?> messageBuilder = MessageBuilder.withPayload(data)
						.setHeader("response", response);
				
			/*	messageBuilder.setHeader("http-headers", createHeaderMap(request));
				messageBuilder.setHeader("Session", session);*/
				
				messageBuilder.setHeader(ApplicationConstant.REQUEST, request);

				testChannel.send(messageBuilder.build());
			}

		} catch (Exception e)
		{
			log.error("Exception in reading message ......." + e.getMessage());
			sendGenericErrorMessage(response, applicationContext);

		}

	}

	private void sendGenericErrorMessage(HttpServletResponse response,
			ApplicationContext applicationContext) {
		
		MessageChannel deviceResponseChannel = (MessageChannel) applicationContext
				.getBean(ApplicationConstant.DEVICE_RESPONSE_CHANNEL);
		deviceResponseChannel.send(MessageBuilder.withPayload(MessageUtility.createErrorMessage())
				.setHeader(ApplicationConstant.RESPONSE, response).build());
		
		
	}

	@SuppressWarnings({ "unused" })
	private Object createHeaderMap(HttpServletRequest request) {
		log.info("Inside createHeaderMap().......");

		Enumeration<String> headerNames = request.getHeaderNames();

		log.info("Request headers are ------- >" + headerNames);

		Map<String, String> headerMap = new HashMap<String, String>();

		while (headerNames.hasMoreElements())
		{
			String header = (String) headerNames.nextElement();
			headerMap.put(header, request.getHeader(header));
		}

		return headerMap;

	}
	
	
	private void readQueryString(HttpServletRequest request)
	{
		
		Enumeration<String> enumeration = request.getParameterNames();

		while (enumeration.hasMoreElements())
		{
			String parameterName = enumeration.nextElement();

			String parameterValue = request.getParameter(parameterName);

			if (log.isInfoEnabled())
			{
				log.info(parameterName + " : " + parameterValue);
			}
		}
	}

	private String readBody(HttpServletRequest request) 
	{
		log.info("Inside readBody()....");

		String data = null;
		try 
		{
			InputStream is = request.getInputStream();

			ByteArrayOutputStream arrayOutputStream = new ByteArrayOutputStream();

			byte[] buf = new byte[1000];

			for (int nChunk = is.read(buf); nChunk != -1; nChunk = is.read(buf)) {
				arrayOutputStream.write(buf, 0, nChunk);
			}
			
			data = new String(arrayOutputStream.toByteArray(), "utf-8");

			//data = FlashDecryptionUtil.decryptedMessage(new String(arrayOutputStream.toByteArray(), "utf-8"));

			log.info("data is ----- > " + data);

			return data;
		}
		catch (UnsupportedEncodingException e) 
		{
			log.error("Encoding exception ............. " + e.getMessage());
			e.printStackTrace();
		}
		catch (IOException e)
		{
			log.error("Exception in file handling ............. " + e.getMessage());
			e.printStackTrace();
		}

		return data;

	}
}
