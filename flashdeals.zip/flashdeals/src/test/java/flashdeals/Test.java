package flashdeals;

public class Test {
public static void main(String[] args)
{
	Test test = new Test();
	test.printName(null);
	}

private void printName(String str) {
	System.out.println("str 1: " + str);
	

}

private void printName(Object str) {
	System.out.println("str : " + str);
	

}
}
