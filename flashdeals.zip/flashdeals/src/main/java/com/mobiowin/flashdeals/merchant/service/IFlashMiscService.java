package com.mobiowin.flashdeals.merchant.service;

import java.util.HashMap;

public interface IFlashMiscService {

	String submitNotificationDetails(HashMap<String, String> notificationDataMap);

}
