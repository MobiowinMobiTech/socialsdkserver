package com.mobiowin.flashdeals.helper.service;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.imageio.ImageIO;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.flashdeals.bean.DealResponseBean;
import com.mobiowin.flashdeals.bean.MerchantDealBean;
import com.mobiowin.flashdeals.commons.ApplicationConstant;
import com.mobiowin.flashdeals.commons.FlashIdGeneratorUtility;
import com.mobiowin.flashdeals.commons.FlashLocallyUtillity;
import com.mobiowin.flashdeals.commons.FlashUtility;
import com.mobiowin.flashdeals.dao.IDealSyncDao;
import com.mobiowin.flashdeals.geo.ReverseGeoService;
import com.sun.org.apache.xerces.internal.impl.dv.util.Base64;

@Service("dealSyncHelperService")
@Component
public class DealSyncHelperService implements IDealSyncHelperService {
	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private ReverseGeoService reverseGeoService;
	
	@Autowired
	private IDealSyncDao dealSyncDao;

	@Autowired
	private @Resource
	Map<String, List<String>> flashImageConfig;
	
	@Autowired
	private FlashImageUrlService flashImageService;
	
	public String syncCustomerDealData(HashMap<String, String> dataMap) 
	{
		log.info("inside DealSyncHelperService/syncUserDealData()");
		
		String userLocallyData = null;
		ArrayList<DealResponseBean> localDealSList = null;
		ArrayList<String> userLocationList = null;
		HashMap<String,String> customerLocationDataMap = null;
		List<MerchantDealBean> customerDealResList = null;
		
		if((null != dataMap.get(ApplicationConstant.USER_LATITUDE)) && (null != dataMap.get(ApplicationConstant.USER_LATITUDE)))
		{
			userLocallyData = reverseGeoService.getUserLocallyDetails(dataMap.get(ApplicationConstant.USER_LATITUDE),dataMap.get(ApplicationConstant.USER_LONGITUDE));
			userLocationList = FlashLocallyUtillity.getUserDetailMap(userLocallyData);
			
			if(log.isInfoEnabled())
			{
				log.info("User locally data is : " + userLocallyData);
				log.info("User local address list is : " + userLocationList);
			}
			
			List<String> customerLocaleLocationList = FlashLocallyUtillity.getLocaleLocationList(userLocationList); 
					
			log.info("customerLocaleLocationList is :" + customerLocaleLocationList);
			
			customerLocationDataMap = new HashMap<String,String>();
			customerLocationDataMap.put(ApplicationConstant.CITY, userLocationList.get(0));
			customerLocationDataMap.put(ApplicationConstant.COUNTRY,userLocationList.get(2));
			customerLocationDataMap.put(ApplicationConstant.PINCODE,customerLocaleLocationList.get(1) );
			customerLocationDataMap.put(ApplicationConstant.STATE, customerLocaleLocationList.get(0));
			
			log.info("customerLocationDataMap : " + customerLocationDataMap);
			
			customerDealResList = dealSyncDao.getCustomerDeals(customerLocationDataMap);
			
			/*
			if (!dataMap.get(ApplicationConstant.DEAL_RADIUS).equals(
					ApplicationConstant.EMPTY_STRING)
					|| dataMap.get(ApplicationConstant.DEAL_RADIUS) != null)
			{
			
			
				if(null != userLocationList)
				{
					localDealSList = dealSyncDao.getUserLocalDeals(userLocationList);
				}
				
				ArrayList<String> userDealList = new ArrayList<String>();
			
			
				
					
			}
			else
			{
				userLocallyData = reverseGeoService.getUserLocallyDetails(dataMap.get(ApplicationConstant.USER_LATITUDE), dataMap.get(ApplicationConstant.USER_LONGITUDE));
			}
			
			log.info("User locally data is : " + userLocallyData);
*/
			
			
		}
		
		HashMap<String,Object> customerDealsListMap = null;
		
		if(null != customerDealResList)
		{
			customerDealsListMap = new HashMap<String,Object>();
			customerDealsListMap.put("CUSTOMER_DEALS_LIST", customerDealResList);
			return FlashUtility.createJSONFromMap(FlashUtility.createSuccessResponseMessage(customerDealsListMap));
		}
		else
		{
			customerDealsListMap = new HashMap<String,Object>();
			customerDealsListMap.put("CUSTOMER_DEALS_LIST", customerDealResList);
			return FlashUtility.createSuccessMessage("No Deals mapped");
		}
		
		
	}

	@SuppressWarnings("unchecked")
	public String submitMerchantDeal(HashMap<String, Object> dealDataMap) 
	{
		log.info("Inside DealSyncHelperService/submitMerchantDeal()");
		
		MerchantDealBean merchantDealBean = null;
		String isSuccessfulSubmit = null;
		String dealImgPath = null;
		String merchantDealId = null;
		ArrayList<String> dealLocationList = null;
		String dealLocaleData = null; 
		List<String> dealLocaleList = null;
		String updateStatus = null;
		HashMap<String, Object> dataMap = null;
		
		
		if(null != String.valueOf(dealDataMap.get(ApplicationConstant.DEAL_ID)) && !String.valueOf(dealDataMap.get(ApplicationConstant.DEAL_ID)).equals(ApplicationConstant.EMPTY_STRING))
		{
			merchantDealId = String.valueOf(dealDataMap.get(ApplicationConstant.DEAL_ID));
		}
		else
		{
			merchantDealId = FlashIdGeneratorUtility.generateMerchantStoreId(dealDataMap);
		}
		
		log.info("Merchant Deal Id is : " + merchantDealId);
		
		if(dealDataMap.get(ApplicationConstant.MERCHANT_DEAL_IMAGE) != null || dealDataMap.get(ApplicationConstant.MERCHANT_DEAL_IMAGE).equals(ApplicationConstant.EMPTY_STRING))
		{
			dealImgPath = saveMerhantDealImage(dealDataMap,merchantDealId);
			log.info("Merchant deal image path : " +dealImgPath);
		}
		
		dealLocaleData = reverseGeoService.getUserLocallyDetails(String.valueOf(dealDataMap.get(ApplicationConstant.USER_LATITUDE)),String.valueOf(dealDataMap.get(ApplicationConstant.USER_LONGITUDE)));
		dealLocationList = FlashLocallyUtillity.getUserDetailMap(dealLocaleData);
		dealLocaleList = FlashLocallyUtillity.getLocaleLocationList(dealLocationList);
		
		if(log.isInfoEnabled())
		{
			log.info("Merchant Deal locally data is : " + dealLocaleData);
			log.info("Merchant local address list is : " + dealLocaleList);
		}
		
		if(null != dealDataMap)
		{
			merchantDealBean = new MerchantDealBean();
			
			merchantDealBean.setMerchantId(String.valueOf(dealDataMap.get(ApplicationConstant.MERCHANT_ID)));
			merchantDealBean.setMerchantDealId(merchantDealId);
			merchantDealBean.setDealName(String.valueOf(dealDataMap.get(ApplicationConstant.MERCHANT_DEAL_NAME)));
			merchantDealBean.setDealCategory(String.valueOf(dealDataMap.get(ApplicationConstant.MERCHANT_DEAL_CATEGORY)));
			merchantDealBean.setDealDiscription(String.valueOf(dealDataMap.get(ApplicationConstant.MERCHANT_DEAL_DISCRIPTION)));
			merchantDealBean.setDealRadius(String.valueOf(dealDataMap.get(ApplicationConstant.MERCHANT_DEAL_RADIUS)));
			merchantDealBean.setDealStartTime(String.valueOf(dealDataMap.get(ApplicationConstant.MERCHANT_DEAL_START_TIME)));
			merchantDealBean.setDealEndTime(String.valueOf(dealDataMap.get(ApplicationConstant.MERCHANT_DEAL_END_TIME)));
			merchantDealBean.setDealImage(dealImgPath);
			merchantDealBean.setDealStoreId(String.valueOf(dealDataMap.get(ApplicationConstant.MERCHANT_DEAL_STORE_ID)));
			merchantDealBean.setLatitude(String.valueOf(dealDataMap.get(ApplicationConstant.USER_LATITUDE)));
			merchantDealBean.setLongitude(String.valueOf(dealDataMap.get(ApplicationConstant.USER_LONGITUDE)));
			merchantDealBean.setCity(dealLocationList.get(0));
			merchantDealBean.setCountry(dealLocationList.get(2));
			merchantDealBean.setState(dealLocaleList.get(0));
			merchantDealBean.setPinCode(dealLocaleList.get(1));
			merchantDealBean.setCreatedBy(ApplicationConstant.SYSTEM_CREATED_BY);
			merchantDealBean.setCreateDt(new Date());
			merchantDealBean.setModifiedBy(ApplicationConstant.SYSTEM_MODIFIED_BY);
			merchantDealBean.setModifyDt(new Date());
			merchantDealBean.setDeleteFlag(ApplicationConstant.DEL_FLAG);
			merchantDealBean.setIsExclusive(String.valueOf(dealDataMap.get(ApplicationConstant.IS_EXCLUSIVE)));
			
		}
		
		log.info("Merchant deal bean is : " + merchantDealBean);
		
		boolean isDealExist = dealSyncDao.isMerchantDealExist(merchantDealBean);
		
		log.info("Is merchant deal exist : " + isDealExist);
		
		if(isDealExist)
		{
			updateStatus = dealSyncDao.updateMerchantDeal(merchantDealBean);
			
			dataMap = new HashMap<String, Object>();
			dataMap.put(ApplicationConstant.MERCHANT_ID, merchantDealBean.getMerchantId());
			dataMap.put(ApplicationConstant.MERCHANT_STORE_ID, merchantDealBean.getDealStoreId());
			dataMap.put(ApplicationConstant.MERCHANT_DEAL_IMAGE, merchantDealBean.getDealImage());
			dataMap.put(ApplicationConstant.DEAL_ID, merchantDealBean.getMerchantDealId());

			return FlashUtility.createJSONFromMap(FlashUtility.createSuccessResponseMessage(dataMap));
		}
		else
		{
			isSuccessfulSubmit = dealSyncDao.submitMerchantDeal(merchantDealBean);
			
			log.info("Is Successful Submit " + isSuccessfulSubmit);
			
			if(isSuccessfulSubmit.equals(ApplicationConstant.SUCCESS))
			{
				dataMap = new HashMap<String, Object>();
				dataMap.put(ApplicationConstant.MERCHANT_ID, merchantDealBean.getMerchantId());
				dataMap.put(ApplicationConstant.MERCHANT_STORE_ID, merchantDealBean.getDealStoreId());
				dataMap.put(ApplicationConstant.MERCHANT_DEAL_IMAGE, merchantDealBean.getDealImage());
				dataMap.put(ApplicationConstant.DEAL_ID, merchantDealBean.getMerchantDealId());

				return FlashUtility.createJSONFromMap(FlashUtility.createSuccessResponseMessage(dataMap));
			}
			
			return FlashUtility.createErrorMessage();
		}
		
	}

	private String saveMerhantDealImage(HashMap<String, Object> dealDataMap, String merchantDealId)
	{
		log.info("Inside DealSyncHelperService/saveMerhantDealImage()");
		
		List<String> imaBasePathList = (List<String>) flashImageConfig.get("IMG_PATH_DIR");
		String destDirName = imaBasePathList.get(2).trim(); 
		Map<String,String> imageUrlMap = null;
		String dealImgPath = null;
		String dealImgUrl = null;
		
		try
		{
			byte[] bytearray = Base64.decode(String.valueOf(dealDataMap.get(ApplicationConstant.MERCHANT_DEAL_IMAGE)));
			BufferedImage imag=ImageIO.read(new ByteArrayInputStream(bytearray));
			String merchantDealImgName = getImageName(dealDataMap,merchantDealId);
			ImageIO.write(imag, "jpg", new File(destDirName,merchantDealImgName));
			dealImgPath = destDirName+merchantDealImgName; 
			log.info("DealImgPath is : " + dealImgPath);
			
			imageUrlMap = flashImageService.getDealImgUrl(merchantDealImgName);
			dealImgUrl = imageUrlMap.get("DealImgUrl");
			log.info("Deal image url : " +dealImgUrl);
			
			return dealImgUrl;
		} 
		catch (IOException e) 
		{
			log.error("Exception in saving deal image : " + e.getMessage());
			e.printStackTrace();
		}
		
		return dealImgPath;
		
		
	}

	private String getImageName(HashMap<String, Object> dealDataMap, String merchantDealId) 
	{
		log.info("Inside DealSyncHelperService/getImageName()");
		
		StringBuilder dealImgNameBuilder = new StringBuilder();
		dealImgNameBuilder.append(merchantDealId);
		dealImgNameBuilder.append(".jpg");
		return dealImgNameBuilder.toString();
	}

	
	public String fetchMerchantDealDetails(HashMap<String, String> requestDataMap) 
	{
		log.info("Inside DealSyncHelperService/fetchMerchantDealDetails()");
		
		MerchantDealBean merchantDealBean = null;
		HashMap<String,Object> merchantStoreListMap = null;
		if(null!= requestDataMap)
		{
			merchantDealBean = new MerchantDealBean();
			merchantDealBean.setMerchantId(requestDataMap.get(ApplicationConstant.MERCHANT_ID));
		}
		
		List<MerchantDealBean> merchantDealList = dealSyncDao.fetchMerchantDealDetails(merchantDealBean);
		
		if(null != merchantDealList && merchantDealList.size() > 0 )
		{
			merchantStoreListMap = new HashMap<String,Object>();
			merchantStoreListMap.put(ApplicationConstant.MERCHANT_STORE_LIST, merchantDealList);
			return FlashUtility.createJSONFromMap(FlashUtility.createSuccessResponseMessage(merchantStoreListMap));
		}
		else
		{
			merchantStoreListMap = new HashMap<String,Object>();
			merchantStoreListMap.put(ApplicationConstant.MERCHANT_STORE_LIST, merchantDealList);
			return FlashUtility.createSuccessMessage("No store mapped");
		}
		
	}

}
