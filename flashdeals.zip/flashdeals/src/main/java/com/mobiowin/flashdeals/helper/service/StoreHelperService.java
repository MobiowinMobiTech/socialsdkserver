package com.mobiowin.flashdeals.helper.service;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.imageio.ImageIO;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.flashdeals.bean.MerchantStoreBean;
import com.mobiowin.flashdeals.commons.ApplicationConstant;
import com.mobiowin.flashdeals.commons.FlashIdGeneratorUtility;
import com.mobiowin.flashdeals.commons.FlashUtility;
import com.mobiowin.flashdeals.dao.IStoreSyncDao;
import com.sun.org.apache.xerces.internal.impl.dv.util.Base64;

@Service("storeService")
@Component
public class StoreHelperService implements IStoreHelperService {

	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private IStoreSyncDao storeSyncDao;

	@Autowired
	private FlashImageUrlService flashImageService;

	@Autowired
	private @Resource Map<String, List<String>> flashImageConfig;

	@SuppressWarnings("unchecked")

	public String tagMerchantStore(HashMap<String, Object> requestDataMap) {
		log.info("inside StoreTagHelperService/isStoreExists()");

		MerchantStoreBean merchantStoreBean = null;
		boolean isStoreExist = false;
		HashMap<String, Object> dataMap = null;
		ArrayList<String> storeImagePathList = null;
		String storeUpdateStatus = null;
		ArrayList<String> storeImageList = null;
		String merchantStoreId = null;

		if(null != String.valueOf(requestDataMap.get(ApplicationConstant.MERCHANT_STORE_ID)) && !String.valueOf(requestDataMap.get(ApplicationConstant.MERCHANT_STORE_ID)).equals(ApplicationConstant.EMPTY_STRING))
		{
			merchantStoreId = String.valueOf(requestDataMap.get(ApplicationConstant.MERCHANT_STORE_ID));
		}
		else
		{
			merchantStoreId = FlashIdGeneratorUtility.generateMerchantStoreId(requestDataMap);
		}

		log.info("");
		
		if (null != requestDataMap)
		{
			merchantStoreBean = new MerchantStoreBean();
			merchantStoreBean.setMerchantId(String.valueOf(requestDataMap.get(ApplicationConstant.MERCHANT_ID)));
			merchantStoreBean.setStoreId(merchantStoreId);
			merchantStoreBean.setStoreName(String.valueOf(requestDataMap.get(ApplicationConstant.STORE_NAME)));
			merchantStoreBean.setStoreCategory(String.valueOf(requestDataMap.get(ApplicationConstant.STORE_CATEGORY)));
			merchantStoreBean
					.setStoreDiscription(String.valueOf(requestDataMap.get(ApplicationConstant.STORE_DISCRIPTION)));
			merchantStoreBean.setLatitude(String.valueOf(requestDataMap.get(ApplicationConstant.USER_LATITUDE)));
			merchantStoreBean.setLongitude(String.valueOf(requestDataMap.get(ApplicationConstant.USER_LONGITUDE)));

			storeImagePathList = saveStoreImage(requestDataMap);
			

			log.info("Store imgae path list is : " + storeImagePathList);

			merchantStoreBean.setStoreImage1(storeImagePathList.get(0));
			merchantStoreBean.setStoreImage2(storeImagePathList.get(1));
			merchantStoreBean.setStoreImage3(storeImagePathList.get(2));
			merchantStoreBean.setStoreImage4(storeImagePathList.get(3));
			merchantStoreBean.setStoreId(merchantStoreId);
			merchantStoreBean.setCreatedBy(String.valueOf(requestDataMap.get(ApplicationConstant.MERCHANT_ID)));
			merchantStoreBean.setCreateDt(new Date());
			merchantStoreBean.setModifiedBy(String.valueOf(requestDataMap.get(ApplicationConstant.MERCHANT_ID)));
			merchantStoreBean.setModifyDt(new Date());
			merchantStoreBean.setDeleteFlag(ApplicationConstant.DEL_FLAG);

		}

		isStoreExist = storeSyncDao.isStoreExist(merchantStoreBean);

		log.info("Is Merhcant Store Exist : " + isStoreExist);

		if (isStoreExist) 
		{
			storeUpdateStatus = storeSyncDao.updateMerchantStoreDetails(merchantStoreBean);

			log.info("Store Update Status is : " + storeUpdateStatus);

			storeImageList = getStoreImgList(merchantStoreBean);

			dataMap = new HashMap<String, Object>();
			dataMap.put(ApplicationConstant.MERCHANT_ID, merchantStoreBean.getMerchantId());
			dataMap.put(ApplicationConstant.MERCHANT_STORE_ID, merchantStoreBean.getStoreId());
			dataMap.put(ApplicationConstant.MERCHANT_STORE_IMG, storeImageList);

			return FlashUtility.createJSONFromMap(FlashUtility.createSuccessResponseMessage(dataMap));

		}
		else
		{
			storeUpdateStatus = storeSyncDao.tagStoreLocation(merchantStoreBean);

			log.info("Store image update status : " + storeUpdateStatus);

			if (storeUpdateStatus.equals(ApplicationConstant.SUCCESS)) {
				dataMap = new HashMap<String, Object>();
				storeImageList = getStoreImgList(merchantStoreBean);
				dataMap.put(ApplicationConstant.MERCHANT_ID, merchantStoreBean.getMerchantId());
				dataMap.put(ApplicationConstant.MERCHANT_STORE_ID, merchantStoreBean.getStoreId());
				dataMap.put(ApplicationConstant.MERCHANT_STORE_IMG, storeImageList);

				return FlashUtility.createJSONFromMap(FlashUtility.createSuccessResponseMessage(dataMap));
			}
			else {
				return FlashUtility.createErrorMessage("Store Not Tagged successfully");
			}
		}

	}

	private ArrayList<String> getStoreImgList(MerchantStoreBean merchantStoreBean) {
		ArrayList<String> storeImgList = new ArrayList<String>();

		storeImgList.add(merchantStoreBean.getStoreImage1());
		storeImgList.add(merchantStoreBean.getStoreImage2());
		storeImgList.add(merchantStoreBean.getStoreImage3());
		storeImgList.add(merchantStoreBean.getStoreImage4());

		return storeImgList;
	}

	private ArrayList<String> saveStoreImage(HashMap<String, Object> requestDataMap) {
		log.info("Inside StoreTagHelperService/saveStoreImage()");

		List<String> imaBasePathList = (List<String>) flashImageConfig.get("IMG_PATH_DIR");
		String destDirName = imaBasePathList.get(0).trim();
		String storeImgPath = null;
		ArrayList<String> storeImgUrlList = null;
		ArrayList<String> storeImgList = null;
		Map<String, String> storeImageUrlMap = null;

		if (null != requestDataMap) {
			storeImgList = (ArrayList<String>) requestDataMap.get(ApplicationConstant.MERCHANT_STORE_IMG);
		}

		try {

			storeImgUrlList = new ArrayList<String>();
			for (String storeImg : storeImgList) {

				byte[] bytearray = Base64.decode(storeImg);
				BufferedImage imag = ImageIO.read(new ByteArrayInputStream(bytearray));
				String storeImgName = getImageName(String.valueOf(requestDataMap.get(ApplicationConstant.MERCHANT_ID)));
				ImageIO.write(imag, "jpg", new File(destDirName, storeImgName));
				storeImgPath = destDirName + storeImgName;

				log.info("Store image path is : " + storeImgPath);

				storeImageUrlMap = flashImageService.getStoreImgUrl(storeImgName);
				String storeImgUrl = storeImageUrlMap.get("StoreImgUrl");
				storeImgUrlList.add(storeImgUrl);
				log.info("store image url : " + storeImgUrl);
			}
			return storeImgUrlList;

		} catch (IOException e) {
			log.error("Exception in saving deal image : " + e.getMessage());
			e.printStackTrace();
		}

		return storeImgUrlList;

	}

	private String getImageName(String merchantId) {
		log.info("Inside ProfileSyncService/getImageName()");
		String nanoTime = String.valueOf(System.nanoTime());
		nanoTime = nanoTime.substring(nanoTime.length() - 4, nanoTime.length());

		StringBuilder dpImgNameBuilder = new StringBuilder();
		dpImgNameBuilder.append(merchantId);
		dpImgNameBuilder.append("_");
		dpImgNameBuilder.append(nanoTime);
		dpImgNameBuilder.append(".jpg");
		return dpImgNameBuilder.toString();

	}

	public String fetchStoreDetails(HashMap<String, String> requestDataMap) 
	{
		log.info("Inside StoreTagHelperService/fetchStoreDetails()");

		MerchantStoreBean merchantStoreBean = null;
		HashMap<String, Object> merchantStoreListMap = null;
		
		if (null != requestDataMap) 
		{
			merchantStoreBean = new MerchantStoreBean();
			merchantStoreBean.setMerchantId(requestDataMap.get(ApplicationConstant.MERCHANT_ID));
		}

		List<MerchantStoreBean> merchantStoreList = storeSyncDao.fetchStoreDetails(merchantStoreBean);

		if (null != merchantStoreList && merchantStoreList.size() > 0)
		{
			merchantStoreListMap = new HashMap<String, Object>();
			merchantStoreListMap.put(ApplicationConstant.MERCHANT_STORE_LIST, merchantStoreList);
			return FlashUtility.createJSONFromMap(FlashUtility.createSuccessResponseMessage(merchantStoreListMap));
		}
		else 
		{
			merchantStoreListMap = new HashMap<String, Object>();
			merchantStoreListMap.put(ApplicationConstant.MERCHANT_STORE_LIST, merchantStoreList);
			return FlashUtility.createSuccessMessage("No store mapped");
		}

	}

}
