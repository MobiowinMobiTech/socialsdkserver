package com.mobiowin.flashdeals.test;

import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import org.json.JSONObject;

public class FCMTest {
	public static void pushFCMNotification(String userDeviceIdKey) {

		String authKey = "AAAAbkdbV8A:APA91bET2vx61ECwwWoE78F0zXV9xS3WVmB8d7KIvJCiAOebkfffGK4TwFIYpEkIP1q_Y8HVpxolgoeUBu5jC9I1z2UMCLxj4wnCC8lly_LT7F4Gjeqc-dTMm4s3tT3Ug7uvRE9OcB9dRWeHYJzBf8Nxw1NCjo0qTg";   // You FCM AUTH key
		String FMCurl = "https://fcm.googleapis.com/fcm/send";     

		try {
			URL url = new URL(FMCurl);
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();

			conn.setUseCaches(false);
			conn.setDoInput(true);
			conn.setDoOutput(true);

			conn.setRequestMethod("POST");
			conn.setRequestProperty("Authorization","key="+authKey);
			conn.setRequestProperty("Content-Type","application/json");

			JSONObject json = new JSONObject();
			json.put("to",userDeviceIdKey.trim());
			JSONObject info = new JSONObject();
			info.put("title", "UOTM Test");   // Notification title
			info.put("body", "Testing 123"); // Notification body
			json.put("notification", info);

			OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
			wr.write(json.toString());
			wr.flush();
			conn.getInputStream();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	
	public static void main(String[] args) {
		String userID = "f0cVoU42pQ4:APA91bFV39MGPeRxoVcyaBsnIyor4mDL6ZfCHrXxs9R_tnoB3HxRSP8RuoBcqb6vSqUdGEoLKeat5M4LkXfot5a2zrKkxOznChSUnSPui9QymQTTbje7WMfnzUeRfhf6dkVtGzh-Bzmt";
		FCMTest.pushFCMNotification(userID);
	}

}
