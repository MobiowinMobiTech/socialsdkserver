package com.mobiowin.flashdeals.test;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class ReverseGeoService
{
	private Log log  = LogFactory.getLog(this.getClass());
	
	public String getAddress(String latlong)
	{
		log.info("Inside ReverseGeoService/getAddress()......");
		String address = null;
		String gURL = "http://maps.google.com/maps/api/geocode/xml?latlng=" + latlong + "&sensor=true";
		log.info("Fianl URL  is : " + gURL);
		
		try
		{
			DocumentBuilderFactory df = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = df.newDocumentBuilder();
			Document dom = db.parse(gURL);
			Element docEl = dom.getDocumentElement();
			NodeList nl = docEl.getElementsByTagName("result");
			if (nl != null && nl.getLength() > 0)
			{
				address = ((Element) nl.item(0))
						.getElementsByTagName("formatted_address").item(0)
						.getTextContent();
				for (int i = 0; i < nl.getLength(); i++)
				{
					String temp = ((Element) nl.item(i))
							.getElementsByTagName("formatted_address").item(0)
							.getTextContent();
				}
			}
		} catch (Exception ex)
		{
			address = "Err";
		}
		System.out.println("Address is :" + address);
		return address;
	}

	public String getAddress(String lat, String lon)
	{
		return getAddress(lat + "," + lon);
	}

	public String getAddress(double lat, double lon)
	{
		return getAddress("" + lat, "" + lon);
	}

	public static void main(String[] args) 
	{
		ReverseGeoService geoService = new ReverseGeoService();
		geoService.getAddress("19.197840,72.827690");
		
	}
}
	
	

