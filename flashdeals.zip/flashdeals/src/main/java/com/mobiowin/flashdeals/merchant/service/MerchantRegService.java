package com.mobiowin.flashdeals.merchant.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.flashdeals.commons.ApplicationConstant;
import com.mobiowin.flashdeals.helper.service.IRegistrationHelperService;
import com.mobiowin.flashdeals.messaging.IFlashService;

@Service("merchantRegService")
@Component
public class MerchantRegService implements IFlashService
{

	private Log log = LogFactory.getLog(this.getClass());
	
	@Autowired
	private IRegistrationHelperService registrationHelperService;
	
	public Message<String> execute(Message<String> message) 
	{
		log.info("Inside MerchantRegService/execute()");
		
		String jsonData = message.getPayload();

		Map<String, Object> messageHeaders = message.getHeaders();

		JSONObject merchantDataJson = null;
		JSONObject merchantRegDataJson = null;
		
		String mobileNo = null;
		String imeiNo = null;
		String password = null;
		String emailId = null;
		String response = null;

		try 
		{
			merchantDataJson = new JSONObject(jsonData);
			merchantRegDataJson = merchantDataJson.getJSONObject(ApplicationConstant.DATA);

			if (merchantRegDataJson.has(ApplicationConstant.MOBILE_NO))
		    {
				mobileNo = merchantRegDataJson
						.getString(ApplicationConstant.MOBILE_NO);
			}

			if (merchantRegDataJson.has(ApplicationConstant.IMEI_NO))
			{
				imeiNo = merchantRegDataJson
						.getString(ApplicationConstant.IMEI_NO);
			}
			
			if (merchantRegDataJson.has(ApplicationConstant.FLASH_PASSWORD))
			{
				password = merchantRegDataJson
						.getString(ApplicationConstant.FLASH_PASSWORD);
			}
			
			if (merchantRegDataJson.has(ApplicationConstant.EMAIL_ID))
			{
				emailId = merchantRegDataJson
						.getString(ApplicationConstant.EMAIL_ID);
			}
			
			
			
			if(log.isInfoEnabled())
			{
				log.info("Merchant Data is : " + merchantRegDataJson);
				log.info("Message Headers : " + messageHeaders);
				log.info("Merchant mobile no is : " + mobileNo);
				log.info("Merchant imei no is : " + imeiNo);
				log.info("Merchant password no is : " + password);
				log.info("Merchant email id is : " + emailId);
			}
			
			HashMap<String,String> merchantDataMap = merchantDataMap(mobileNo,imeiNo,password,emailId);
			
			boolean isExistingMerchant = registrationHelperService.isExistingMerchant(merchantDataMap);
			
			if(isExistingMerchant)
			{
				response = registrationHelperService.registerMerchant(merchantDataMap);
			}
			else
			{
				response = registrationHelperService.existingMerchantRes();
			}
			
			
			
			return MessageBuilder.withPayload(response).build();

		} catch (Exception ex)
		{
			log.error("Exception in RegistrationService/execute() " + ex.getMessage(),ex.getCause());

		}
		return null;
	}

	private HashMap<String, String> merchantDataMap(String mobileNo, String imeiNo,
			String password, String emailId) 
	{
		HashMap<String,String> merchantDataMap = new HashMap<String, String>();
		merchantDataMap.put(ApplicationConstant.IMEI_NO, imeiNo);
		merchantDataMap.put(ApplicationConstant.MOBILE_NO, mobileNo);
		merchantDataMap.put(ApplicationConstant.EMAIL_ID, emailId);
		merchantDataMap.put(ApplicationConstant.FLASH_PASSWORD, password);
		
		return merchantDataMap;
	}
	

}
