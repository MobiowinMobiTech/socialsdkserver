package com.mobiowin.flashdeals.bean;

public class AccountDetails
{

	private String accountNo;
	private String accountType;
	private String balance;
	
	
	public String getAccountNo()
	{
		return accountNo;
	}
	public void setAccountNo(String accountNo)
	{
		this.accountNo = accountNo;
	}
	public String getAccountType()
	{
		return accountType;
	}
	public void setAccountType(String accountType)
	{
		this.accountType = accountType;
	}
	public String getBalance()
	{
		return balance;
	}
	public void setBalance(String balance)
	{
		this.balance = balance;
	}
	
	
	
}
