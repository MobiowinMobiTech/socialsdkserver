package com.mobiowin.flashdeals.helper.service;

import java.util.HashMap;

import javax.mail.internet.MimeMessage;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service("sendOtpOnMailService")
@Component
public class SendOtpOnMailService 
{

	private Log log = LogFactory.getLog(this.getClass());
	
	@Autowired
	private JavaMailSender mailSender;
	
	@Autowired
	private SimpleMailMessage simpleMailMessage;
	
	public JavaMailSender getMailSender()
	{
		return mailSender;
	}

	public SimpleMailMessage getSimpleMailMessage()
	{
		return simpleMailMessage;
	}
	public void setMailSender(JavaMailSender mailSender)
	{
		this.mailSender = mailSender;
	}
	public void setSimpleMailMessage(SimpleMailMessage simpleMailMessage)
	{
		this.simpleMailMessage = simpleMailMessage;
	}
	
	public boolean sendOtpOnMailService(HashMap<String,String> reqDataMap) 
	{
		log.info("Inside SendOtpOnMailService/sendOtpOnMailService...");
		
		try
		{
			MimeMessage mimeMessage = mailSender.createMimeMessage();
			
			MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);
			
			log.info("Customer registration bean is : " + registrationBean);
			log.info("Customer registration bean is : " + registrationBean.getMobileNo());
			helper.setFrom(simpleMailMessage.getFrom());
			helper.setTo(registrationBean.getMobileNo());
			helper.setSubject(simpleMailMessage.getSubject());
			helper.setText("Hiii");
			
			mailSender.send(mimeMessage);
			
			return true;
			
			
		} 
		catch (Exception e)
		{
			log.error("Exception in sending mail ...." + e.getMessage());
			return false;
		}
		
	}

}
