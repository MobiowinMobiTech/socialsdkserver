package com.mobiowin.flashdeals.messaging;

import org.springframework.messaging.Message;

public interface IFlashMessageReceiver {
	public Message<String> recieve(Message<String> message);
}
