package com.mobiowin.flashdeals.test;


public class TestUtility {

	public static void main(String[] args) {
		
		String mobileNo = "7709642004";
		mobileNo = mobileNo.substring(5, 10);
		
		StringBuilder merchantIdBuilder = new StringBuilder();
		merchantIdBuilder.append("Flash");
		merchantIdBuilder.append(mobileNo);
		System.out.println("Merchant id is :" +  merchantIdBuilder.toString());
		
		StringBuilder dealIdbuilder = new StringBuilder();
		dealIdbuilder.append(merchantIdBuilder).append("_").append(System.nanoTime());
		System.out.println("Deal id is :" +  dealIdbuilder.toString());
		
		String nanoTime = String.valueOf(System.nanoTime());
		System.out.println("Nano time is :" + nanoTime);
		
		nanoTime = nanoTime.substring(nanoTime.length()-4, nanoTime.length());
		
		System.out.println("Nano time is :" + nanoTime);
		
		
	}
}
