package com.mobiowin.flashdeals.helper.service;

import java.util.HashMap;

public interface IRegistrationHelperService {

	String registerCustomer(HashMap<String, String> dataMap);

	String registerMerchant(HashMap<String, String> merchantDataMap);

	boolean isExistingMerchant(HashMap<String, String> merchantDataMap);

	String existingMerchantRes();

	String fetchMerchantId(HashMap<String, String> merchantDataMap);

}
