package com.mobiowin.flashdeals.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.mobiowin.flashdeals.bean.DealResponseBean;
import com.mobiowin.flashdeals.bean.MerchantDealBean;

public interface IDealSyncDao {

	ArrayList<DealResponseBean> getUserLocalDeals(ArrayList<String> userLocationList);

	String submitMerchantDeal(MerchantDealBean merchantDealBean);

	List<MerchantDealBean> fetchMerchantDealDetails(MerchantDealBean merchantDealBean);

	List<MerchantDealBean> getCustomerDeals(HashMap<String, String> customerLocationDataMap);

	boolean isMerchantDealExist(MerchantDealBean merchantDealBean);

	String updateMerchantDeal(MerchantDealBean merchantDealBean);

}
