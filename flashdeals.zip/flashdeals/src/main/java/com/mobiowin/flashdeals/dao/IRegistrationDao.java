package com.mobiowin.flashdeals.dao;

import com.mobiowin.flashdeals.bean.CustomerRegistrationBean;
import com.mobiowin.flashdeals.bean.MerchantRegistrationBean;

public interface IRegistrationDao {

	String registerCustomer(CustomerRegistrationBean registrationBean);

	String registerMerchant(MerchantRegistrationBean merchantRegistrationBean);

	String isExistingMerchantDao(
			MerchantRegistrationBean merchantRegistrationBean);

	String fetchMerchantById(MerchantRegistrationBean merchantRegistrationBean);

}
