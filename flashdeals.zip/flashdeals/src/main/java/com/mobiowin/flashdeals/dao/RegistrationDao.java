package com.mobiowin.flashdeals.dao;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.mobiowin.flashdeals.bean.CustomerRegistrationBean;
import com.mobiowin.flashdeals.bean.MerchantRegistrationBean;
import com.mobiowin.flashdeals.commons.ApplicationConstant;

@Repository("registrationDao")
@Component
public class RegistrationDao implements IRegistrationDao {
	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private SessionFactory sessionFactory;

	Session session = null;
	Transaction transaction = null;

	public String registerCustomer(CustomerRegistrationBean registrationBean) {
		log.info("inside RegistrationDao/registerCustomer()");

		int queryOutput = 0;

		if (queryOutput == 0) {
			return ApplicationConstant.TRUE;
		} else {
			return ApplicationConstant.FALSE;
		}
	}

	public String registerMerchant(MerchantRegistrationBean merchantRegistrationBean) {

		log.info("inside RegistrationDao/registerMerchant()");

		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			session.save(merchantRegistrationBean);
			session.flush();
			transaction.commit();

			return ApplicationConstant.TRUE;
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
			log.error("Exception in registerMerchant : " + e.getMessage(), e.getCause());
			return ApplicationConstant.FALSE;
		} catch (Exception ex) {
			transaction.rollback();
			ex.printStackTrace();
			log.error("Exception in registerMerchant : " + ex.getMessage(), ex.getCause());
			return ApplicationConstant.FALSE;
		}

	}

	public String isExistingMerchantDao(MerchantRegistrationBean merchantRegistrationBean)
	{

		log.info("inside RegistrationDao/isExistingMerchantDao()");
		
		log.info("Merchant registration bean is : " + merchantRegistrationBean);
		
		StringBuilder merchantCheckQueryBuilder = new StringBuilder();
		merchantCheckQueryBuilder.append("from MerchantRegistrationBean ");

		StringBuilder mechantCheckQuery = getMerchantCheckQuery(merchantCheckQueryBuilder);

		Query query = sessionFactory.openSession().createQuery(mechantCheckQuery.toString());
		query.setParameter("emailId", merchantRegistrationBean.getEmailId());
		query.setParameter("mobileno", merchantRegistrationBean.getMobileNo());

		List<MerchantRegistrationBean> regMerchantList = query.list();

		log.info("merchantLoginList : " + regMerchantList);

		if (regMerchantList.size() > 0) {
			return ApplicationConstant.FALSE;
		}

		return ApplicationConstant.TRUE;

	}

	private StringBuilder getMerchantCheckQuery(StringBuilder merchantCheckQueryBuilder) {
		merchantCheckQueryBuilder.append("where emailId = :emailId and mobileNo =:mobileno");
		return merchantCheckQueryBuilder;
	}

	public String fetchMerchantById(MerchantRegistrationBean merchantRegistrationBean) 
	{
		log.info("Inside RegistrationDao / fetchMerchantById()");
		
		 Query query = sessionFactory.openSession().createQuery("select merchantId FROM MerchantRegistrationBean where emailId = :mobileno or mobileNo =:mobileno");
		 //query.setParameter("emailId", merchantRegistrationBean.getMobileNo());
		 query.setParameter("mobileno", merchantRegistrationBean.getMobileNo());
		 
		 List<String> merchantIdList = query.list();
		 
		 if(log.isInfoEnabled())
		 {
			 log.info("Merchant id list is : " + merchantIdList);
		 }
		 
		 return merchantIdList.get(0);
	}

}
