package com.mobiowin.flashdeals.commons;

public class ApplicationConstant {
	public static final String DEVICE_REQUEST_CHANNEL = "deviceRequestChannel";

	public static final String DEVICE_RESPONSE_CHANNEL = "deviceResponseChannel";

	public static final String RESPONSE = "response";

	public static final String DATA = "data";

	public static final String LOCATION_DATA = "location";

	public static final String LEVEL_INFO = "level";

	public static final String APPLICATION_ID = "appId";

	public static final String DEAL_RADIUS = "dealradius";
	
	public static final String IS_EXCLUSIVE = "isexclusive";

	public static final String ERR_MSG = "errmsg";

	public static final String REQUEST = "request";

	public static final String USER_LATITUDE = "latitude";

	public static final String USER_LONGITUDE = "longitude";

	public static final String TYPE = "type";

	public static final String ENTITY = "entity";

	public static final String ACTON = "action";

	public static final String LOGIN = "login";

	public static final String ERROR = "error";

	public static final String STATUS = "status";

	public static final String SUCCESS = "success";

	public static final String MESSAGE = "message";

	public static final String SUCCESS_MESSAGE = "msg";

	public static final String INFO = "info";

	public static final String HISTORY = "history";

	public static final String EMPTY_STRING = "";

	public static final String STRING_SEPERATOR = "_";

	public static final String SECRET_KEY = "secretKey";

	public static final String IS_VALID = "isValid";

	public static final String IS_GIFT = "isGift";

	public static final String BUSINESS_IMAGE_CONFIG = "merchantImageConfig";

	public static final String FLASH_IMAGE_CONFIG = "flashImageConfig";

	public static final String TRUE = "true";

	public static final String FALSE = "false";

	public static final String AWARD_CODE = "promoCode";

	public static final String EMAIL_ID = "emailid";

	public static final String MOBILE_NO = "mobileno";

	// public static final String PINCODE = "pinCode";

	public static final String IMEI_NO = "imeino";

	public static final String FAILURE = "failure";

	public static final String ERROR_MESSAGE = "errMessage";

	public static final String FILE_PATH_SEPERATOR = "/";

	public static final String IMAGE_SERVLET_IMAGE_PARAM = "img";

	public static final String FLASH_IAMGE_FORMAT = ".jpg";
	
	public static final String FLASH_DEL_FLAG = "delflag";

	public static final String FLASH_URL_APPENDER = "&";

	public static final String FLASH_VALUE_ASSIGNER = "=";

	public static final String FLASH_REQUEST_HEADER = "type";

	public static final String FLASH_IMAGE_ASSIGNER = "img";

	public static final String FLASH_CUST_OTP = "otp";

	public static final String FLASH_PASSWORD = "password";

	public static final String FLASH_USER_ID = "userid";

	public static final String FIRST_NAME = "firstname";

	public static final String LAST_NAME = "lastname";

	public static final String BRAND_NAME = "brandname";

	public static final String BRAND_CATEGORY = "brandcategory";

	public static final String CITY = "city";

	public static final String STATE = "state";

	public static final String COUNTRY = "country";

	public static final String PINCODE = "pincode";

	public static final String DISPLAY_IMAGE = "dpimage";

	public static final String MERCHANT_TYPE = "merchanttype";

	public static final String MERCHANT_ID = "merchantid";

	// Merhant Store

	public static final String STORE_NAME = "storename";

	public static final String STORE_CATEGORY = "storecategory";

	public static final String STORE_DISCRIPTION = "storediscription";

	public static final String MERCHANT_PROFILE = "merchantprofile";

	// Merchant Deal Constant

	public static final String MERCHANT_DEAL_NAME = "dealname";

	public static final String MERCHANT_DEAL_CATEGORY = "dealcategory";

	public static final String MERCHANT_DEAL_DISCRIPTION = "dealdiscription";

	public static final String MERCHANT_DEAL_IMAGE = "dealimage";
	
	public static final String DEAL_ID = "dealid";

	public static final String MERCHANT_DEAL_END_TIME = "dealendtime";

	public static final String MERCHANT_DEAL_START_TIME = "dealstarttime";

	public static final String MERCHANT_DEAL_RADIUS = "dealradius";

	public static final String MERCHANT_DEAL_STORE_ID = "dealstoreid";

	public static final String MERCHANT_STORE_LIST = "storelist";

	public static final String MERCHANT_DEAL_IMG = "flashMerchantDeal";

	public static final String MERCHANT_DEAL_IMG_PATH = "merchantdealimg";

	public static final String MERCHANT_STORE_ID = "storeid";

	public static final String MERCHANT_STORE_IMG = "merchantstoreimg";

	public static final String APP_SLIDER_LIST = "sliderlist";

	public static final String APP_CATEGORY_LIST = "categorylist";

	public static final String APP_VERSION = "appversion";

	public static final String SUBSCRIPTION_MODEL = "subscription";
	
	//public static final String STORE_ID = "storeid";
	// Standrad Bean
	
	public static final String SYSTEM_CREATED_BY = "SYSTEM";
	
	public static final String SYSTEM_MODIFIED_BY = "SYSTEM";
	
	public static final String ACTIVE_DEL_FLAG = "T";
	
	public static final String DEL_FLAG = "F";
	
	public static final String BASIC_MODEL = "basic";
	
	public static final String SILVER_MODEL = "silver";
	
	public static final String GOLD_MODEL = "gold";
	
	public static final String NOTIFICATION_ID = "notificationid";
	
	public static final String OS_TYPE = "ostype";
	
	public static final String OS_VERSION = "osversion";
	
	public static final String FCM_SERVER_AUTH_KEY = "serverkey";
	
	public static final String FCM_NOTIFICATION_URL = "fcmurl";
	
	

}
