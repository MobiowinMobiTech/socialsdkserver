package com.mobiowin.flashdeals.mail;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;

public class MailReport
{

	private Log log = LogFactory.getLog(this.getClass());
	
	
	@Autowired
	private JavaMailSender mailSender;
	
	public boolean sendMail()
	{
		log.info("Inside MailReport/sendMail().....");
		
		return false;
	}
}
