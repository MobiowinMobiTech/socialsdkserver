package com.mobiowin.flashdeals.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;

public class StatndradBean implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	
	
	@Column(name = "created_by")
	private String createdBy;
	@Column(name = "created_dt")
	private Date createDt;
	@Column(name = "modified_by")
	private String modifiedBy;
	@Column(name = "modify_dt")
	private Date modifyDt;
	@Column(name = "del_flag")
	private String deleteFlag;
	
	public StatndradBean(String createdBy, Date createDt, String modifiedBy, Date modifyDt, String deleteFlag) {
		super();
		this.createdBy = createdBy;
		this.createDt = createDt;
		this.modifiedBy = modifiedBy;
		this.modifyDt = modifyDt;
		this.deleteFlag = deleteFlag;
	}
	
	
	
	public StatndradBean() {
		super();
	}



	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreateDt() {
		return createDt;
	}
	public void setCreateDt(Date createDt) {
		this.createDt = createDt;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifyDt() {
		return modifyDt;
	}
	public void setModifyDt(Date modifyDt) {
		this.modifyDt = modifyDt;
	}
	public String getDeleteFlag() {
		return deleteFlag;
	}
	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}
}
