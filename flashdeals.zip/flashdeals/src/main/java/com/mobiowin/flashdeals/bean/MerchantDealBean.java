package com.mobiowin.flashdeals.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "deal_master", catalog = "flashdeals")
public class MerchantDealBean implements Serializable 
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@Column(name = "merchant_id")
	private String merchantId;
	
	@Column(name = "deal_name")
	private String dealName;
	
	@Column(name = "deal_img")
	private String dealImage;
	
	@Column(name = "deal_discription")
	private String dealDiscription;
	
	@Column(name = "deal_start_time")
	private String dealStartTime;
	
	@Column(name = "deal_end_time")
	private String dealEndTime;
	
	@Column(name = "deal_category")
	private String dealCategory;
	
	@Column(name = "deal_radius")
	private String dealRadius;
	
	@Column(name = "deal_store_id")
	private String dealStoreId;
	
	@Column(name = "merchant_deal_id")
	private String merchantDealId;
	
	@Column(name = "imei_no")
	private String imeiNo;
	
	@Column(name = "is_exclusive")
	private String isExclusive;
	
	@Column(name = "latitude")
	private String latitude;
	
	@Column(name = "longitude")
	private String longitude;
	
	@Column(name = "pin_code")
	private String pinCode;
	
	@Column(name = "city")
	private String city;
	
	@Column(name = "state")
	private String state;
	
	@Column(name = "country")
	private String country;
	
	@Column(name = "created_by")
	private String createdBy;
	
	@Column(name = "created_dt")
	private Date createDt;
	
	@Column(name = "modified_by")
	private String modifiedBy;
	
	@Column(name = "modified_dt")
	private Date modifyDt;
	
	@Column(name = "del_flag")
	private String deleteFlag;

	

	public MerchantDealBean(int id, String merchantId, String dealName, String dealImage, String dealDiscription,
			String dealStartTime, String dealEndTime, String dealCategory, String dealRadius, String dealStoreId,
			String merchantDealId, String imeiNo, String isExclusive, String latitude, String longitude, String pinCode,
			String city, String state, String country, String createdBy, Date createDt, String modifiedBy,
			Date modifyDt, String deleteFlag) {
		super();
		this.id = id;
		this.merchantId = merchantId;
		this.dealName = dealName;
		this.dealImage = dealImage;
		this.dealDiscription = dealDiscription;
		this.dealStartTime = dealStartTime;
		this.dealEndTime = dealEndTime;
		this.dealCategory = dealCategory;
		this.dealRadius = dealRadius;
		this.dealStoreId = dealStoreId;
		this.merchantDealId = merchantDealId;
		this.imeiNo = imeiNo;
		this.isExclusive = isExclusive;
		this.latitude = latitude;
		this.longitude = longitude;
		this.pinCode = pinCode;
		this.city = city;
		this.state = state;
		this.country = country;
		this.createdBy = createdBy;
		this.createDt = createDt;
		this.modifiedBy = modifiedBy;
		this.modifyDt = modifyDt;
		this.deleteFlag = deleteFlag;
	}

	public MerchantDealBean() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public String getDealName() {
		return dealName;
	}

	public void setDealName(String dealName) {
		this.dealName = dealName;
	}

	public String getDealImage() {
		return dealImage;
	}

	public void setDealImage(String dealImage) {
		this.dealImage = dealImage;
	}

	public String getDealDiscription() {
		return dealDiscription;
	}

	public void setDealDiscription(String dealDiscription) {
		this.dealDiscription = dealDiscription;
	}

	public String getDealStartTime() {
		return dealStartTime;
	}

	public void setDealStartTime(String dealStartTime) {
		this.dealStartTime = dealStartTime;
	}

	public String getDealEndTime() {
		return dealEndTime;
	}

	public void setDealEndTime(String dealEndTime) {
		this.dealEndTime = dealEndTime;
	}

	public String getDealCategory() {
		return dealCategory;
	}

	public void setDealCategory(String dealCategory) {
		this.dealCategory = dealCategory;
	}

	public String getDealRadius() {
		return dealRadius;
	}

	public void setDealRadius(String dealRadius) {
		this.dealRadius = dealRadius;
	}

	public String getDealStoreId() {
		return dealStoreId;
	}

	public void setDealStoreId(String dealStoreId) {
		this.dealStoreId = dealStoreId;
	}

	public String getMerchantDealId() {
		return merchantDealId;
	}

	public void setMerchantDealId(String merchantDealId) {
		this.merchantDealId = merchantDealId;
	}

	public String getImeiNo() {
		return imeiNo;
	}

	public void setImeiNo(String imeiNo) {
		this.imeiNo = imeiNo;
	}

	public String getIsExclusive() {
		return isExclusive;
	}

	public void setIsExclusive(String isExclusive) {
		this.isExclusive = isExclusive;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Date createDt) {
		this.createDt = createDt;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifyDt() {
		return modifyDt;
	}

	public void setModifyDt(Date modifyDt) {
		this.modifyDt = modifyDt;
	}

	public String getDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}

	@Override
	public String toString() {
		return "MerchantDealBean [id=" + id + ", merchantId=" + merchantId + ", dealName=" + dealName + ", dealImage="
				+ dealImage + ", dealDiscription=" + dealDiscription + ", dealStartTime=" + dealStartTime
				+ ", dealEndTime=" + dealEndTime + ", dealCategory=" + dealCategory + ", dealRadius=" + dealRadius
				+ ", dealStoreId=" + dealStoreId + ", merchantDealId=" + merchantDealId + ", imeiNo=" + imeiNo
				+ ", isExclusive=" + isExclusive + ", latitude=" + latitude + ", longitude=" + longitude + ", pinCode="
				+ pinCode + ", city=" + city + ", state=" + state + ", country=" + country + ", createdBy=" + createdBy
				+ ", createDt=" + createDt + ", modifiedBy=" + modifiedBy + ", modifyDt=" + modifyDt + ", deleteFlag="
				+ deleteFlag + "]";
	}

		
}
