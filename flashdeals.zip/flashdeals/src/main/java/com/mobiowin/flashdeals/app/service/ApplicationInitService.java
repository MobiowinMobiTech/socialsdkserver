package com.mobiowin.flashdeals.app.service;

import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.flashdeals.helper.service.IAppSyncHelperServie;
import com.mobiowin.flashdeals.messaging.IFlashService;

@Service("appInitInitService")
@Component
public class ApplicationInitService implements IFlashService{

	private Log log = LogFactory.getLog(this.getClass());
	
	@Autowired
	private IAppSyncHelperServie appSyncService;
	
	
	public Message<String> execute(Message<String> message) 
	{
		log.info("Inside ApplicationInitService/execute()");
		
		String jsonData = message.getPayload();

		Map<String, Object> messageHeaders = message.getHeaders();
		
		if(log.isInfoEnabled())
		{
			log.info("Message Headers : " + messageHeaders);
			log.info("Json Data is  : " + jsonData);
		}
		
		String registerResponse = appSyncService.syncApplciationData();
		
		return MessageBuilder.withPayload(registerResponse).build();
		
	}

}
