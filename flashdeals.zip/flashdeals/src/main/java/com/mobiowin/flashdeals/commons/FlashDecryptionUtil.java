package com.mobiowin.flashdeals.commons;

import java.security.Key;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.codec.binary.Base64;

public class FlashDecryptionUtil
{
	
	public static final String secretKey = "AB081F9ABCAF3911";
	
	public static String decryptedMessage(String message)
	{
		byte[] decryptedValue = null;
		try
		{
			Key key = new SecretKeySpec(secretKey.getBytes(),"AES");
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			final byte[] iv =  new byte[16];
			cipher.init(Cipher.DECRYPT_MODE, key, new IvParameterSpec(iv));
			byte[] decrypted = Base64.decodeBase64(message.getBytes());
			decryptedValue = cipher.doFinal(decrypted);
			System.out.println("Decrypted message is : " + new String(decryptedValue));
			return new String(decryptedValue);
		}
		catch(Exception ex)
		{
			System.out.println("Excetion in decryption : " + ex.getMessage());
			
		}
		
		return null;
	}
}
