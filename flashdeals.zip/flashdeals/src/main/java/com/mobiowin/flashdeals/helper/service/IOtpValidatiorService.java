package com.mobiowin.flashdeals.helper.service;

import java.util.HashMap;

public interface IOtpValidatiorService {

	String validateCustomerOtp(HashMap<String, String> dataMap);

}
