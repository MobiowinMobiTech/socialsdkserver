package com.mobiowin.flashdeals.dao;

import java.util.HashMap;
import java.util.List;

import com.mobiowin.flashdeals.bean.MerchantProfileBean;

public interface IProfileSyncDao {

	List<MerchantProfileBean> fetchMerchantProfile(
			MerchantProfileBean merchantProfileBean);

	String updateMerchantProfile(MerchantProfileBean merchantProfileBean);

	String fetchMerchantId(HashMap<String, String> merchantDataMap);

	List<MerchantProfileBean> fetchMerchantProfile(String merchantId);

	String createMerchantProfile(MerchantProfileBean merchantProfileBean);

	String updateSubscriptionModel(MerchantProfileBean merchantSubscriptionBean);

	List<MerchantProfileBean> getMerchantProfile(MerchantProfileBean merchantProfileBean);

}
