package com.mobiowin.flashdeals.merchant.service;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.messaging.Message;

import com.mobiowin.flashdeals.messaging.IFlashService;

public class MerchantValidationService implements IFlashService
{
	private Log log = LogFactory.getLog(this.getClass());

	public Message<String> execute(Message<String> message) 
	{
		log.info("Inside MerchantValidationService/execute()");
		
		
		return null;
	}

}
