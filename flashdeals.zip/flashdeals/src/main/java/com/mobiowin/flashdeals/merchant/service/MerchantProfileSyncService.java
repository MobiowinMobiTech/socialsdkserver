package com.mobiowin.flashdeals.merchant.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.flashdeals.commons.ApplicationConstant;
import com.mobiowin.flashdeals.helper.service.IProfileSyncService;
import com.mobiowin.flashdeals.messaging.IFlashService;

@Service("merchantProfileSyncService")
@Component
public class MerchantProfileSyncService implements IFlashService{

	private Log log = LogFactory.getLog(this.getClass());
	
	@Autowired
	private IProfileSyncService profileSyncService;
	
	public Message<String> execute(Message<String> message) 
	{
		log.info("Inside MerchantProfileSyncService/execute()");
		
		String jsonData = message.getPayload();

		Map<String, Object> messageHeaders = message.getHeaders();

		JSONObject merchantProfileJson = null;
		JSONObject merchantProfileDataJson = null;
		
		String mercahntId = null;
		String firstName = null;
		String lastName = null;
		String brandName = null;
		String brandCategory = null;
		String city = null;
		String state = null;
		String country = null;
		String pinCode = null;
		String dpImage = null;
		String mobileNo = null;
		String merchantType = null;

		try 
		{
			merchantProfileJson = new JSONObject(jsonData);
			merchantProfileDataJson = merchantProfileJson.getJSONObject(ApplicationConstant.DATA);

			if (merchantProfileDataJson.has(ApplicationConstant.MERCHANT_ID))
		    {
				mercahntId = merchantProfileDataJson
						.getString(ApplicationConstant.MERCHANT_ID);
			}
			
			if (merchantProfileDataJson.has(ApplicationConstant.FIRST_NAME))
		    {
				firstName = merchantProfileDataJson
						.getString(ApplicationConstant.FIRST_NAME);
			}

			if (merchantProfileDataJson.has(ApplicationConstant.LAST_NAME))
			{
				lastName = merchantProfileDataJson
						.getString(ApplicationConstant.LAST_NAME);
			}
			
			if (merchantProfileDataJson.has(ApplicationConstant.BRAND_NAME))
			{
				brandName = merchantProfileDataJson
						.getString(ApplicationConstant.BRAND_NAME);
			}
			
			if (merchantProfileDataJson.has(ApplicationConstant.BRAND_CATEGORY))
			{
				brandCategory = merchantProfileDataJson
						.getString(ApplicationConstant.BRAND_CATEGORY);
			}
			
			if (merchantProfileDataJson.has(ApplicationConstant.CITY))
			{
				city = merchantProfileDataJson
						.getString(ApplicationConstant.CITY);
			}
			
			if (merchantProfileDataJson.has(ApplicationConstant.STATE))
			{
				state = merchantProfileDataJson
						.getString(ApplicationConstant.STATE);
			}
			
			if (merchantProfileDataJson.has(ApplicationConstant.COUNTRY))
			{
				country = merchantProfileDataJson
						.getString(ApplicationConstant.COUNTRY);
			}
			
			if (merchantProfileDataJson.has(ApplicationConstant.PINCODE))
			{
				pinCode = merchantProfileDataJson
						.getString(ApplicationConstant.PINCODE);
			}
			
			if (merchantProfileDataJson.has(ApplicationConstant.DISPLAY_IMAGE))
			{
				dpImage = merchantProfileDataJson
						.getString(ApplicationConstant.DISPLAY_IMAGE);
			}
			
			if (merchantProfileDataJson.has(ApplicationConstant.MOBILE_NO))
			{
				mobileNo = merchantProfileDataJson
						.getString(ApplicationConstant.MOBILE_NO);
			}
			
			if (merchantProfileDataJson.has(ApplicationConstant.MOBILE_NO))
			{
				mobileNo = merchantProfileDataJson
						.getString(ApplicationConstant.MOBILE_NO);
			}
			
			if (merchantProfileDataJson.has(ApplicationConstant.MERCHANT_TYPE))
			{
				merchantType = merchantProfileDataJson
						.getString(ApplicationConstant.MERCHANT_TYPE);
			}
			
			
			if(log.isInfoEnabled())
			{
				log.info("Message Headers is : " + messageHeaders);
				log.info("Merchant id is : " + mercahntId);
				log.info("First name is : " + firstName);
				log.info("Last name is : " + lastName);
				log.info("Brand Name is : " + brandName);
				log.info("Brand Category is : " + brandCategory);
				log.info("City is : " + city);
				log.info("State is : " + state);
				log.info("Country is : " + country);
				log.info("Pin code is : " + pinCode);
				log.info("Display Image is : " + dpImage);
				log.info("Mobile No is : " + mobileNo);
				log.info("Merchant type is :" + merchantType);
			}
			
			HashMap<String,String> merchantProfileDataMap = getMerchantProfileDataMap(mercahntId,firstName,lastName,brandCategory,brandName,city,state,country,pinCode,dpImage,mobileNo,merchantType);
			
			String response = profileSyncService.updateMerchantProfile(merchantProfileDataMap);
			
			log.info("Response is : " + response);
			
			return MessageBuilder.withPayload(response).build();
		}
		catch(Exception ex)
		{
			log.error("Exception in data parsing MerchantProfileSyncService " + ex.getMessage());
		}

		return null;
	}

	private HashMap<String, String> getMerchantProfileDataMap(String mercahntId,String firstName,
			String lastName, String brandCategory, String brandName,
			String city, String state, String country, String pinCode,
			String dpImage,String mobileNo,String merchantType) {
		
		HashMap<String,String> merchantProfileDataMap = new HashMap<String,String>();
		
		merchantProfileDataMap.put(ApplicationConstant.MERCHANT_ID, mercahntId);
		merchantProfileDataMap.put(ApplicationConstant.FIRST_NAME, firstName);
		merchantProfileDataMap.put(ApplicationConstant.LAST_NAME, lastName);
		merchantProfileDataMap.put(ApplicationConstant.BRAND_NAME, brandName);
		merchantProfileDataMap.put(ApplicationConstant.BRAND_CATEGORY, brandCategory);
		merchantProfileDataMap.put(ApplicationConstant.CITY, city);
		merchantProfileDataMap.put(ApplicationConstant.STATE, state);
		merchantProfileDataMap.put(ApplicationConstant.COUNTRY, country);
		merchantProfileDataMap.put(ApplicationConstant.PINCODE, pinCode);
		merchantProfileDataMap.put(ApplicationConstant.DISPLAY_IMAGE, dpImage);
		merchantProfileDataMap.put(ApplicationConstant.MOBILE_NO, mobileNo);
		merchantProfileDataMap.put(ApplicationConstant.MERCHANT_TYPE, merchantType);
		
		return merchantProfileDataMap;
	}

}
