package com.mobiowin.flashdeals.messaging;

import org.springframework.messaging.Message;

public interface IFlashService {
	public abstract Message<String> execute(Message<String> message);
}
