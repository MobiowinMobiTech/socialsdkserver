package com.mobiowin.flashdeals.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "category_master", catalog = "flashdeals")
public class CategoryBean extends StatndradBean implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@Column(name = "category_code")
	private String categoryCode;
	
	@Column(name = "category_discription")
	private String categoryDiscription;
	
	@Column(name = "category_img_path")
	private String categoryImgPath;
	
	
	
	
	public CategoryBean(String createdBy, Date createDt, String modifiedBy, Date modifyDt, String deleteFlag, int id,
			String categoryCode, String categoryDiscription, String categoryImgPath) {
		super(createdBy, createDt, modifiedBy, modifyDt, deleteFlag);
		this.id = id;
		this.categoryCode = categoryCode;
		this.categoryDiscription = categoryDiscription;
		this.categoryImgPath = categoryImgPath;
	}
	
	
	public CategoryBean() {
		super();
		// TODO Auto-generated constructor stub
	}


	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCategoryCode() {
		return categoryCode;
	}
	public void setCategoryCode(String categoryCode) {
		this.categoryCode = categoryCode;
	}
	public String getCategoryDiscription() {
		return categoryDiscription;
	}
	public void setCategoryDiscription(String categoryDiscription) {
		this.categoryDiscription = categoryDiscription;
	}
	public String getCategoryImgPath() {
		return categoryImgPath;
	}
	public void setCategoryImgPath(String categoryImgPath) {
		this.categoryImgPath = categoryImgPath;
	}
	
	@Override
	public String toString() {
		return "CategoryBean [id=" + id + ", categoryCode=" + categoryCode + ", categoryDiscription="
				+ categoryDiscription + ", categoryImgPath=" + categoryImgPath + "]";
	}
	
	
	
	
}
