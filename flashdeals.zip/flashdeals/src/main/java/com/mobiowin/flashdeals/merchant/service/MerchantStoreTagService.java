package com.mobiowin.flashdeals.merchant.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.flashdeals.commons.ApplicationConstant;
import com.mobiowin.flashdeals.commons.FlashLocallyUtillity;
import com.mobiowin.flashdeals.geo.ReverseGeoService;
import com.mobiowin.flashdeals.helper.service.IStoreHelperService;
import com.mobiowin.flashdeals.messaging.IFlashService;

@Service("merchantStoreTagService")
@Component
public class MerchantStoreTagService implements IFlashService {
	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private IStoreHelperService storeService;

	@Autowired
	private ReverseGeoService reverseGeoService;

	public Message<String> execute(Message<String> message) {
		log.info("inside MerchantStoreTagService/execute()");

		String jsonData = message.getPayload();

		Map<String, Object> messageHeaders = message.getHeaders();

		JSONObject merchantDataJson = null;
		JSONObject merchantStoreDataJson = null;
		JSONArray merchantStoreImgArray = null;

		String storeName = null;
		String storeCategory = null;
		String storeDiscription = null;
		String latitude = null;
		String longitude = null;
		String merchantId = null;
		String storeAddress = null;
		String storeId = null;
		List<String> storeImgList = null;
		String delFlag = null;
		try {
			merchantDataJson = new JSONObject(jsonData);
			merchantStoreDataJson = merchantDataJson.getJSONObject(ApplicationConstant.DATA);

			if (merchantStoreDataJson.has(ApplicationConstant.MERCHANT_ID)) {
				merchantId = merchantStoreDataJson.getString(ApplicationConstant.MERCHANT_ID);
			}

			if (merchantStoreDataJson.has(ApplicationConstant.STORE_NAME)) {
				storeName = merchantStoreDataJson.getString(ApplicationConstant.STORE_NAME);
			}

			if (merchantStoreDataJson.has(ApplicationConstant.STORE_CATEGORY)) {
				storeCategory = merchantStoreDataJson.getString(ApplicationConstant.STORE_CATEGORY);
			}

			if (merchantStoreDataJson.has(ApplicationConstant.STORE_DISCRIPTION)) {
				storeDiscription = merchantStoreDataJson.getString(ApplicationConstant.STORE_DISCRIPTION);
			}

			if (merchantStoreDataJson.has(ApplicationConstant.USER_LATITUDE)) {
				latitude = merchantStoreDataJson.getString(ApplicationConstant.USER_LATITUDE);
			}

			if (merchantStoreDataJson.has(ApplicationConstant.USER_LONGITUDE)) {
				longitude = merchantStoreDataJson.getString(ApplicationConstant.USER_LONGITUDE);
			}

			if (merchantStoreDataJson.has(ApplicationConstant.USER_LONGITUDE)) {
				longitude = merchantStoreDataJson.getString(ApplicationConstant.USER_LONGITUDE);
			}

			if (merchantStoreDataJson.has(ApplicationConstant.FLASH_DEL_FLAG)) {
				delFlag = merchantStoreDataJson.getString(ApplicationConstant.FLASH_DEL_FLAG);
			}
			
			if (merchantStoreDataJson.has(ApplicationConstant.MERCHANT_STORE_ID)) {
				storeId = merchantStoreDataJson.getString(ApplicationConstant.MERCHANT_STORE_ID);
			}

			if (merchantStoreDataJson.has(ApplicationConstant.MERCHANT_STORE_IMG)) {
				merchantStoreImgArray = merchantStoreDataJson.getJSONArray(ApplicationConstant.MERCHANT_STORE_IMG);
				storeImgList = new ArrayList<String>();

				for (int i = 0; i < merchantStoreImgArray.length(); i++) {
					if (null != merchantStoreImgArray.getJSONObject(i).getString("img") || !merchantStoreImgArray
							.getJSONObject(i).getString("img").equalsIgnoreCase(ApplicationConstant.EMPTY_STRING)) {
						storeImgList.add(merchantStoreImgArray.getJSONObject(i).getString("img"));
					}
				}

			}

			storeAddress = reverseGeoService.getUserLocallyDetails(latitude, longitude);

			// log.info("StoreAddress : " + storeAddress);

			ArrayList<String> merchantStoreDetails = FlashLocallyUtillity.getUserDetailMap(storeAddress);

			if (log.isInfoEnabled()) {
				log.info("Message headers is  : " + messageHeaders);
				log.info("Merchant Id is  : " + merchantId);
				log.info("Store Discription : " + storeDiscription);
				log.info("Store name : " + storeName);
				log.info("Store category : " + storeCategory);
				log.info("Store latitude : " + latitude);
				log.info("Store longitude : " + longitude);
				log.info("Merchant store Details : " + merchantStoreDetails);
				log.info("Merchant store image details : " + storeImgList.size());
				log.info("Merchant store delete flag is : " + delFlag);
				log.info("Merchant store Id is : " + storeId);
			}

			HashMap<String, Object> requestDataMap = getRequestDataMap(merchantId, storeDiscription, storeName,
					storeCategory, latitude, longitude, storeImgList, delFlag,storeId);

			log.info("Request dataMap is : " + requestDataMap);

			String response = storeService.tagMerchantStore(requestDataMap);

			// log.info("response is :" + response);

			return MessageBuilder.withPayload(response).build();

		} catch (JSONException e) {
			log.error("Exception in parsing json " + e.getMessage());
			e.printStackTrace();
		}

		return null;
	}

	private HashMap<String, Object> getRequestDataMap(String merchantId, String storeDiscription, String storeName,
			String storeCategory, String latitude, String longitude, List<String> storeImgList, String delFlag, String storeId) {
		HashMap<String, Object> storeDataMap = new HashMap<String, Object>();

		storeDataMap.put(ApplicationConstant.STORE_NAME, storeName);
		storeDataMap.put(ApplicationConstant.STORE_DISCRIPTION, storeDiscription);
		storeDataMap.put(ApplicationConstant.STORE_CATEGORY, storeCategory);
		storeDataMap.put(ApplicationConstant.MERCHANT_ID, merchantId);
		storeDataMap.put(ApplicationConstant.USER_LATITUDE, latitude);
		storeDataMap.put(ApplicationConstant.USER_LONGITUDE, longitude);
		storeDataMap.put(ApplicationConstant.USER_LONGITUDE, longitude);
		storeDataMap.put(ApplicationConstant.MERCHANT_STORE_IMG, storeImgList);
		storeDataMap.put(ApplicationConstant.FLASH_DEL_FLAG, delFlag);
		storeDataMap.put(ApplicationConstant.MERCHANT_STORE_ID, storeId);

		return storeDataMap;
	}

}
