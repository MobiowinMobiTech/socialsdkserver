package com.mobiowin.flashdeals.merchant.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Service;

import com.mobiowin.flashdeals.commons.ApplicationConstant;
import com.mobiowin.flashdeals.helper.service.ISubscriptionService;
import com.mobiowin.flashdeals.messaging.IFlashService;

@Service("subscriptionSyncService")
public class SubscriptionSyncService implements IFlashService
{
	private Log log = LogFactory.getLog(this.getClass());
	
	@Autowired
	private ISubscriptionService subscriptionService;
	
	public Message<String> execute(Message<String> message) 
	{
		log.info("Inside SubscriptionSyncService/execute()");
		
		String jsonData = message.getPayload();

		Map<String, Object> messageHeaders = message.getHeaders();

		JSONObject merchantDataJson = null;
		JSONObject merchantSubscriptionDataJson = null;
		
		String merchantId = null;
		String subscriptionModel = null;
		
		try 
		{
			merchantDataJson = new JSONObject(jsonData);
			merchantSubscriptionDataJson = merchantDataJson.getJSONObject(ApplicationConstant.DATA);
			
			
			if (merchantSubscriptionDataJson.has(ApplicationConstant.MERCHANT_ID))
		    {
				merchantId = merchantSubscriptionDataJson
						.getString(ApplicationConstant.MERCHANT_ID);
			}
			
			if (merchantSubscriptionDataJson.has(ApplicationConstant.SUBSCRIPTION_MODEL))
		    {
				subscriptionModel = merchantSubscriptionDataJson
						.getString(ApplicationConstant.SUBSCRIPTION_MODEL);
			}
			
			if(log.isInfoEnabled())
			{
				log.info("Message headers is : " + messageHeaders);
				log.info("Merchnat id is : " + merchantId);
				log.info("Subscription model is : " + subscriptionModel);
				
			}
			
			HashMap<String,Object> requestDataMap = getRequestDataMap(merchantId,subscriptionModel);
			
			String response = subscriptionService.submitsubscriptionModel(requestDataMap);
			
			log.info("response is :" + response);
			
			return MessageBuilder.withPayload(response).build();
		} 
		catch (Exception e) 
		{
			log.error("Exception in SubscriptionSyncService " + e.getMessage());
		}
		
		
		return null;
	}

	private HashMap<String, Object> getRequestDataMap(String merchantId, String subscriptionModel)
	{
		HashMap<String,Object> requestDataMap = new HashMap<String,Object>();
		
		requestDataMap.put(ApplicationConstant.MERCHANT_ID, merchantId);
		requestDataMap.put(ApplicationConstant.SUBSCRIPTION_MODEL, subscriptionModel);
		
		return requestDataMap;
	}

}
