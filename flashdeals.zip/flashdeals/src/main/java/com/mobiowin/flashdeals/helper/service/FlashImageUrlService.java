package com.mobiowin.flashdeals.helper.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.flashdeals.commons.ApplicationConstant;


@Service("flashImageService")
@Component
public class FlashImageUrlService
{
	private Log log = LogFactory.getLog(this.getClass());
	
	@Autowired
	private @Resource
	Map<String, List<String>> merchantImageConfig;

	@Autowired
	private @Resource
	Map<String, List<String>> flashImageConfig;

	public Map<String,String> getImageUrl(String merchantId)
	{

		List<String> businessImageBasePath = (List<String>) merchantImageConfig
				.get("MERCHANT_IMAGE_BASE_PATH");
		
		List<String> geeniImageBasePath = (List<String>) flashImageConfig
				.get("FLASH_IMAGE_BASE_PATH");

		String basePath = businessImageBasePath.get(0).trim();
		String urlAddress = businessImageBasePath.get(1).trim();
		String entityValue = businessImageBasePath.get(3).trim();

		if (log.isInfoEnabled())
		{
			log.info("Base Path is    : " + basePath);
			log.info("Url Address is  : " + urlAddress);
			log.info("Entity value is : " + entityValue);
		}

		StringBuilder businessImagePath = new StringBuilder();
		businessImagePath.append(urlAddress);
		businessImagePath.append(ApplicationConstant.ENTITY);
		businessImagePath.append(ApplicationConstant.FLASH_VALUE_ASSIGNER);
		businessImagePath.append(entityValue);
		businessImagePath.append(ApplicationConstant.FLASH_URL_APPENDER);
		businessImagePath.append(ApplicationConstant.FLASH_IMAGE_ASSIGNER);
		businessImagePath.append(ApplicationConstant.FLASH_VALUE_ASSIGNER);
		businessImagePath.append(merchantId);
		
	
		
		
		String geeniBasePath = geeniImageBasePath.get(0).trim();
		String geeniUrlAddress = geeniImageBasePath.get(1).trim();
		
		StringBuilder flashImagePath = new StringBuilder();
		flashImagePath.append(geeniImageBasePath.get(1).trim());
		flashImagePath.append(ApplicationConstant.ENTITY);
		flashImagePath.append(ApplicationConstant.FLASH_VALUE_ASSIGNER);
		flashImagePath.append(geeniImageBasePath.get(3).trim());
		flashImagePath.append(ApplicationConstant.FLASH_URL_APPENDER);
		flashImagePath.append(ApplicationConstant.FLASH_IMAGE_ASSIGNER);
		flashImagePath.append(ApplicationConstant.FLASH_VALUE_ASSIGNER);
		flashImagePath.append(geeniImageBasePath.get(2).trim());
		
		
		
		
		if (log.isInfoEnabled())
		{
			log.info("Flash Base Path is    : " + geeniBasePath);
			log.info("Flash Url Address is  : " + geeniUrlAddress);
			log.info("Business Image Url : " + businessImagePath.toString());
			log.info("Business Image Url : " + flashImagePath.toString());
		}
		

		HashMap<String, String> imageUrlMap = new HashMap<String, String>();
		imageUrlMap.put("BusinessUrl", businessImagePath.toString());
		imageUrlMap.put("FlashUrl", flashImagePath.toString());
		
		
		
		return imageUrlMap;
	}

	public Map<String, String> getStoreImgUrl(String imgName) 
	{
		List<String> storeImageBasePath = (List<String>) merchantImageConfig
				.get("MERCHANT_STORE_IMG_BASE_PATH");
		

		String basePath = storeImageBasePath.get(0).trim();
		String urlAddress = storeImageBasePath.get(1).trim();
		String entityType = storeImageBasePath.get(2).trim();

		if (log.isInfoEnabled())
		{
			log.info("Base Path is    : " + basePath);
			log.info("Url Address is  : " + urlAddress);
			log.info("Entity value is : " + entityType);
		}
		
		StringBuilder storeImagePath = new StringBuilder();
		storeImagePath.append(urlAddress);
		storeImagePath.append(ApplicationConstant.ENTITY);
		storeImagePath.append(ApplicationConstant.FLASH_VALUE_ASSIGNER);
		storeImagePath.append(entityType);
		storeImagePath.append(ApplicationConstant.FLASH_URL_APPENDER);
		storeImagePath.append(ApplicationConstant.FLASH_IMAGE_ASSIGNER);
		storeImagePath.append(ApplicationConstant.FLASH_VALUE_ASSIGNER);
		storeImagePath.append(imgName);

		HashMap<String, String> imageUrlMap = new HashMap<String, String>();
		imageUrlMap.put("StoreImgUrl", storeImagePath.toString());
		return imageUrlMap;
	}
	
	public Map<String, String> getDealImgUrl(String imgName) 
	{
		List<String> storeImageBasePath = (List<String>) merchantImageConfig
				.get("MERCHANT_DEAL_IMG_BASE_PATH");
		

		String basePath = storeImageBasePath.get(0).trim();
		String urlAddress = storeImageBasePath.get(1).trim();
		String entityType = storeImageBasePath.get(2).trim();

		if (log.isInfoEnabled())
		{
			log.info("Base Path is    : " + basePath);
			log.info("Url Address is  : " + urlAddress);
			log.info("Entity value is : " + entityType);
		}
		
		StringBuilder storeImagePath = new StringBuilder();
		storeImagePath.append(urlAddress);
		storeImagePath.append(ApplicationConstant.ENTITY);
		storeImagePath.append(ApplicationConstant.FLASH_VALUE_ASSIGNER);
		storeImagePath.append(entityType);
		storeImagePath.append(ApplicationConstant.FLASH_URL_APPENDER);
		storeImagePath.append(ApplicationConstant.FLASH_IMAGE_ASSIGNER);
		storeImagePath.append(ApplicationConstant.FLASH_VALUE_ASSIGNER);
		storeImagePath.append(imgName);

		HashMap<String, String> imageUrlMap = new HashMap<String, String>();
		imageUrlMap.put("DealImgUrl", storeImagePath.toString());
		return imageUrlMap;
	}
	
	
	public Map<String, String> getMerchantProfileImgUrl(String imgName) 
	{
		List<String> storeImageBasePath = (List<String>) merchantImageConfig
				.get("MERCHANT_DP_IMG_BASE_PATH");
		

		String basePath = storeImageBasePath.get(0).trim();
		String urlAddress = storeImageBasePath.get(1).trim();
		String entityType = storeImageBasePath.get(2).trim();

		if (log.isInfoEnabled())
		{
			log.info("Base Path is    : " + basePath);
			log.info("Url Address is  : " + urlAddress);
			log.info("Entity value is : " + entityType);
		}
		
		StringBuilder storeImagePath = new StringBuilder();
		storeImagePath.append(urlAddress);
		storeImagePath.append(ApplicationConstant.ENTITY);
		storeImagePath.append(ApplicationConstant.FLASH_VALUE_ASSIGNER);
		storeImagePath.append(entityType);
		storeImagePath.append(ApplicationConstant.FLASH_URL_APPENDER);
		storeImagePath.append(ApplicationConstant.FLASH_IMAGE_ASSIGNER);
		storeImagePath.append(ApplicationConstant.FLASH_VALUE_ASSIGNER);
		storeImagePath.append(imgName);

		HashMap<String, String> imageUrlMap = new HashMap<String, String>();
		imageUrlMap.put("MerchantProfileImgLink", storeImagePath.toString());
		return imageUrlMap;
	}

	

}
