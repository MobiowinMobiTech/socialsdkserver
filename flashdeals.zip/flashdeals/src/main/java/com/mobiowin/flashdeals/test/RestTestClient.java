package com.mobiowin.flashdeals.test;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.mobiowin.flashdeals.messaging.IFlashService;

@Service("restTestClient")
@Component
public class RestTestClient implements IFlashService {
	
	private Log log = LogFactory.getLog(this.getClass());
	

	@Autowired
	private RestTemplate restTemplate;
	
	public Message<String> execute(Message<String> message)
	{
		String jsonData = message.getPayload();
		
		log.info("Rest template is : " + restTemplate);
		
		String uri = "http://localhost:8091/SocialSdkTestApp/rest/customerdetails/json/";
		
		//ResponseEntity<CustomerAccountDeatail> personEntity = restTemplate.getForEntity(uri,CustomerAccountDeatail.class, "");
		//JSONObject empjosn = new JSONObject(personEntity);
		
		
		
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<String> entity = new HttpEntity<String>(jsonData,headers);

		// send request and parse result
		String answer = restTemplate.postForObject(uri, entity, String.class);
		JSONObject responseJson = new JSONObject(answer);
		
		//log.info("personEntity : " + personEntity.getBody());
		log.info("answer : " + responseJson);
		
		String response = "raman";
		
		return MessageBuilder.withPayload(answer).build();
	}

}
