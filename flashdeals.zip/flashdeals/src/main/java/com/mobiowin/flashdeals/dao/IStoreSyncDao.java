package com.mobiowin.flashdeals.dao;

import java.util.List;

import com.mobiowin.flashdeals.bean.MerchantStoreBean;

public interface IStoreSyncDao {

	boolean isStoreExist(MerchantStoreBean merchantStoreBean);

	String tagStoreLocation(MerchantStoreBean merchantStoreBean);

	List<MerchantStoreBean> fetchStoreDetails(MerchantStoreBean merchantStoreBean);

	String updateMerchantStoreDetails(MerchantStoreBean merchantStoreBean);

}
