package com.mobiowin.flashdeals.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.mobiowin.flashdeals.bean.DealResponseBean;
import com.mobiowin.flashdeals.bean.MerchantDealBean;
import com.mobiowin.flashdeals.bean.MerchantStoreBean;
import com.mobiowin.flashdeals.commons.ApplicationConstant;
import com.mobiowin.flashdeals.helper.service.FlashImageUrlService;


@Repository("dealSyncDao")
@Component
public class DealSyncDao implements IDealSyncDao
{
	private Log log = LogFactory.getLog(this.getClass());
	
	@Autowired
	private FlashImageUrlService flashImageUrlService;

	@Autowired
	private SessionFactory sessionFactory;

	Session session = null;
	Transaction transaction = null;

	
	public ArrayList<DealResponseBean> getUserLocalDeals(ArrayList<String> userLocationList) 
	{
		log.info("Inside DealSyncDao/getUserLocalDeals()");
		
		/*
		 * userLocationList.get(0) ----> customer city
		 * Select * from dealsMaster where city = 'city'
		 * 
		 * 		"dealcategory": "2",
                "dealtitle": "",
                "dealdiscription": "",
                "merchantname": "",
                "merchantlocation": "",
                "merchantdiscription": "",
                "merchantcity":"",
                "merchantstate":"",
                "merchantcountry":"",
                "merchantpincode":"",
                "dealexpiry": "",
                "dealstatus": "T", ----------> true/false
	 			"dealcode":"BOX8BOGO" -------> mapping to image 

		 * */
		
		
		
		ArrayList<DealResponseBean> customerDealList =  new ArrayList<DealResponseBean>();
		
		DealResponseBean dealResponseBean = new DealResponseBean();
		dealResponseBean.setDealCode("FLASH2004");
		dealResponseBean.setDealCategory("Food");
		dealResponseBean.setDealTitle("Buy One Get One Free");
		dealResponseBean.setDealDiscription("Flash Presents you best pizza deal near by you. Enjoy!!");
		dealResponseBean.setDealExpiry("1234567889988");
		dealResponseBean.setDealStatus("T");
		dealResponseBean.setMerchatName("FLASH DEALS");
		dealResponseBean.setMerchantCity("Mumbai");
		dealResponseBean.setDealImg("http://localhost:8080/FlashDeals/FlashImageServlet?entity=deal&img=Flash42004_Flash42004_1234_2891");
		dealResponseBean.setMerchantDiscription("Flash.Deals");
		dealResponseBean.setStoreLocation("LAT,LONG");
		
		DealResponseBean dealResponseBean1 = new DealResponseBean();
		dealResponseBean1.setDealCode("FLASH2004");
		dealResponseBean1.setDealCategory("Spa");
		dealResponseBean1.setDealTitle("Buy One Get One Free");
		dealResponseBean1.setDealDiscription("Flash Presents you best pizza deal near by you. Enjoy!!");
		dealResponseBean1.setDealExpiry("1234567889988");
		dealResponseBean1.setDealStatus("T");
		dealResponseBean1.setMerchatName("FLASH DEALS");
		dealResponseBean1.setMerchantCity("Mumbai");
		dealResponseBean1.setMerchantDiscription("Flash.Deals");
		dealResponseBean1.setStoreLocation("LAT,LONG");
		dealResponseBean1.setDealImg("http://localhost:8080/FlashDeals/FlashImageServlet?entity=deal&img=Flash42004_Flash42004_1234_2891");
		
		customerDealList.add(dealResponseBean);
		customerDealList.add(dealResponseBean1);
		
		
		return customerDealList;
	}

	
	public String submitMerchantDeal(MerchantDealBean merchantDealBean)
	{
		log.info("Inside DealSyncDao/submitMerchantDeal()");
		
		if(log.isInfoEnabled())
		{
			log.info("Merchant Deal bean : " + merchantDealBean);
		}
		
		try 
		{
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			session.save(merchantDealBean);
			session.flush();
			transaction.commit();

			return ApplicationConstant.SUCCESS;
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
			log.error("Exception in Submit Merchant Deal : " + e.getMessage(), e.getCause());
			return ApplicationConstant.FAILURE;
		} catch (Exception ex) {
			transaction.rollback();
			ex.printStackTrace();
			log.error("Exception in Submit merchant deal : " + ex.getMessage(), ex.getCause());
			return ApplicationConstant.FAILURE;
		}

	}

	
	public List<MerchantDealBean> fetchMerchantDealDetails(MerchantDealBean merchantDealBean) 
	{
		/*
		 * select * from merchant_deal_master
		 * where merchantid = merchantId
		 * 
		 * */
		
		List<MerchantDealBean> merchantDealList = new ArrayList<MerchantDealBean>();
		
		MerchantDealBean merchantDealBean2 = new MerchantDealBean();
		merchantDealBean2.setDealName("20% off on mens merchandise");
		merchantDealBean2.setMerchantId("Flash42004");
		merchantDealBean2.setDealRadius("");
		merchantDealBean2.setMerchantDealId("Flash2004_1234");
		
		MerchantDealBean merchantDealBean3 = new MerchantDealBean();
		merchantDealBean3.setDealName("20% off on mens merchandise");
		merchantDealBean3.setMerchantId("Flash42004");
		merchantDealBean3.setDealRadius("5");
		merchantDealBean3.setMerchantDealId("Flash2004_1234");
		
		merchantDealList.add(merchantDealBean2);
		merchantDealList.add(merchantDealBean3);
		
		return merchantDealList;
	}

	
	public List<MerchantDealBean> getCustomerDeals(HashMap<String, String> customerLocationDataMap) 
	{
		log.info("Inside DealSyncDao/getCustomerDeals()");
		
		/*
		 * 
		 * Select * from flash_deal_mstr
		 * where city = customerlocationMap.get("City")
		 * */
		
		List<String> storeImgList = new ArrayList<String>();
		storeImgList.add("http://localhost:8080/FlashDeals/FlashImageServlet?entity=store&img=Flash42004_3266.jpg");
		storeImgList.add("http://localhost:8080/FlashDeals/FlashImageServlet?entity=store&img=Flash42004_3266.jpg");
		
		MerchantDealBean merchantDealBean = new MerchantDealBean();
		merchantDealBean.setId(1);
		merchantDealBean.setMerchantId("Flash_2004");
		
		merchantDealBean.setDealCategory("Fashion");
		merchantDealBean.setDealName("Flash 20% off in Shoes");
		merchantDealBean.setDealImage("http://localhost:8080/FlashDeals/FlashImageServlet?entity=deal&img=Flash42004_Flash42004_1234_9524.jpg");
		
		
		MerchantDealBean merchantDealBean2 = new MerchantDealBean();
		merchantDealBean2.setId(2);
		merchantDealBean2.setMerchantId("Flash_20012");
		
		merchantDealBean2.setDealCategory("Fashion");
		merchantDealBean2.setDealName("Flash 20% off in Shoes");
		merchantDealBean2.setDealImage("http://localhost:8080/FlashDeals/FlashImageServlet?entity=deal&img=Flash42004_Flash42004_1234_9524.jpg");
		
		List<MerchantDealBean> merchantDealResList = new ArrayList<MerchantDealBean>();
		merchantDealResList.add(merchantDealBean);
		merchantDealResList.add(merchantDealBean2);
		
		return merchantDealResList;
	}


	public boolean isMerchantDealExist(MerchantDealBean merchantDealBean) 
	{
		log.info("Inside DealSyncDao/isMerchantDealExist()");
		
		StringBuilder merchantDealQueryBuilder = new StringBuilder();
		merchantDealQueryBuilder.append("from  MerchantDealBean ");

		StringBuilder mechantDealCheckQuery = getMerchantDealChkQuery(merchantDealQueryBuilder);

		Query query = sessionFactory.openSession().createQuery(mechantDealCheckQuery.toString());
		query.setParameter("merchantDealId", merchantDealBean.getMerchantDealId());
		query.setParameter("merchantId", merchantDealBean.getMerchantId());
		query.setParameter("dealStoreId", merchantDealBean.getDealStoreId());
		

		List<MerchantDealBean> merchantDealList = query.list();

		log.info("Merchant store list : " + merchantDealList);

		if (merchantDealList.size() > 0) 
		{
			return true;
		}

		return false;

	}


	private StringBuilder getMerchantDealChkQuery(StringBuilder merchantDealQueryBuilder) 
	{
		merchantDealQueryBuilder.append("where merchantDealId =:merchantDealId and merchantId =:merchantId ");
		merchantDealQueryBuilder.append("and dealStoreId =:dealStoreId ");
		return merchantDealQueryBuilder;
	}


	public String updateMerchantDeal(MerchantDealBean merchantDealBean) 
	{
		log.info("Inside dealSyncDao/updateMerchantDeal()");
		
		if(log.isInfoEnabled())
		{
			log.info("Merchant Deal Bean is : " + merchantDealBean);
		}
		
		StringBuilder dealUpdateQueryBuilder = null;
		try 
		{
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			
			dealUpdateQueryBuilder = new StringBuilder();
			dealUpdateQueryBuilder.append("update MerchantDealBean ");
			dealUpdateQueryBuilder = merchantDealUpdateBuilder(dealUpdateQueryBuilder);
			
			log.info("Merchant Store update query is : " + dealUpdateQueryBuilder.toString());
			
			
			
			Query query=session.createQuery(dealUpdateQueryBuilder.toString());
			query.setParameter("dealDiscription", merchantDealBean.getDealDiscription());
			query.setParameter("dealStartTime", merchantDealBean.getDealStartTime());
			query.setParameter("dealEndTime", merchantDealBean.getDealEndTime());
			query.setParameter("dealRadius", merchantDealBean.getDealRadius());
			query.setParameter("merchantDealId", merchantDealBean.getMerchantDealId());
			query.setParameter("merchantId", merchantDealBean.getMerchantId());
			query.setParameter("dealStoreId", merchantDealBean.getDealStoreId());
			query.setParameter("deleteFlag", merchantDealBean.getDeleteFlag());
			
			int merchantStoreUpdateStatus = query.executeUpdate();
			
			log.info("Merchant store Update Status : " + merchantStoreUpdateStatus);
			
			session.flush();
			transaction.commit();
			
			return ApplicationConstant.SUCCESS;
		}
		catch (Exception e) 
		{
			log.error("Exception in updating merchant profile : " + e.getMessage(),e.getCause());
			e.printStackTrace();
			
			return ApplicationConstant.FAILURE;
			
		}
		
	}


	private StringBuilder merchantDealUpdateBuilder(StringBuilder dealUpdateQueryBuilder) 
	{
		log.info("Inside fetchStoreUpdateBuilder()");
		
		dealUpdateQueryBuilder.append("set dealDiscription = :dealDiscription,");
		dealUpdateQueryBuilder.append(" dealStartTime = :dealStartTime,");
		dealUpdateQueryBuilder.append(" dealEndTime = :dealEndTime,");
		dealUpdateQueryBuilder.append(" dealRadius = :dealRadius ");
		dealUpdateQueryBuilder.append(" where merchantDealId = :merchantDealId");
		dealUpdateQueryBuilder.append(" and merchantId = :merchantId");
		dealUpdateQueryBuilder.append(" and dealStoreId = :dealStoreId");
		dealUpdateQueryBuilder.append(" and deleteFlag = :deleteFlag ");
		
		
		return dealUpdateQueryBuilder;
		
	}

}
