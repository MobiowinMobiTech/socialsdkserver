package com.mobiowin.flashdeals.helper.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.flashdeals.bean.CategoryBean;
import com.mobiowin.flashdeals.bean.SliderDealBean;
import com.mobiowin.flashdeals.commons.ApplicationConstant;
import com.mobiowin.flashdeals.commons.FlashUtility;
import com.mobiowin.flashdeals.dao.IAppSyncHelperDao;

@Service("appSyncService")
@Component
public class AppSyncHelperServie implements IAppSyncHelperServie
{
	private Log log = LogFactory.getLog(this.getClass());
	
	@Autowired
	private IAppSyncHelperDao appSyncDao;
	
	@Autowired
	private @Resource
	Map<String, String> FlashDeals;
	
	public String syncApplciationData()
	{
		log.info("Inside AppSyncHelperServie/AppSyncHelperServie()");
		
		/*
		 * Slider Image Data
		 * Category image & data
		 * Exclusive deal/Notification data for popup
		 * */
		
		HashMap<String,Object> dataMap = null;
		List<SliderDealBean> sliderImageDataList = appSyncDao.fetchSliderImageData();
		List<CategoryBean> categoryDataList = appSyncDao.fetchCategoryData();
		
		if(log.isInfoEnabled())
		{
			log.info("Slider Image Data List Size is : " + sliderImageDataList.size());
			log.info("Category Data List Size is : " + categoryDataList.size());
		} 
		
		
		dataMap = new HashMap<String,Object>();
		dataMap.put(ApplicationConstant.APP_SLIDER_LIST,sliderImageDataList);
		dataMap.put(ApplicationConstant.APP_CATEGORY_LIST,categoryDataList);
		
		return FlashUtility.createJSONFromMap(FlashUtility.createSuccessResponseMessage(dataMap));
	}

	public boolean checkAppversion(HashMap<String, String> appReqDataMap)
	{
		log.info("AppSyncHelperServie/checkAppversion()");
		
		String appVersion = (String) FlashDeals.get("version");
		
		log.info("App version is : " + appVersion);
		
		boolean isValidVersion = false;
		
		if(appVersion.endsWith(appReqDataMap.get(ApplicationConstant.APP_VERSION)))
		{
			isValidVersion = true;
		}
		
		return isValidVersion;
	}

	public String generateSuccessResponse()
	{
		HashMap<String, Object> appVersioResMap = null;
		appVersioResMap = new HashMap<String,Object>();
		String response = FlashUtility.createJSONFromMap(FlashUtility.createSuccessResponseMessage(appVersioResMap));
		return response;
	}

	public String generateErrorResponse()
	{
		HashMap<String, Object> appVersioResMap = null;
		appVersioResMap = new HashMap<String,Object>();
		appVersioResMap.put(ApplicationConstant.APP_VERSION, "Playstore Link to update app");
		String response = FlashUtility.createJSONFromMap(FlashUtility.createSuccessResponseMessage(appVersioResMap));
		return response;
		
	}
	

}
