package com.mobiowin.flashdeals.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "merchant_master", catalog = "flashdeals")
public class MerchantRegistrationBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;

	@Column(name = "mobile_no")
	private String mobileNo;
	@Column(name = "imei_no")
	private String imeiNo;
	@Column(name = "email_id")
	private String emailId;
	@Column(name = "password")
	private String password;
	@Column(name = "merchant_id")
	private String merchantId;
	@Column(name = "reg_otp")
	private String otp;
	@Column(name = "created_by")
	private String createdBy;
	@Column(name = "created_dt")
	private Date createDt;
	@Column(name = "modified_by")
	private String modifiedBy;
	@Column(name = "modified_dt")
	private Date modifyDt;
	@Column(name = "del_flag")
	private String deleteFlag;

	public MerchantRegistrationBean(int id, String mobileNo, String imeiNo, String emailId, String password,
			String merchantId, String otp, String createdBy, Date createDt, String modifiedBy, Date modifyDt,
			String deleteFlag) {
		super();
		this.id = id;
		this.mobileNo = mobileNo;
		this.imeiNo = imeiNo;
		this.emailId = emailId;
		this.password = password;
		this.merchantId = merchantId;
		this.otp = otp;
		this.createdBy = createdBy;
		this.createDt = createDt;
		this.modifiedBy = modifiedBy;
		this.modifyDt = modifyDt;
		this.deleteFlag = deleteFlag;
	}

	public MerchantRegistrationBean() {
		super();
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Date createDt) {
		this.createDt = createDt;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifyDt() {
		return modifyDt;
	}

	public void setModifyDt(Date modifyDt) {
		this.modifyDt = modifyDt;
	}

	public String getDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getImeiNo() {
		return imeiNo;
	}

	public void setImeiNo(String imeiNo) {
		this.imeiNo = imeiNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getOtp() {
		return otp;
	}

	public void setOtp(String otp) {
		this.otp = otp;
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	@Override
	public String toString() {
		return "MerchantRegistrationBean [id=" + id + ", mobileNo=" + mobileNo + ", imeiNo=" + imeiNo + ", emailId="
				+ emailId + ", password=" + password + ", merchantId=" + merchantId + ", otp=" + otp + "]";
	}

}
