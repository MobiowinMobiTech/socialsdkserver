package com.mobiowin.flashdeals.bean;

import java.io.Serializable;
import java.util.Date;

public class SliderDealBean implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private int id;
	private String dealName;
	private String dealCode;
	private String dealDiscription;
	private String dealImagePath;
	private String createdBy;
	private Date createdDt;
	private String modifiedBy;
	private Date modifiedDt;
	private String del_flag;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDealName() {
		return dealName;
	}
	public void setDealName(String dealName) {
		this.dealName = dealName;
	}
	public String getDealDiscription() {
		return dealDiscription;
	}
	public void setDealDiscription(String dealDiscription) {
		this.dealDiscription = dealDiscription;
	}
	public String getDealImagePath() {
		return dealImagePath;
	}
	public void setDealImagePath(String dealImagePath) {
		this.dealImagePath = dealImagePath;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public Date getCreatedDt() {
		return createdDt;
	}
	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}
	public String getModifiedBy() {
		return modifiedBy;
	}
	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}
	public Date getModifiedDt() {
		return modifiedDt;
	}
	public void setModifiedDt(Date modifiedDt) {
		this.modifiedDt = modifiedDt;
	}
	public String getDel_flag() {
		return del_flag;
	}
	public void setDel_flag(String del_flag) {
		this.del_flag = del_flag;
	}
	
	
	public String getDealCode() {
		return dealCode;
	}
	public void setDealCode(String dealCode) {
		this.dealCode = dealCode;
	}
	@Override
	public String toString() {
		return "SliderDealBean [id=" + id + ", dealName=" + dealName
				+ ", dealCode=" + dealCode + ", dealDiscription="
				+ dealDiscription + ", dealImagePath=" + dealImagePath
				+ ", createdBy=" + createdBy + ", createdDt=" + createdDt
				+ ", modifiedBy=" + modifiedBy + ", modifiedDt=" + modifiedDt
				+ ", del_flag=" + del_flag + "]";
	}
	
	
	
	
	
}
