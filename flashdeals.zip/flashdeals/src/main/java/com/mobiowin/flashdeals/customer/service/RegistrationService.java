package com.mobiowin.flashdeals.customer.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.flashdeals.commons.ApplicationConstant;
import com.mobiowin.flashdeals.helper.service.IRegistrationHelperService;
import com.mobiowin.flashdeals.messaging.IFlashService;

@Service("customerRegService")
@Component
public class RegistrationService implements IFlashService {
	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private IRegistrationHelperService registrationHelperService;
	
	
	public Message<String> execute(Message<String> message) {
		log.info("Inside RegistrationService/execute()");

		String jsonData = message.getPayload();

		Map<String, Object> messageHeaders = message.getHeaders();

		JSONObject customerDataJson = null;
		JSONObject customerRegDataJson = null;
		String mobileNo = null;
		String imeiNo = null;
		String emailId = null;

		try {
			customerDataJson = new JSONObject(jsonData);
			customerRegDataJson = customerDataJson.getJSONObject(ApplicationConstant.DATA);

			if (customerRegDataJson.has(ApplicationConstant.MOBILE_NO))
		    {
				mobileNo = customerRegDataJson
						.getString(ApplicationConstant.MOBILE_NO);
			}

			if (customerRegDataJson.has(ApplicationConstant.IMEI_NO))
			{
				imeiNo = customerRegDataJson
						.getString(ApplicationConstant.IMEI_NO);
			}
			if (customerRegDataJson.has(ApplicationConstant.EMAIL_ID))
			{
				emailId = customerRegDataJson
						.getString(ApplicationConstant.EMAIL_ID);
			}
			
			if(log.isInfoEnabled())
			{
				log.info("customerDataJson : " + customerDataJson);
				log.info("Message Headers : " + messageHeaders);
				log.info("Customer mobile no is : " + mobileNo);
				log.info("Customer imei no is : " + imeiNo);
				log.info("Customer email id : " + emailId);
			}
			
			HashMap<String,String> dataMap = getDataMap(mobileNo,imeiNo,emailId);
			
			String registerResponse = registrationHelperService.registerCustomer(dataMap);
			
			return MessageBuilder.withPayload(registerResponse).build();

		} catch (Exception ex)
		{
			log.error("Exception in RegistrationService/execute() " + ex.getMessage(),ex.getCause());

		}

		return null;
	}

	private HashMap<String, String> getDataMap(String mobileNo, String imeiNo, String emailId)
	{
		HashMap<String,String> dataMap = new HashMap<String, String>();
		dataMap.put(ApplicationConstant.MOBILE_NO, mobileNo);
		dataMap.put(ApplicationConstant.IMEI_NO, imeiNo);
		dataMap.put(ApplicationConstant.EMAIL_ID, emailId);
		return dataMap;
	}

}
