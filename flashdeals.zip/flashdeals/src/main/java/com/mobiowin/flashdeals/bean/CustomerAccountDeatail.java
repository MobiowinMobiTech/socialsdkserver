/**
 * 
 */
package com.mobiowin.flashdeals.bean;

import java.util.List;




public class CustomerAccountDeatail {
	
	/*private String customerId;
	private String name;*/
	private List<AccountDetails> accountDetailList;
	
	
	/*public String getCustomerId()
	{
		return customerId;
	}
	public void setCustomerId(String customerId)
	{
		this.customerId = customerId;
	}*/
	
	
	/*public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}*/
	public List<AccountDetails> getAccountDetailList()
	{
		return accountDetailList;
	}
	public void setAccountDetailList(List<AccountDetails> accountDetailList)
	{
		this.accountDetailList = accountDetailList;
	}
	
	
	
	
	

}
