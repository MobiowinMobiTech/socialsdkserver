package com.mobiowin.flashdeals.customer.service;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.flashdeals.commons.ApplicationConstant;
import com.mobiowin.flashdeals.helper.service.IOtpValidatiorService;
import com.mobiowin.flashdeals.messaging.IFlashService;

@Service("customerOtpService")
@Component
public class OTPService implements IFlashService{

	private Log log = LogFactory.getLog(this.getClass());
	
	@Autowired
	private IOtpValidatiorService otpValidateService;
	
	
	public Message<String> execute(Message<String> message) 
	{
		log.info("Inside OTPService/execute()");

		String jsonData = message.getPayload();

		Map<String, Object> messageHeaders = message.getHeaders();

		JSONObject customerDataJson = null;
		JSONObject customerOtpDataJson = null;
		String custOtp = null;
		String imeiNo = null;
		
		try {
			customerDataJson = new JSONObject(jsonData);
			customerOtpDataJson = customerDataJson.getJSONObject(ApplicationConstant.DATA);

			if (customerOtpDataJson.has(ApplicationConstant.FLASH_CUST_OTP))
		    {
				custOtp = customerOtpDataJson
						.getString(ApplicationConstant.FLASH_CUST_OTP);
			}
			
			if (customerOtpDataJson.has(ApplicationConstant.IMEI_NO))
		    {
				imeiNo = customerOtpDataJson
						.getString(ApplicationConstant.IMEI_NO);
			}

			if(log.isInfoEnabled())
			{
				log.info("customerDataJson : " + customerDataJson);
				log.info("Message Headers : " + messageHeaders);
				log.info("Customer mobile no is : " + custOtp);
				log.info("Imei No is : " + imeiNo);
			}
			
			HashMap<String,String> dataMap = getDataMap(custOtp,imeiNo);
			
			String otpValidationResponse = otpValidateService.validateCustomerOtp(dataMap);
			
			return MessageBuilder.withPayload(otpValidationResponse).build();

		} catch (Exception ex)
		{
			log.error("Exception in RegistrationService/execute() " + ex.getMessage(),ex.getCause());

		}
		return null;
	}
	
	private HashMap<String, String> getDataMap(String custOtp,String imeiNo)
	{
		HashMap<String,String> dataMap = new HashMap<String, String>();
		dataMap.put(ApplicationConstant.FLASH_CUST_OTP, custOtp);
		dataMap.put(ApplicationConstant.IMEI_NO, imeiNo);
		return dataMap;
	}

}
