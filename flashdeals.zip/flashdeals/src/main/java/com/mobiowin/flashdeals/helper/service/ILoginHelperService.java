package com.mobiowin.flashdeals.helper.service;

import java.util.HashMap;

public interface ILoginHelperService {

	boolean validateLogin(HashMap<String, String> merchantDataMap);

	String generateSuccessResponse(HashMap<String, String> merchantDataMap);

	String generateErrorResponse();

	boolean validateMerchant(HashMap<String, String> merchantDataMap);

	String generateOtpSuccessResponse(HashMap<String, String> merchantDataMap);

}
