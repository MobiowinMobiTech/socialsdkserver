package com.mobiowin.flashdeals.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "store_master", catalog = "flashdeals")
public class MerchantStoreBean implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	
	@Column(name = "merchant_id")
	private String merchantId;
	
	@Column(name = "store_id")
	private String storeId;
	
	@Column(name = "store_name")
	private String storeName;
	
	@Column(name = "store_category")
	private String storeCategory;
	
	@Column(name = "store_discription")
	private String storeDiscription;
	
	@Column(name = "pincode")
	private String pinCode;
	
	@Column(name = "city")
	private String city;
	
	@Column(name = "state")
	private String state;
	
	@Column(name = "country")
	private String country;
	
	@Column(name = "latitude")
	private String latitude;
	
	@Column(name = "longitude")
	private String longitude;
	
	@Column(name = "img_1")
	private String storeImage1;
	
	@Column(name = "img_2")
	private String storeImage2;
	
	@Column(name = "img_3")
	private String storeImage3;
	
	@Column(name = "img_4")
	private String storeImage4;
	
	@Column(name = "created_by")
	private String createdBy;
	
	@Column(name = "created_dt")
	private Date createDt;
	
	@Column(name = "modified_by")
	private String modifiedBy;
	
	@Column(name = "modified_dt")
	private Date modifyDt;
	
	@Column(name = "del_flag")
	private String deleteFlag;

	public MerchantStoreBean(int id, String merchantId, String storeId, String storeName, String storeCategory,
			String storeDiscription, String pinCode, String city, String state, String country, String latitude,
			String longitude, String storeImage1, String storeImage2, String storeImage3,
			String storeImage4, String createdBy, Date createDt, String modifiedBy, Date modifyDt, String deleteFlag) {
		super();
		this.id = id;
		this.merchantId = merchantId;
		this.storeId = storeId;
		this.storeName = storeName;
		this.storeCategory = storeCategory;
		this.storeDiscription = storeDiscription;
		this.pinCode = pinCode;
		this.city = city;
		this.state = state;
		this.country = country;
		this.latitude = latitude;
		this.longitude = longitude;
		
		this.storeImage1 = storeImage1;
		this.storeImage2 = storeImage2;
		this.storeImage3 = storeImage3;
		this.storeImage4 = storeImage4;
		this.createdBy = createdBy;
		this.createDt = createDt;
		this.modifiedBy = modifiedBy;
		this.modifyDt = modifyDt;
		this.deleteFlag = deleteFlag;
	}

	public MerchantStoreBean() {
		super();
	}

	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public String getStoreId() {
		return storeId;
	}

	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}

	public String getStoreName() {
		return storeName;
	}

	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}

	public String getStoreCategory() {
		return storeCategory;
	}

	public void setStoreCategory(String storeCategory) {
		this.storeCategory = storeCategory;
	}

	public String getStoreDiscription() {
		return storeDiscription;
	}

	public void setStoreDiscription(String storeDiscription) {
		this.storeDiscription = storeDiscription;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	
	public String getStoreImage1() {
		return storeImage1;
	}

	public void setStoreImage1(String storeImage1) {
		this.storeImage1 = storeImage1;
	}

	public String getStoreImage2() {
		return storeImage2;
	}

	public void setStoreImage2(String storeImage2) {
		this.storeImage2 = storeImage2;
	}

	public String getStoreImage3() {
		return storeImage3;
	}

	public void setStoreImage3(String storeImage3) {
		this.storeImage3 = storeImage3;
	}

	public String getStoreImage4() {
		return storeImage4;
	}

	public void setStoreImage4(String storeImage4) {
		this.storeImage4 = storeImage4;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Date createDt) {
		this.createDt = createDt;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifyDt() {
		return modifyDt;
	}

	public void setModifyDt(Date modifyDt) {
		this.modifyDt = modifyDt;
	}

	public String getDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}

	@Override
	public String toString() {
		return "MerchantStoreBean [id=" + id + ", merchantId=" + merchantId + ", storeId=" + storeId + ", storeName="
				+ storeName + ", storeCategory=" + storeCategory + ", storeDiscription=" + storeDiscription
				+ ", pinCode=" + pinCode + ", city=" + city + ", state=" + state + ", country=" + country
				+ ", latitude=" + latitude + ", longitude=" + longitude + ", storeImage1="
				+ storeImage1 + ", storeImage2=" + storeImage2 + ", storeImage3=" + storeImage3 + ", storeImage4="
				+ storeImage4 + ", createdBy=" + createdBy + ", createDt=" + createDt + ", modifiedBy=" + modifiedBy
				+ ", modifyDt=" + modifyDt + ", deleteFlag=" + deleteFlag + "]";
	}

	
	
	
	
	
	
}
