package com.mobiowin.jwt.message;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.impl.crypto.MacProvider;

import java.security.Key;

public class MeesageTokenTest {

	
	public static void main(String[] args) {
		
		String messageToken = getJwtMessageToken();
		System.out.println("Message Token is : " + messageToken);
	}

	private static String getJwtMessageToken()
	{
		Key key = MacProvider.generateKey();

		String compactJws = Jwts.builder()
		  .setSubject("Joe")
		  .signWith(SignatureAlgorithm.HS512, key)
		  .compact();
		return compactJws;
	}
}
