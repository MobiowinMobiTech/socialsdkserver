/**
 * SoapExampleService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.mobiowin.soap.test;

public interface SoapExampleService extends javax.xml.rpc.Service {
    public java.lang.String getSoapExampleAddress();

    public com.mobiowin.soap.test.SoapExample getSoapExample() throws javax.xml.rpc.ServiceException;

    public com.mobiowin.soap.test.SoapExample getSoapExample(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
