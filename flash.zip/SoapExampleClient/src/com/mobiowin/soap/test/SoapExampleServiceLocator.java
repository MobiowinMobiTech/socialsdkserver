/**
 * SoapExampleServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.mobiowin.soap.test;

public class SoapExampleServiceLocator extends org.apache.axis.client.Service implements com.mobiowin.soap.test.SoapExampleService {

    public SoapExampleServiceLocator() {
    }


    public SoapExampleServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public SoapExampleServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for SoapExample
    private java.lang.String SoapExample_address = "http://localhost:8080/SoapExample/services/SoapExample";

    public java.lang.String getSoapExampleAddress() {
        return SoapExample_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String SoapExampleWSDDServiceName = "SoapExample";

    public java.lang.String getSoapExampleWSDDServiceName() {
        return SoapExampleWSDDServiceName;
    }

    public void setSoapExampleWSDDServiceName(java.lang.String name) {
        SoapExampleWSDDServiceName = name;
    }

    public com.mobiowin.soap.test.SoapExample getSoapExample() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(SoapExample_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getSoapExample(endpoint);
    }

    public com.mobiowin.soap.test.SoapExample getSoapExample(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            com.mobiowin.soap.test.SoapExampleSoapBindingStub _stub = new com.mobiowin.soap.test.SoapExampleSoapBindingStub(portAddress, this);
            _stub.setPortName(getSoapExampleWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setSoapExampleEndpointAddress(java.lang.String address) {
        SoapExample_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (com.mobiowin.soap.test.SoapExample.class.isAssignableFrom(serviceEndpointInterface)) {
                com.mobiowin.soap.test.SoapExampleSoapBindingStub _stub = new com.mobiowin.soap.test.SoapExampleSoapBindingStub(new java.net.URL(SoapExample_address), this);
                _stub.setPortName(getSoapExampleWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("SoapExample".equals(inputPortName)) {
            return getSoapExample();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://test.soap.mobiowin.com", "SoapExampleService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://test.soap.mobiowin.com", "SoapExample"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("SoapExample".equals(portName)) {
            setSoapExampleEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
