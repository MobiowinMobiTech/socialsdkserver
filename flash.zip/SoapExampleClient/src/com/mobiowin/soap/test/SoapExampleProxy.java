package com.mobiowin.soap.test;

public class SoapExampleProxy implements com.mobiowin.soap.test.SoapExample {
  private String _endpoint = null;
  private com.mobiowin.soap.test.SoapExample soapExample = null;
  
  public SoapExampleProxy() {
    _initSoapExampleProxy();
  }
  
  public SoapExampleProxy(String endpoint) {
    _endpoint = endpoint;
    _initSoapExampleProxy();
  }
  
  private void _initSoapExampleProxy() {
    try {
      soapExample = (new com.mobiowin.soap.test.SoapExampleServiceLocator()).getSoapExample();
      if (soapExample != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)soapExample)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)soapExample)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (soapExample != null)
      ((javax.xml.rpc.Stub)soapExample)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public com.mobiowin.soap.test.SoapExample getSoapExample() {
    if (soapExample == null)
      _initSoapExampleProxy();
    return soapExample;
  }
  
  public java.lang.String sayHelloWorld(java.lang.String in0) throws java.rmi.RemoteException{
    if (soapExample == null)
      _initSoapExampleProxy();
    return soapExample.sayHelloWorld(in0);
  }
  
  
}