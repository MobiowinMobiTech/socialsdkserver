package com.mobicule.icatalog.test.concept.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.mobicule.icatalog.concept.dao.ConceptDao;

@ContextConfiguration(locations = { "file:/home/shalini/workspace/icatalog-core/config/spring/spring-config.xml" })
@Test(groups = { "init" })
public class ConceptDaoTest extends AbstractTestNGSpringContextTests
{
	@Autowired
	private ConceptDao conceptDao;

	@BeforeClass
	protected void setUp()
	{
		System.out.println("in set up" + conceptDao);
		Assert.assertNotNull(conceptDao);
	}

	@Test(enabled = true)
	public void testNativeSQL()
	{
		String result = conceptDao.getNewlyAddedEntities(0, 100, null);

		System.out.println("result : " + result);
	}
}
