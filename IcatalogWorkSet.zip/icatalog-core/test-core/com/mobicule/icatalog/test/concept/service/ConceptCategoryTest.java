package com.mobicule.icatalog.test.concept.service;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.mobicule.icatalog.concept.bean.ConceptCategory;
import com.mobicule.icatalog.concept.service.ConceptCategoryService;

@ContextConfiguration(locations = { "file:/home/shalini/workspace/icatalog-core/config/spring/spring-config.xml" })
@Test(groups = { "init" })
public class ConceptCategoryTest extends AbstractTestNGSpringContextTests
{
	@Autowired
	private ConceptCategoryService categoryService;
	
	@BeforeClass
	protected void setUp()
	{
		Assert.assertNotNull(categoryService);
	}

	@Test(enabled=false)
	public void testAdd()
	{
		System.out.println("Concept category  add  "+categoryService);
		
		ConceptCategory conceptcategory = new ConceptCategory();
	
		conceptcategory.setCode("C02");
		conceptcategory.setName("Test2");
		conceptcategory.setDescription("Test2");
		conceptcategory.setCreatedBy(225L);
		conceptcategory.setModifiedBy(225L);
	//	conceptcategory.setModifiedOn(new Timestamp(System.currentTimeMillis()));
		//conceptcategory.setDeleteFlag("F");
		//conceptcategory.setCreatedOn("22/03/2012");*/
		boolean result=categoryService.add(conceptcategory);
		
		System.out.println("Result: "+ result);
	}
	@Test(enabled=false)
	public void testUpdate()
	{
		System.out.println("Concept category  update  "+categoryService);
		
		ConceptCategory conceptcategory = new ConceptCategory();
		conceptcategory.setId(1L);
		conceptcategory.setCode("C01");
		conceptcategory.setName("Test2");
		conceptcategory.setDescription("Test2");
		conceptcategory.setCreatedBy(255L);
		conceptcategory.setModifiedBy(5L);
		conceptcategory.setModifiedOn(new Timestamp(System.currentTimeMillis()));
		conceptcategory.setDeleteFlag("F");
		//conceptcategory.setCreatedOn("22/03/2012");
		boolean result=categoryService.update(conceptcategory);
		
		System.out.println("Result: "+ result);
	}
	
	@Test(enabled=false)
	public void testDelete()
	{
		System.out.println("Concept category  delete  "+categoryService);
		
		ConceptCategory conceptcategory = new ConceptCategory();
		conceptcategory.setId(1L);
		conceptcategory.setCode("C01");
		conceptcategory.setName("Test2");
		conceptcategory.setDescription("Test2");
		conceptcategory.setCreatedBy(225L);
		conceptcategory.setModifiedBy(5L);
		/*conceptcategory.setModifiedOn(new Timestamp(System.currentTimeMillis()));
		conceptcategory.setDeleteFlag("T");
		//conceptcategory.setCreatedOn("22/03/2012");*/
		boolean result=categoryService.delete(conceptcategory);
		
		System.out.println("Result: "+ result);
		
		
	}
	
	@Test(enabled=true)
	public void testSearch()
	{
		System.out.println("Concept category  search  "+categoryService);
		
		
		List<ConceptCategory> categoryList =categoryService.searchName("1");
		
		System.out.println("Result of search : "+ categoryList.size());
		
		
	}
	
	
}
