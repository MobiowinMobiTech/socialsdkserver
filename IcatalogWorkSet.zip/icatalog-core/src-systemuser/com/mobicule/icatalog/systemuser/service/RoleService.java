package com.mobicule.icatalog.systemuser.service;

import com.mobicule.icatalog.entity.service.EntityService;
import com.mobicule.icatalog.systemuser.bean.Role;
import com.mobicule.icatalog.systemuser.dao.RoleDao;

public interface RoleService extends EntityService<Role, RoleDao>
{

}
