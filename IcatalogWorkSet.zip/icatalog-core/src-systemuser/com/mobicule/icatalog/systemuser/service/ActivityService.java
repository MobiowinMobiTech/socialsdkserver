package com.mobicule.icatalog.systemuser.service;

import java.util.List;

import com.mobicule.icatalog.entity.service.EntityService;
import com.mobicule.icatalog.systemuser.bean.Activity;
import com.mobicule.icatalog.systemuser.dao.ActivityDao;

public interface ActivityService extends EntityService<Activity, ActivityDao>
{
	public List<Activity> doActivitySearch(String activityCode);

}
