package com.mobicule.icatalog.systemuser.service;

import java.util.List;

import com.mobicule.icatalog.entity.service.EntityService;
import com.mobicule.icatalog.systemuser.bean.Profile;
import com.mobicule.icatalog.systemuser.dao.ProfileDao;

public interface ProfileService extends EntityService<Profile, ProfileDao>
{
	public List<Profile> doCustomSearch(Profile profile);
	
}
