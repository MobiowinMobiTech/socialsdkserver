/**
******************************************************************************
* C O P Y R I G H T  A N D  C O N F I D E N T I A L I T Y  N O T I C E
* <p>
* Copyright © 2008-2009 Mobicule Technologies Pvt. Ltd. All rights reserved. 
* This is proprietary information of Mobicule Technologies Pvt. Ltd.and is 
* subject to applicable licensing agreements. Unauthorized reproduction, 
* transmission or distribution of this file and its contents is a 
* violation of applicable laws.
******************************************************************************
*
* @project icatalog-core
*/
package com.mobicule.icatalog.systemuser.service;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.mobicule.icatalog.entity.service.EntityServiceImpl;
import com.mobicule.icatalog.systemuser.bean.ProfileActivityMapping;
import com.mobicule.icatalog.systemuser.dao.ProfileActivityDao;

/**
* 
* <enter description here>
*
* @author shalini <Nair>
* @see 
*
* @createdOn 27-Apr-2012
* @modifiedOn
*
* @copyright © 2008-2009 Mobicule Technologies Pvt. Ltd. All rights reserved.
*/
public class ProfileActivityServiceImpl extends EntityServiceImpl<ProfileActivityMapping, ProfileActivityDao> implements ProfileActivityService
{
	private Log log = LogFactory.getLog(this.getClass());
	private ProfileActivityDao profileActivityDao;
	
	public ProfileActivityDao getProfileActivityDao() {
		return profileActivityDao;
	}

	public void setProfileActivityDao(ProfileActivityDao profileActivityDao) {
		this.profileActivityDao = profileActivityDao;
	}

	@Override
	public List<ProfileActivityMapping> doProfileActivityMappingSearch(String profileCode)
	{

		return getGenericDataBeanDAO().doProfileActivityMappingSearch(profileCode);
	}
}
