package com.mobicule.icatalog.systemuser.service;

import java.util.List;

import com.mobicule.icatalog.entity.service.EntityService;
import com.mobicule.icatalog.systemuser.bean.SystemUser;
import com.mobicule.icatalog.systemuser.bean.Territory;
import com.mobicule.icatalog.systemuser.dao.TerritoryDao;;

public interface TerritoryService extends EntityService<Territory, TerritoryDao>
{
	public List<Territory> doCustomSearch(Territory territory);
	public List<Territory> doTerritorySearch(SystemUser systemUser);
	public Long retrieveRecord(String code);
}
