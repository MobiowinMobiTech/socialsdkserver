package com.mobicule.icatalog.systemuser.service;

import java.util.List;

import com.mobicule.icatalog.entity.service.EntityService;
import com.mobicule.icatalog.systemuser.bean.SystemUser;
import com.mobicule.icatalog.systemuser.dao.SystemUserDao;

public interface SystemUserService extends EntityService<SystemUser, SystemUserDao>
{
	public List<SystemUser> doCustomSearch(SystemUser systemUser);
	public List<SystemUser> activeUserSearch(SystemUser systemUser);
	public List<SystemUser> checkUniqueUserName(String login);
	public List<SystemUser> authenticateUser(SystemUser user);
	public List<SystemUser> doUserSearch(SystemUser systemUser);
	
	public String validateLogin(String loginId,String password);
	
	public List<SystemUser>  authorizeUser(String loginId,String password);
	
	public String chkSyncForUser(String entity);
}
