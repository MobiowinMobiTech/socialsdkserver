package com.mobicule.icatalog.systemuser.service;

import java.util.List;

import com.mobicule.icatalog.entity.service.EntityServiceImpl;
import com.mobicule.icatalog.systemuser.bean.UserTerritoryMapping;
import com.mobicule.icatalog.systemuser.dao.UserTerritoryMappingDao;

public class UserTerritoryMappingServiceImpl extends EntityServiceImpl<UserTerritoryMapping, UserTerritoryMappingDao> implements UserTerritoryMappingService
{

	@Override
	public List<UserTerritoryMapping> doCustomSearch(UserTerritoryMapping userTerritoryMapping)
	{
	
		return getGenericDataBeanDAO().doCustomSearch(userTerritoryMapping);
	}
	
	@Override
	public List<UserTerritoryMapping> doUserTerritorySearch(Long userId)
	{
	
		
		return getGenericDataBeanDAO().doUserTerritorySearch(userId);
	}
	public void addMap(UserTerritoryMapping UserTerritoryMap)
	{
		getGenericDataBeanDAO().add(UserTerritoryMap);
	}
}
