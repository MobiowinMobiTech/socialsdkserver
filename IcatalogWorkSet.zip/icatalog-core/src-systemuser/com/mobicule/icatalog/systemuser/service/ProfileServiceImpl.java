package com.mobicule.icatalog.systemuser.service;

import java.util.List;

import com.mobicule.icatalog.entity.service.EntityServiceImpl;
import com.mobicule.icatalog.systemuser.bean.Profile;
import com.mobicule.icatalog.systemuser.dao.ProfileDao;

public class ProfileServiceImpl extends EntityServiceImpl<Profile, ProfileDao> implements ProfileService
{
	@Override
	public List<Profile> doCustomSearch(Profile profile)
	{
	
		return getGenericDataBeanDAO().doCustomSearch(profile);
	}
	
}
