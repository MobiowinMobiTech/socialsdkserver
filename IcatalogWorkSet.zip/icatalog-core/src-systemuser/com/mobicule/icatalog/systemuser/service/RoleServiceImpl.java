package com.mobicule.icatalog.systemuser.service;

import com.mobicule.icatalog.entity.service.EntityServiceImpl;
import com.mobicule.icatalog.systemuser.bean.Role;
import com.mobicule.icatalog.systemuser.dao.RoleDao;

public class RoleServiceImpl extends EntityServiceImpl<Role, RoleDao> implements RoleService
{

}
