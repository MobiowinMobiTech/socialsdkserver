package com.mobicule.icatalog.systemuser.service;

import java.util.List;

import com.mobicule.icatalog.entity.service.EntityService;
import com.mobicule.icatalog.systemuser.bean.UserTerritoryMapping;
import com.mobicule.icatalog.systemuser.dao.UserTerritoryMappingDao;

public interface UserTerritoryMappingService extends EntityService<UserTerritoryMapping, UserTerritoryMappingDao>
{
	public List<UserTerritoryMapping> doCustomSearch(UserTerritoryMapping userTerritoryMapping);
	public List<UserTerritoryMapping> doUserTerritorySearch(Long userId);
}
