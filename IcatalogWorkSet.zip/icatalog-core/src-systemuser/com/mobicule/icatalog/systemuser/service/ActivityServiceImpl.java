package com.mobicule.icatalog.systemuser.service;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.mobicule.icatalog.entity.service.EntityServiceImpl;
import com.mobicule.icatalog.systemuser.bean.Activity;
import com.mobicule.icatalog.systemuser.dao.ActivityDao;

public class ActivityServiceImpl extends EntityServiceImpl<Activity,ActivityDao> implements ActivityService
{
	private Log log = LogFactory.getLog(this.getClass());
	private ActivityDao activityDao;
	
	public ActivityDao getActivityDao() {
		return activityDao;
	}

	public void setActivityDao(ActivityDao activityDao) {
		this.activityDao = activityDao;
	}

	@Override
	public List<Activity> doActivitySearch(String activityCode)
	{

		return getGenericDataBeanDAO().doActivitySearch(activityCode);
	}
}
