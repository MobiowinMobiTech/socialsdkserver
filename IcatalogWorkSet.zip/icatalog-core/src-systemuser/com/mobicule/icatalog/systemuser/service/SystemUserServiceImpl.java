package com.mobicule.icatalog.systemuser.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.mobicule.icatalog.appconfig.dao.AppConfigDao;
import com.mobicule.icatalog.core.constants.IcatalogUtility;
import com.mobicule.icatalog.entity.service.EntityServiceImpl;
import com.mobicule.icatalog.systemuser.bean.Profile;
import com.mobicule.icatalog.systemuser.bean.ProfileActivityMapping;
import com.mobicule.icatalog.systemuser.bean.SystemUser;
import com.mobicule.icatalog.systemuser.bean.UserTerritoryMapping;
import com.mobicule.icatalog.systemuser.dao.ProfileActivityDao;
import com.mobicule.icatalog.systemuser.dao.ProfileDao;
import com.mobicule.icatalog.systemuser.dao.SystemUserDao;
import com.mobicule.icatalog.systemuser.dao.UserTerritoryMappingDao;

public class SystemUserServiceImpl extends EntityServiceImpl<SystemUser, SystemUserDao> implements SystemUserService
{
	private Log log = LogFactory.getLog(this.getClass());

	private AppConfigDao appConfigDao;

	private UserTerritoryMappingDao userTerrDao;

	private ProfileDao profileDao;

	private ProfileActivityDao profileActivityDao;

	public AppConfigDao getAppConfigDao()
	{
		return appConfigDao;
	}

	public void setAppConfigDao(AppConfigDao appConfigDao)
	{
		this.appConfigDao = appConfigDao;
	}

	public ProfileActivityDao getProfileActivityDao()
	{
		return profileActivityDao;
	}

	public void setProfileActivityDao(ProfileActivityDao profileActivityDao)
	{
		this.profileActivityDao = profileActivityDao;
	}

	public UserTerritoryMappingDao getUserTerrDao()
	{
		return userTerrDao;
	}

	public void setUserTerrDao(UserTerritoryMappingDao userTerrDao)
	{
		this.userTerrDao = userTerrDao;
	}

	public ProfileDao getProfileDao()
	{
		return profileDao;
	}

	public void setProfileDao(ProfileDao profileDao)
	{
		this.profileDao = profileDao;
	}

	@Override
	public boolean add(SystemUser entity)
	{
		if (entity == null)
		{
			return false;
		}

		try
		{
			boolean status = super.add(entity);

			return status;
		}
		catch (Exception e)
		{
			log.error("", e);
			return false;
		}
	}

	@Override
	public List<SystemUser> doCustomSearch(SystemUser systemUser)
	{

		return getGenericDataBeanDAO().doCustomSearch(systemUser);
	}

	@Override
	public List<SystemUser> doUserSearch(SystemUser systemUser)
	{

		return getGenericDataBeanDAO().doUserSearch(systemUser);
	}

	@Override
	public List<SystemUser> activeUserSearch(SystemUser systemUser)
	{

		return getGenericDataBeanDAO().activeUserSearch(systemUser);
	}

	@Override
	public List<SystemUser> checkUniqueUserName(String login)
	{

		SystemUser user = new SystemUser();
		List<SystemUser> userBeanList = new ArrayList<SystemUser>();

		user.setLogin(login);

		log.info("Search bean is :" + user);

		userBeanList = getGenericDataBeanDAO().findMatchingBeans(user);

		return userBeanList;

	}

	@Override
	public List<SystemUser> authenticateUser(SystemUser user)
	{
		List<SystemUser> userList = new ArrayList<SystemUser>();
		userList = getGenericDataBeanDAO().findMatchingBeans(user);
		return userList;
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param loginId
	 * @param password
	 * @return
	 *
	 * @author shalini
	 * @createdOn 27-Apr-2012
	 * @modifiedOn 27-Apr-2012 
	 * 
	 */
	@Override
	public String validateLogin(String loginId, String password)
	{
		SystemUser loginUser = new SystemUser();
		loginUser.setLogin(loginId);
		loginUser.setPassword(password);
		loginUser.setDeleteFlag("F");
		List<SystemUser> userList = authenticateUser(loginUser);

		String message = null;
		Map dataMap = new HashMap();
		List<Map> dataMapList = new ArrayList<Map>();
		Map responseMap = new HashMap();
		String response = null;

		if ((userList == null) || (userList.size() == 0) || (userList.size() > 1))
		{
			message = "Login Failed";
			responseMap = IcatalogUtility.createLoginResponse(message, dataMapList);
			response = IcatalogUtility.createJSONFromMap(responseMap);

		}
		else
		{
			message = "Login Successful";

			SystemUser user = userList.get(0);
			Profile userProfile = profileDao.findMatchingBeanById(Profile.class, "id", user.getProfileId());

			// retrieving activity as per profile

			ProfileActivityMapping activity = new ProfileActivityMapping();
			activity.setProfileCode(userProfile.getCode());
			activity.setDeleteFlag("F");

			List<ProfileActivityMapping> activityList = profileActivityDao.findMatchingBeans(activity);

			List<String> activityCode = new ArrayList<String>();
			for (ProfileActivityMapping currentActivity : activityList)
			{
				activityCode.add(currentActivity.getActivityCode());
			}

			// retrieving territory as per user

			UserTerritoryMapping userTerritoryMapping = new UserTerritoryMapping();
			userTerritoryMapping.setUserCode(user.getId());
			userTerritoryMapping.setDeleteFlag("F");
			List<UserTerritoryMapping> terrMappingList = userTerrDao.findMatchingBeans(userTerritoryMapping);

			List<Long> territoryIdlist = new ArrayList<Long>();

			for (UserTerritoryMapping territoryMapping : terrMappingList)
			{
				territoryIdlist.add(territoryMapping.getId());
			}

			dataMap.put("id", user.getId());
			dataMap.put("first_name", user.getFirstName());
			dataMap.put("last_name", user.getLastName());
			dataMap.put("profile", userProfile.getName());
			dataMap.put("activity_list", activityCode);
			dataMap.put("store_id", territoryIdlist);

			dataMapList.add(dataMap);

			responseMap = IcatalogUtility.createLoginResponse(message, dataMapList);
			response = IcatalogUtility.createJSONFromMap(responseMap);

		}

		return response;
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param loginId
	 * @param password
	 * @return
	 *
	 * @author shalini
	 * @createdOn 05-May-2012
	 * @modifiedOn 05-May-2012 
	 * 
	 */
	@Override
	public List<SystemUser> authorizeUser(String loginId, String password)
	{
		SystemUser loginUser = new SystemUser();
		loginUser.setLogin(loginId);
		loginUser.setPassword(password);
		loginUser.setDeleteFlag("F");
		List<SystemUser> userList = authenticateUser(loginUser);

		return userList;
	}

	public String chkSyncForUser(String entity)
	{
		String sync = appConfigDao.checkSyncFlag(entity);

		log.info("----------------In User Service-----------Sync for User is----------" + sync);

		return sync;
		
		/*if (sync.equalsIgnoreCase("disable"))
		{
			return sync;
		}
		else
		{
			return sync;
		}*/

	}
}
