package com.mobicule.icatalog.systemuser.service;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.mobicule.icatalog.commons.MoreThanOneRecodeFoundException;
import com.mobicule.icatalog.entity.service.EntityServiceImpl;
import com.mobicule.icatalog.systemuser.bean.SystemUser;
import com.mobicule.icatalog.systemuser.bean.Territory;
import com.mobicule.icatalog.systemuser.dao.TerritoryDao;

public class TerritoryServiceImpl extends EntityServiceImpl<Territory, TerritoryDao> implements TerritoryService
{
	private Log log = LogFactory.getLog(this.getClass());

	@Override
	public List<Territory> doCustomSearch(Territory territory)
	{

		return getGenericDataBeanDAO().doCustomSearch(territory);
	}

	@Override
	public List<Territory> doTerritorySearch(SystemUser systemUser)
	{

		return getGenericDataBeanDAO().doTerritorySearch(systemUser);
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param code
	 * @return
	 *
	 * @author shalini
	 * @createdOn 27-Apr-2012
	 * @modifiedOn 27-Apr-2012 
	 * 
	 */
	@Override
	public Long retrieveRecord(String code)
	{
		Territory territory = new Territory();
		territory.setCode(code);
		territory.setDeleteFlag("F");
		List<Territory> terrList = search(territory);

		if (terrList == null || terrList.size() == 0)
		{
			log.info("terrList null" + terrList + "or size 0" + terrList.size());

			return null;
		}

		try
		{

			if (terrList.size() > 1)
			{
				log.info("more than 1 record exist size" + terrList.size());
				throw new MoreThanOneRecodeFoundException();

			}
		}
		catch (Exception e)
		{
			log.info("Error");
		}

		log.info("single record found size" + terrList.size());

		return terrList.get(0).getId();

	}
}
