package com.mobicule.icatalog.systemuser.dao;

import java.util.List;

import org.hibernate.Query;

import com.mobicule.component.system.db.dao.GenericDataBeanHibernateDAO;
import com.mobicule.icatalog.systemuser.bean.Profile;
import com.mobicule.icatalog.systemuser.bean.SystemUser;
import com.mobicule.icatalog.systemuser.bean.Territory;

public class TerritoryHibernateDao extends GenericDataBeanHibernateDAO<Territory> implements TerritoryDao
{
	@Override
	public List<Territory> doCustomSearch(Territory territory)
	{
		StringBuilder searchQueryBuilder = new StringBuilder(" from Territory ");
		Long searchTags = territory.getId();
		
		if (null != searchTags)
		{
			
			searchQueryBuilder.append(" where id =:searchTags");
		}
		
		Query query = getSession().createQuery(searchQueryBuilder.toString());
		
		System.out.println("QUERY IS "+searchQueryBuilder.toString());
	
		
		query.setParameter("searchTags", searchTags);
		
		/*StringBuilder sb = new StringBuilder();
		sb.append(searchTags);
		sb.append("%");
		
		String param = sb.toString();
		System.out.println("------------------param is "+param);
		if (null != searchTags)
		{
			query.setString("searchTags",param);
		}*/
		
		List<Territory> territoryList = query.list();
		
		System.out.println("------------------Result is ----------- "+territoryList);

		return territoryList;
	}
	
	@Override
	public List<Territory> doTerritorySearch(SystemUser systemUser)
	{
		StringBuilder searchQueryBuilder = 
	new StringBuilder(" from Territory t where t.id in(select territoryCode from UserTerritoryMapping m ");
		Long searchTags = systemUser.getId();
		
		if (null != searchTags)
		{
			
			searchQueryBuilder.append(" where m.userCode =:searchTags )");
		}
		
		Query query = getSession().createQuery(searchQueryBuilder.toString());
		
		System.out.println("QUERY IS "+searchQueryBuilder.toString());
		
		query.setParameter("searchTags", searchTags);
		
		/*StringBuilder sb = new StringBuilder();
		sb.append(searchTags);
		sb.append("%");
		
		String param = sb.toString();
		System.out.println("------------------param is "+param);
		if (null != searchTags)
		{
			query.setString("searchTags",param);
		}*/
		
		List<Territory> territoryList = query.list();
		
		System.out.println("------------------Result is ----------- "+territoryList);

		return territoryList;
	}
}
