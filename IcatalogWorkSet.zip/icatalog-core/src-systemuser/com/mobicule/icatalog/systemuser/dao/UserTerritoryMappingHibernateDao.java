package com.mobicule.icatalog.systemuser.dao;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;

import com.mobicule.component.system.db.dao.GenericDataBeanHibernateDAO;
import com.mobicule.icatalog.systemuser.bean.UserTerritoryMapping;


public class UserTerritoryMappingHibernateDao extends GenericDataBeanHibernateDAO<UserTerritoryMapping> implements UserTerritoryMappingDao
{
	private Log log = LogFactory.getLog(this.getClass());
	@Override
	public List<UserTerritoryMapping> doCustomSearch(UserTerritoryMapping userTerritoryMapping)
	{
		StringBuilder searchQueryBuilder = new StringBuilder(" from UserTerritoryMapping ");
		Long searchTags = userTerritoryMapping.getId();
		
		if (null != searchTags)
		{
			log.info("------searchTags---------"+searchTags);
			searchQueryBuilder.append(" where id =:searchTags");
		}
		
		Query query = getSession().createQuery(searchQueryBuilder.toString());
		
		System.out.println("QUERY IS "+searchQueryBuilder.toString());
		
		if(null!=searchTags)
		{
			query.setParameter("searchTags", searchTags);
		}
		
		
		
		/*StringBuilder sb = new StringBuilder();
		sb.append(searchTags);
		sb.append("%");
		
		String param = sb.toString();
		System.out.println("------------------param is "+param);
		if (null != searchTags)
		{
			query.setString("searchTags",param);
		}*/
		
		List<UserTerritoryMapping> userTerritoryMappingList = query.list();
		
		System.out.println("------------------Result is ----------- "+userTerritoryMappingList);

		return userTerritoryMappingList;
	}
	@Override
	public List<UserTerritoryMapping> doUserTerritorySearch(Long userId)
	{
		StringBuilder searchQueryBuilder = new StringBuilder(" from UserTerritoryMapping ");
		Long searchTags = userId;
		
		if (null != searchTags)
		{
			
			searchQueryBuilder.append(" where userCode =:searchTags");
		}
		
		Query query = getSession().createQuery(searchQueryBuilder.toString());
		
		System.out.println("QUERY IS "+searchQueryBuilder.toString());
		
		if (null != searchTags)
		{
			query.setParameter("searchTags", searchTags);
		}
		
		
		
		List<UserTerritoryMapping> userTerritoryMappingList = query.list();
		
		System.out.println("------------------Result is ----------- "+userTerritoryMappingList);

		return userTerritoryMappingList;
	}
}
