package com.mobicule.icatalog.systemuser.dao;

import java.util.List;

import org.hibernate.Query;

import com.mobicule.component.system.db.dao.GenericDataBeanHibernateDAO;
import com.mobicule.icatalog.systemuser.bean.Profile;

public class ProfileHibernateDao extends GenericDataBeanHibernateDAO<Profile> implements ProfileDao
{
	@Override
	public List<Profile> doCustomSearch(Profile profile)
	{
		System.out.println("-------------doCustomSearch-------------"+profile);
		
		StringBuilder searchQueryBuilder = new StringBuilder(" from Profile ");
		Long searchTags = profile.getId();
		System.out.println("-------------doCustomSearch--------ID-----"+searchTags);
		
		
		if (null!=searchTags)
		{
			System.out.println("-------------doCustomSearch--------ID-----"+searchTags);
			searchQueryBuilder.append(" where id =:searchTags");
		}
		
		Query query = getSession().createQuery(searchQueryBuilder.toString());
		
		query.setParameter("searchTags", searchTags);
		System.out.println("-------------doCustomSearch--------SET PARAMETER-----");
		System.out.println("QUERY IS "+searchQueryBuilder.toString());
		
		/*StringBuilder sb = new StringBuilder();
		sb.append(searchTags);
		sb.append("%");
		
		String param = sb.toString();
		System.out.println("------------------param is "+param);
		if (null != searchTags)
		{
			query.setString("searchTags",param);
		}*/
		
		List<Profile> profileList = query.list();
		
		System.out.println("------------------Result is ----------- "+profileList);

		return profileList;
	}
}
