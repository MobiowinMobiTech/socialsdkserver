package com.mobicule.icatalog.systemuser.dao;

import java.util.List;

import com.mobicule.component.system.db.dao.GenericDataBeanDAO;
import com.mobicule.icatalog.systemuser.bean.SystemUser;

public interface SystemUserDao extends GenericDataBeanDAO<SystemUser>
{
	public List<SystemUser> doCustomSearch(SystemUser systemUser);
	public List<SystemUser> activeUserSearch(SystemUser systemUser);
	public List<SystemUser> doUserSearch(SystemUser systemUser);
}
