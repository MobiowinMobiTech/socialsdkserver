package com.mobicule.icatalog.systemuser.dao;

import java.util.List;

import org.hibernate.Query;

import com.mobicule.component.system.db.dao.GenericDataBeanHibernateDAO;
import com.mobicule.icatalog.systemuser.bean.SystemUser;

public class SystemUserHibernateDao extends GenericDataBeanHibernateDAO<SystemUser> implements SystemUserDao
{
	@Override
	public List<SystemUser> doCustomSearch(SystemUser systemUser)
	{
		StringBuilder searchQueryBuilder = new StringBuilder(" from SystemUser  where deleteFlag='F' and login<>'SYS_ADMIN' ");
		String searchTags = systemUser.getCode();
		Long userId=systemUser.getId();
		if (null != searchTags)
		{
			
			searchQueryBuilder.append(" and (firstName like :searchTags or code like :searchTags ) ");
		}
		
		if (null!=userId)
		{
			
			searchQueryBuilder.append(" and id=:userId ");
		}
		
		Query query = getSession().createQuery(searchQueryBuilder.toString());
		
		System.out.println("QUERY IS "+searchQueryBuilder.toString());
		
		StringBuilder sb = new StringBuilder();
		sb.append(searchTags);
		sb.append("%");
		
		String param = sb.toString();
		System.out.println("------------------param is "+param);
		if (null != searchTags)
		{
			query.setString("searchTags",param);
		}
		
		if (null != userId)
		{
			query.setLong("userId",userId);
		}
		
		List<SystemUser> systemUserList = query.list();
		
		System.out.println("------------------Result is ----------- "+systemUserList);

		return systemUserList;
	}
	@Override
	public List<SystemUser> activeUserSearch(SystemUser systemUser)
	{
		StringBuilder searchQueryBuilder = new StringBuilder(" from SystemUser ");
		String searchTags = systemUser.getDeleteFlag();
		
		if (null != searchTags)
		{
			searchQueryBuilder.append(" where deleteFlag =:searchTags and login<>'SYS_ADMIN'");
		}
		
		Query query = getSession().createQuery(searchQueryBuilder.toString());
		
		System.out.println("QUERY IS "+searchQueryBuilder.toString());
		
		query.setParameter("searchTags", searchTags);
		
		/*StringBuilder sb = new StringBuilder();
		sb.append(searchTags);
		sb.append("%");
		
		String param = sb.toString();
		System.out.println("------------------param is "+param);
		if (null != searchTags)
		{
			query.setString("searchTags",param);
		}*/
		
		List<SystemUser> systemUserList = query.list();
		
		System.out.println("------------------Result is ----------- "+systemUserList);

		return systemUserList;
	}
	@Override
	public List<SystemUser> doUserSearch(SystemUser systemUser)
	{
		StringBuilder searchQueryBuilder = new StringBuilder(" from SystemUser ");
		String searchTags = systemUser.getCode();
		
		if (null != searchTags)
		{
			
			searchQueryBuilder.append(" where  code =:searchTags and deleteFlag='F' and login<>'SYS_ADMIN'");
		}
		
		Query query = getSession().createQuery(searchQueryBuilder.toString());
		
		System.out.println("QUERY IS "+searchQueryBuilder.toString());
		
      
        query.setParameter("searchTags", searchTags);
       
		
		/*StringBuilder sb = new StringBuilder();
		sb.append(searchTags);
		sb.append("%");
		
		String param = sb.toString();
		System.out.println("------------------param is "+param);
		if (null != searchTags)
		{
			query.setString("searchTags",param);
		}*/
		
		List<SystemUser> systemUserList = query.list();
		
		System.out.println("------------------Result is ----------- "+systemUserList);

		return systemUserList;
	}
}
