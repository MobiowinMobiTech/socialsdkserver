package com.mobicule.icatalog.systemuser.dao;

import java.util.List;

import com.mobicule.component.system.db.dao.GenericDataBeanDAO;
import com.mobicule.icatalog.systemuser.bean.UserTerritoryMapping;

public interface UserTerritoryMappingDao extends GenericDataBeanDAO<UserTerritoryMapping>
{
	public List<UserTerritoryMapping> doCustomSearch(UserTerritoryMapping userTerritoryMapping);
	public List<UserTerritoryMapping> doUserTerritorySearch(Long userId);
}
