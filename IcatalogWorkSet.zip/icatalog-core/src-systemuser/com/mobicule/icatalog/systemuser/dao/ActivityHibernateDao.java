package com.mobicule.icatalog.systemuser.dao;

import java.util.List;

import org.hibernate.Query;

import com.mobicule.component.system.db.dao.GenericDataBeanHibernateDAO;
import com.mobicule.icatalog.systemuser.bean.Activity;

public class ActivityHibernateDao extends GenericDataBeanHibernateDAO<Activity> implements ActivityDao
{
	@Override
	public List<Activity> doActivitySearch(String profileCode) {
		
		StringBuilder searchQueryBuilder = new StringBuilder(" from Activity ");
		String searchTags = profileCode;
		
		if (null != searchTags)
		{
			
			searchQueryBuilder.append(" where  code =:searchTags and deleteFlag='F' ");
		}
		
		Query query = getSession().createQuery(searchQueryBuilder.toString());
		
		System.out.println("QUERY IS "+searchQueryBuilder.toString());
		
      
        query.setParameter("searchTags", searchTags);
		
		List<Activity> activityList = query.list();
		
		System.out.println("------------------Result is ----------- "+activityList);
		
		return activityList;
	}

}
