package com.mobicule.icatalog.systemuser.dao;

import java.util.List;

import com.mobicule.component.system.db.dao.GenericDataBeanDAO;
import com.mobicule.icatalog.systemuser.bean.Activity;

public interface ActivityDao extends GenericDataBeanDAO<Activity>
{
	public List<Activity> doActivitySearch(String activityCode);

}
