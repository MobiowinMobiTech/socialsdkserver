package com.mobicule.icatalog.systemuser.dao;

import java.util.List;

import com.mobicule.component.system.db.dao.GenericDataBeanDAO;
import com.mobicule.icatalog.systemuser.bean.SystemUser;
import com.mobicule.icatalog.systemuser.bean.Territory;

public interface TerritoryDao extends GenericDataBeanDAO<Territory>
{
	public List<Territory> doCustomSearch(Territory systemUser);
	public List<Territory> doTerritorySearch(SystemUser systemUser);
}
