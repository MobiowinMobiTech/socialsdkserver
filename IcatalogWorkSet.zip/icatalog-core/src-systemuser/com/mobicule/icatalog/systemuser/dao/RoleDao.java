package com.mobicule.icatalog.systemuser.dao;

import com.mobicule.component.system.db.dao.GenericDataBeanDAO;
import com.mobicule.icatalog.systemuser.bean.Role;

public interface RoleDao extends GenericDataBeanDAO<Role>
{

}
