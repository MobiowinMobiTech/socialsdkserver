/**
******************************************************************************
* C O P Y R I G H T  A N D  C O N F I D E N T I A L I T Y  N O T I C E
* <p>
* Copyright © 2008-2009 Mobicule Technologies Pvt. Ltd. All rights reserved. 
* This is proprietary information of Mobicule Technologies Pvt. Ltd.and is 
* subject to applicable licensing agreements. Unauthorized reproduction, 
* transmission or distribution of this file and its contents is a 
* violation of applicable laws.
******************************************************************************
*
* @project icatalog-core
*/
package com.mobicule.icatalog.systemuser.dao;

import java.util.List;

import org.hibernate.Query;
import org.springframework.dao.DataAccessException;

import com.mobicule.component.system.db.dao.GenericDataBeanHibernateDAO;
import com.mobicule.icatalog.systemuser.bean.ProfileActivityMapping;

/**
* 
* <enter description here>
*
* @author shalini <Nair>
* @see 
*
* @createdOn 27-Apr-2012
* @modifiedOn
*
* @copyright © 2008-2009 Mobicule Technologies Pvt. Ltd. All rights reserved.
*/
public class ProfileActivityMappingHibernateDao extends GenericDataBeanHibernateDAO<ProfileActivityMapping> implements ProfileActivityDao
{
	@Override
	public List<ProfileActivityMapping> doProfileActivityMappingSearch(String profileCode) {
		
		StringBuilder searchQueryBuilder = new StringBuilder(" from ProfileActivityMapping ");
		String searchTags = profileCode;
		
		if (null != searchTags)
		{
			
			searchQueryBuilder.append(" where  profileCode =:searchTags and deleteFlag='F' ");
		}
		
		Query query = getSession().createQuery(searchQueryBuilder.toString());
		
		System.out.println("QUERY IS "+searchQueryBuilder.toString());
		
      
        query.setParameter("searchTags", searchTags);
		
		List<ProfileActivityMapping> profileActivityMappingList = query.list();
		
		System.out.println("------------------Result is ----------- "+profileActivityMappingList);
		
		return profileActivityMappingList;
	}

}
