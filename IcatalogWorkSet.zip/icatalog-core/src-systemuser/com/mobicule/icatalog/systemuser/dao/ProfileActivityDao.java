/**
******************************************************************************
* C O P Y R I G H T  A N D  C O N F I D E N T I A L I T Y  N O T I C E
* <p>
* Copyright © 2008-2009 Mobicule Technologies Pvt. Ltd. All rights reserved. 
* This is proprietary information of Mobicule Technologies Pvt. Ltd.and is 
* subject to applicable licensing agreements. Unauthorized reproduction, 
* transmission or distribution of this file and its contents is a 
* violation of applicable laws.
******************************************************************************
*
* @project icatalog-core
*/
package com.mobicule.icatalog.systemuser.dao;

import java.util.List;

import com.mobicule.component.system.db.dao.GenericDataBeanDAO;
import com.mobicule.icatalog.systemuser.bean.ProfileActivityMapping;

/**
* 
* <enter description here>
*
* @author shalini <Nair>
* @see 
*
* @createdOn 27-Apr-2012
* @modifiedOn
*
* @copyright © 2008-2009 Mobicule Technologies Pvt. Ltd. All rights reserved.
*/
public interface ProfileActivityDao extends GenericDataBeanDAO<ProfileActivityMapping>
{
	public List<ProfileActivityMapping> doProfileActivityMappingSearch(String profileCode);

}
