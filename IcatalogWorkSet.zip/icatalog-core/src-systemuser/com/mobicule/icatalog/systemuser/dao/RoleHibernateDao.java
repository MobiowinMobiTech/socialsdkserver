package com.mobicule.icatalog.systemuser.dao;

import com.mobicule.component.system.db.dao.GenericDataBeanHibernateDAO;
import com.mobicule.icatalog.systemuser.bean.Role;

public class RoleHibernateDao extends GenericDataBeanHibernateDAO<Role> implements RoleDao
{

}
