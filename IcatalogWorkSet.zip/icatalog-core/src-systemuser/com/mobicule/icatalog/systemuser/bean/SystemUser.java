package com.mobicule.icatalog.systemuser.bean;

import com.mobicule.component.db.standardbean.SimpleDataBean;
import com.mobicule.icatalog.systemuser.bean.Authentication;

public class SystemUser extends SimpleDataBean
{


	private static final long serialVersionUID = 1L;
	
	private Long roleId;
	private Long profileId;
	private String code;
	private String login;
	private String password;
	private String firstName;
	private String middleName;
	private String lastName;
	private String address;
	private String phoneNumber;
	private String email;
	private String contactPerson;
	private Authentication authentication;
	public Long getRoleId() 
	{
		return roleId;
	}
	
	public void setRoleId(Long roleId) 
	{
		this.roleId = roleId;
	}
	
	public Long getProfileId() 
	{
		return profileId;
	}
	
	public void setProfileId(Long profileId) 
	{
		this.profileId = profileId;
	}
	
	public String getCode() 
	{
		return code;
	}
	
	public void setCode(String code) 
	{
		this.code = code;
	}
	
	public String getLogin() 
	{
		return login;
	}
	
	public void setLogin(String login) 
	{
		this.login = login;
	}
	
	public String getPassword() 
	{
		return password;
	}
	
	public void setPassword(String password)
	{
		this.password = password;
	}
	
	public String getFirstName()
	{
		return firstName;
	}
	
	public void setFirstName(String firstName) 
	{
		this.firstName = firstName;
	}
	
	public String getMiddleName()
	{
		return middleName;
	}
	
	public void setMiddleName(String middleName)
	{
		this.middleName = middleName;
	}
	
	public String getLastName() 
	{
		return lastName;
	}
	
	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}
	
	public String getAddress() 
	{
		return address;
	}
	
	public void setAddress(String address) 
	{
		this.address = address;
	}
	
	public String getPhoneNumber() 
	{
		return phoneNumber;
	}
	
	public void setPhoneNumber(String phoneNumber) 
	{
		this.phoneNumber = phoneNumber;
	}
	
	public String getEmail() 
	{
		return email;
	}
	
	public void setEmail(String email) 
	{
		this.email = email;
	}
	
	public String getContactPerson() 
	{
		return contactPerson;
	}
	
	public void setContactPerson(String contactPerson) 
	{
		this.contactPerson = contactPerson;
	}
	
	public Authentication getAuthentication()
	{
		return authentication;
	}

	public void setAuthentication(Authentication authentication)
	{
		this.authentication = authentication;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("SystemUser [roleId=");
		builder.append(roleId);
		builder.append(", profileId=");
		builder.append(profileId);
		builder.append(", code=");
		builder.append(code);
		builder.append(", login=");
		builder.append(login);
		builder.append(", password=");
		builder.append(password);
		builder.append(", firstName=");
		builder.append(firstName);
		builder.append(", middleName=");
		builder.append(middleName);
		builder.append(", lastName=");
		builder.append(lastName);
		builder.append(", address=");
		builder.append(address);
		builder.append(", phoneNumber=");
		builder.append(phoneNumber);
		builder.append(", email=");
		builder.append(email);
		builder.append(", contactPerson=");
		builder.append(contactPerson);
		builder.append(", authentication=");
		builder.append(authentication);
		builder.append("]");
		return builder.toString();
	}
	
	
	

}
