package com.mobicule.icatalog.systemuser.bean;

import com.mobicule.component.db.standardbean.StandardBean;

public class Profile extends StandardBean
{

	private static final long serialVersionUID = 1L;

}
