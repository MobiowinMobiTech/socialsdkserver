/**
******************************************************************************
* C O P Y R I G H T  A N D  C O N F I D E N T I A L I T Y  N O T I C E
* <p>
* Copyright © 2008-2009 Mobicule Technologies Pvt. Ltd. All rights reserved. 
* This is proprietary information of Mobicule Technologies Pvt. Ltd.and is 
* subject to applicable licensing agreements. Unauthorized reproduction, 
* transmission or distribution of this file and its contents is a 
* violation of applicable laws.
******************************************************************************
*
* @project icatalog-core
*/
package com.mobicule.icatalog.systemuser.bean;

import com.mobicule.component.db.standardbean.SimpleDataBean;

/**
* 
* <enter description here>
*
* @author shalini <Nair>
* @see 
*
* @createdOn 27-Apr-2012
* @modifiedOn
*
* @copyright © 2008-2009 Mobicule Technologies Pvt. Ltd. All rights reserved.
*/
public class ProfileActivityMapping extends SimpleDataBean
{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String profileCode;
	
	private String activityCode;

	public String getProfileCode()
	{
		return profileCode;
	}

	public void setProfileCode(String profileCode)
	{
		this.profileCode = profileCode;
	}

	public String getActivityCode()
	{
		return activityCode;
	}

	public void setActivityCode(String activityCode)
	{
		this.activityCode = activityCode;
	}
	
	

}
