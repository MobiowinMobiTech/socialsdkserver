package com.mobicule.icatalog.systemuser.bean;

import com.mobicule.component.db.standardbean.StandardBean;

public class Role extends StandardBean
{

	private static final long serialVersionUID = 1L;
	
	private String displayName;
	private Long parentRole;
	
	public String getDisplayName()
	{
		return displayName;
	}
	
	public void setDisplayName(String displayName)
	{
		this.displayName = displayName;
	}
	
	public Long getParentRole()
	{
		return parentRole;
	}
	
	public void setParentRole(Long parentRole) 
	{
		this.parentRole = parentRole;
	}

	@Override
	public String toString() {
		return "Role [displayName=" + displayName + ", parentRole="
				+ parentRole + "]";
	}

}
