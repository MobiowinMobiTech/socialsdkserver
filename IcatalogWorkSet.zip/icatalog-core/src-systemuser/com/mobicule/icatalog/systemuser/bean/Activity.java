package com.mobicule.icatalog.systemuser.bean;

import com.mobicule.component.db.standardbean.StandardBean;

public class Activity extends StandardBean
{


	private static final long serialVersionUID = 1L;

}
