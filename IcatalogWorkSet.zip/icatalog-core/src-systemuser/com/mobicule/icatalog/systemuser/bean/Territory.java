package com.mobicule.icatalog.systemuser.bean;

import com.mobicule.component.db.standardbean.StandardBean;

public class Territory extends StandardBean
{

	private static final long serialVersionUID = 1L;
	
	private String displayName;
	private Long parentTerritory;
	
	public String getDisplayName()
	{
		return displayName;
	}
	
	public void setDisplayName(String displayName)
	{
		this.displayName = displayName;
	}
	
	public Long getParentTerritory()
	{
		return parentTerritory;
	}
	
	public void setParentTerritory(Long parentTerritory) 
	{
		this.parentTerritory = parentTerritory;
	}

	@Override
	public String toString() {
		return "Role [displayName=" + displayName + ", parentTerritory="
				+ parentTerritory + "]";
	}

}
