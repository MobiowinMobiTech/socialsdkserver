package com.mobicule.icatalog.core.common;

public class ICatalogConstants
{
	public static final String FLAG_FALSE = "F";
	public static final String FLAG_TRUE = "T";
	public static final String EMPTY_STRING = "";

	public static final String PASSWORD_RESET = "pwd";

	public static final String ADD_ENTITY = "ADD";

	public static final String MODIFY_ENTITY = "MODIFY";

	public static final String DELETE_ENTITY = "DELETE";

	public static final String EMAIL_STATUS_PENDING = "PENDING";
	public static final String EMAIL_STATUS_SUCCESS = "SUCCESS";
	public static final String EMAIL_STATUS_FAILURE = "FAILURE";

	public static final String ITEM_TYPE_CONCEPT = "CONCEPT";
	public static final String ITEM_TYPE_PRODUCT = "PRODUCT";
	
	public static final String EMAIL_ATTEMPTS_MAXIMUM = "EMAIL_ATTEMPTS_MAXIMUM";
}