package com.mobicule.icatalog.core.common;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.imageio.ImageIO;
import javax.mail.internet.MimeMessage;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.FileSystemResource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

public class MailReport
{
	private static final int IMG_WIDTH = 230;

	private static final int IMG_HEIGHT = 160;

	private JavaMailSender mailSender;

	private SimpleMailMessage simpleMailMessage;

	private Log log = LogFactory.getLog(getClass());

	public void setSimpleMailMessage(SimpleMailMessage simpleMailMessage)
	{
		this.simpleMailMessage = simpleMailMessage;
	}

	public void setMailSender(JavaMailSender mailSender)
	{
		this.mailSender = mailSender;
	}

	public boolean sendMail(String to, String path, String name, String subject, String imageDir, String startFrom,
			String endOn)
	{
		HashMap<String, String> imageMap = new HashMap<String, String>();
		MimeMessage message = mailSender.createMimeMessage();

		try
		{
			String reportHtml = changeImageSources(path, imageMap);

			MimeMessageHelper helper = new MimeMessageHelper(message, true);

			helper.setFrom(simpleMailMessage.getFrom());
			helper.setTo(to);
			helper.setSubject(simpleMailMessage.getSubject() + " " + subject + " " + startFrom);
			helper.setText(String.format(simpleMailMessage.getText(), name, startFrom, reportHtml), true);

			Set<String> keys = imageMap.keySet();

			for (String key : keys)
			{
				final String imagePath = imageMap.get(key);

				int lastCharIndex = imagePath.lastIndexOf("/") + 1;

				final String imageName = imagePath.substring(lastCharIndex);

				helper.addInline(key, new ByteArrayResource(getCompressedImageData(imagePath))
				{
					@Override
					public String getFilename()
					{
						return imageName;
					}
				});
			}
		}
		catch (Exception e)
		{
			log.error("EXception in send mail", e);
			
			return false;
		}

		mailSender.send(message);
		
		return true;
	}

	private static byte[] getCompressedImageData(String imagePath) throws IOException
	{
		BufferedImage originalImage = ImageIO.read(new File(imagePath));

		int type = originalImage.getType() == 0 ? BufferedImage.TYPE_INT_ARGB : originalImage.getType();

		BufferedImage resizeImagePng = resizeImage(originalImage, type);

		ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();

		ImageIO.write(resizeImagePng, "png", byteArrayOutputStream);

		byte[] compressedImageBytes = byteArrayOutputStream.toByteArray();
		return compressedImageBytes;
	}

	private static BufferedImage resizeImage(BufferedImage originalImage, int type)
	{
		BufferedImage resizedImage = new BufferedImage(IMG_WIDTH, IMG_HEIGHT, type);
		Graphics2D g = resizedImage.createGraphics();
		g.drawImage(originalImage, 0, 0, IMG_WIDTH, IMG_HEIGHT, null);
		g.dispose();

		return resizedImage;
	}

	private String changeImageSources(String htmlString, HashMap<String, String> imageMap)
	{
		log.info("in change image sources");
		Pattern imagePattern = Pattern.compile("<img[^>]+src\\s*=\\s*['\"]([^'\"]+)['\"][^>]*>");
		Matcher imageMatcher = imagePattern.matcher(htmlString);

		// print all the matches that we find
		while (imageMatcher.find())
		{
			String imgTag = imageMatcher.group();

			Pattern sourcePattern = Pattern.compile("src\\s*=\\s*['\"]([^'\"]+)['\"]*");
			Matcher srcMatcher = sourcePattern.matcher(imgTag);
			while (srcMatcher.find())
			{
				String imgTagString = srcMatcher.group();
				log.info("imgTag: " + imgTagString);

				int start = imgTagString.indexOf("\"") + 1;
				log.info("imgTag start: " + start);
				int end = imgTagString.lastIndexOf("\"");
				log.info("imgTag end: " + end);
				String imagePath = imgTagString.substring(start, end);

				log.info("PATH of IMAGE IS  === " + imagePath);

				FileSystemResource file = new FileSystemResource(new File(imagePath));

				log.info("FILENAME is  " + file.getFilename());

				String cid = createRandomid();

				imageMap.put(cid, imagePath);

				String newimageTag = imgTag.replace(imagePath, "cid:" + cid);
				log.info("=========================\n");
				log.info("NEW IMAGE IS..." + newimageTag);
				log.info("=========================\n");

				htmlString = htmlString.replace(imgTag, newimageTag);

				log.info("THe html string is :: " + htmlString);
			}

		}
		return htmlString;
	}

	private static String createRandomid()
	{
		String chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
		String pass = "";
		try
		{
			int length = 20;

			for (int x = 0; x < length; x++)
			{
				int i = (int) Math.floor(Math.random() * 62);
				pass += chars.charAt(i);
			}
		}
		catch (Exception e)
		{

		}

		return pass;
	}

}