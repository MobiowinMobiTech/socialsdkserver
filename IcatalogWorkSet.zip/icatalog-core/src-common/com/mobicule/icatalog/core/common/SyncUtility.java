/**
******************************************************************************
* C O P Y R I G H T  A N D  C O N F I D E N T I A L I T Y  N O T I C E
* <p>
* Copyright � 2010 - 2011 Mobicule Technologies Pvt. Ltd. All rights reserved. 
* This is proprietary information of Mobicule Technologies Pvt. Ltd.and is 
* subject to applicable licensing agreements. Unauthorized reproduction, 
* transmission or distribution of this file and its contents is a 
* violation of applicable laws.
******************************************************************************
*
* @project msales-core
*/
package com.mobicule.icatalog.core.common;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
* 
* <enter description here>
*
* @author PRANAV <MALTHANKAR>
* @see 
*
* @createdOn Sep 02, 2012
* @modifiedOn
*
* @copyright � 2008-2009 Mobicule Technologies Pvt. Ltd. All rights reserved.
*/
public class SyncUtility
{
	private static Log log = LogFactory.getLog(SyncUtility.class);

	public static int getEffectivePageNumber(int pageNumber, int pageSize, int entryCount)
	{
		int quotient = entryCount / pageSize;
		int remainder = entryCount % pageSize;
		int effectivePageNumber = quotient - 1;

		if (remainder > 0)
		{
			effectivePageNumber++;
		}

		if (effectivePageNumber < 0)
		{
			effectivePageNumber = 0;
		}

		log.info("entryCount : " + entryCount);
		log.info("quotient : " + quotient);
		log.info("remainder : " + remainder);
		log.info("effectivePageNumberAdd : " + effectivePageNumber);
		log.info("pageNumber : " + pageNumber);

		return effectivePageNumber;
	}
}
