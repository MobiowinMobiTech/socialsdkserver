package com.mobicule.icatalog.core.common;


import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.StringTokenizer;
import java.util.TimeZone;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class CommonServices
{
	private static Log log = LogFactory.getLog(CommonServices.class);
	public static final String DATE_FORMATE_dd_MMM_yyyyHH_mm_ss = "dd-MMM-yyyy HH:mm:ss";

	public static final String DATE_FORMAT_dd_MMM_yyyyHH_mm = "dd-MMM-yyyy HH:mm";
	public static Timestamp getMobiculeTime(String dateStr)
	{
		Timestamp ts = null;

		try
		{
			if (ICatalogConstants.EMPTY_STRING.equals(dateStr))
			{
				return ts;
			}
			else
			{
				StringTokenizer strz = new StringTokenizer(dateStr, "-");
				int date = Integer.parseInt(strz.nextToken());
				String m = strz.nextToken();
				int month = 0;

				if (("JANUARY").startsWith(m.toUpperCase()))
				{
					month = Calendar.JANUARY;
				}
				if (("FEBRUARY").startsWith(m.toUpperCase()))
				{
					month = Calendar.FEBRUARY;
				}
				if (("MARCH").startsWith(m.toUpperCase()))
				{
					month = Calendar.MARCH;
				}
				if (("APRIL").startsWith(m.toUpperCase()))
				{
					month = Calendar.APRIL;
				}
				if (("MAY").startsWith(m.toUpperCase()))
				{
					month = Calendar.MAY;
				}
				if (("JUNE").startsWith(m.toUpperCase()))
				{
					month = Calendar.JUNE;
				}
				if (("JULY").startsWith(m.toUpperCase()))
				{
					month = Calendar.JULY;
				}
				if (("AUGUST").startsWith(m.toUpperCase()))
				{
					month = Calendar.AUGUST;
				}
				if (("SEPTEMBER").startsWith(m.toUpperCase()))
				{
					month = Calendar.SEPTEMBER;
				}
				if (("OCTOBER").startsWith(m.toUpperCase()))
				{
					month = Calendar.OCTOBER;
				}
				if (("NOVEMBER").startsWith(m.toUpperCase()))
				{
					month = Calendar.NOVEMBER;
				}
				if (("DECEMBER").startsWith(m.toUpperCase()))
				{
					month = Calendar.DECEMBER;
				}
				int year = Integer.parseInt(strz.nextToken());

				SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yy");
				Calendar cal = Calendar.getInstance();
				cal.set(year, month, date);
				log.info("formated date  " + sdf.format(cal.getTime()));

				long timeinmill = cal.getTimeInMillis();
				ts = new Timestamp(timeinmill);
			}
			log.info("TimeStamp =" + ts);

			return ts;
		}
		catch (NullPointerException e)
		{
			log.info("ERROR IN ORDER DATA RECEIVED -- " + e);
			e.printStackTrace();
			return ts;
		}
	}

	public static Timestamp convertDateToTimeStamp(String dateStr, String dateFormat) throws Exception
	{
		Timestamp timestamp = null;
		Date date = null;
		Calendar cal = null;
		SimpleDateFormat formatter = null;

		//LogUtil.logger.info("=========** The value of  dateStr and dateFormat**========"+dateStr+" and "+dateFormat);

		try
		{
			if (!ICatalogConstants.EMPTY_STRING.equals(dateStr))
			{
				formatter = new SimpleDateFormat(dateFormat);

				log.info("The value of  date : " + date);

				date = formatter.parse(dateStr);

				log.info("The value of  date : " + date);

				cal = Calendar.getInstance();

				log.info("The value of  cal : " + cal);
				cal.setTime(date);
				log.info("The value of  cal after set : " + cal);
				timestamp = new Timestamp(cal.getTimeInMillis());
				log.info("The value of  timestamp : " + timestamp);
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw e;
		}
		return timestamp;
	}

	public static Timestamp convertDateToTimeStampIncrementByOne(String dateStr, String dateFormat) throws Exception
	{
		Timestamp timestamp = null;
		Date date = null;
		Calendar cal = null;
		SimpleDateFormat formatter = null;
		int one = 1;
		//LogUtil.logger.info("=========** The value of  dateStr and dateFormat**========"+dateStr+" and "+dateFormat);

		try
		{
			if (!ICatalogConstants.EMPTY_STRING.equals(dateStr))
			{
				formatter = new SimpleDateFormat(dateFormat);

				date = formatter.parse(dateStr);

				log.info("The value of  date : " + date);

				cal = Calendar.getInstance();

				log.info("The value of  cal : " + cal);
				cal.setTime(date);
				cal.add(Calendar.DATE, one);
				log.info("The value of  cal : " + cal.getTime() + "" + cal);
				timestamp = new Timestamp(cal.getTimeInMillis());
				log.info("The value of  timestamp : " + timestamp);
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
			throw e;
		}
		return timestamp;
	}

	/*public static String getFormatedDate(String requiredFormat, Timestamp date) throws ParseException
	{
		SimpleDateFormat df1 = new SimpleDateFormat("yyyy-MM-dd kk:mm:ss");
		String startdatetime = date.toString();
		SimpleDateFormat df2 = new SimpleDateFormat(requiredFormat);
		String updatedFormat = df2.format(df1.parse(startdatetime)).toString();

		return updatedFormat;
	}*/

	public static String getFormatedDate(String requiredFormat, Timestamp timestamp)
	{
		String updatedFormat = "";
		try
		{

			if (timestamp == null)
			{
				return "-";
			}

			SimpleDateFormat df1 = new SimpleDateFormat("yyyy-MM-dd kk:mm:ss");
			String startdatetime = timestamp.toString();
			SimpleDateFormat df2 = new SimpleDateFormat(requiredFormat);
			updatedFormat = df2.format(df1.parse(startdatetime)).toString();

		}
		catch (Exception e)
		{
			log.error("Error", e);
			updatedFormat = "-";
		}

		return updatedFormat;
	}

	public static Timestamp getTimeStamp(String dateTimeStr, String dateTimeFormat, String timeZoneStr)
			throws Exception
	{
		return new Timestamp(getDateObject(dateTimeStr, dateTimeFormat, timeZoneStr).getTime());
	}

	public static Date getDateObject(String dateTimeStr, String dateTimeFormat, String timeZoneStr) throws Exception
	{
		SimpleDateFormat sFormat = new SimpleDateFormat(dateTimeFormat);

		if (null != timeZoneStr)
		{
			TimeZone timeZone = TimeZone.getTimeZone(timeZoneStr);
			sFormat.setTimeZone(timeZone);
		}

		return sFormat.parse(dateTimeStr);
	}
	
	
	public static String getFormattedDateFromTimestamp(Timestamp timestamp, String format)
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat(format);
		String formattedDate = dateFormat.format(timestamp);
		return formattedDate;
	}
	
	
	public static String getFormattedDateFromTimestamp(Timestamp timestamp)
	{
		String format = CommonServices.DATE_FORMAT_dd_MMM_yyyyHH_mm;
		
		return getFormattedDateFromTimestamp(timestamp, format);
		
	}
}
