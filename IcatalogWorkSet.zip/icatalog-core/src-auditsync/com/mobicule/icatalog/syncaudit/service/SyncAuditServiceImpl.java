package com.mobicule.icatalog.syncaudit.service;

import java.sql.Timestamp;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.mobicule.icatalog.entity.service.EntityServiceImpl;
import com.mobicule.icatalog.syncaudit.bean.SyncAudit;
import com.mobicule.icatalog.syncaudit.bean.SyncAuditWrapper;
import com.mobicule.icatalog.syncaudit.dao.SyncAuditDao;

public class SyncAuditServiceImpl extends EntityServiceImpl<SyncAudit, SyncAuditDao>
implements SyncAuditService 
{
	private Log log = LogFactory.getLog(this.getClass());
	private SyncAuditDao syncAuditDao;
	
	public SyncAuditDao getSyncAuditDao() {
		return syncAuditDao;
	}

	public void setSyncAuditDao(SyncAuditDao syncAuditDao) {
		this.syncAuditDao = syncAuditDao;
	}

	@Override
	public List<SyncAuditWrapper> doCustomSearch(SyncAudit syncAudit,Timestamp syncDateTimestampDate)
	{

		return syncAuditDao.doCustomSearch(syncAudit,syncDateTimestampDate);
	}
	
	@Override
	public List<SyncAudit> syncAuditList(SyncAudit syncAudit){
		
		log.info("--------in syncAuditServiceImpl----------"+syncAudit);
		List<SyncAudit> syncAuditList=syncAuditDao.syncAuditList(syncAudit);
		log.info("--------After dao call --->------syncAuditServiceImpl----------");
		if(syncAudit!=null)
		{
			log.info("--------in syncAuditServiceImpl is not empty----------"+syncAudit);
			return syncAuditList;	
		}
		
		else
		{
			log.info("--------in syncAuditServiceImpl is Empty----------"+syncAudit);
			return syncAuditList;
		}
			
	}
	
	@Override
	public List<String> masterSearch(SyncAudit syncAudit){
		
		List<String> masterList=syncAuditDao.masterSearch(syncAudit);
		return masterList;
	}
	
	@Override
	public List<SyncAuditWrapper> syncAuditWrapperDetails(SyncAudit syncAudit)
	{
		
		List<SyncAuditWrapper> syncAuditWrapperList=syncAuditDao.syncAuditWrapperDetails(syncAudit);
		return syncAuditWrapperList;
	}
	
}
