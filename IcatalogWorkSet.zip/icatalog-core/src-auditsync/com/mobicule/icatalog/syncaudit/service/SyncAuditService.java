package com.mobicule.icatalog.syncaudit.service;

import java.sql.Timestamp;
import java.util.List;

import com.mobicule.icatalog.entity.service.EntityService;
import com.mobicule.icatalog.syncaudit.bean.SyncAudit;
import com.mobicule.icatalog.syncaudit.bean.SyncAuditWrapper;
import com.mobicule.icatalog.syncaudit.dao.SyncAuditDao;

public interface SyncAuditService extends EntityService<SyncAudit, SyncAuditDao>
{
	public List<SyncAudit> syncAuditList(SyncAudit syncAudit);
	
	public List<SyncAuditWrapper> doCustomSearch(SyncAudit syncAudit,Timestamp syncDateTimestampDate);
	
	public List<String> masterSearch(SyncAudit syncAudit);
	
	public List<SyncAuditWrapper> syncAuditWrapperDetails(SyncAudit syncAudit);
}
