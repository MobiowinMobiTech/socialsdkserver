package com.mobicule.icatalog.syncaudit.bean;

import java.io.Serializable;

import com.mobicule.icatalog.syncaudit.bean.SyncAudit;
import com.mobicule.icatalog.systemuser.bean.SystemUser;

/**
******************************************************************************
* C O P Y R I G H T  A N D  C O N F I D E N T I A L I T Y  N O T I C E
* <p>
* Copyright © 2008-2009 Mobicule Technologies Pvt. Ltd. All rights reserved. 
* This is proprietary information of Mobicule Technologies Pvt. Ltd.and is 
* subject to applicable licensing agreements. Unauthorized reproduction, 
* transmission or distribution of this file and its contents is a 
* violation of applicable laws.
******************************************************************************
*
* @project icatalog-core
*/

/**
* 
* <enter description here>
*
* @author Pranav <Malthankar>
* @see 
*
* @createdOn 18-May-2012
* @modifiedOn
*
* @copyright © 20012-2013 Mobicule Technologies Pvt. Ltd. All rights reserved.
*/

public class SyncAuditWrapper  implements Serializable
{
	private static final long serialVersionUID = 1L;
	
	private SyncAudit syncAudit;
	
	private SystemUser systemUser;

	public SyncAudit getSyncAudit() {
		return syncAudit;
	}

	public void setSyncAudit(SyncAudit syncAudit) {
		this.syncAudit = syncAudit;
	}
	
	public SystemUser getSystemUser() {
		return systemUser;
	}

	public void setSystemUser(SystemUser systemUser) {
		this.systemUser = systemUser;
	}

	@Override
	public String toString()
	{
		StringBuilder builder = new StringBuilder();
		builder.append("SyncAuditWrapper [\n\tsyncAudit=");
		builder.append(syncAudit);
		builder.append(", \n\tsystemUser=");
		builder.append(systemUser);
		builder.append("]");
		return builder.toString();
	}
}
