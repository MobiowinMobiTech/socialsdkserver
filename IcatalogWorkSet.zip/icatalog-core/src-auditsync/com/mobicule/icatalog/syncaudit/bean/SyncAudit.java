package com.mobicule.icatalog.syncaudit.bean;

import java.sql.Timestamp;

import com.mobicule.component.db.standardbean.SimpleDataBean;

public class SyncAudit extends SimpleDataBean
{

	private static final long serialVersionUID = 1L;
	
	private long userId;
	private String master;
	private long recordAdded;
	private long recordModified;
	private long recordDeleted;
	private Timestamp syncDate;
	
	
	public long getUserId()
	{
		return userId;
	}
	
	public void setUserId(long userId)
	{
		this.userId = userId;
	}
	
	public String getMaster()
	{
		return master;
	}
	
	public void setMaster(String master)
	{
		this.master = master;
	}
	
	public long getRecordAdded()
	{
		return recordAdded;
	}
	
	public void setRecordAdded(long recordAdded) 
	{
		this.recordAdded = recordAdded;
	}
	
	public long getRecordModified()
	{
		return recordModified;
	}
	
	public void setRecordModified(long recordModified)
	{
		this.recordModified = recordModified;
	}
	
	public long getRecordDeleted()
	{
		return recordDeleted;
	}
	
	public void setRecordDeleted(long recordDeleted) 
	{
		this.recordDeleted = recordDeleted;
	}
	
	public Timestamp getSyncDate() 
	{
		return syncDate;
	}
	
	public void setSyncDate(Timestamp syncDate)
	{
		this.syncDate = syncDate;
	}
	
	

}
