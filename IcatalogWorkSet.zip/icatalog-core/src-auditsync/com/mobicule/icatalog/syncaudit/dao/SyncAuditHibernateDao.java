package com.mobicule.icatalog.syncaudit.dao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;

import com.mobicule.component.system.db.dao.GenericDataBeanHibernateDAO;
import com.mobicule.icatalog.syncaudit.bean.SyncAudit;
import com.mobicule.icatalog.syncaudit.bean.SyncAuditWrapper;
import com.mobicule.icatalog.systemuser.bean.SystemUser;

public class SyncAuditHibernateDao extends GenericDataBeanHibernateDAO<SyncAudit> implements SyncAuditDao 
{
	private Log log = LogFactory.getLog(this.getClass());
	
	
	@Override
	public List<SyncAudit> syncAuditList(SyncAudit syncAudit)
	{
		log.info("-----In syncAuditList method------SyncAudit---");
		Long userId=syncAudit.getId();
		
		StringBuilder searchQueryBuilder = new StringBuilder(" from SyncAudit ");
		
		searchQueryBuilder.append(" where deleteFlag ='F' ");
		
		
		if(null!=userId)
		{
			log.info("userId :"+userId);
			searchQueryBuilder.append(" and userId =:userId ");
		}
		
		Query query = getSession().createQuery(searchQueryBuilder.toString());
		
		if (null != userId)
		{
			query.setLong("userId",userId);
		}
		
		System.out.println("QUERY IS "+searchQueryBuilder.toString());
		
		
		List<SyncAudit> syncAuditList=new ArrayList<SyncAudit>();
		syncAuditList= query.list();
		
		//System.out.println("------------------Result is ----------- "+syncAuditList);

		return syncAuditList;
	}
	
	@Override
	public List<SyncAuditWrapper> doCustomSearch(SyncAudit syncAudit,Timestamp syncDateTimestampDate)
	{
		log.info("-----doCustomSearch------SyncAudit---");
		
		StringBuilder searchQueryBuilder = new StringBuilder(" from SystemUser su, SyncAudit sa  where sa.userId=su.id  and sa.deleteFlag ='F' " +
				"and su.deleteFlag ='F'");


		boolean isFirstClause = true;

		String master=null;
		master= syncAudit.getMaster();
		Long userId =null;
		userId=syncAudit.getUserId();
		
		if (null != master)
		{
			log.info("-----master-----"+master+"-------");
			searchQueryBuilder.append(" and sa.master =:master ");
		}
		
		if (0!= userId)
		{
			log.info("-----userId-----"+userId+"-------");
			searchQueryBuilder.append(" and sa.userId =:userId ");
		}
		
		if (null != syncDateTimestampDate)
		{
			log.info("-----syncDate-----"+syncDateTimestampDate+"-------");
			searchQueryBuilder.append(" and sa.syncDate >= :syncDateTimestampDate ");
		}
		searchQueryBuilder.append(" order by sa.id");
		
		Query query = getSession().createQuery(searchQueryBuilder.toString());

		if (null != master)
		{
			query.setParameter("master", master );
		}
		if (null != syncDateTimestampDate)
		{
			query.setTimestamp("syncDateTimestampDate",syncDateTimestampDate);
		}
		if (0 != userId)
		{
			query.setLong("userId",userId);
		}

		log.info("----query for search-----::: " + query);


		List<Object[]> resultList = query.list();
		List<SyncAuditWrapper> syncAuditWrapperList=new ArrayList<SyncAuditWrapper>();
		for (Object[] obj : resultList)
		{

			SystemUser currentSystemUser = (SystemUser) obj[0];
			SyncAudit currentSyncAudit = (SyncAudit) obj[1];

			SyncAuditWrapper syncAuditWrapper = new SyncAuditWrapper();

			syncAuditWrapper.setSyncAudit(currentSyncAudit);
			syncAuditWrapper.setSystemUser(currentSystemUser);

			syncAuditWrapperList.add(syncAuditWrapper);
		}

		return syncAuditWrapperList;
	}
	
	@Override
	public List<String> masterSearch(SyncAudit syncAudit)
	{
		
		Long userId=syncAudit.getId();
		StringBuilder searchQueryBuilder = new StringBuilder(" select distinct master from SyncAudit where deleteFlag ='F'");
		
		if(null!=userId)
		{
			log.info("userId :"+userId);
			searchQueryBuilder.append(" and userId =:userId ");
		}

		
		Query query = getSession().createQuery(searchQueryBuilder.toString());
		if (null != userId)
		{
			query.setLong("userId",userId);
		}
		List<String> masterList = query.list();
		return masterList;
		
	}
	
	@Override
	public List<SyncAuditWrapper> syncAuditWrapperDetails(SyncAudit syncAudit)
	{
		Long userId=syncAudit.getId();
		
		StringBuilder searchQueryBuilder = new StringBuilder(" from SystemUser su, SyncAudit sa  where sa.userId=su.id  and sa.deleteFlag ='F' " +
				"and su.deleteFlag ='F' ");
		
		if(null!=userId)
		{
			log.info("userId :"+userId);
			searchQueryBuilder.append(" and sa.userId =:userId ");
		}
			searchQueryBuilder.append(" order by sa.id "); 
		
		
		Query query = getSession().createQuery(searchQueryBuilder.toString());
		
		if (null != userId)
		{
			query.setLong("userId",userId);
		}
		List<Object[]> resultList = query.list();
		List<SyncAuditWrapper> syncAuditWrapperList=new ArrayList<SyncAuditWrapper>();
		for (Object[] obj : resultList)
		{

			SystemUser currentSystemUser = (SystemUser) obj[0];
			SyncAudit currentSyncAudit = (SyncAudit) obj[1];

			SyncAuditWrapper syncAuditWrapper = new SyncAuditWrapper();

			syncAuditWrapper.setSyncAudit(currentSyncAudit);
			syncAuditWrapper.setSystemUser(currentSystemUser);

			syncAuditWrapperList.add(syncAuditWrapper);
		}
		
		
		return syncAuditWrapperList;
		
	}
}
