package com.mobicule.icatalog.syncaudit.dao;

import java.sql.Timestamp;
import java.util.List;

import com.mobicule.component.system.db.dao.GenericDataBeanDAO;
import com.mobicule.icatalog.syncaudit.bean.SyncAudit;
import com.mobicule.icatalog.syncaudit.bean.SyncAuditWrapper;

public interface SyncAuditDao extends GenericDataBeanDAO<SyncAudit>
{
	public List<SyncAudit> syncAuditList(SyncAudit syncAudit);
	
	public List<SyncAuditWrapper> doCustomSearch(SyncAudit syncAudit,Timestamp syncDateTimestampDate);
	
	public List<String> masterSearch(SyncAudit syncAudit);
	
	public List<SyncAuditWrapper> syncAuditWrapperDetails(SyncAudit syncAudit);
}
