package com.mobicule.icatalog.customer.bean;

import java.sql.Timestamp;

import com.mobicule.component.db.standardbean.SimpleDataBean;
import com.mobicule.icatalog.systemuser.bean.SystemUser;

public class CustomerShortlist extends SimpleDataBean
{


	private static final long serialVersionUID = 1L;
	
	private Long customerId;
	private Long userId;
	private Timestamp visitedDate;
	private String shortlistedItemType;
	private String shortlistedItemCode;
	/*private List<String> itemTypeList;
	private List<String> itemCodeList;*/
	
	private SystemUser user;
	public CustomerShortlist()
	{
		user=new SystemUser();
	}
	public Long getCustomerId()
	{
		return customerId;
	}
	public void setCustomerId(Long customerId)
	{
		this.customerId = customerId;
	}
	public Long getUserId()
	{
		return userId;
	}
	public void setUserId(Long userId)
	{
		this.userId = userId;
	}
	public Timestamp getVisitedDate()
	{
		return visitedDate;
	}
	public void setVisitedDate(Timestamp visitedDate)
	{
		this.visitedDate = visitedDate;
	}
	public String getShortlistedItemType()
	{
		return shortlistedItemType;
	}
	public void setShortlistedItemType(String shortlistedItemType)
	{
		this.shortlistedItemType = shortlistedItemType;
	}
	public String getShortlistedItemCode()
	{
		return shortlistedItemCode;
	}
	public void setShortlistedItemCode(String shortlistedItemCode)
	{
		this.shortlistedItemCode = shortlistedItemCode;
	}
	@Override
	public String toString()
	{
		StringBuilder builder = new StringBuilder();
		builder.append("CustomerShortlist [\n\tcustomerId=");
		builder.append(customerId);
		builder.append(", \n\tuserId=");
		builder.append(userId);
		builder.append(", \n\tvisitedDate=");
		builder.append(visitedDate);
		builder.append(", \n\tshortlistedItemType=");
		builder.append(shortlistedItemType);
		builder.append(", \n\tshortlistedItemCode=");
		builder.append(shortlistedItemCode);
		builder.append("\n]");
		return builder.toString();
	}
	public SystemUser getUser()
	{
		return user;
	}
	public void setUser(SystemUser user)
	{
		this.user = user;
	}
	
	
}
