/**
******************************************************************************
* C O P Y R I G H T  A N D  C O N F I D E N T I A L I T Y  N O T I C E
* <p>
* Copyright © 2008-2009 Mobicule Technologies Pvt. Ltd. All rights reserved. 
* This is proprietary information of Mobicule Technologies Pvt. Ltd.and is 
* subject to applicable licensing agreements. Unauthorized reproduction, 
* transmission or distribution of this file and its contents is a 
* violation of applicable laws.
******************************************************************************
*
* @project icatalog-core
*/
package com.mobicule.icatalog.customer.bean;

import java.util.ArrayList;
import java.util.List;

import com.mobicule.component.db.standardbean.SimpleDataBean;

/**
* 
* <enter description here>
*
* @author himanshu <Singh>
* @see 
*
* @createdOn 14-May-2012
* @modifiedOn
*
* @copyright © 2008-2009 Mobicule Technologies Pvt. Ltd. All rights reserved.
*/
public class Customer extends SimpleDataBean
{
	private static final long serialVersionUID = 1L;

	private String name;
	private Long contact;
	private String gender;
	private String email;
	private String location;
	private List<CustomerShortlist> shortList;
	
	private String emailStatus;
	private Long emailAttempts;
	
	public Customer()
	{
		shortList=new ArrayList<CustomerShortlist>();
	}
	
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public Long getContact()
	{
		return contact;
	}
	public void setContact(Long contact)
	{
		this.contact = contact;
	}
	public String getGender()
	{
		return gender;
	}
	public void setGender(String gender)
	{
		this.gender = gender;
	}
	public String getEmail()
	{
		return email;
	}
	public void setEmail(String email)
	{
		this.email = email;
	}
	public String getLocation()
	{
		return location;
	}
	public void setLocation(String location)
	{
		this.location = location;
	}
	@Override
	public String toString()
	{
		StringBuilder builder = new StringBuilder();
		builder.append("Customer [\n\tname=");
		builder.append(name);
		builder.append(", \n\tcontact=");
		builder.append(contact);
		builder.append(", \n\tgender=");
		builder.append(gender);
		builder.append(", \n\temail=");
		builder.append(email);
		builder.append(", \n\tlocation=");
		builder.append(location);
		builder.append("\n]");
		return builder.toString();
	}
	public List<CustomerShortlist> getShortList()
	{
		return shortList;
	}
	public void setShortList(List<CustomerShortlist> shortList)
	{
		this.shortList = shortList;
	}

	public String getEmailStatus()
	{
		return emailStatus;
	}

	public void setEmailStatus(String emailStatus)
	{
		this.emailStatus = emailStatus;
	}

	public Long getEmailAttempts()
	{
		return emailAttempts;
	}

	public void setEmailAttempts(Long emailAttempts)
	{
		this.emailAttempts = emailAttempts;
	}
	
	
		
}
