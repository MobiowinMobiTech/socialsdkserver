/**
******************************************************************************
* C O P Y R I G H T  A N D  C O N F I D E N T I A L I T Y  N O T I C E
* <p>
* Copyright © 2008-2009 Mobicule Technologies Pvt. Ltd. All rights reserved. 
* This is proprietary information of Mobicule Technologies Pvt. Ltd.and is 
* subject to applicable licensing agreements. Unauthorized reproduction, 
* transmission or distribution of this file and its contents is a 
* violation of applicable laws.
******************************************************************************
*
* @project icatalog-core
*/
package com.mobicule.icatalog.customer.dao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.springframework.dao.DataAccessException;
import org.springframework.util.CollectionUtils;

import com.mobicule.component.system.db.dao.GenericDataBeanDAO;
import com.mobicule.icatalog.common.dao.AbstractSyncDao;
import com.mobicule.icatalog.core.common.ICatalogConstants;
import com.mobicule.icatalog.core.constants.IcatalogUtility;
import com.mobicule.icatalog.core.constants.SyncConstants;
import com.mobicule.icatalog.customer.bean.Customer;
import com.mobicule.icatalog.customer.bean.CustomerShortlist;
import com.mobicule.icatalog.systemuser.bean.SystemUser;


public class CustomerHibernateDao extends AbstractSyncDao<Customer> implements CustomerDao
{

	private Log log = LogFactory.getLog(this.getClass());

	@SuppressWarnings({ "unchecked", "rawtypes", "unused" })
	@Override
	public String getNewlyAddedEntities(int pageNumber, int pageSize, String login)
	{
		final List<HashMap> customerMapList = new LinkedList<HashMap>();

		if (log.isInfoEnabled())
		{
			log.info("in newly added Entity pagenumber: " + pageNumber);
		}

/*Fetching customer codes and setting page size on that*/
		
		StringBuilder queryForCustEmail = new StringBuilder();
		queryForCustEmail.append("select distinct(c.email) cemail ");
		createQueryForNewEntries(queryForCustEmail);
		
		if (log.isInfoEnabled())
		{
			log.info("in newly added queryForConceptCode: " + queryForCustEmail.toString());
		}

		SQLQuery query1 = getSession().createSQLQuery(queryForCustEmail.toString());
		query1.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);
		

		query1.setFirstResult(pageNumber * pageSize);
		query1.setMaxResults(pageSize);

		List<String> emailList = query1.addScalar("cemail", Hibernate.STRING).list();

		log.info("emailList: " + emailList.size());

		//Fetching data for customer as per previously retrieved code
		StringBuilder queryForNewEntries = new StringBuilder();
		queryForNewEntries.append("select {c.*},{cs.*}, {ut.*} ");
		createQueryForNewEntries(queryForNewEntries);
		appendCustomerEmailWithIn(emailList, queryForNewEntries);

		if (log.isInfoEnabled())
		{
			log.info("in newly added queryForNewEntries: " + queryForNewEntries.toString());
		}

		SQLQuery query = getSession().createSQLQuery(queryForNewEntries.toString());
		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);

		/*query.setFirstResult(pageNumber * pageSize);
		query.setMaxResults(pageSize);*/

		List<Object[]> list = query.addEntity("c", Customer.class).addEntity("cs", CustomerShortlist.class)
				.addEntity("ut", SystemUser.class).list();

		if (log.isInfoEnabled())
		{
			log.info("List size: " + list.size());
		}

		if (log.isDebugEnabled())
		{
			log.debug("list : " + ((list == null) ? "null" : list.size()));
		}

		HashMap<Long, Customer> customerCache = new HashMap<Long, Customer>();

		for (Object[] obj : list)
		{
			Customer currentCustomer = (Customer) obj[0];

			SystemUser currentUser = null;
			CustomerShortlist existingShortlist = null;
			if ((null != obj[2]))
			{
				currentUser = (SystemUser) obj[2];
			}
			if ((null != obj[1]))
			{
				existingShortlist = (CustomerShortlist) obj[1];
			}
			//log.info("existingShortlist.getShortlistedItemType(): "+ existingShortlist.getShortlistedItemType());

			Long currentCustomerId = currentCustomer.getId();
			Customer tempCustomer = null;
			List<CustomerShortlist> tempShortlist = null;

			if (currentCustomer.getDeleteFlag().equalsIgnoreCase("F"))
			{
				// add Customer
				if (!customerCache.containsKey(currentCustomerId))
				{

					tempShortlist = new ArrayList<CustomerShortlist>();
					if (existingShortlist != null)
					{
						log.info("existingShortlist: " + existingShortlist.getDeleteFlag());
						if (existingShortlist.getDeleteFlag().equalsIgnoreCase("F"))
						{

							existingShortlist.setUser(currentUser);

							tempShortlist.add(existingShortlist);

							currentCustomer.setShortList(tempShortlist);
						}
					}

					customerCache.put(currentCustomerId, currentCustomer);

				}
				else
				{

					Customer cust = customerCache.get(currentCustomerId);
					List<CustomerShortlist> existingcustomerShortlist = cust.getShortList();
					log.info("existingShortlist: " + existingShortlist.getDeleteFlag());
					if (existingShortlist.getDeleteFlag().equalsIgnoreCase("F"))
					{
						if (!existingcustomerShortlist.contains(existingShortlist))
						{

							existingShortlist.setUser(currentUser);
							existingcustomerShortlist.add(existingShortlist);
							cust.setShortList(existingcustomerShortlist);

						}
						else
						{
							if (existingShortlist != null)
							{
								existingShortlist.setUser(currentUser);
							}

						}
					}
				}
			}

		}
		formatWrapper(customerMapList, customerCache, "ADD");

		HashMap dataMap = IcatalogUtility.createResponseMessage(customerMapList);

		String response = IcatalogUtility.createJSONFromMap(dataMap);

		return response;
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param queryForNewEntries
	 *
	 * @author shalini

	 * @createdOn 14-May-2012
	 * @modifiedOn 14-May-2012 
	 * 
	 */
	private void createQueryForNewEntries(StringBuilder queryForNewEntries)
	{

		queryForNewEntries.append("  from customer_shortlist cs RIGHT OUTER JOIN customer c ");
		queryForNewEntries.append("on c.id=cs.customer_id  LEFT OUTER JOIN user_table ut on cs.user_id=ut.id ");
		queryForNewEntries.append(" where  (c.delete_flag= :deleteFlag) ");

	}

	@SuppressWarnings("rawtypes")
	private void formatWrapper(List<HashMap> customerMapList, HashMap<Long, Customer> customerCache, String action)

	{
		for (Long key : customerCache.keySet())
		{
			Customer wrapper = new Customer();
			HashMap<String, Object> formattedCustomer = new HashMap<String, Object>();
			List<HashMap> itemList = new ArrayList<HashMap>();

			wrapper = customerCache.get(key);

			formattedCustomer.put("id", wrapper.getId());
			formattedCustomer.put("customer_name", wrapper.getName());
			if (wrapper.getContact() != 0L)
			{
				formattedCustomer.put("customer_contact", wrapper.getContact().toString());
			}
			else
			{
				formattedCustomer.put("customer_contact", ICatalogConstants.EMPTY_STRING);
			}

			formattedCustomer.put("customer_email", wrapper.getEmail());

			
			
			if (wrapper.getGender() != null)
			{
				formattedCustomer.put("customer_gender", wrapper.getGender());
			}
			else
			{
				formattedCustomer.put("customer_gender", ICatalogConstants.EMPTY_STRING);
			}
			formattedCustomer.put("customer_gender", wrapper.getGender());

			if (wrapper.getLocation() != null)
			{
				formattedCustomer.put("customer_location", wrapper.getLocation());
			}
			else
			{
				formattedCustomer.put("customer_location", ICatalogConstants.EMPTY_STRING);
			}
			formattedCustomer.put("customer_location", wrapper.getLocation());

			if (wrapper.getShortList().size() != 0)
			{

				for (int j = 0; j < wrapper.getShortList().size(); j++)
				{
					HashMap<String, Object> itemMap = new HashMap<String, Object>();
					itemMap.put("user_id", wrapper.getShortList().get(j).getUser().getId());
					itemMap.put("user_name", wrapper.getShortList().get(j).getUser().getFirstName() + " "
							+ wrapper.getShortList().get(j).getUser().getLastName());
					log.info("visited_date: " + wrapper.getShortList().get(j).getVisitedDate());
					itemMap.put("visited_date", wrapper.getShortList().get(j).getVisitedDate());

					itemMap.put("item_type", wrapper.getShortList().get(j).getShortlistedItemType());
					itemMap.put("item_code", wrapper.getShortList().get(j).getShortlistedItemCode());
					itemList.add(itemMap);
				}
			}

			formattedCustomer.put("shortlist", itemList);

			if (action.equalsIgnoreCase("add"))
			{
				formattedCustomer.put("sync_flag", "A");
			}
			else if (action.equalsIgnoreCase("modify"))
			{
				formattedCustomer.put("sync_flag", "M");
			}
			else if (action.equalsIgnoreCase("delete"))
			{
				formattedCustomer.put("sync_flag", "D");
			}

			customerMapList.add(formattedCustomer);
		}

	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param login
	 * @return
	 *
	 * @author himanshu
	 * @createdOn 15-May-2012
	 * @modifiedOn 15-May-2012 
	 * 
	 */
	@SuppressWarnings("unchecked")
	@Override
	public int getAddedEntitiesCount(String login)
	{
		StringBuilder queryForNewEntries = new StringBuilder();

		queryForNewEntries.append("select count( distinct(c.email)) custEmail ");
		createQueryForNewEntries(queryForNewEntries);
		SQLQuery query = getSession().createSQLQuery(queryForNewEntries.toString());

		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);

		List<Long> returnValue = query.addScalar("custEmail", Hibernate.LONG).list();

		if (CollectionUtils.isEmpty(returnValue))
		{
			return 0;
		}
		else
		{
			return returnValue.get(0).intValue();
		}
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param lastSyncDate
	 * @param login
	 * @return
	 *
	 * @author himanshu
	 * @createdOn 15-May-2012
	 * @modifiedOn 15-May-2012 
	 * 
	 */
	@SuppressWarnings("unchecked")
	@Override
	public int getNewlyAddedEntitiesAfterSyncDateCount(Timestamp lastSyncDate, String login)
	{
		StringBuilder queryForNewEntries = new StringBuilder();

		queryForNewEntries.append(" select count(distinct c.email) emailCount ");
		createQueryForNewEntriesAfterSyncDate(queryForNewEntries);

		SQLQuery query = getSession().createSQLQuery(queryForNewEntries.toString());

		if (log.isInfoEnabled())
		{
			log.info("query in add: " + queryForNewEntries);
		}

		query.setTimestamp("createdOn", lastSyncDate);
		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);

		List<Long> returnValue = query.addScalar("emailCount", Hibernate.LONG).list();

		if (CollectionUtils.isEmpty(returnValue))
		{
			return 0;
		}
		else
		{
			return returnValue.get(0).intValue();
		}
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param queryForNewEntries
	 *

	 * @author shalini
	 * @createdOn 15-May-2012
	 * @modifiedOn 15-May-2012 

	 * 
	 */
	private void createQueryForNewEntriesAfterSyncDate(StringBuilder queryForNewEntries)
	{
		queryForNewEntries.append("  from customer_shortlist cs RIGHT OUTER JOIN customer c ");
		queryForNewEntries.append("on c.id=cs.customer_id  LEFT OUTER JOIN user_table ut on cs.user_id=ut.id ");
		queryForNewEntries.append(" where  (c.delete_flag= :deleteFlag ) ");
		queryForNewEntries.append("and c.created_on>= :createdOn");

	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param lastSyncDate
	 * @param login
	 * @return
	 *
	 * @author himanshu
	 * @createdOn 15-May-2012
	 * @modifiedOn 15-May-2012 
	 * 
	 */
	@SuppressWarnings("unchecked")
	@Override
	public int getModifiedEntitiesAfterSyncDateCount(Timestamp lastSyncDate, String login)
	{
		StringBuilder queryForModifiedEntries = new StringBuilder();

		queryForModifiedEntries.append(" select count(distinct(c.email)) emailCount ");
		createQueryForModifiedEntries(queryForModifiedEntries);

		if (log.isInfoEnabled())
		{
			log.info("Query: " + queryForModifiedEntries.toString());
		}

		SQLQuery query = getSession().createSQLQuery(queryForModifiedEntries.toString());

		query.setTimestamp("createdOn", lastSyncDate);
		query.setTimestamp("modifiedOn", lastSyncDate);
		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);

		List<Long> returnValue = query.addScalar("emailCount", Hibernate.LONG).list();

		if (CollectionUtils.isEmpty(returnValue))
		{
			return 0;
		}
		else
		{
			return returnValue.get(0).intValue();
		}
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param queryForModifiedEntries
	 *

	 * @author shalini
	 * @createdOn 15-May-2012
	 * @modifiedOn 15-May-2012 

	 * 
	 */
	private void createQueryForModifiedEntries(StringBuilder queryForModifiedEntries)
	{
		queryForModifiedEntries.append("  from customer_shortlist cs RIGHT OUTER JOIN customer c ");
		queryForModifiedEntries.append("on c.id=cs.customer_id  LEFT OUTER JOIN user_table ut on cs.user_id=ut.id ");
		queryForModifiedEntries.append(" where  (c.delete_flag= :deleteFlag ) ");
		queryForModifiedEntries.append("and ((c.created_on< :createdOn and c.modified_on >= :modifiedOn) ");
		queryForModifiedEntries.append("or c.id in (select s.customer_id from customer_shortlist s ");
		queryForModifiedEntries.append("where s.modified_on>= :modifiedOn)) ");

	}

	public  void appendCustomerEmailWithIn(List<String> emailList, StringBuilder queryBuilder)
    {
        if (CollectionUtils.isEmpty(emailList))
        {
            return;
        }

        queryBuilder.append(" and ( ");
        int chunkRemainder = 0;
        boolean isFirstTime = true;

        for (int i = 0; i < emailList.size(); i++)
        {
            String code = emailList.get(i);

            chunkRemainder = (i) % SyncConstants.MAX_IN_QUERY_LIST_SIZE;

            if (chunkRemainder == 0)
            {
                if (isFirstTime)
                {
                    isFirstTime = false;
                }
                else
                {
                	queryBuilder.append(" or ");
                }

                queryBuilder.append(" c.email in  ( '");

                queryBuilder.append(code);

                if (!(chunkRemainder == SyncConstants.MAX_IN_QUERY_LIST_SIZE - 1) && (i < emailList.size() - 1))
                {
                	queryBuilder.append("', '");
                }
                else if (i == (emailList.size() - 1))
                {
                	queryBuilder.append("' ) ");
                }
            }
            else if (chunkRemainder == SyncConstants.MAX_IN_QUERY_LIST_SIZE - 1)
            {
            	queryBuilder.append(code);
            	queryBuilder.append("' ) ");
            }
            else
            {
            	queryBuilder.append(code);

                if (!(chunkRemainder == SyncConstants.MAX_IN_QUERY_LIST_SIZE - 1) && (i < emailList.size() - 1))
                {
                	queryBuilder.append("', '");
                }
                else if (i == (emailList.size() - 1))
                {
                	queryBuilder.append("' ) ");
                }
            }
        }
        
        queryBuilder.append(" )");
    }
	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param lastSyncDate
	 * @return
	 *
	 * @author himanshu
	 * @createdOn 15-May-2012
	 * @modifiedOn 15-May-2012 
	 * 
	 */
	@SuppressWarnings("unchecked")
	@Override
	public int getDeletedEntitiesAfterSyncDateCount(Timestamp lastSyncDate)
	{
		StringBuilder queryForDeletedEntries = new StringBuilder();

		queryForDeletedEntries.append(" select count(distinct c.email) emailCount ");
		createQueryForDeletedEntries(queryForDeletedEntries);

		SQLQuery query = getSession().createSQLQuery(queryForDeletedEntries.toString());
		query.setTimestamp("createdOn", lastSyncDate);
		query.setTimestamp("modifiedOn", lastSyncDate);
		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_TRUE);

		List<Long> returnValue = query.addScalar("emailCount", Hibernate.LONG).list();

		if (CollectionUtils.isEmpty(returnValue))
		{
			return 0;
		}
		else
		{
			return returnValue.get(0).intValue();
		}
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param queryForDeletedEntries
	 *

	 * @author shalini
	 * @createdOn 15-May-2012
	 * @modifiedOn 15-May-2012 

	 * 
	 */
	private void createQueryForDeletedEntries(StringBuilder queryForDeletedEntries)
	{
		queryForDeletedEntries.append("  from  customer c ");
		queryForDeletedEntries.append(" where c.delete_flag= :deleteFlag  ");
		queryForDeletedEntries.append("and c.created_on< :createdOn and c.modified_on >= :modifiedOn ");

	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param lastSyncDate
	 * @param pageNumber
	 * @param pageSize
	 * @param login
	 * @return
	 *
	 * @author himanshu
	 * @createdOn 15-May-2012
	 * @modifiedOn 15-May-2012 
	 * 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@Override
	public String getNewlyAddedEntitiesAfterSyncDate(Timestamp lastSyncDate, int pageNumber, int pageSize, String login)
	{
		final List<HashMap> customerMapList = new LinkedList<HashMap>();

		if (log.isInfoEnabled())
		{
			log.info("in newly added Entity pagenumber: " + pageNumber);
		}
/*Fetching customer codes and setting page size on that*/
		
		StringBuilder queryForCustEmail = new StringBuilder();
		queryForCustEmail.append("select distinct(c.email) cemail ");
		createQueryForNewEntriesAfterSyncDate(queryForCustEmail);
		
		if (log.isInfoEnabled())
		{
			log.info("in newly added queryForCustomerCode: " + queryForCustEmail.toString());
		}

		SQLQuery query1 = getSession().createSQLQuery(queryForCustEmail.toString());
		query1.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);
		query1.setTimestamp("createdOn", lastSyncDate);
		

		query1.setFirstResult(pageNumber * pageSize);
		query1.setMaxResults(pageSize);

		List<String> emailList = query1.addScalar("cemail", Hibernate.STRING).list();

		log.info("emailList: " + emailList.size());

		//Fetching data for customer as per previously retrieved code
		StringBuilder queryForNewEntries = new StringBuilder();
		queryForNewEntries.append("select {c.*},{cs.*}, {ut.*} ");

		createQueryForNewEntriesAfterSyncDate(queryForNewEntries);
		appendCustomerEmailWithIn(emailList, queryForNewEntries);

		if (log.isInfoEnabled())
		{
			log.info("in newly added queryForNewEntries: " + queryForNewEntries.toString());
		}

		SQLQuery query = getSession().createSQLQuery(queryForNewEntries.toString());
		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);
		query.setTimestamp("createdOn", lastSyncDate);

		/*query.setFirstResult(pageNumber * pageSize);
		query.setMaxResults(pageSize);*/

		List<Object[]> list = query.addEntity("c", Customer.class).addEntity("cs", CustomerShortlist.class)
				.addEntity("ut", SystemUser.class).list();

		if (log.isInfoEnabled())
		{
			log.info("List size: " + list.size());
		}

		if (log.isDebugEnabled())
		{
			log.debug("list : " + ((list == null) ? "null" : list.size()));
		}

		HashMap<Long, Customer> customerCache = new HashMap<Long, Customer>();

		for (Object[] obj : list)
		{
			Customer currentCustomer = (Customer) obj[0];

			SystemUser currentUser = null;
			CustomerShortlist existingShortlist = null;
			if ((null != obj[2]))
			{
				currentUser = (SystemUser) obj[2];
			}
			if ((null != obj[1]))
			{
				existingShortlist = (CustomerShortlist) obj[1];
			}

			Long currentCustomerId = currentCustomer.getId();

			List<CustomerShortlist> tempShortlist = null;

			if (currentCustomer.getDeleteFlag().equalsIgnoreCase("F"))
			{
				// add Customer
				if (!customerCache.containsKey(currentCustomerId))
				{

					tempShortlist = new ArrayList<CustomerShortlist>();
					if (existingShortlist != null)
					{
						if (existingShortlist.getDeleteFlag().equalsIgnoreCase("F"))
						{

							existingShortlist.setUser(currentUser);

							tempShortlist.add(existingShortlist);

							currentCustomer.setShortList(tempShortlist);
						}

					}

					customerCache.put(currentCustomerId, currentCustomer);

				}
				else
				{

					Customer cust = customerCache.get(currentCustomerId);
					List<CustomerShortlist> existingcustomerShortlist = cust.getShortList();
					log.info("existingShortlist: " + existingShortlist.getDeleteFlag());

					if (existingShortlist.getDeleteFlag().equalsIgnoreCase("F"))
					{

						if (!existingcustomerShortlist.contains(existingShortlist))
						{

							existingShortlist.setUser(currentUser);
							existingcustomerShortlist.add(existingShortlist);
							cust.setShortList(existingcustomerShortlist);

						}
						else
						{
							if (existingShortlist != null)
							{
								existingShortlist.setUser(currentUser);
							}

						}
					}
				}
			}

		}
		formatWrapper(customerMapList, customerCache, "ADD");

		HashMap dataMap = IcatalogUtility.createResponseMessage(customerMapList);

		String response = IcatalogUtility.createJSONFromMap(dataMap);

		return response;
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param lastSyncDate
	 * @param pageNumber
	 * @param pageSize
	 * @param login
	 * @return
	 *
	 * @author himanshu
	 * @createdOn 15-May-2012
	 * @modifiedOn 15-May-2012 
	 * 
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public String getModifiedEntitiesAfterSyncDate(Timestamp lastSyncDate, int pageNumber, int pageSize, String login)
	{
		final List<HashMap> customerMapList = new LinkedList<HashMap>();

		if (log.isInfoEnabled())
		{
			log.info("in newly added Entity pagenumber: " + pageNumber);
		}

/*Fetching customer codes and setting page size on that*/
		
		StringBuilder queryForCustEmail = new StringBuilder();
		queryForCustEmail.append("select distinct(c.email) cemail ");
		createQueryForModifiedEntries(queryForCustEmail);
		
		if (log.isInfoEnabled())
		{
			log.info("in newly added queryForConceptCode: " + queryForCustEmail.toString());
		}

		SQLQuery query1 = getSession().createSQLQuery(queryForCustEmail.toString());
		query1.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);
		query1.setTimestamp("createdOn", lastSyncDate);
		query1.setTimestamp("modifiedOn", lastSyncDate);
		

		query1.setFirstResult(pageNumber * pageSize);
		query1.setMaxResults(pageSize);

		List<String> emailList = query1.addScalar("cemail", Hibernate.STRING).list();

		log.info("emailList: " + emailList.size());

		//Fetching data for customer as per previously retrieved code
		StringBuilder queryForModifiedEntries = new StringBuilder();
		queryForModifiedEntries.append("select {c.*},{cs.*}, {ut.*} ");

		createQueryForModifiedEntries(queryForModifiedEntries);
		appendCustomerEmailWithIn(emailList, queryForModifiedEntries);

		if (log.isInfoEnabled())
		{
			log.info("in newly added queryForNewEntries: " + queryForModifiedEntries.toString());
		}

		SQLQuery query = getSession().createSQLQuery(queryForModifiedEntries.toString());
		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);
		query.setTimestamp("createdOn", lastSyncDate);
		query.setTimestamp("modifiedOn", lastSyncDate);

		/*query.setFirstResult(pageNumber * pageSize);
		query.setMaxResults(pageSize);*/

		List<Object[]> list = query.addEntity("c", Customer.class).addEntity("cs", CustomerShortlist.class)
				.addEntity("ut", SystemUser.class).list();

		if (log.isInfoEnabled())
		{
			log.info("List size: " + list.size());
		}

		if (log.isDebugEnabled())
		{
			log.debug("list : " + ((list == null) ? "null" : list.size()));
		}

		HashMap<Long, Customer> customerCache = new HashMap<Long, Customer>();

		for (Object[] obj : list)
		{
			Customer currentCustomer = (Customer) obj[0];
			/*log.info(" obj[0]-----" + obj[0]);
			log.info(" obj[1]-----" + obj[1]);
			log.info(" obj[2]-------" + obj[2]);*/
			SystemUser currentUser = null;
			CustomerShortlist existingShortlist = null;
			if ((null != obj[2]))
			{
				currentUser = (SystemUser) obj[2];
			}
			if ((null != obj[1]))
			{
				existingShortlist = (CustomerShortlist) obj[1];
			}

			Long currentCustomerId = currentCustomer.getId();

			List<CustomerShortlist> tempShortlist = null;

			if (currentCustomer.getDeleteFlag().equalsIgnoreCase("F"))
			{

				if (!customerCache.containsKey(currentCustomerId))
				{

					tempShortlist = new ArrayList<CustomerShortlist>();
					if (existingShortlist != null)
					{
						if (existingShortlist.getDeleteFlag().equalsIgnoreCase("F"))
						{

							existingShortlist.setUser(currentUser);

							tempShortlist.add(existingShortlist);

							currentCustomer.setShortList(tempShortlist);
						}

					}

					customerCache.put(currentCustomerId, currentCustomer);

				}
				else
				{

					Customer cust = customerCache.get(currentCustomerId);
					List<CustomerShortlist> existingcustomerShortlist = cust.getShortList();
					log.info("existingShortlist: " + existingShortlist.getDeleteFlag());

					if (existingShortlist.getDeleteFlag().equalsIgnoreCase("F"))
					{

						if (!existingcustomerShortlist.contains(existingShortlist))
						{

							existingShortlist.setUser(currentUser);
							existingcustomerShortlist.add(existingShortlist);
							cust.setShortList(existingcustomerShortlist);

						}
						else
						{
							if (existingShortlist != null)
							{
								existingShortlist.setUser(currentUser);
							}

						}
					}
				}
			}

		}
		formatWrapper(customerMapList, customerCache, "MODIFY");

		HashMap dataMap = IcatalogUtility.createResponseMessage(customerMapList);

		String response = IcatalogUtility.createJSONFromMap(dataMap);

		return response;
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param lastSyncDate
	 * @param pageNumber
	 * @param pageSize
	 * @return
	 *
	 * @author himanshu
	 * @createdOn 15-May-2012
	 * @modifiedOn 15-May-2012 
	 * 
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	public String getDeletedEntitiesAfterSyncDate(Timestamp lastSyncDate, int pageNumber, int pageSize)
	{
		final List<HashMap> customerMapList = new LinkedList<HashMap>();

		if (log.isInfoEnabled())
		{
			log.info("in newly added Entity pagenumber: " + pageNumber);
		}

		StringBuilder queryForDeletedEntries = new StringBuilder();
		queryForDeletedEntries.append("select {c.*} ");
		createQueryForDeletedEntries(queryForDeletedEntries);

		if (log.isInfoEnabled())
		{
			log.info("in newly added queryForNewEntries: " + queryForDeletedEntries.toString());
		}

		SQLQuery query = getSession().createSQLQuery(queryForDeletedEntries.toString());
		query.setTimestamp("createdOn", lastSyncDate);
		query.setTimestamp("modifiedOn", lastSyncDate);
		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_TRUE);

		query.setFirstResult(pageNumber * pageSize);
		query.setMaxResults(pageSize);

		List<Customer> list = query.addEntity("c", Customer.class).list();

		if (log.isInfoEnabled())
		{
			log.info("List size: " + list.size());
		}

		if (log.isDebugEnabled())
		{
			log.debug("list : " + ((list == null) ? "null" : list.size()));
		}

		HashMap<Long, Customer> customerCache = new HashMap<Long, Customer>();

		for (Customer currentCustomer : list)
		{

			Long currentCustomerId = currentCustomer.getId();

			if (!customerCache.containsKey(currentCustomerId))
			{

				customerCache.put(currentCustomerId, currentCustomer);

			}

		}

		formatWrapper(customerMapList, customerCache, "DELETE");

		HashMap dataMap = IcatalogUtility.createResponseMessage(customerMapList);

		String response = IcatalogUtility.createJSONFromMap(dataMap);

		return response;
	}

	@Override
	public String findAllAfterSyncDate(Timestamp lastSyncDate, int pageNumber, int pageSize, String entity)
	{
		return null;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Customer> retrieveAllCustomer()
	{
		//List<Customer> currentList=new ArrayList<Customer>();

		String fetchQuery = " from Customer";

		Query query = getSession().createQuery(fetchQuery);

		List<Customer> currentList = query.list();

		return currentList;

	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param arg0
	 * @return
	 * @throws DataAccessException
	 *
	 * @author himanshu
	 * @createdOn 15-May-2012
	 * @modifiedOn 15-May-2012 
	 * 
	 */

	@SuppressWarnings("unchecked")
	@Override
	public List<Customer> doCustomSearch(Customer customer)
	{
		StringBuilder searchQueryBuilder = new StringBuilder(" from Customer where deleteFlag = :deleteFlag ");

		long customerid = customer.getId();
		System.out.println("----------------IN doCustomSearch----------------" + customerid);

		if (customerid != 0)
		{
			searchQueryBuilder.append("and id=:customerid");
		}

		String searchQuery = searchQueryBuilder.toString();

		System.out.println("QUERY IS " + searchQuery);

		Query query = getSession().createQuery(searchQuery);

		query.setString("deleteFlag", "F");

		if (customerid != 0)
		{
			query.setLong("customerid", customerid);
		}

		List<Customer> customerList = query.list();

		System.out.println("----------------After doCustomSearch and getting List----------------" + customerList);

		return customerList;
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param arg0
	 * @return
	 * @throws DataAccessException
	 *
	 * @author himanshu
	 * @createdOn 17-May-2012
	 * @modifiedOn 17-May-2012 
	 * 
	 */

	@SuppressWarnings("unchecked")
	@Override
	public List<Customer> CustomSearch(Customer customer)
	{
		StringBuilder searchQueryBuilder = new StringBuilder(" from Customer where deleteFlag = :deleteFlag ");

		String searchTags = customer.getName();
		System.out.println("----------------IN doCustomSearch----------------" + searchTags);

		if (null != searchTags)
		{
			searchQueryBuilder.append("  and name like :searchTags ");
		}

		String searchQuery = searchQueryBuilder.toString();

		System.out.println("QUERY IS " + searchQuery);

		Query query = getSession().createQuery(searchQuery);

		query.setString("deleteFlag", "F");

		if (null != searchTags)
		{
			query.setString("searchTags", searchTags + "%");
		}

		List<Customer> customerList = query.list();

		System.out.println("----------------After doCustomSearch and getting List----------------" + customerList);

		return customerList;
	}
}
