package com.mobicule.icatalog.customer.dao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.dao.DataAccessException;

import com.mobicule.icatalog.common.dao.AbstractSyncDao;
import com.mobicule.icatalog.customer.bean.Customer;
import com.mobicule.icatalog.customer.bean.CustomerShortlist;

public class CustomerShortListHibernateDao extends AbstractSyncDao<CustomerShortlist> implements CustomerShortlistDao
{

	private Log log = LogFactory.getLog(this.getClass());

	@Override
	public List<CustomerShortlist> doCustomSearch(CustomerShortlist customerShortlist)
	{

		StringBuilder searchQueryBuilder = new StringBuilder(" from CustomerShortlist where deleteFlag = :deleteFlag ");

		long customerid = customerShortlist.getCustomerId();
		System.out.println("----------------IN doCustomSearch----------------" + customerid);

		if (customerid != 0)
		{
			searchQueryBuilder.append("and customerId=:customerid");
		}

		String searchQuery = searchQueryBuilder.toString();

		System.out.println("QUERY IS " + searchQuery);

		Query query = getSession().createQuery(searchQuery);

		query.setString("deleteFlag", "F");

		if (customerid != 0)
		{
			query.setLong("customerid", customerid);
		}

		List<CustomerShortlist> customerShortlistList = query.list();

		System.out.println("----------------After doCustomSearch and getting List----------------"
				+ customerShortlistList);

		return customerShortlistList;
	}

	@Override
	public List<CustomerShortlist> fetchShortlistForCustomer(Long customerId)
	{
		String fetchQuery = " from CustomerShortlist where customerId=:id";
		Query query = getSession().createQuery(fetchQuery);
		query.setLong("id", customerId);
		List<CustomerShortlist> list = query.list();

		return list;
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param lastSyncDate
	 * @param pageNumber
	 * @param pageSize
	 * @param entity
	 * @return
	 *
	 * @author shalini
	 * @createdOn 17-May-2012
	 * @modifiedOn 17-May-2012 
	 * 
	 */
	@Override
	public String findAllAfterSyncDate(Timestamp lastSyncDate, int pageNumber, int pageSize, String entity)
	{

		return null;
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param pageNumber
	 * @param pageSize
	 * @param login
	 * @return
	 *
	 * @author shalini
	 * @createdOn 17-May-2012
	 * @modifiedOn 17-May-2012 
	 * 
	 */
	@Override
	public String getNewlyAddedEntities(int pageNumber, int pageSize, String login)
	{

		return null;
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param login
	 * @return
	 *
	 * @author shalini
	 * @createdOn 17-May-2012
	 * @modifiedOn 17-May-2012 
	 * 
	 */
	@Override
	public int getAddedEntitiesCount(String login)
	{

		return 0;
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param lastSyncDate
	 * @param login
	 * @return
	 *
	 * @author shalini
	 * @createdOn 17-May-2012
	 * @modifiedOn 17-May-2012 
	 * 
	 */
	@Override
	public int getNewlyAddedEntitiesAfterSyncDateCount(Timestamp lastSyncDate, String login)
	{

		return 0;
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param lastSyncDate
	 * @param login
	 * @return
	 *
	 * @author shalini
	 * @createdOn 17-May-2012
	 * @modifiedOn 17-May-2012 
	 * 
	 */
	@Override
	public int getModifiedEntitiesAfterSyncDateCount(Timestamp lastSyncDate, String login)
	{

		return 0;
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param lastSyncDate
	 * @return
	 *
	 * @author shalini
	 * @createdOn 17-May-2012
	 * @modifiedOn 17-May-2012 
	 * 
	 */
	@Override
	public int getDeletedEntitiesAfterSyncDateCount(Timestamp lastSyncDate)
	{

		return 0;
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param lastSyncDate
	 * @param pageNumber
	 * @param pageSize
	 * @param login
	 * @return
	 *
	 * @author shalini
	 * @createdOn 17-May-2012
	 * @modifiedOn 17-May-2012 
	 * 
	 */
	@Override
	public String getNewlyAddedEntitiesAfterSyncDate(Timestamp lastSyncDate, int pageNumber, int pageSize, String login)
	{

		return null;
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param lastSyncDate
	 * @param pageNumber
	 * @param pageSize
	 * @param login
	 * @return
	 *
	 * @author shalini
	 * @createdOn 17-May-2012
	 * @modifiedOn 17-May-2012 
	 * 
	 */
	@Override
	public String getModifiedEntitiesAfterSyncDate(Timestamp lastSyncDate, int pageNumber, int pageSize, String login)
	{

		return null;
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param lastSyncDate
	 * @param pageNumber
	 * @param pageSize
	 * @return
	 *
	 * @author shalini
	 * @createdOn 17-May-2012
	 * @modifiedOn 17-May-2012 
	 * 
	 */
	@Override
	public String getDeletedEntitiesAfterSyncDate(Timestamp lastSyncDate, int pageNumber, int pageSize)
	{

		return null;
	}
}
