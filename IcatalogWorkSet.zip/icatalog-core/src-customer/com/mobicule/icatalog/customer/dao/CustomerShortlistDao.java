package com.mobicule.icatalog.customer.dao;

import java.util.List;
import java.util.Map;

import com.mobicule.component.system.db.dao.GenericDataBeanDAO;
import com.mobicule.icatalog.common.dao.SyncDao;
import com.mobicule.icatalog.customer.bean.Customer;
import com.mobicule.icatalog.customer.bean.CustomerShortlist;

public interface CustomerShortlistDao extends GenericDataBeanDAO<CustomerShortlist> 
{
	List<CustomerShortlist> doCustomSearch(CustomerShortlist customerShortlist);

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param customerId
	 * @return
	 *
	 * @author shalini
	 * @createdOn 16-May-2012
	 * @modifiedOn 16-May-2012 
	 * 
	 */
	public List<CustomerShortlist> fetchShortlistForCustomer(Long customerId);
}
