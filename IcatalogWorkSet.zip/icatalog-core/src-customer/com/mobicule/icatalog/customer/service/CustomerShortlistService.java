package com.mobicule.icatalog.customer.service;

import java.util.List;

import com.mobicule.icatalog.concept.bean.Concept;
import com.mobicule.icatalog.core.common.MailReport;
import com.mobicule.icatalog.customer.bean.Customer;
import com.mobicule.icatalog.customer.bean.CustomerShortlist;
import com.mobicule.icatalog.customer.dao.CustomerShortlistDao;
import com.mobicule.icatalog.entity.service.EntityService;
import com.mobicule.icatalog.product.bean.ProductWrapper;

public interface CustomerShortlistService extends EntityService<CustomerShortlist, CustomerShortlistDao>
{
	public List<CustomerShortlist> doCustomSearch(CustomerShortlist customerShortlist);

	public List<CustomerShortlist> fetchShortlistForCustomer(Long customerId);

	public List<CustomerShortlist> extractCustomerShortlistsOnCustomer(Customer customer);

	public boolean createEmail(String email, String name, String visitedDate, List<Concept> shortlistConcepts,
			List<ProductWrapper> shortlistedProductList, List<String> imageBasePath);
}
