/**
******************************************************************************
* C O P Y R I G H T  A N D  C O N F I D E N T I A L I T Y  N O T I C E
* <p>
* Copyright © 2008-2009 Mobicule Technologies Pvt. Ltd. All rights reserved. 
* This is proprietary information of Mobicule Technologies Pvt. Ltd.and is 
* subject to applicable licensing agreements. Unauthorized reproduction, 
* transmission or distribution of this file and its contents is a 
* violation of applicable laws.
******************************************************************************
*
* @project icatalog-core
*/
package com.mobicule.icatalog.customer.service;

import java.sql.Timestamp;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.mobicule.icatalog.core.common.ICatalogConstants;
import com.mobicule.icatalog.customer.bean.Customer;
import com.mobicule.icatalog.customer.dao.CustomerDao;
import com.mobicule.icatalog.entity.service.EntityServiceImpl;
import com.mobicule.icatalog.entity.service.SyncService;

/**
* 
* <enter description here>
*
* @author himanshu <Singh>
* @see 
*
* @createdOn 14-May-2012
* @modifiedOn
*
* @copyright © 2008-2009 Mobicule Technologies Pvt. Ltd. All rights reserved.
*/
public class CustomerServiceImpl extends EntityServiceImpl<Customer, CustomerDao> implements CustomerService,
		SyncService
{

	private Log log = LogFactory.getLog(this.getClass());

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param lastSyncDate
	 * @param pageNumber
	 * @param pageSize
	 * @param entity
	 * @param action
	 * @param login
	 * @return
	 *
	 * @author himanshu
	 * @createdOn 14-May-2012
	 * @modifiedOn 14-May-2012 
	 * 
	 */
	@Override
	public String fetchAllAfterSyncDate(Timestamp lastSyncDate, int pageNumber, int pageSize, String entity,
			String action, String login)
	{
		if (log.isInfoEnabled())
		{
			log.info("In service Impl: " + lastSyncDate + ", " + pageNumber);
		}
		return getGenericDataBeanDAO().fetchAllAfterSyncDate(lastSyncDate, pageNumber, pageSize, entity, action, login);

	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @return
	 *
	 * @author shalini
	 * @createdOn 16-May-2012
	 * @modifiedOn 16-May-2012 
	 * 
	 */
	@Override
	public List<Customer> retrieveAllCustomer()
	{
		List<Customer> customerList = getGenericDataBeanDAO().retrieveAllCustomer();
		return customerList;
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param currentCustomer
	 * @return
	 *
	 * @author shalini
	 * @createdOn 16-May-2012
	 * @modifiedOn 16-May-2012 
	 * 
	 */
	@Override
	public Long searchCustomerBean(Customer currentCustomer)
	{
		log.info("customer in service: "+ currentCustomer);
		List<Customer> customerList=getGenericDataBeanDAO().findMatchingBeans(currentCustomer);
		log.info("customerList in service"+ customerList.size());
		Long custId=null;
		if(customerList!=null || customerList.size()!=0)
		{
			custId=customerList.get(0).getId();
		}
		
		return custId;
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param customer
	 * @return
	 *
	 * @author himanshu
	 * @createdOn 15-May-2012
	 * @modifiedOn 15-May-2012 
	 * 
	 */
	@Override
	public List<Customer> doCustomSearch(Customer customer)
	{
		return getGenericDataBeanDAO().doCustomSearch(customer);
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param customer
	 * @return
	 *
	 * @author himanshu
	 * @createdOn 17-May-2012
	 * @modifiedOn 17-May-2012 
	 * 
	 */
	@Override
	public List<Customer> CustomSearch(Customer customer)
	{
		return getGenericDataBeanDAO().CustomSearch(customer);
	}

	@Override
	public List<Customer> extractCustomersOnEmailStatus(String emailStatus)
	{
		Customer customer = new Customer();
		
		customer.setEmailStatus(emailStatus);
		customer.setDeleteFlag(ICatalogConstants.FLAG_FALSE);
		
		List<Customer> customerList = getGenericDataBeanDAO().findMatchingBeans(customer);
		
		return customerList;
	}	
}
