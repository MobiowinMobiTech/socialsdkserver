package com.mobicule.icatalog.customer.service;

import java.sql.Timestamp;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.mobicule.icatalog.concept.bean.Concept;
import com.mobicule.icatalog.core.common.ICatalogConstants;
import com.mobicule.icatalog.core.common.MailReport;
import com.mobicule.icatalog.customer.bean.Customer;
import com.mobicule.icatalog.customer.bean.CustomerShortlist;
import com.mobicule.icatalog.customer.dao.CustomerShortlistDao;
import com.mobicule.icatalog.entity.service.EntityServiceImpl;
import com.mobicule.icatalog.entity.service.SyncService;
import com.mobicule.icatalog.product.bean.ProductWrapper;

public class CustomerShortlistServiceImpl extends EntityServiceImpl<CustomerShortlist, CustomerShortlistDao> implements
		CustomerShortlistService, SyncService
{

	private Log log = LogFactory.getLog(this.getClass());
	
	private MailReport mailReport;

	public MailReport getMailReport()
	{
		return mailReport;
	}

	public void setMailReport(MailReport mailReport)
	{
		this.mailReport = mailReport;
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param lastSyncDate
	 * @param pageNumber
	 * @param pageSize
	 * @param entity
	 * @param action
	 * @return
	 *
	 * @author shalini
	 * @createdOn 06-Apr-2012
	 * @modifiedOn 06-Apr-2012 
	 * 
	 */
	@Override
	public String fetchAllAfterSyncDate(Timestamp lastSyncDate, int pageNumber, int pageSize, String entity,
			String action, String login)
	{
		return null;
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param customerId
	 * @return
	 *
	 * @author shalini
	 * @createdOn 16-May-2012
	 * @modifiedOn 16-May-2012 
	 * 
	 */
	@Override
	public List<CustomerShortlist> fetchShortlistForCustomer(Long customerId)
	{

		List<CustomerShortlist> customerShortlists = getGenericDataBeanDAO().fetchShortlistForCustomer(customerId);
		return customerShortlists;
	}

	@Override
	public List<CustomerShortlist> doCustomSearch(CustomerShortlist customerShortlist)
	{
		return getGenericDataBeanDAO().doCustomSearch(customerShortlist);
	}

	@Override
	public List<CustomerShortlist> extractCustomerShortlistsOnCustomer(Customer customer)
	{
		CustomerShortlist customerShortlist = new CustomerShortlist();
		
		customerShortlist.setCustomerId(customer.getId());
		customerShortlist.setDeleteFlag(ICatalogConstants.FLAG_FALSE);
		
		List<CustomerShortlist> customerShortlistList = getGenericDataBeanDAO().findMatchingBeans(customerShortlist);

		return customerShortlistList;
	}

	public boolean createEmail(String email, String name, String visitedDate, List<Concept> shortlistConcepts,
			List<ProductWrapper> shortlistedProductList, List<String> imageBasePath)
	{
		try
		{
			StringBuilder shortlist = new StringBuilder();
			String custName = null;
			shortlist.append("<table>");
			if (shortlistedProductList != null || shortlistedProductList.size() != 0)
			{
				log.info("shorlist size" + shortlistedProductList.size());
				for (int i = 0; i < shortlistedProductList.size(); i++)
				{
					//log.info("shortListedProduct: "+ shortlistedProductList.get(i).getProduct().getCode() );
					formatProductShortlist(shortlist, shortlistedProductList.get(i), imageBasePath);
				}
			}
			if (shortlistConcepts != null || shortlistConcepts.size() != 0)
			{
				for (int i = 0; i < shortlistConcepts.size(); i++)
				{
					formatConceptShortlist(shortlist, shortlistConcepts.get(i), imageBasePath);
				}
			}
			shortlist.append("</table>");
			if (null == name)
			{
				custName = " ";

			}
			else
			{
				custName = name;
			}

			return (mailReport.sendMail(email, shortlist.toString(), custName, "Your favorites at Home Stop!", "","", ""));
		}
		catch (Exception e)
		{
			e.printStackTrace();
			
			return false;
		}
	}

	private void formatConceptShortlist(StringBuilder shortlist, Concept concept, List<String> imageBasePath)
	{

		String imageName = configurePath("concept", concept.getCode(), imageBasePath);

		shortlist.append("<tr><td>");
		shortlist.append("<img src=\"" + imageName + "\" height=50 width=50 alt=demo></img></td>");
		shortlist.append("<td>" + concept.getCode() + "</td>");
		shortlist.append("<td>" + concept.getName() + "</td>");
		shortlist.append("<td>" + concept.getRetailPrice() + "</td>");
		shortlist.append("</tr>");

	}

	private void formatProductShortlist(StringBuilder shortlist, ProductWrapper productWrapper,
			List<String> imageBasePath)
	{
		String imageName = configurePath("product", productWrapper.getProduct().getCode(), imageBasePath);

		shortlist.append("<tr><td>");
		shortlist.append("<img src=\"" + imageName + "\" height=50 width=50 alt=demo></img></td>");
		shortlist.append("<td>" + productWrapper.getProduct().getCode() + "</td>");
		shortlist.append("<td>" + productWrapper.getProduct().getName() + "</td>");
		shortlist.append("<td>" + productWrapper.getPrice().getRetailPrice() + "</td>");
		shortlist.append("</tr>");

	}

	private String configurePath(String entity, String imageName, List<String> imageBasePath)
	{
		log.info("imagePath: " + imageBasePath.size());
		String servletPath = imageBasePath.get(0);
		//String parameter = imageBasePath.get(1);

		String imgPath = servletPath.concat("/" + entity + "/").concat(imageName).concat(".png");
		System.out.println("imgPath: " + imgPath);
		return imgPath;
	}
}
