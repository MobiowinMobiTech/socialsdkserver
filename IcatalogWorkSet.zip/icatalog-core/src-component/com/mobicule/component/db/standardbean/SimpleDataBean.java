package com.mobicule.component.db.standardbean;

import java.io.Serializable;
import java.sql.Timestamp;

import com.mobicule.component.system.db.DataBean;

public class SimpleDataBean implements Serializable, DataBean
{

	private static final long serialVersionUID = 1L;

	private Long id;

	private Long createdBy;

	private Long modifiedBy;

	private Timestamp createdOn;

	private Timestamp modifiedOn;

	private String deleteFlag;

	//private String syncFlag;

	public SimpleDataBean(Long id, Long createdBy, Long modifiedBy, Timestamp createdOn, Timestamp modifiedOn,
			String deleteFlag)
	{
		super();
		this.id = id;
		this.createdBy = createdBy;
		this.modifiedBy = modifiedBy;
		this.createdOn = createdOn;
		this.modifiedOn = modifiedOn;
		this.deleteFlag = deleteFlag;
	}

	public SimpleDataBean()
	{
		super();

	}

	public Long getId()
	{
		return id;
	}

	public void setId(Long id)
	{
		this.id = id;
	}

	@Override
	public Long getCreatedBy()
	{
		return createdBy;
	}

	@Override
	public void setCreatedBy(Long createdBy)
	{
		this.createdBy = createdBy;
	}

	@Override
	public Long getModifiedBy()
	{
		return modifiedBy;
	}

	@Override
	public void setModifiedBy(Long modifiedBy)
	{
		this.modifiedBy = modifiedBy;
	}

	@Override
	public Timestamp getCreatedOn()
	{
		return createdOn;
	}

	@Override
	public void setCreatedOn(Timestamp createdOn)
	{
		this.createdOn = createdOn;
	}

	@Override
	public Timestamp getModifiedOn()
	{
		return modifiedOn;
	}

	@Override
	public void setModifiedOn(Timestamp modifiedOn)
	{
		this.modifiedOn = modifiedOn;
	}

	@Override
	public String getDeleteFlag()
	{
		return deleteFlag;
	}

	@Override
	public void setDeleteFlag(String deleteFlag)
	{
		this.deleteFlag = deleteFlag;
	}

	@Override
	public String toString()
	{
		StringBuilder builder = new StringBuilder();
		builder.append("SimpleDataBean [id=");
		builder.append(id);
		builder.append(", createdBy=");
		builder.append(createdBy);
		builder.append(", modifiedBy=");
		builder.append(modifiedBy);
		builder.append(", createdOn=");
		builder.append(createdOn);
		builder.append(", modifiedOn=");
		builder.append(modifiedOn);
		builder.append(", deleteFlag=");
		builder.append(deleteFlag);
		builder.append("]");
		return builder.toString();
	}

	/*public String getSyncFlag()
	{
		return syncFlag;
	}

	public void setSyncFlag(String syncFlag)
	{
		this.syncFlag = syncFlag;
	}*/
}
