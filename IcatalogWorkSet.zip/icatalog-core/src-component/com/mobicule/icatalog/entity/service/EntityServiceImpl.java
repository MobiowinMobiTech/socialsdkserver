package com.mobicule.icatalog.entity.service;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.mobicule.component.db.standardbean.SimpleDataBean;
import com.mobicule.component.system.db.dao.GenericDataBeanDAO;

public class EntityServiceImpl<T extends SimpleDataBean, E extends GenericDataBeanDAO<T>> implements
		EntityService<T, E>

{
	private Log log = LogFactory.getLog(getClass());

	private Class<T> entityClass;

	private E genericDataBeanDAO;

	public void setEntityClass(Class<T> entityClass)
	{
		this.entityClass = entityClass;
	}

	public E getGenericDataBeanDAO()
	{
		return genericDataBeanDAO;
	}

	public void setGenericDataBeanDAO(E genericDataBeanDAO)
	{
		this.genericDataBeanDAO = genericDataBeanDAO;
	}

	@Override
	public boolean add(T entity)
	{
		if (entity == null)
		{
			log.error("entity is null");
			return false;
		}

		if (entity.getId() != null)
		{
			log.error("entity id is not null");
			return false;
		}

		try
		{
			genericDataBeanDAO.add(entity);

			return true;
		}
		catch (Exception e)
		{
			log.error("entity not added", e);

			return false;
		}
	}

	@Override
	public boolean update(T entity)
	{
		if (entity == null)
		{
			return false;
		}

		if (entity.getId() == null)
		{
			return false;
		}

		try
		{
			genericDataBeanDAO.update(entity);

			return true;
		}
		catch (Exception e)
		{
			return false;
		}
	}

	@Override
	public boolean delete(T entity)
	{
		if (entity == null)
		{
			return false;
		}

		if (entity.getId() == null)
		{
			return false;
		}

		try
		{
			genericDataBeanDAO.softDelete(entity);

			return true;
		}
		catch (Exception e)
		{
			return false;
		}
	}

	@Override
	public List<T> search(T searchEntity)
	{

		try
		{
			log.info(" Searching entity " + searchEntity.getClass());
			return genericDataBeanDAO.findMatchingBeans(searchEntity);
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}

}
