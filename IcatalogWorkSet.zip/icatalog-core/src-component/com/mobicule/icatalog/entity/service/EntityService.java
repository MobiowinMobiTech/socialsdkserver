package com.mobicule.icatalog.entity.service;

import java.util.List;

import com.mobicule.component.system.db.DataBean;
import com.mobicule.component.system.db.dao.GenericDataBeanDAO;

public interface EntityService<T extends DataBean, E extends GenericDataBeanDAO<T>>
{

	public List<T> search(T searchEntity);

	public boolean add(T entity);

	public boolean update(T entity);

	public boolean delete(T entity);

}
