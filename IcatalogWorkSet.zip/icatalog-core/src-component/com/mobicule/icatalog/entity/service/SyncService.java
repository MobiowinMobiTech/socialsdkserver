package com.mobicule.icatalog.entity.service;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;

public interface SyncService
{
	
	public String fetchAllAfterSyncDate(Timestamp lastSyncDate, int pageNumber, int pageSize,
			String entity, String action, String login);

	
}
