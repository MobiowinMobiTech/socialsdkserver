package com.mobicule.icatalog.core.constants;

public class JsonKeyConstants
{
	public static final String MESSAGE = "message";

	public static final String STATUS = "status";

	public static final String DATA = "data";

	public static final String ERROR = "error";

	public static final String TYPE = "type";

	public static final String ENTITY = "entity";

	public static final String ACTION = "action";

	public static final String SUCCESS = "success";

	public static final String DSE_CODE = "dseCode";

	public static final String CIRCLE_CODE = "circleCode";

	public static final String ITEM_GROUP_TYPE_CODE = "itemGroupTypeCode";

	public static final String COMPANY_LIST = "companyList";

	public static final String NAME = "name";

	public static final String CODE = "code";

	public static final String CHEQUE_DATE = "chequeDate";

	public static final String RECEIPT_DATE = "receiptDate";

	public static final String FROM_DATE = "fromDate";

	public static final String TO_DATE = "toDate";

	public static final String LAST_SYNC_DATE = "lastSyncDate";

	public static final String PAGE_SIZE = "pageSize";

	public static final String PAGE_NUMBER = "pageNumber";

	public static final String SERVER_DATE = "serverDate";

	public static final String USER = "user";

	public static final String LINE_ITEMS = "lineItems";

	public static final String COMPANY_CODE = "companyCode";

	public static final String PASSWORD = "password";

	public static final String TYPE_LOGIN = "login";

	public static final String TYPE_SYNC = "sync";

	public static final String SERIAL_NUMBER_GROUP = "serialNumberGroup";

	public static final String SERIAL_NUMBER_LIST = "serialNumberList";

	public static final String INVOICE_DATE = "invoiceDate";

}
