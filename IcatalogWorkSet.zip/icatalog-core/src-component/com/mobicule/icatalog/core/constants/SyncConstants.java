package com.mobicule.icatalog.core.constants;

public class SyncConstants
{
	public static String IS_ACTIVE_FLAG = "Y";

	public static String IS_INACTIVE_FLAG = "N";

	public static String INIT = "init";

	public static String ADD = "add";

	public static String MODIFY = "modify";

	public static String DELETE = "delete";
	
	public static String IMAGE = "image";

	public static String COMPLETION = "completion";

	public static final String COMPLETION_IMAGE = "completionImage";
//	
  //public static String IMGPATH="/home/shalini/Pictures/images/";
	

   public static String IMGPATH="/home/mobicule/iCatalog/images/";
   
   public static int MAX_IN_QUERY_LIST_SIZE=20;


}
