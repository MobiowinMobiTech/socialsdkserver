package com.mobicule.icatalog.core.constants;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.codehaus.jackson.map.ObjectMapper;

public class IcatalogUtility
{
	private static ObjectMapper objectMapper = new ObjectMapper();
	
//	@Resource(name="imageConfig")
//	private HashMap<String, String> imagePath;
	
	public static String createJSONFromMap(Map<String,Object> dataMap)
	{
		try
		{
			ByteArrayOutputStream baos = new ByteArrayOutputStream();

			objectMapper.writeValue(baos, dataMap);

			return baos.toString();
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}

	public static String createErrorMessage()
	{
		try
		{
			Map errorMap = new HashMap();
			List<Map> lists = new ArrayList<Map>();

			errorMap.put(JsonKeyConstants.STATUS, JsonKeyConstants.ERROR);
			errorMap.put(JsonKeyConstants.MESSAGE, "Some error has occured.Please Try Again");
			errorMap.put(JsonKeyConstants.DATA, lists);

			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			objectMapper.writeValue(baos, errorMap);

			return baos.toString();
		}
		catch (Exception e)
		{
			e.printStackTrace();
			return null;
		}
	}

	public static String getEntity(String data)
	{
		int position = data.indexOf("_");

		System.out.println("position is " + position);

		return data.substring(0, position);
	}

	public static String getCode(String data)
	{
		int position = data.indexOf("_");

		System.out.println("position is " + position);

		return data.substring(position + 1);
	}
	
	public static HashMap createResponseMessage(final List<HashMap> dataMapList)
	{
		HashMap dataMap = new HashMap();

		dataMap.put("status", "success");
		if (CollectionUtils.isEmpty(dataMapList))
		{
			dataMap.put("message", String.valueOf(System.currentTimeMillis()));
		}
		else
		{
			dataMap.put("message", "");
		}
		dataMap.put("data", dataMapList);

		return dataMap;
	}
	
	public static List<String> fetchImageList(String basePath,String entity,String code)
	{
		String path=basePath.concat(entity);
		/*System.out.println(imagePath);
		String path=imagePath.get("IMAGE_BASE_PATH").concat(entity);*/
		System.out.println("image path: "+ path);
		List<String> fileList=new ArrayList<String>();
		File dir=new File(path);
		
		if(dir.isDirectory())
		{
			String[] fileArray=dir.list();
			for(String file: fileArray )
			{
				if(file.startsWith(code))
				{
					if(file.substring(0, code.length()).equalsIgnoreCase(code))
					{
					
					String fileName=file.substring(0,file.indexOf("."));
					System.out.println("img fileName: "+ fileName);
					fileList.add(fileName);
					}
				}
			}
			 
		}
		
		return fileList;
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param message
	 * @param dataMap
	 * @return
	 *
	 * @author shalini
	 * @createdOn 27-Apr-2012
	 * @modifiedOn 27-Apr-2012 
	 * 
	 */
	public static HashMap createLoginResponse(String message, List<Map> dataMap)
	{
		HashMap responseMap = new HashMap();

		
		if (dataMap.isEmpty())
		{
			responseMap.put("status", "failure");
			responseMap.put("message", message);
		}
		else
		{
			responseMap.put("status", "success");
			responseMap.put("message", message);
		}
		responseMap.put("data", dataMap);

		return responseMap;
	}
}
