package com.mobicule.icatalog.common.dao;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.mobicule.component.db.standardbean.SimpleDataBean;
import com.mobicule.component.db.standardbean.StandardBean;
import com.mobicule.component.system.db.dao.GenericDataBeanHibernateDAO;
import com.mobicule.icatalog.core.constants.IcatalogUtility;
import com.mobicule.icatalog.core.constants.SyncConstants;

public abstract class AbstractSyncDao<T extends SimpleDataBean> extends GenericDataBeanHibernateDAO<T> implements
		SyncDao
{
	private Log log = LogFactory.getLog(getClass());

	@Override
	public String fetchAllAfterSyncDate(Timestamp lastSyncDate, int pageNumber, int pageSize, String entity,
			String action, String login)
	{
		if (lastSyncDate.equals(new Timestamp(0)))
			log.info("it is equal" + lastSyncDate);
		else
			log.info("it is not equal" + lastSyncDate);

		if (action.equalsIgnoreCase(SyncConstants.INIT))
		{
			HashMap<String, Integer> pagesMap = getTotalPages(lastSyncDate, pageNumber, pageSize, entity, login);
			List<HashMap> mapList = new LinkedList<HashMap>();

			mapList.add(pagesMap);
			HashMap responseMap = IcatalogUtility.createResponseMessage(mapList);
			
			responseMap.put("message", String.valueOf(System.currentTimeMillis()));
			
			String response = IcatalogUtility.createJSONFromMap(responseMap);
			return response;
		}
		else if (action.equalsIgnoreCase(SyncConstants.ADD))
		{
			if ((lastSyncDate == null) || (lastSyncDate.equals(new Timestamp(0))))
			{
				log.info("--------------------------- DOING COMPLETE SYNC FOR ENTITY------" + entity + pageNumber + ","
						+ pageSize);
				String newlyAddedEntities = getNewlyAddedEntities(pageNumber, pageSize, login);
				log.info("newlyAddedEntities: " + newlyAddedEntities);
				return newlyAddedEntities;
			}
			else
			{
				log.info("--------------------------- GOING TO FETCH NEWLY ADDED ENTRIES FOR ENTITY----------------------------"
						+ entity);
				String newlyAddedEntities = getNewlyAddedEntitiesAfterSyncDate(lastSyncDate, pageNumber, pageSize,
						login);
				return newlyAddedEntities;
			}
		}
		else if (action.equalsIgnoreCase(SyncConstants.MODIFY))
		{
			log.info("--------------------------- GOING TO FETCH MODIFIED  ENTRIES FOR ENTITY------------" + entity);
			String modifiedEntities = getModifiedEntitiesAfterSyncDate(lastSyncDate, pageNumber, pageSize, login);
			return modifiedEntities;
		}
		else if (action.equalsIgnoreCase(SyncConstants.DELETE))
		{
			log.info("--------------------------- GOING TO FETCH DELETED  ENTRIES FOR ENTITY------------" + entity);
			String deletedEntities = getDeletedEntitiesAfterSyncDate(lastSyncDate, pageNumber, pageSize);
			return deletedEntities;
		}
		else if ((action.equalsIgnoreCase(SyncConstants.COMPLETION))
				|| (action.equalsIgnoreCase(SyncConstants.COMPLETION_IMAGE)))
		{
			List<HashMap> mapList = new LinkedList<HashMap>();
			HashMap responseMap = IcatalogUtility.createResponseMessage(mapList);
			String response = IcatalogUtility.createJSONFromMap(responseMap);
			return response;
		}
		
		return null;
	}

	@Override
	public HashMap<String, Integer> getTotalPages(Timestamp lastSyncDate, int pageNumber, int pageSize, String entity,
			String login)
	{
		HashMap<String, Integer> pageMap = new HashMap<String, Integer>();
		int addPages = 0;
		int modifyPages = 0;
		int deletePages = 0;

		log.info("LastSyncDate: " + lastSyncDate);

		if ((lastSyncDate == null) || (lastSyncDate.equals(new Timestamp(0))))
		{
			int addedCount = getAddedEntitiesCount(login);
			log.info("Added count: " + addedCount);
			addPages = getPages(pageSize, addedCount);
			log.info("addPages: " + addPages);
		}
		else
		{
			int addCount = getNewlyAddedEntitiesAfterSyncDateCount(lastSyncDate, login);
			int modifyCount = getModifiedEntitiesAfterSyncDateCount(lastSyncDate, login);
			int deleteCount = getDeletedEntitiesAfterSyncDateCount(lastSyncDate);

			log.info("addCount: " + addCount + " modifyCount: " + modifyCount + " deleteCount: " + deleteCount);

			addPages = getPages(pageSize, addCount);
			modifyPages = getPages(pageSize, modifyCount);
			deletePages = getPages(pageSize, deleteCount);

		}
		createPageMap(pageMap, addPages, modifyPages, deletePages);
		log.info("page map is " + pageMap);

		return pageMap;

	}

	@Override
	public void createPageMap(HashMap<String, Integer> pageMap, int addPages, int modifyPages, int deletePages)
	{
		pageMap.put(SyncConstants.ADD, addPages);
		pageMap.put(SyncConstants.MODIFY, modifyPages);
		pageMap.put(SyncConstants.DELETE, deletePages);
	}

	public int getPages(int pageSize, int totalCount)
	{
		int pages;
		float addedPageNumbers = (float) totalCount / pageSize;
		pages = (int) Math.ceil(addedPageNumbers);
		return pages;
	}

}
