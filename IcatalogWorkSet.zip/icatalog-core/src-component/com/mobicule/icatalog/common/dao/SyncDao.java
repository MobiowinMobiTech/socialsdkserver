package com.mobicule.icatalog.common.dao;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;

public interface SyncDao 
{
	public String findAllAfterSyncDate( Timestamp lastSyncDate, int pageNumber, int pageSize,
			String entity);

	//public String getNewlyAddedEntities( int pageNumber, int pageSize);
	
	public String getNewlyAddedEntities( int pageNumber, int pageSize,String login);

	public int getAddedEntitiesCount(String login);

	public int getNewlyAddedEntitiesAfterSyncDateCount( Timestamp lastSyncDate,String login);

	public int getModifiedEntitiesAfterSyncDateCount( Timestamp lastSyncDate,String login);

	public int getDeletedEntitiesAfterSyncDateCount( Timestamp lastSyncDate);

	/*public String getNewlyAddedEntitiesAfterSyncDate( Timestamp lastSyncDate, int pageNumber,
			int pageSize);

	public String getModifiedEntitiesAfterSyncDate( Timestamp lastSyncDate, int pageNumber,
			int pageSize);*/
	
	public String getNewlyAddedEntitiesAfterSyncDate( Timestamp lastSyncDate, int pageNumber,
			int pageSize,String login);

	public String getModifiedEntitiesAfterSyncDate( Timestamp lastSyncDate, int pageNumber,
			int pageSize,String login);

	public String getDeletedEntitiesAfterSyncDate( Timestamp lastSyncDate, int pageNumber,
			int pageSize);


	public String fetchAllAfterSyncDate(Timestamp lastSyncDate, int pageNumber, int pageSize,
			String entity, String action,String login);

	public HashMap<String, Integer> getTotalPages(Timestamp lastSyncDate, int pageNumber,
			int pageSize, String entity,String login);
	
	public int getPages(int pageSize, int totalCount);
	
	public void createPageMap(HashMap<String, Integer> pageMap, int addPages, int modifyPages, int deletePages);
}
