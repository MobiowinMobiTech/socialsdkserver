package com.mobicule.icatalog.concept.service;

import java.sql.Timestamp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.mobicule.icatalog.concept.bean.Concept;
import com.mobicule.icatalog.concept.bean.ConceptHotspotMapping;

@ContextConfiguration(locations = { "file:/home/shailini/workspace/icatalog-core/config/spring/spring-config.xml" })
@Test(groups = { "init" })
public class ConceptTest extends AbstractTestNGSpringContextTests
{
 

	@Autowired
	private ConceptService conceptService;
	
	@BeforeClass
	protected void setUp()
	{
		Assert.assertNotNull(conceptService);
	}

	@Test(enabled=false)
	public void testAdd()
	{
		System.out.println("Concept   add  "+conceptService);
		
		Concept concept = new Concept();
	
		concept.setCode("Con03");
		concept.setName("ConceptA");
		concept.setDescription("ConceptA");
		//concept.setTitle("ConceptA");
		concept.setCategoryId(1L);
		concept.setRetailPrice(4523.0);
		concept.setOfferFlag("N");
		concept.setCreatedBy(225L);
		concept.setModifiedBy(225L);
	//	concept.setModifiedOn(new Timestamp(System.currentTimeMillis()));
		//concept.setDeleteFlag("F");
		//concept.setCreatedOn("22/03/2012");*/
		boolean result=conceptService.add(concept);
		
		System.out.println("Result: "+ result);
	}
	@Test(enabled=false)
	public void testUpdate()
	{
		System.out.println("Concept   update  "+conceptService);
		
		Concept concept = new Concept();
		concept.setId(1L);
		//concept.setCode("Con02");
		concept.setName("ConceptA");
		concept.setDescription("New Desc");
		concept.setCreatedBy(255L);
		concept.setModifiedBy(5L);
		concept.setModifiedOn(new Timestamp(System.currentTimeMillis()));
		concept.setDeleteFlag("F");
		//concept.setCreatedOn("22/03/2012");
		boolean result=conceptService.update(concept);
		
		System.out.println("Result: "+ result);
	}
	
	@Test(enabled=false)
	public void testDelete()
	{
		System.out.println("Concept   delete  "+conceptService);
		
		Concept concept = new Concept();
		concept.setId(1L);
		concept.setCode("Con02");
		concept.setName("ConceptA");
		concept.setDescription("Desc");
		concept.setCreatedBy(225L);
		concept.setModifiedBy(5L);
		/*concept.setModifiedOn(new Timestamp(System.currentTimeMillis()));
		concept.setDeleteFlag("T");
		//concept.setCreatedOn("22/03/2012");*/
		boolean result=conceptService.delete(concept);
		
		System.out.println("Result: "+ result);
		
		
	}
	
	@Test(enabled=false)
	public void testAddHotspot()
	{
		System.out.println("Concept   hotspot add  "+conceptService);
		
		/*concept.setModifiedOn(new Timestamp(System.currentTimeMillis()));
		concept.setDeleteFlag("T");
		//concept.setCreatedOn("22/03/2012");*/
		/*ConceptHotspotMapping hotspotMapping=new ConceptHotspotMapping();
		hotspotMapping.setConceptId(1L);
		
		hotspotMapping.setHotspotX(5L);
		hotspotMapping.setHotspotY(6L);
		hotspotMapping.setProductId(1L);
		hotspotMapping.setCreatedBy(255L);
		hotspotMapping.setModifiedBy(255L);*/
		boolean result=conceptService.addHotspot(1L, 2L, 3L, 1L);
	//boolean result=conceptService.addHotspot(hotspotMapping);
		
		
		
		System.out.println("Result: "+ result);
		
		
	}
	
	@Test(enabled=false)
	public void testEditHotspot()
	{
		System.out.println("Concept   hotspot edit  "+conceptService);
		
		/*concept.setModifiedOn(new Timestamp(System.currentTimeMillis()));
		concept.setDeleteFlag("T");
		//concept.setCreatedOn("22/03/2012");*/
		ConceptHotspotMapping hotspotMapping=new ConceptHotspotMapping();
		hotspotMapping.setConceptId(1L);
		hotspotMapping.setId(1L);
		hotspotMapping.setHotspotX(15L);
		hotspotMapping.setHotspotY(16L);
		hotspotMapping.setProductId(1L);
		hotspotMapping.setCreatedBy(255L);
		hotspotMapping.setModifiedBy(255L);
		hotspotMapping.setDeleteFlag("F");
		//boolean result=conceptService.addHotspot(1L, 2L, 3L, 1L);
	boolean result=conceptService.editHotspot(hotspotMapping);
		
		
		
		System.out.println("Result: "+ result);
		
		
	}
	
	@Test(enabled=true)
	public void testDeleteHotspot()
	{
		System.out.println("Concept   hotspot edit  "+conceptService);
		
		/*concept.setModifiedOn(new Timestamp(System.currentTimeMillis()));
		concept.setDeleteFlag("T");
		//concept.setCreatedOn("22/03/2012");*/
		ConceptHotspotMapping hotspotMapping=new ConceptHotspotMapping();
		hotspotMapping.setConceptId(1L);
		hotspotMapping.setId(1L);
		hotspotMapping.setHotspotX(15L);
		hotspotMapping.setHotspotY(16L);
		hotspotMapping.setProductId(1L);
		hotspotMapping.setCreatedBy(255L);
		hotspotMapping.setModifiedBy(255L);
		//hotspotMapping.setDeleteFlag("F");
		//boolean result=conceptService.addHotspot(1L, 2L, 3L, 1L);
	boolean result=conceptService.deleteHotspot(hotspotMapping);
		
		
		
		System.out.println("Result: "+ result);
		
		
	}
	
	
}
