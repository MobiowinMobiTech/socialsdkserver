package com.mobicule.icatalog.customer.service;

import java.sql.Timestamp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.mobicule.icatalog.customer.bean.CustomerShortlist;

@ContextConfiguration(locations = { "file:/home/shailini/workspace/icatalog-core/config/spring/spring-config.xml" })
@Test(groups = { "init" })
public class CustomerTest extends AbstractTestNGSpringContextTests
{
	@Autowired
	private CustomerShortlistService customerService;
	
	@BeforeClass
	protected void setUp()
	{
		Assert.assertNotNull(customerService);
	}

	@Test(enabled=false)
	public void testAdd()
	{
		System.out.println("customerService   add  "+customerService);
		
		CustomerShortlist customer = new CustomerShortlist();
	
		customer.setName("Shalini");
		customer.setContact(98531264L);
		
		customer.setUserId(1L);
		customer.setShortlistedItemCode("C02");
		customer.setShortlistedItemType("ABC");
		customer.setCreatedBy(225L);
		customer.setModifiedBy(225L);
	//	concept.setModifiedOn(new Timestamp(System.currentTimeMillis()));
		//concept.setDeleteFlag("F");
		//concept.setCreatedOn("22/03/2012");*/
		boolean result=customerService.add(customer);
		
		System.out.println("Result: "+ result);
	}
	@Test(enabled=false)
	public void testUpdate()
	{
		System.out.println("customerService   update  "+customerService);
		
		CustomerShortlist customer = new CustomerShortlist();
		customer.setId(1L);
		//concept.setCode("Con02");
		customer.setName("Shals");
		customer.setUserId(1L);
		customer.setShortlistedItemCode("C02");
		customer.setShortlistedItemType("XYZ");
		//customer.setDescription("New Desc");
		customer.setCreatedBy(255L);
		customer.setModifiedBy(5L);
		customer.setModifiedOn(new Timestamp(System.currentTimeMillis()));
		customer.setDeleteFlag("F");
		//concept.setCreatedOn("22/03/2012");
		boolean result=customerService.update(customer);
		
		System.out.println("Result: "+ result);
	}
	
	@Test(enabled=true)
	public void testDelete()
	{
		System.out.println("customerService   delete  "+customerService);
		
		CustomerShortlist customer = new CustomerShortlist();
		customer.setId(1L);
	//	customer.setCode("Con02");
		customer.setName("Shalu");
		customer.setShortlistedItemCode("C02");
		customer.setShortlistedItemType("XYZ");
		//customer.setDescription("Desc");
		customer.setCreatedBy(225L);
		customer.setModifiedBy(5L);
		/*concept.setModifiedOn(new Timestamp(System.currentTimeMillis()));
		concept.setDeleteFlag("T");
		//concept.setCreatedOn("22/03/2012");*/
		boolean result=customerService.delete(customer);
		
		System.out.println("Result: "+ result);
		
		
	}
	
}
