package com.mobicule.icatalog.product.service;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.mobicule.icatalog.concept.bean.ConceptCategory;
import com.mobicule.icatalog.product.bean.ProductCategory;

@ContextConfiguration(locations = { "file:/home/shailini/workspace/icatalog-core/config/spring/spring-config.xml" })
@Test(groups = { "init" })

public class ProductCategoryTest extends AbstractTestNGSpringContextTests
{
	@Autowired
	private ProductCategoryService productCategoryService;
	
	@BeforeClass
	protected void setUp()
	{
		Assert.assertNotNull(productCategoryService);
	}
	
	@Test(enabled=false)
	public void testAdd()
	{
		System.out.println("Product category  add  "+ productCategoryService);
		
		ProductCategory productcategory = new ProductCategory();
	
		productcategory.setCode("PC02");
		productcategory.setName("Product2");
		productcategory.setDescription("Product2");
		productcategory.setCreatedBy(225L);
		productcategory.setModifiedBy(225L);
		
		boolean result=productCategoryService.add(productcategory);
		
		System.out.println("Result: "+ result);
	}
	
	@Test(enabled=false)
	public void testUpdate()
	{
		System.out.println("Product category  update  "+ productCategoryService);
		
		ProductCategory productcategory = new ProductCategory();
		
		productcategory.setId(1L);
		productcategory.setCode("PC01");
		productcategory.setName("Product1");
		productcategory.setDescription("Product1");
		productcategory.setCreatedBy(225L);
		productcategory.setModifiedBy(5L);
		productcategory.setModifiedOn(new Timestamp(System.currentTimeMillis()));
		productcategory.setDeleteFlag("F");
		
		boolean result=productCategoryService.update(productcategory);
		
		System.out.println("Result: "+ result);
	}
	
	@Test(enabled=false)
	public void testDelete()
	{
		System.out.println("Product category  update  "+ productCategoryService);
		
		ProductCategory productcategory = new ProductCategory();
		
		productcategory.setId(2L);
		productcategory.setCode("PC02");
		productcategory.setName("Product1");
		productcategory.setDescription("Product1");
		productcategory.setCreatedBy(225L);
		productcategory.setModifiedBy(5L);
		productcategory.setModifiedOn(new Timestamp(System.currentTimeMillis()));
	//	productcategory.setDeleteFlag("F")
		
		boolean result=productCategoryService.delete(productcategory);
		
		System.out.println("Result: "+ result);
	}
	
	@Test(enabled=true)
	public void testSearch()
	{
		System.out.println("Concept category  search  "+productCategoryService);
		
		
		List<ProductCategory> categoryList =productCategoryService.searchName("P");
		
		System.out.println("Result of search : "+ categoryList.get(0).getCode() + categoryList.get(0).getCode());
		
		
	}
	
	
}
