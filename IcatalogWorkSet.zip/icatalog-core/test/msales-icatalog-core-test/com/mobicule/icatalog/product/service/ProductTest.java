package com.mobicule.icatalog.product.service;

import java.sql.Timestamp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.mobicule.icatalog.product.bean.Product;
import com.mobicule.icatalog.product.bean.ProductCategory;
import com.mobicule.icatalog.product.bean.ProductInventory;
import com.mobicule.icatalog.product.bean.ProductPrice;
import com.mobicule.icatalog.product.bean.ProductRecommendation;
import com.mobicule.icatalog.product.bean.ProductVariant;
import com.mobicule.icatalog.product.dao.ProductCategoryDao;
import com.mobicule.icatalog.product.dao.ProductDao;

@ContextConfiguration(locations = { "file:config/spring/spring-config.xml" })
@Test(groups = { "init" })
public class ProductTest extends AbstractTestNGSpringContextTests
{
	@Autowired
	private ProductService productService;

	@Autowired
	private ProductDao productDao;

	@Autowired
	private ProductCategoryDao productCategoryDao;

	@BeforeClass
	protected void setUp()
	{
		Assert.assertNotNull(productService);
	}

	@Test(enabled = false)
	public void testAdd()
	{
		System.out.println("Product   add  " + productService);

		Product product = new Product();

		product.setCode("Prod01");
		product.setName("ProductA");
		product.setDescription("ProductA");
		//concept.setTitle("ConceptA");
		product.setCategoryId(1L);
		product.setDepartment("ABC");
		product.setOfferFlag("N");
		product.setSubDepartment("ABC");
		product.setStyle("ASf");
		product.setSubClass("subClass");
		product.setProductClass("productClass");
		product.setCreatedBy(225L);
		product.setModifiedBy(225L);
		//	concept.setModifiedOn(new Timestamp(System.currentTimeMillis()));
		//concept.setDeleteFlag("F");
		//concept.setCreatedOn("22/03/2012");*/
		boolean result = productService.add(product);

		System.out.println("Result: " + result);
	}

	@Test(enabled = false)
	public void testUpdate()
	{
		System.out.println("Product   update  " + productService);

		Product product = new Product();
		product.setId(1L);
		//concept.setCode("Con02");
		product.setName("ConceptA");
		product.setDescription("New Desc");
		product.setCreatedBy(255L);
		product.setModifiedBy(5L);
		product.setModifiedOn(new Timestamp(System.currentTimeMillis()));
		product.setDeleteFlag("F");
		//concept.setCreatedOn("22/03/2012");
		boolean result = productService.update(product);

		System.out.println("Result: " + result);
	}

	@Test(enabled = false)
	public void testDelete()
	{
		System.out.println("Product   delete  " + productService);

		Product product = new Product();
		product.setId(1L);
		product.setCode("ConceptA");
		product.setName("ConceptA");
		product.setDescription("Desc");
		product.setCreatedBy(225L);
		product.setModifiedBy(5L);
		/*concept.setModifiedOn(new Timestamp(System.currentTimeMillis()));
		concept.setDeleteFlag("T");
		//concept.setCreatedOn("22/03/2012");*/
		boolean result = productService.delete(product);

		System.out.println("Result: " + result);

	}

	@Test(enabled = false)
	public void testAddInventory()
	{
		System.out.println("Product   inventory add  " + productService);

		ProductInventory product = new ProductInventory();
		//product.setId(1L);
		/*product.setCode("ConceptA");
		product.setName("ConceptA");
		product.setDescription("Desc");*/
		product.setInventory(200L);
		product.setProductId(1L);
		product.setCreatedBy(225L);
		product.setModifiedBy(5L);
		/*concept.setModifiedOn(new Timestamp(System.currentTimeMillis()));
		concept.setDeleteFlag("T");
		//concept.setCreatedOn("22/03/2012");*/
		boolean result = productService.addInventory(product);

		System.out.println("Result: " + result);

	}

	@Test(enabled = false)
	public void testUpdateInventory()
	{
		System.out.println("Product   inventory update  " + productService);

		ProductInventory product = new ProductInventory();
		product.setId(1L);
		/*product.setCode("ConceptA");
		product.setName("ConceptA");
		product.setDescription("Desc");*/
		product.setInventory(250L);
		product.setProductId(1L);
		product.setCreatedBy(225L);
		product.setModifiedBy(5L);
		product.setDeleteFlag("F");
		/*concept.setModifiedOn(new Timestamp(System.currentTimeMillis()));
		concept.setDeleteFlag("T");
		//concept.setCreatedOn("22/03/2012");*/
		boolean result = productService.editInventory(product);

		System.out.println("Result: " + result);

	}

	@Test(enabled = false)
	public void testDeleteInventory()
	{
		System.out.println("Product   inventory update  " + productService);

		ProductInventory product = new ProductInventory();
		product.setId(1L);
		/*product.setCode("ConceptA");
		product.setName("ConceptA");
		product.setDescription("Desc");*/
		product.setInventory(250L);
		product.setProductId(1L);
		product.setCreatedBy(225L);
		product.setModifiedBy(5L);
		//product.setDeleteFlag("F");
		/*concept.setModifiedOn(new Timestamp(System.currentTimeMillis()));
		concept.setDeleteFlag("T");
		//concept.setCreatedOn("22/03/2012");*/
		boolean result = productService.deleteInventory(product);

		System.out.println("Result: " + result);

	}

	@Test(enabled = false)
	public void testAddPrice()
	{
		System.out.println("Product   price  add  " + productService);

		ProductPrice product = new ProductPrice();
		//product.setId(1L);
		/*product.setCode("ConceptA");
		product.setName("ConceptA");
		product.setDescription("Desc");*/
		product.setRetailPrice(2000);
		product.setProductId(1L);
		product.setCreatedBy(225L);
		product.setModifiedBy(5L);
		/*concept.setModifiedOn(new Timestamp(System.currentTimeMillis()));
		concept.setDeleteFlag("T");
		//concept.setCreatedOn("22/03/2012");*/
		boolean result = productService.addPrice(product);

		System.out.println("Result: " + result);

	}

	@Test(enabled = false)
	public void testEditPrice()
	{
		System.out.println("Product   price  add  " + productService);

		ProductPrice product = new ProductPrice();
		product.setId(1L);
		/*product.setCode("ConceptA");
		product.setName("ConceptA");
		product.setDescription("Desc");*/
		product.setRetailPrice(25420);
		product.setProductId(1L);
		product.setCreatedBy(225L);
		product.setModifiedBy(5L);
		product.setDeleteFlag("F");
		/*concept.setModifiedOn(new Timestamp(System.currentTimeMillis()));
		concept.setDeleteFlag("T");
		//concept.setCreatedOn("22/03/2012");*/
		boolean result = productService.updatePrice(product);

		System.out.println("Result: " + result);

	}

	@Test(enabled = false)
	public void testDeletePrice()
	{
		System.out.println("Product   price  add  " + productService);

		ProductPrice product = new ProductPrice();
		product.setId(1L);
		/*product.setCode("ConceptA");
		product.setName("ConceptA");
		product.setDescription("Desc");*/
		product.setRetailPrice(25420);
		product.setProductId(1L);
		product.setCreatedBy(225L);
		product.setModifiedBy(5L);
		//product.setDeleteFlag("F");
		/*concept.setModifiedOn(new Timestamp(System.currentTimeMillis()));
		concept.setDeleteFlag("T");
		//concept.setCreatedOn("22/03/2012");*/
		boolean result = productService.deletePrice(product);

		System.out.println("Result: " + result);

	}

	@Test(enabled = false)
	public void testAddVariant()
	{
		System.out.println("Product   variant  add  " + productService);

		ProductVariant product = new ProductVariant();
		//product.setId(1L);
		/*product.setCode("ConceptA");
		product.setName("ConceptA");
		product.setDescription("Desc");*/
		product.setVariantId(2L);
		product.setProductId(1L);
		product.setCreatedBy(225L);
		product.setModifiedBy(5L);
		/*concept.setModifiedOn(new Timestamp(System.currentTimeMillis()));
		concept.setDeleteFlag("T");
		//concept.setCreatedOn("22/03/2012");*/
		boolean result = productService.addVariants(product);

		System.out.println("Result: " + result);

	}

	@Test(enabled = false)
	public void testEditVariant()
	{
		System.out.println("Product   variant  add  " + productService);

		ProductVariant product = new ProductVariant();
		product.setId(1L);
		/*product.setCode("ConceptA");
		product.setName("ConceptA");
		product.setDescription("Desc");*/
		product.setVariantId(2L);
		product.setProductId(1L);
		product.setCreatedBy(335L);
		product.setModifiedBy(5L);
		product.setDeleteFlag("F");
		/*concept.setModifiedOn(new Timestamp(System.currentTimeMillis()));
		concept.setDeleteFlag("T");
		//concept.setCreatedOn("22/03/2012");*/
		boolean result = productService.editVariants(product);

		System.out.println("Result: " + result);

	}

	@Test(enabled = false)
	public void testDeleteVariant()
	{
		System.out.println("Product   variant  add  " + productService);

		ProductVariant product = new ProductVariant();
		product.setId(1L);
		/*product.setCode("ConceptA");
		product.setName("ConceptA");
		product.setDescription("Desc");*/
		product.setVariantId(2L);
		product.setProductId(1L);
		product.setCreatedBy(335L);
		product.setModifiedBy(5L);
		//product.setDeleteFlag("F");
		/*concept.setModifiedOn(new Timestamp(System.currentTimeMillis()));
		concept.setDeleteFlag("T");
		//concept.setCreatedOn("22/03/2012");*/
		boolean result = productService.deleteVariants(product);

		System.out.println("Result: " + result);

	}

	@Test(enabled = false)
	public void testAddRecommend()
	{
		System.out.println("Product   recommend  add  " + productService);

		ProductRecommendation product = new ProductRecommendation();
		//product.setId(1L);
		/*product.setCode("ConceptA");
		product.setName("ConceptA");
		product.setDescription("Desc");*/
		product.setRecommendId(2L);
		product.setProductId(1L);
		product.setCreatedBy(225L);
		product.setModifiedBy(5L);
		/*concept.setModifiedOn(new Timestamp(System.currentTimeMillis()));
		concept.setDeleteFlag("T");
		//concept.setCreatedOn("22/03/2012");*/
		boolean result = productService.addRecommendation(product);

		System.out.println("Result: " + result);

	}

	@Test(enabled = false)
	public void testEditRecomend()
	{
		System.out.println("Product   variant  add  " + productService);

		ProductRecommendation product = new ProductRecommendation();
		product.setId(1L);
		/*product.setCode("ConceptA");
		product.setName("ConceptA");
		product.setDescription("Desc");*/
		product.setRecommendId(2L);
		product.setProductId(1L);
		product.setCreatedBy(335L);
		product.setModifiedBy(5L);
		product.setDeleteFlag("F");
		/*concept.setModifiedOn(new Timestamp(System.currentTimeMillis()));
		concept.setDeleteFlag("T");
		//concept.setCreatedOn("22/03/2012");*/
		boolean result = productService.editRecommendation(product);

		System.out.println("Result: " + result);

	}

	@Test(enabled = false)
	public void testDeleteRecommend()
	{
		System.out.println("Product   variant  add  " + productService);

		ProductRecommendation product = new ProductRecommendation();
		product.setId(1L);
		/*product.setCode("ConceptA");
		product.setName("ConceptA");
		product.setDescription("Desc");*/
		product.setRecommendId(2L);
		product.setProductId(1L);
		product.setCreatedBy(335L);
		product.setModifiedBy(5L);
		//product.setDeleteFlag("F");
		/*concept.setModifiedOn(new Timestamp(System.currentTimeMillis()));
		concept.setDeleteFlag("T");
		//concept.setCreatedOn("22/03/2012");*/
		boolean result = productService.deleteRecommendation(product);

		System.out.println("Result: " + result);

	}

	@Test(enabled = true)
	public void testSearch()
	{
		//		Product product = new Product();
		//
		//		product.setCode("Bench");
		//
				System.out.println("Result: " + productDao.findMatchingBeans(new Product()));

		//System.out.println("Result: " + productCategoryDao.findMatchingBeans(new ProductCategory()));

		//		Product product = new Product();
		//
		//		product.setCode("Bench");
		//		product.setName("Italian Bench");
		//		product.setDescription("New Desc");
		//		product.setDeleteFlag("F");
		//		product.setCategoryId(1L);
		//		product.setCreatedBy(335L);
		//		product.setModifiedBy(5L);
		//		
		//		System.out.println("Result: " + productService.add(product));
	}
}
