package com.mobicule.icatalog.systemuser.service;

import java.sql.Timestamp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.mobicule.icatalog.customer.bean.CustomerShortlist;
import com.mobicule.icatalog.customer.service.CustomerShortlistService;
import com.mobicule.icatalog.systemuser.bean.SystemUser;

@ContextConfiguration(locations = { "file:/home/shailini/workspace/icatalog-core/config/spring/spring-config.xml" })
@Test(groups = { "init" })
public class SystemUserTest extends AbstractTestNGSpringContextTests
{
	@Autowired
	private SystemUserService userService;
	
	@BeforeClass
	protected void setUp()
	{
		Assert.assertNotNull(userService);
	}
	
	@Test(enabled=false)
	public void testAdd()
	{
		System.out.println("userService   add  "+userService);
		
		SystemUser user = new SystemUser();
	
		user.setActiveFlag("Y");
		user.setCode("US-01");
		user.setFirstName("Shalini");
		user.setLastName("Nair");
		user.setRoleId(1L);
		user.setProfileId(1L);
		user.setLogin("Shals");
		user.setPassword("***");
		user.setCreatedBy(225L);
		user.setModifiedBy(225L);
	//	concept.setModifiedOn(new Timestamp(System.currentTimeMillis()));
		//concept.setDeleteFlag("F");
		//concept.setCreatedOn("22/03/2012");*/
		boolean result=userService.add(user);
		
		System.out.println("Result: "+ result);
	}
	@Test(enabled=false)
	public void testUpdate()
	{
		System.out.println("userService   update  "+userService);
		
		SystemUser user = new SystemUser();
		user.setId(1L);
		//concept.setCode("Con02");
		user.setActiveFlag("Y");
		user.setCode("US-01");
		user.setFirstName("Shalini");
		user.setLastName("Nair");
		user.setRoleId(1L);
		user.setProfileId(1L);
		user.setLogin("Shals");
		user.setPassword("sap");
		//customer.setDescription("New Desc");
		user.setCreatedBy(255L);
		user.setModifiedBy(5L);
		user.setModifiedOn(new Timestamp(System.currentTimeMillis()));
		user.setDeleteFlag("F");
		//concept.setCreatedOn("22/03/2012");
		boolean result=userService.update(user);
		
		System.out.println("Result: "+ result);
	}
	
	@Test(enabled=true)
	public void testDelete()
	{
		System.out.println("userService   delete  "+userService);
		
		SystemUser user = new SystemUser();
		user.setId(1L);
		user.setActiveFlag("Y");
		user.setCode("US-01");
		user.setFirstName("Shalini");
		user.setLastName("Nair");
		user.setRoleId(1L);
		user.setProfileId(1L);
		user.setLogin("Shals");
		user.setPassword("sap");
		user.setCreatedBy(225L);
		user.setModifiedBy(5L);
		/*concept.setModifiedOn(new Timestamp(System.currentTimeMillis()));
		concept.setDeleteFlag("T");
		//concept.setCreatedOn("22/03/2012");*/
		boolean result=userService.delete(user);
		
		System.out.println("Result: "+ result);
		
		
	}
	
	
}
