package com.mobicule.icatalog.concept.bean;

import java.sql.Timestamp;

import com.mobicule.component.db.standardbean.StandardBean;

public class Concept extends StandardBean
{

	private static final long serialVersionUID = 1L;

	//private String title;
	private Long categoryId;

	private Double retailPrice;

	private String offerFlag;

	private Double offerPrice;

	private String giftFlag;

	private String searchTags;
	
	private Timestamp imageModifiedOn;

	public Concept()
	{
		super();
		
	}

	private String brand;

	public Concept(Long id, Long createdBy, Long modifiedBy, Timestamp createdOn, Timestamp modifiedOn,
			String deleteFlag, String code, String name, String description, Long categoryId, Double retailPrice,
			String offerFlag, Double offerPrice, String searchTags, String brand)
	{
		super(id, createdBy, modifiedBy, createdOn, modifiedOn, deleteFlag, code, name, description);
		this.categoryId = categoryId;
		this.retailPrice = retailPrice;
		this.offerFlag = offerFlag;
		this.offerPrice = offerPrice;
		this.searchTags = searchTags;
		this.brand = brand;
	}

	/*	public String getTitle() 
		{
			return title;
		}
		
		public void setTitle(String title) 
		{
			this.title = title;
		}*/

	public Long getCategoryId()
	{
		return categoryId;
	}

	public void setCategoryId(Long categoryId)
	{
		this.categoryId = categoryId;
	}

	public Double getRetailPrice()
	{
		return retailPrice;
	}

	public void setRetailPrice(Double retailPrice)
	{
		this.retailPrice = retailPrice;
	}

	public String getOfferFlag()
	{
		return offerFlag;
	}

	public void setOfferFlag(String offerFlag)
	{
		this.offerFlag = offerFlag;
	}

	public Double getOfferPrice()
	{
		return offerPrice;
	}

	public void setOfferPrice(Double offerPrice)
	{
		this.offerPrice = offerPrice;
	}
	
	public String getGiftFlag() {
		return giftFlag;
	}

	public void setGiftFlag(String giftFlag) {
		this.giftFlag = giftFlag;
	}

	public String getSearchTags() 

	{
		return searchTags;
	}

	public void setSearchTags(String searchTags)
	{
		this.searchTags = searchTags;
	}

	public String getBrand()
	{
		return brand;
	}

	public void setBrand(String brand)
	{
		this.brand = brand;
	}

	public Timestamp getImageModifiedOn()
	{
		return imageModifiedOn;
	}

	public void setImageModifiedOn(Timestamp imageModifiedOn)
	{
		this.imageModifiedOn = imageModifiedOn;
	}

	@Override
	public String toString()
	{
		StringBuilder builder = new StringBuilder();
		builder.append("Concept [categoryId=");
		builder.append(categoryId);
		builder.append(", retailPrice=");
		builder.append(retailPrice);
		builder.append(", offerFlag=");
		builder.append(offerFlag);
		builder.append(", offerPrice=");
		builder.append(offerPrice);
		builder.append(", giftFlag=");
		builder.append(giftFlag);
		builder.append(", searchTags=");
		builder.append(searchTags);
		builder.append(", brand=");
		builder.append(brand);
		builder.append("]");
		return builder.toString();
	}

}
