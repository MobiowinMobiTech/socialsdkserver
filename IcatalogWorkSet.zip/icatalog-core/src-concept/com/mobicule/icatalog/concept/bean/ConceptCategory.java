package com.mobicule.icatalog.concept.bean;

import java.sql.Timestamp;

import com.mobicule.component.db.standardbean.StandardBean;

public class ConceptCategory  extends StandardBean
{
	private static final long serialVersionUID = 1L;
}
