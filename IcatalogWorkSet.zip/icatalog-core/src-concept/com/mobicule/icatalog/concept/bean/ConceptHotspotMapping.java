package com.mobicule.icatalog.concept.bean;

import com.mobicule.component.db.standardbean.SimpleDataBean;

public class ConceptHotspotMapping extends SimpleDataBean {

	private static final long serialVersionUID = 1L;
	private Long conceptId;
	private Long hotspotX;
	private Long hotspotY;
	private Long productId;

/*	public ConceptHotspotMapping(Long conceptId, Long hotspotX, Long hotspotY,
			Long productId) 
	{
		super();
		this.conceptId = conceptId;
		this.hotspotX = hotspotX;
		this.hotspotY = hotspotY;
		this.productId = productId;
	}
*/
	

	public Long getConceptId() {
		return conceptId;
	}

	public void setConceptId(Long conceptId) {
		this.conceptId = conceptId;
	}

	public Long getHotspotX() {
		return hotspotX;
	}

	public void setHotspotX(Long hotspotX) {
		this.hotspotX = hotspotX;
	}

	public Long getHotspotY() {
		return hotspotY;
	}

	public void setHotspotY(Long hotspotY) {
		this.hotspotY = hotspotY;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("ConceptHotspotMapping [conceptId=");
		builder.append(conceptId);
		builder.append(", hotspotX=");
		builder.append(hotspotX);
		builder.append(", hotspotY=");
		builder.append(hotspotY);
		builder.append(", productId=");
		builder.append(productId);
		builder.append("]");
		return builder.toString();
	}
}
