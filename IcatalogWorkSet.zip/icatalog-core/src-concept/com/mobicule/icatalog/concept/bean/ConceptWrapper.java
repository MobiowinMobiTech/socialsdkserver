/**
******************************************************************************
* C O P Y R I G H T  A N D  C O N F I D E N T I A L I T Y  N O T I C E
* <p>
* Copyright © 2008-2009 Mobicule Technologies Pvt. Ltd. All rights reserved. 
* This is proprietary information of Mobicule Technologies Pvt. Ltd.and is 
* subject to applicable licensing agreements. Unauthorized reproduction, 
* transmission or distribution of this file and its contents is a 
* violation of applicable laws.
******************************************************************************
*
* @project icatalog-core
*/
package com.mobicule.icatalog.concept.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
* 
* <enter description here>
*
* @author shalini <Nair>
* @see 
*
* @createdOn 04-Apr-2012
* @modifiedOn
*
* @copyright © 2008-2009 Mobicule Technologies Pvt. Ltd. All rights reserved.
*/
public class ConceptWrapper implements Serializable
{

	private static final long serialVersionUID = 1L;

	private Concept concept;

	private List<ConceptHotspotMapping> hotspot;

	public ConceptWrapper()
	{
		hotspot = new ArrayList<ConceptHotspotMapping>();

	}

	public Concept getConcept()
	{
		return concept;
	}

	public void setConcept(Concept concept)
	{
		this.concept = concept;
	}

	public List<ConceptHotspotMapping> getHotspot()
	{
		return hotspot;
	}

	public void setHotspot(List<ConceptHotspotMapping> hotspot)
	{
		this.hotspot = hotspot;
	}

	@Override
	public String toString()
	{
		StringBuilder builder = new StringBuilder();
		builder.append("ConceptWrapper [\n\tconcept=");
		builder.append(concept);
		builder.append(", \n\thotspot=");
		builder.append(hotspot);
		builder.append("]");
		return builder.toString();
	}

}
