package com.mobicule.icatalog.concept.service;

import java.sql.Timestamp;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import com.mobicule.icatalog.concept.bean.ConceptCategory;
import com.mobicule.icatalog.concept.dao.ConceptCategoryDao;
import com.mobicule.icatalog.entity.service.EntityServiceImpl;
import com.mobicule.icatalog.entity.service.SyncService;

public class ConceptCategoryServiceImpl extends EntityServiceImpl<ConceptCategory, ConceptCategoryDao> implements
		ConceptCategoryService, SyncService
{
	private Log log = LogFactory.getLog(this.getClass());

	@Override
	public List<ConceptCategory> searchName(String name)
	{
		return getGenericDataBeanDAO().searchName(name);
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param conceptCategory
	 * @return
	 *
	 * @author himanshu
	 * @createdOn 09-Apr-2012
	 * @modifiedOn 09-Apr-2012 
	 * 
	 */
	@Override
	public List<ConceptCategory> doCustomSearch(ConceptCategory conceptCategory)
	{

		return getGenericDataBeanDAO().doCustomSearch(conceptCategory);
	}

	@Override
	public String fetchAllAfterSyncDate(Timestamp lastSyncDate, int pageNumber, int pageSize, String entity,
			String action,String login)
	{

		return getGenericDataBeanDAO().fetchAllAfterSyncDate(lastSyncDate, pageNumber, pageSize, entity, action,login);
	}
	@Override
	public List<ConceptCategory> checkUniqueConceptCategoryCode(String conceptCategoryCode)
	{
		log.info("code in service :" + conceptCategoryCode);
		ConceptCategory conceptCategory = new ConceptCategory();
		conceptCategory.setCode(conceptCategoryCode);
		log.info("Search bean is :" + conceptCategory);
		
		List<ConceptCategory> conceptBeanList = getGenericDataBeanDAO().findMatchingBeans(conceptCategory);
		log.info("conceptBeanList is :" + conceptBeanList);
		
		return conceptBeanList;

	}

}
