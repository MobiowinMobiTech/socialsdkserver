package com.mobicule.icatalog.concept.service;

import java.util.List;

import com.mobicule.icatalog.concept.bean.Concept;
import com.mobicule.icatalog.concept.bean.ConceptHotspotMapping;
import com.mobicule.icatalog.concept.dao.ConceptDao;
import com.mobicule.icatalog.entity.service.EntityService;

public interface ConceptService extends EntityService<Concept, ConceptDao>
{

	public boolean addHotspot(Long conceptId, Long hotspotX, Long hotspotY, Long productId);

	public boolean addHotspot(ConceptHotspotMapping hotspotMapping);

	public boolean editHotspot(ConceptHotspotMapping hotspotMapping);

	public boolean deleteHotspot(ConceptHotspotMapping hotspotMapping);

	public List<Concept> getConceptBeanList(String conceptCode);

	public String getImageWithHotSpot(Concept concept, String conceptImageLocation);

	public Boolean deleteConceptHotSpotMapping(ConceptHotspotMapping conceptHotspotMapping);

	public ConceptHotspotMapping getConceptHotspotMappingBean(ConceptHotspotMapping conceptHotspotMapping);

	public List<Concept> customSearch(Concept searchConcept, Long conceptCategoryId);

	public List<Concept> doCustomSearch(Concept searchConcept);
	
	public String getConceptCategoryImageCode(String code);

}
