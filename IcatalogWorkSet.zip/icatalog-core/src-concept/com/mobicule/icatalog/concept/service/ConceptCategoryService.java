package com.mobicule.icatalog.concept.service;

import java.util.List;

import com.mobicule.icatalog.concept.bean.ConceptCategory;
import com.mobicule.icatalog.concept.dao.ConceptCategoryDao;
import com.mobicule.icatalog.entity.service.EntityService;

public interface ConceptCategoryService extends EntityService<ConceptCategory, ConceptCategoryDao>
{

	public List<ConceptCategory> searchName(String name);

	public List<ConceptCategory> doCustomSearch(ConceptCategory conceptCategory);

	public List<ConceptCategory> checkUniqueConceptCategoryCode(String conceptCategoryCode);

}
