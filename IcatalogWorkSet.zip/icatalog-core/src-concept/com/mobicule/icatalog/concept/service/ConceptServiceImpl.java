package com.mobicule.icatalog.concept.service;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.mobicule.icatalog.concept.bean.Concept;
import com.mobicule.icatalog.concept.bean.ConceptCategory;
import com.mobicule.icatalog.concept.bean.ConceptHotspotMapping;
import com.mobicule.icatalog.concept.bean.ConceptWrapper;
import com.mobicule.icatalog.concept.dao.ConceptCategoryDao;
import com.mobicule.icatalog.concept.dao.ConceptDao;
import com.mobicule.icatalog.concept.dao.ConceptHotspotDao;
import com.mobicule.icatalog.core.constants.IcatalogUtility;
import com.mobicule.icatalog.entity.service.EntityServiceImpl;
import com.mobicule.icatalog.entity.service.SyncService;

public class ConceptServiceImpl extends EntityServiceImpl<Concept, ConceptDao> implements ConceptService, SyncService
{
	private Log log = LogFactory.getLog(this.getClass());

	private ConceptHotspotDao hotspotDao;

	private ConceptDao conceptDao;

	private ConceptCategoryDao conceptCategoryDao;

	public ConceptHotspotDao getHotspotDao()
	{
		return hotspotDao;
	}

	public void setHotspotDao(ConceptHotspotDao hotspotDao)
	{
		this.hotspotDao = hotspotDao;
	}

	public ConceptDao getConceptDao()
	{
		return conceptDao;
	}

	public void setConceptDao(ConceptDao conceptDao)
	{
		this.conceptDao = conceptDao;
	}

	public ConceptCategoryDao getConceptCategoryDao()
	{
		return conceptCategoryDao;
	}

	public void setConceptCategoryDao(ConceptCategoryDao conceptCategoryDao)
	{
		this.conceptCategoryDao = conceptCategoryDao;
	}

	@Override
	public boolean addHotspot(Long conceptId, Long hotspotX, Long hotspotY, Long productId)
	{

		ConceptHotspotMapping hotspotMapping = new ConceptHotspotMapping();//(conceptId, hotspotX, hotspotY, productId);
		/*hotspotMapping.setConceptId(conceptId);
		hotspotMapping.setHotspotX(hotspotX);
		hotspotMapping.setHotspotY(hotspotY);
		hotspotMapping.setProductId(productId);*/
		hotspotMapping.setCreatedBy(255L);
		hotspotMapping.setModifiedBy(255L);

		try
		{
			hotspotDao.add(hotspotMapping);
			return true;
		}
		catch (Exception e)
		{
			if (log.isErrorEnabled())
			{
				log.error("", e);
			}
			return false;
		}
	}

	@Override
	public boolean addHotspot(ConceptHotspotMapping hotspotMapping)
	{
		if (hotspotMapping == null)
		{
			if (log.isErrorEnabled())
			{
				log.error("entity is null");
			}
			return false;
		}

		if (hotspotMapping.getId() != null)
		{
			if (log.isErrorEnabled())
			{
				log.error("entity id is not null");
			}
			return false;
		}

		try
		{
			hotspotDao.add(hotspotMapping);

			return true;
		}
		catch (Exception e)
		{
			if (log.isErrorEnabled())
			{
				log.error("entity not added", e);
			}
			return false;
		}
	}

	@Override
	public boolean editHotspot(ConceptHotspotMapping hotspotMapping)
	{
		if (hotspotMapping == null)
		{
			if (log.isErrorEnabled())
			{
				log.error("entity is null");
			}
			return false;
		}

		if (hotspotMapping.getId() == null)
		{
			return false;
		}

		try
		{
			hotspotDao.update(hotspotMapping);

			return true;
		}
		catch (Exception e)
		{
			if (log.isErrorEnabled())
			{
				log.error("entity not added", e);
			}
			return false;
		}
	}

	@Override
	public boolean deleteHotspot(ConceptHotspotMapping hotspotMapping)
	{
		if (hotspotMapping == null)
		{
			if (log.isErrorEnabled())
			{
				log.error("entity is null");
			}
			return false;
		}

		if (hotspotMapping.getId() == null)
		{
			return false;
		}

		try
		{
			hotspotDao.softDelete(hotspotMapping);

			return true;
		}
		catch (Exception e)
		{
			if (log.isErrorEnabled())
			{
				log.error("entity not added", e);
			}
			return false;
		}
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param lastSyncDate
	 * @param pageNumber
	 * @param pageSize
	 * @param entity
	 * @param action
	 * @return
	 *
	 * @author shalini
	 * @createdOn 03-Apr-2012
	 * @modifiedOn 03-Apr-2012 
	 * 
	 */
	@Override
	public String fetchAllAfterSyncDate(Timestamp lastSyncDate, int pageNumber, int pageSize, String entity,
			String action, String login)
	{
		if (log.isInfoEnabled())
		{
			log.info("In service Impl: " + lastSyncDate + ", " + pageNumber);
		}
		return getGenericDataBeanDAO().fetchAllAfterSyncDate(lastSyncDate, pageNumber, pageSize, entity, action, login);
	}

	public List<Concept> getConceptBeanList(String conceptCode)
	{

		Concept concept = new Concept();
		concept.setCode(conceptCode);
		//concept.setDeleteFlag("F");
		log.info("Search bean is :" + concept);

		List<Concept> conceptBeanList = getGenericDataBeanDAO().findMatchingBeans(concept);

		return conceptBeanList;

	}

	public String getImageWithHotSpot(Concept concept, String conceptImageLocation)
	{
		List<Concept> concepts = getConceptBeanList(concept.getCode());
		Concept conceptBean = concepts.get(0);

		List<ConceptHotspotMapping> conceptHotspotMappingList = hotspotDao.getConceptHotSpotMappingList(conceptBean);

		HashMap<String, ConceptWrapper> conceptWrapperCache = new HashMap<String, ConceptWrapper>();

		ConceptWrapper conceptWrapper = new ConceptWrapper();
		conceptWrapper.setConcept(conceptBean);
		conceptWrapper.setHotspot(conceptHotspotMappingList);

		conceptWrapperCache.put(concept.getCode(), conceptWrapper);

		List<HashMap> conceptMapListForJson = new LinkedList<HashMap>();

		conceptDao.formatHotSpotWrapper(conceptMapListForJson, conceptWrapperCache, conceptImageLocation);

		String response = IcatalogUtility.createJSONFromMap(conceptMapListForJson.get(0));

		log.info("response json = " + response);

		return response;

	}

	/*public Boolean addHotspotList(List<ConceptHotspotMapping> conceptHostMappingList)
	{
		Boolean insertedData = false;
		for(int i=0 ;i <conceptHostMappingList.size();i++)
		{
			insertedData = addHotspot(conceptHostMappingList.get(i));
		}
		
		return insertedData;
		
	}*/

	public Boolean deleteConceptHotSpotMapping(ConceptHotspotMapping conceptHotspotMapping)
	{
		Boolean isDeleted = hotspotDao.deleteConceptHotSpotMapping(conceptHotspotMapping);

		return isDeleted;

	}

	public ConceptHotspotMapping getConceptHotspotMappingBean(ConceptHotspotMapping conceptHotspotMapping)
	{
		return hotspotDao.getConceptHotspotMappingBean(conceptHotspotMapping).get(0);
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param searchConcept
	 * @param conceptCategoryId
	 * @return
	 *
	 * @author himanshu
	 * @createdOn 02-May-2012
	 * @modifiedOn 02-May-2012 
	 * 
	 */

	public List<Concept> customSearch(Concept searchConcept, Long conceptCategoryId)
	{
		return getGenericDataBeanDAO().customSearch(searchConcept, conceptCategoryId);
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param searchConcept
	 * @return
	 *
	 * @author himanshu
	 * @createdOn 02-May-2012
	 * @modifiedOn 02-May-2012 
	 * 
	 */

	public List<Concept> doCustomSearch(Concept searchConcept)
	{
		return getGenericDataBeanDAO().doCustomSearch(searchConcept);
	}

	public String getConceptCategoryImageCode(String code)
	{
		String categoryCode = code;
		log.info("-----------In ConceptServiceImp / Category Code------------:" + categoryCode);

		List<ConceptCategory> conList = conceptCategoryDao.getConceptCategory(categoryCode);

		ConceptCategory conceptCategory = conList.get(0);
		long id = conceptCategory.getId();

		log.info("--------------------Concept Category Id for getting Oldest Concept----------:" + id);

		List<Concept> concepts = (List<Concept>)conceptDao.getOldestConcept(id);
		
		log.info("------------------Concept List Size-------------------:"+concepts.size());

		Concept concept = concepts.get(0);

		String conceptCode = concept.getCode();
		log.info("---------------ConceptCategoryImageCode---------------" + conceptCode);

		return conceptCode;
	}
}
