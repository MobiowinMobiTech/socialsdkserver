package com.mobicule.icatalog.concept.dao;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;

import com.mobicule.component.system.db.dao.GenericDataBeanDAO;
import com.mobicule.component.system.db.dao.GenericDataBeanHibernateDAO;
import com.mobicule.icatalog.concept.bean.Concept;
import com.mobicule.icatalog.concept.bean.ConceptHotspotMapping;

public class ConceptHotspotHibernateDao extends
		GenericDataBeanHibernateDAO<ConceptHotspotMapping> implements
		ConceptHotspotDao {

	private Log log = LogFactory.getLog(this.getClass());

	public List<ConceptHotspotMapping> getConceptHotSpotMappingList(
			Concept concept) {
		StringBuilder queryForHotSpotMapping = new StringBuilder();
		createQueryForToGetHotSpotMapping(queryForHotSpotMapping);

		if (log.isInfoEnabled()) {
			log.info("Concept Bean: " + concept);
			log.info("Query for getConceptHotSpotMappingList: "
					+ queryForHotSpotMapping.toString());
		}

		Query query = getSession().createQuery(
				queryForHotSpotMapping.toString());
		query.setString("conceptCode", concept.getCode());
		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);

		List<ConceptHotspotMapping> conceptHotspotMappinglist = query.list();

		if (log.isInfoEnabled()) {
			log.info("conceptHotspotMappinglist size: "
					+ conceptHotspotMappinglist.size());
		}

		return conceptHotspotMappinglist;

	}

	private void createQueryForToGetHotSpotMapping(
			StringBuilder queryForHotSpotMapping) {

		queryForHotSpotMapping
				.append(" From ConceptHotspotMapping chm where chm.conceptId = (");
		queryForHotSpotMapping
				.append(" select id from Concept c where c.code = :conceptCode and c.deleteFlag = :deleteFlag )");
		queryForHotSpotMapping.append(" and chm.deleteFlag = :deleteFlag");
		
		queryForHotSpotMapping.append(" and chm.productId in(select p.id from Product p,ProductCategory pc where p.categoryId=pc.id and pc.deleteFlag='F' and p.deleteFlag='F')  ");
	}

	public Boolean deleteConceptHotSpotMapping(
			ConceptHotspotMapping conceptHotspotMapping) {
		StringBuilder queryToDeleteHotSpotMapping = new StringBuilder();
		createQueryForToDeleteHotSpotMapping(queryToDeleteHotSpotMapping);

		if (log.isInfoEnabled()) {
			log.info("conceptHotspotMapping Bean: " + conceptHotspotMapping);
			log.info("Query for deleteConceptHotSpotMapping: "
					+ queryToDeleteHotSpotMapping.toString());
		}

		Query query = getSession().createQuery(
				queryToDeleteHotSpotMapping.toString());
		query.setString("deleteFlagTrue", GenericDataBeanDAO.DELETE_FLAG_TRUE);
		query.setString("deleteFlagFalse",
				conceptHotspotMapping.getDeleteFlag());
		query.setLong("Id", conceptHotspotMapping.getId());
		query.setLong("hotspotX", conceptHotspotMapping.getHotspotX());
		query.setLong("hotspotY", conceptHotspotMapping.getHotspotY());
		query.setLong("productId", conceptHotspotMapping.getProductId());
		query.setLong("modifiedBy", conceptHotspotMapping.getModifiedBy());
		query.setTimestamp("modifiedOn", conceptHotspotMapping.getModifiedOn());

		int res = query.executeUpdate();

		if (res > 0) {
			return true;
		} else {
			return false;
		}

	}

	private void createQueryForToDeleteHotSpotMapping(
			StringBuilder queryToDeleteHotSpotMapping) {
		queryToDeleteHotSpotMapping
				.append(" update ConceptHotspotMapping chm set chm.deleteFlag = :deleteFlagTrue,chm.modifiedBy = :modifiedBy,chm.modifiedOn = :modifiedOn");
		queryToDeleteHotSpotMapping
				.append(" where chm.id = :Id and chm.hotspotX = :hotspotX and chm.hotspotY = :hotspotY");
		queryToDeleteHotSpotMapping
				.append(" and chm.productId = :productId and chm.deleteFlag = :deleteFlagFalse");

	}
	
	public List<ConceptHotspotMapping> getConceptHotspotMappingBean(
			ConceptHotspotMapping conceptHotspotMapping) {
		StringBuilder queryForHotSpotMapping = new StringBuilder();
		createQueryForToGetHotSpotMappingBean(queryForHotSpotMapping);

		if (log.isInfoEnabled()) {
			log.info("Concept conceptHotspotMapping: " + conceptHotspotMapping);
			log.info("Query for getConceptHotSpotMappingList: "
					+ queryForHotSpotMapping.toString());
		}

		Query query = getSession().createQuery(
				queryForHotSpotMapping.toString());
		query.setLong("conceptId", conceptHotspotMapping.getConceptId());
		query.setString("deleteFlag", conceptHotspotMapping.getDeleteFlag());
		query.setLong("hotspotX", conceptHotspotMapping.getHotspotX());
		query.setLong("hotspotY", conceptHotspotMapping.getHotspotY());
		query.setLong("productId", conceptHotspotMapping.getProductId());
		query.setLong("createdBy", conceptHotspotMapping.getCreatedBy());
		query.setTimestamp("createdOn", conceptHotspotMapping.getCreatedOn());

		List<ConceptHotspotMapping> conceptHotspotMappinglist = query.list();

		if (log.isInfoEnabled()) {
			log.info("conceptHotspotMappinglist size: "
					+ conceptHotspotMappinglist.size());
		}

		return conceptHotspotMappinglist;

	}
	
	private void createQueryForToGetHotSpotMappingBean(
			StringBuilder queryForHotSpotMapping) {

		queryForHotSpotMapping.append(" From ConceptHotspotMapping chm where chm.conceptId = :conceptId");
		queryForHotSpotMapping.append(" and chm.hotspotX = :hotspotX and chm.hotspotY = :hotspotY and chm.productId = :productId");
		queryForHotSpotMapping.append(" and chm.deleteFlag = :deleteFlag and chm.createdBy = :createdBy and chm.createdOn = :createdOn");
		
	}

}
