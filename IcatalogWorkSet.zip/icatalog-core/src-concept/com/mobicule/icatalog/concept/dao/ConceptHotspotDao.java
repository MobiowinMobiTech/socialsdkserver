package com.mobicule.icatalog.concept.dao;

import java.util.List;

import com.mobicule.component.system.db.dao.GenericDataBeanDAO;
import com.mobicule.icatalog.concept.bean.Concept;
import com.mobicule.icatalog.concept.bean.ConceptHotspotMapping;

public interface ConceptHotspotDao extends GenericDataBeanDAO<ConceptHotspotMapping>
{
	public List<ConceptHotspotMapping> getConceptHotSpotMappingList(Concept concept);

	public Boolean deleteConceptHotSpotMapping(ConceptHotspotMapping conceptHotspotMapping);
	
	public List<ConceptHotspotMapping> getConceptHotspotMappingBean(
			ConceptHotspotMapping conceptHotspotMapping);
}
