package com.mobicule.icatalog.concept.dao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Hibernate;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;

import com.mobicule.component.system.db.dao.GenericDataBeanDAO;
import com.mobicule.icatalog.common.dao.AbstractSyncDao;
import com.mobicule.icatalog.concept.bean.Concept;
import com.mobicule.icatalog.concept.bean.ConceptHotspotMapping;
import com.mobicule.icatalog.concept.bean.ConceptWrapper;
import com.mobicule.icatalog.core.constants.IcatalogUtility;
import com.mobicule.icatalog.core.constants.SyncConstants;
import com.mobicule.icatalog.product.bean.Product;
import com.mobicule.icatalog.product.dao.ProductDao;

public class ConceptHibernateDao extends AbstractSyncDao<Concept> implements ConceptDao
{
	private Log log = LogFactory.getLog(this.getClass());

	private Map<String, List<String>> imageConfig;

	@Autowired
	private ProductDao productDao;

	/*public ProductDao getProductDao()
	{
		return productDao;
	}

	public void setProductDao(ProductDao productDao)
	{
		this.productDao = productDao;
	}
	*/
	public Map<String, List<String>> getImageConfig()
	{
		return imageConfig;
	}

	public void setImageConfig(Map<String, List<String>> imageConfig)
	{
		this.imageConfig = imageConfig;
	}

	@Override
	public String findAllAfterSyncDate(Timestamp lastSyncDate, int pageNumber, int pageSize, String entity)
	{
		return null;
	}

	@Override
	public String getNewlyAddedEntities(int pageNumber, int pageSize, String login)
	{
		final List<HashMap> conceptMapList = new LinkedList<HashMap>();

		if (log.isInfoEnabled())
		{
			log.info("in newly added Entity pagenumber: " + pageNumber);
		}
		
/*Fetching concept codes and setting page size on that*/
		
		StringBuilder queryForConceptCode = new StringBuilder();
		queryForConceptCode.append("select distinct(c.code) ccode ");
		createQueryForNewEntries(queryForConceptCode);
		
		if (log.isInfoEnabled())
		{
			log.info("in newly added queryForConceptCode: " + queryForConceptCode.toString());
		}

		SQLQuery query1 = getSession().createSQLQuery(queryForConceptCode.toString());
		query1.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);
		

		query1.setFirstResult(pageNumber * pageSize);
		query1.setMaxResults(pageSize);

		List<String> conceptCodes = query1.addScalar("ccode", Hibernate.STRING).list();

		log.info("conceptCodes: " + conceptCodes.size());

		//Fetching data for concept as per previously retrieved code
		
		StringBuilder queryForNewEntries = new StringBuilder();
		queryForNewEntries.append("select {c.*}, {chm.*} ");
	
		createQueryForNewEntries(queryForNewEntries);
		appendConceptCodeWithIn(conceptCodes, queryForNewEntries);

		if (log.isInfoEnabled())
		{
			log.info("in newly added queryForNewEntries: " + queryForNewEntries.toString());
		}

		SQLQuery query = getSession().createSQLQuery(queryForNewEntries.toString());
		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);

		/*query.setFirstResult(pageNumber * pageSize);
		query.setMaxResults(pageSize);
*/
		List<Object[]> list = query.addEntity("c", Concept.class).addEntity("chm", ConceptHotspotMapping.class).list();

		if (log.isInfoEnabled())
		{
			log.info("List size: " + list.size());
		}

		/*if (CollectionUtils.isEmpty(list))
		{
			return null;
		}*/

		if (log.isDebugEnabled())
		{
			log.debug("list : " + ((list == null) ? "null" : list.size()));
		}

		HashMap<String, ConceptWrapper> conceptWrapperCache = new HashMap<String, ConceptWrapper>();

		for (Object[] obj : list)
		{
			//Concept currentConcept = (Concept) obj[0];
			//	ConceptHotspotMapping currentConceptHotspotMapping = (ConceptHotspotMapping) obj[1];

			/*System.err.println(currentConcept.getDeleteFlag());
			System.err.println(currentConceptHotspotMapping.getDeleteFlag());
			System.err.println("----------------");*/

			Concept currentConcept = (Concept) obj[0];

			String currentConceptCode = currentConcept.getCode();

			ConceptWrapper currentConceptWrapper = null;

			if (currentConcept.getDeleteFlag().equalsIgnoreCase("F"))
			{
				// add Concept
				if (!conceptWrapperCache.containsKey(currentConceptCode))
				{
					currentConceptWrapper = new ConceptWrapper();
					currentConceptWrapper.setConcept(currentConcept);

					conceptWrapperCache.put(currentConceptCode, currentConceptWrapper);
				}
				else
				{
					currentConceptWrapper = conceptWrapperCache.get(currentConceptCode);
				}
			}
			else
			{
				continue;
			}
			if (obj[1] != null)
			{

				ConceptHotspotMapping currentConceptHotspot = (ConceptHotspotMapping) obj[1];

				List<ConceptHotspotMapping> hotspotList = currentConceptWrapper.getHotspot();

				if (currentConceptHotspot.getDeleteFlag().equals("F"))
				{
					if (!hotspotList.contains(currentConceptHotspot))
					{
						hotspotList.add(currentConceptHotspot);
					}
				}
			}
			if (log.isInfoEnabled())
			{
				log.info("Concept Wrapper: " + currentConceptWrapper.toString());
				log.info("Size of cache: " + conceptWrapperCache.size());
			}

		}

		if (log.isDebugEnabled())
		{
			log.debug("conceptWrapperCache : " + conceptWrapperCache);
		}

		formatWrapper(conceptMapList, conceptWrapperCache, "ADD");
		HashMap dataMap = IcatalogUtility.createResponseMessage(conceptMapList);

		String response = IcatalogUtility.createJSONFromMap(dataMap);

		return response;
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param obj
	 * @return
	 *
	 * @author shalini
	 * @createdOn 10-May-2012
	 * @modifiedOn 10-May-2012 
	 * 
	 */
	private ConceptHotspotMapping createConceptHotspotBean(Object[] obj)
	{
		ConceptHotspotMapping hotspotMapping = new ConceptHotspotMapping();

		if (obj[15] != null)
		{
			hotspotMapping.setId(Long.parseLong(obj[15].toString()));
		}
		if (obj[16] != null)
		{
			hotspotMapping.setConceptId(Long.parseLong(obj[16].toString()));
		}
		if (obj[17] != null)
		{
			hotspotMapping.setHotspotX(Long.parseLong(obj[17].toString()));
		}
		if (obj[18] != null)
		{
			hotspotMapping.setHotspotY(Long.parseLong(obj[18].toString()));
		}
		if (obj[19] != null)
		{
			hotspotMapping.setProductId(Long.parseLong(obj[19].toString()));
		}
		if (obj[20] != null)
		{
			hotspotMapping.setCreatedBy(Long.parseLong(obj[20].toString()));
		}
		if (obj[21] != null)
		{
			hotspotMapping.setCreatedOn((Timestamp) obj[21]);
		}
		if (obj[22] != null)
		{
			hotspotMapping.setModifiedBy(Long.parseLong(obj[22].toString()));
		}
		if (obj[23] != null)
		{
			hotspotMapping.setModifiedOn((Timestamp) obj[23]);
		}
		if (obj[24] != null)
		{
			log.info("obj[24]: " + obj[24]);
			hotspotMapping.setDeleteFlag(obj[24].toString());
		}

		return hotspotMapping;
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param obj
	 * @return
	 *
	 * @author shalini
	 * @createdOn 10-May-2012
	 * @modifiedOn 10-May-2012 
	 * 
	 */
	private Concept createConceptBean(Object[] obj)
	{
		Concept concept = new Concept();

		if (obj[0] != null)
		{
			concept.setId(Long.parseLong(obj[0].toString()));
		}
		if (obj[1] != null)
		{
			concept.setCode(obj[1].toString());
		}
		if (obj[2] != null)
		{
			concept.setName(obj[2].toString());
		}
		if (obj[3] != null)
		{
			concept.setDescription(obj[3].toString());
		}
		if (obj[4] != null)
		{
			concept.setCategoryId(Long.parseLong(obj[4].toString()));
		}
		if (obj[5] != null)
		{
			concept.setRetailPrice(Double.parseDouble(obj[5].toString()));
		}
		if (obj[6] != null)
		{
			concept.setOfferFlag(obj[6].toString());
		}
		if (obj[7] != null)
		{
			concept.setOfferPrice(Double.parseDouble(obj[7].toString()));
		}
		if (obj[8] != null)
		{
			concept.setSearchTags(obj[8].toString());
		}
		if (obj[9] != null)
		{
			concept.setBrand(obj[9].toString());
		}
		if (obj[10] != null)
		{
			concept.setCreatedBy(Long.parseLong(obj[10].toString()));
		}
		if (obj[11] != null)
		{
			concept.setCreatedOn((Timestamp) obj[11]);
		}
		if (obj[12] != null)
		{
			concept.setModifiedBy(Long.parseLong(obj[12].toString()));
		}
		if (obj[13] != null)
		{
			concept.setModifiedOn((Timestamp) obj[13]);
		}
		if (obj[14] != null)
		{
			concept.setDeleteFlag(obj[14].toString());
		}
		return concept;
	}

	public  void appendConceptCodeWithIn(List<String> codeList, StringBuilder queryBuilder)
    {
        if (CollectionUtils.isEmpty(codeList))
        {
            return;
        }

        queryBuilder.append(" and ( ");
        int chunkRemainder = 0;
        boolean isFirstTime = true;

        for (int i = 0; i < codeList.size(); i++)
        {
            String code = codeList.get(i);

            chunkRemainder = (i) % SyncConstants.MAX_IN_QUERY_LIST_SIZE;

            if (chunkRemainder == 0)
            {
                if (isFirstTime)
                {
                    isFirstTime = false;
                }
                else
                {
                	queryBuilder.append(" or ");
                }

                queryBuilder.append(" c.code in  ( '");

                queryBuilder.append(code);

                if (!(chunkRemainder == SyncConstants.MAX_IN_QUERY_LIST_SIZE - 1) && (i < codeList.size() - 1))
                {
                	queryBuilder.append("', '");
                }
                else if (i == (codeList.size() - 1))
                {
                	queryBuilder.append("' ) ");
                }
            }
            else if (chunkRemainder == SyncConstants.MAX_IN_QUERY_LIST_SIZE - 1)
            {
            	queryBuilder.append(code);
            	queryBuilder.append("' ) ");
            }
            else
            {
            	queryBuilder.append(code);

                if (!(chunkRemainder == SyncConstants.MAX_IN_QUERY_LIST_SIZE - 1) && (i < codeList.size() - 1))
                {
                	queryBuilder.append("', '");
                }
                else if (i == (codeList.size() - 1))
                {
                	queryBuilder.append("' ) ");
                }
            }
        }
        
        queryBuilder.append(" )");
    }
	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param conceptMapList
	 * @param conceptWrapperCache
	 * @param string
	 *
	 * @author shalini
	 * @createdOn 04-Apr-2012
	 * @modifiedOn 04-Apr-2012 
	 * 
	 */
	public void formatWrapper(List<HashMap> conceptMapList, HashMap<String, ConceptWrapper> conceptWrapperCache,
			String action)
	{
		log.info("In formatWrapper" + conceptWrapperCache);
		List<String> imageBasePath = (List<String>) imageConfig.get("IMAGE_BASE_PATH");
		for (String key : conceptWrapperCache.keySet())
		{
			ConceptWrapper wrapper = new ConceptWrapper();
			HashMap<String, Object> formattedConcept = new HashMap<String, Object>();

			List<HashMap> hotspotList = new ArrayList<HashMap>();

			int i = 0;

			wrapper = conceptWrapperCache.get(key);

			List<String> imgList = new ArrayList<String>();
			log.info("In formatWrapper / wrapper.getConcept().getCode() = " + wrapper.getConcept().getCode());
			imgList = IcatalogUtility.fetchImageList(imageBasePath.get(0), "concept", wrapper.getConcept().getCode());
			log.info("In formatWrapper / imgList = " + imgList);
			List<String> imgConfigList = configImgList(imgList);
			log.info("In formatWrapper / imgConfigList = " + imgConfigList);
			formattedConcept.put("id", wrapper.getConcept().getId().toString());
			formattedConcept.put("code", wrapper.getConcept().getCode());
			formattedConcept.put("name", wrapper.getConcept().getName());
			formattedConcept.put("imgModOn", wrapper.getConcept().getImageModifiedOn());

			if (wrapper.getConcept().getRetailPrice() != null)
			{
				formattedConcept.put("price", wrapper.getConcept().getRetailPrice());
			}

			if (wrapper.getConcept().getOfferPrice() != null)
			{
				formattedConcept.put("offer_price", wrapper.getConcept().getOfferPrice());
			}
			if (wrapper.getConcept().getOfferFlag() != null)
			{
				formattedConcept.put("offer_flag", wrapper.getConcept().getOfferFlag());
			}
			if (wrapper.getConcept().getGiftFlag() != null)
			{
				formattedConcept.put("gift_flag", wrapper.getConcept().getGiftFlag());
			}

			if (wrapper.getConcept().getDescription() != null)
			{
				formattedConcept.put("description", wrapper.getConcept().getDescription());
			}

			formattedConcept.put("category_id", wrapper.getConcept().getCategoryId());

			log.info(" wrapper.getHotspot() = " + wrapper.getHotspot());
			log.info(" wrapper.getHotspot() = " + wrapper.getHotspot().size());

			for (i = 0; i < wrapper.getHotspot().size(); i++)
			{
				ConceptHotspotMapping conceptHotspotMapping = wrapper.getHotspot().get(i);
				
				Long productId = conceptHotspotMapping.getProductId();
				Long hotspotX = conceptHotspotMapping.getHotspotX();
				Long hotspotY = conceptHotspotMapping.getHotspotY();
				
				if (null == productId || null == hotspotX || null == hotspotY)
				{
					continue;
				}
				
				Product product = productDao.findMatchingBeanById(Product.class, "id", productId);
				
				if (null == product)
				{
					continue;
				}
				
				if (log.isInfoEnabled())
				{
					log.info("product code: " + product.getCode());
				}
				
				List<String> prodImgList = IcatalogUtility.fetchImageList(imageBasePath.get(0), "product",
						product.getCode());

				if (null == prodImgList)
				{
					continue;
				}

				HashMap<String, Object> hotspotMap = new HashMap<String, Object>();
				
				hotspotMap.put("product_id", productId);
				hotspotMap.put("x_coordinate", hotspotX);
				hotspotMap.put("y_coordinate", hotspotY);

				hotspotList.add(hotspotMap);
			}
			
			//log.info(" wrapper.getHotspot() = " + wrapper.getHotspot().size());
			formattedConcept.put("hotspot_definitions", hotspotList);

			log.info(" formattedConcept after put = " + formattedConcept);

			if (imgConfigList != null)
			{
				formattedConcept.put("image", imgConfigList);
			}
			else
				log.info("img list size: " + imgConfigList.size());

			if (action.equalsIgnoreCase("add"))
			{
				formattedConcept.put("sync_flag", "A");
			}
			else if (action.equalsIgnoreCase("modify"))
			{
				formattedConcept.put("sync_flag", "M");
			}
			else if (action.equalsIgnoreCase("delete"))
			{
				formattedConcept.put("sync_flag", "D");
			}
			log.info(" formattedConcept last= " + formattedConcept);
			conceptMapList.add(formattedConcept);

		}

	}

	public void formatHotSpotWrapper(List<HashMap> conceptMapList, HashMap<String, ConceptWrapper> conceptWrapperCache,
			String conceptImageLocation)
	{
		System.out.println("In formatHotSpotWrapper" + conceptWrapperCache);
		System.out.println("In formatWrapper / imageConfig = " + imageConfig);
		List<String> imageMap = (List<String>) imageConfig.get("IMAGE_BASE_PATH");
		System.out.println("In formatWrapper / imageMap = " + imageMap.get(0));

		for (String key : conceptWrapperCache.keySet())
		{
			ConceptWrapper wrapper = new ConceptWrapper();
			HashMap<String, Object> formattedConcept = new HashMap<String, Object>();

			List<HashMap> hotspotList = new ArrayList<HashMap>();

			int i = 0;

			wrapper = conceptWrapperCache.get(key);

			formattedConcept.put("id", wrapper.getConcept().getId().toString());
			formattedConcept.put("code", wrapper.getConcept().getCode());
			formattedConcept.put("name", wrapper.getConcept().getName());
			formattedConcept.put("imgModOn", wrapper.getConcept().getImageModifiedOn());
			
			if (wrapper.getConcept().getRetailPrice() != null)
			{
				formattedConcept.put("price", wrapper.getConcept().getRetailPrice());
			}

			if (wrapper.getConcept().getDescription() != null)
			{
				formattedConcept.put("description", wrapper.getConcept().getDescription());
			}

			formattedConcept.put("category_id", wrapper.getConcept().getCategoryId());

			log.info(" wrapper.getHotspot() = " + wrapper.getHotspot());
			log.info(" wrapper.getHotspot() = " + wrapper.getHotspot().size());

			for (i = 0; i < wrapper.getHotspot().size(); i++)
			{

				HashMap<String, Object> hotspotMap = new HashMap<String, Object>();
				hotspotMap.put("x_coordinate", wrapper.getHotspot().get(i).getHotspotX());
				hotspotMap.put("y_coordinate", wrapper.getHotspot().get(i).getHotspotY());
				hotspotMap.put("product_id", wrapper.getHotspot().get(i).getProductId());
				hotspotMap.put("hotspot_mapping_id", wrapper.getHotspot().get(i).getId());
				hotspotList.add(hotspotMap);

			}
			log.info(" wrapper.getHotspot() = " + wrapper.getHotspot().size());
			formattedConcept.put("hotspot_definition", hotspotList);
			log.info(" formattedConcept after put = " + formattedConcept);

			formattedConcept.put("image", conceptImageLocation);

			log.info(" formattedConcept last= " + formattedConcept);
			conceptMapList.add(formattedConcept);

		}

	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param imgList
	 * @return
	 *
	 * @author shalini
	 * @createdOn 10-Apr-2012
	 * @modifiedOn 10-Apr-2012 
	 * 
	 */
	private List<String> configImgList(List<String> imgList)
	{
		int i;
		Map mapValues = new HashMap();
		mapValues.put("config", imageConfig.get("IMG_DIM_CONCEPT"));
		log.info("map values" + mapValues);
		List<String> configList = new ArrayList<String>();
		//String newConfig=null;
		for (String img : imgList)
		{
			List imgConfig = (List) mapValues.get("config");

			for (i = 0; i < imgConfig.size(); i++)
			{
				String newConfig = img.concat("-" + imgConfig.get(i));
				log.info("new Img" + newConfig);
				configList.add(newConfig);
			}

		}
		return configList;
	}

	@Override
	public int getAddedEntitiesCount(String login)
	{
		StringBuilder queryForNewEntries = new StringBuilder();

		queryForNewEntries.append("select count(distinct(c.code))  conceptCount ");
		createQueryForNewEntries(queryForNewEntries);
		SQLQuery query = getSession().createSQLQuery(queryForNewEntries.toString());

		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);

		List<Long> returnValue = query.addScalar("conceptCount", Hibernate.LONG).list();

		if (CollectionUtils.isEmpty(returnValue))
		{
			return 0;
		}
		else
		{
			return returnValue.get(0).intValue();
		}
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param queryForNewEntries
	 *
	 * @author shalini
	 * @createdOn 03-Apr-2012
	 * @modifiedOn 03-Apr-2012 
	 * 
	 */
	private void createQueryForNewEntries(StringBuilder queryForNewEntries)
	{

		queryForNewEntries.append(" from concept c LEFT OUTER JOIN concept_hotspot_mapping chm ");
		queryForNewEntries.append("on c.id=chm.concept_id  ");
		queryForNewEntries
				.append("where c.category_id in (select cc.id from concept_category cc where cc.delete_flag =:deleteFlag) ");
		queryForNewEntries.append("and  (c.delete_flag=:deleteFlag or chm.delete_flag=:deleteFlag) ");

	}

	@Override
	public int getNewlyAddedEntitiesAfterSyncDateCount(Timestamp lastSyncDate, String login)
	{
		StringBuilder queryForNewEntries = new StringBuilder();

		queryForNewEntries.append(" select count(distinct(c.code)) conceptCount ");
		createQueryForNewEntriesAfterSyncDate(queryForNewEntries);

		SQLQuery query = getSession().createSQLQuery(queryForNewEntries.toString());

		if (log.isInfoEnabled())
		{
			log.info("query in add: " + queryForNewEntries);
		}

		query.setTimestamp("createdOn", lastSyncDate);
		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);

		List<Long> returnValue = query.addScalar("conceptCount", Hibernate.LONG).list();

		if (CollectionUtils.isEmpty(returnValue))
		{
			return 0;
		}
		else
		{
			return returnValue.get(0).intValue();
		}
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param queryForNewEntries
	 *
	 * @author shalini
	 * @createdOn 03-Apr-2012
	 * @modifiedOn 03-Apr-2012 
	 * 
	 */
	private void createQueryForNewEntriesAfterSyncDate(StringBuilder queryForNewEntries)
	{
		queryForNewEntries.append(" from concept c LEFT OUTER JOIN concept_hotspot_mapping chm ");
		queryForNewEntries.append("on c.id=chm.concept_id  ");
		queryForNewEntries
				.append("where c.category_id in (select cc.id from concept_category cc where cc.delete_flag =:deleteFlag) ");
		queryForNewEntries.append(" and c.created_on>=:createdOn ");
		queryForNewEntries.append("and c.delete_flag=:deleteFlag ");

	}

	@Override
	public int getModifiedEntitiesAfterSyncDateCount(Timestamp lastSyncDate, String login)
	{
		StringBuilder queryForModifiedEntries = new StringBuilder();

		queryForModifiedEntries.append(" select count(distinct(c.code)) conceptCount ");
		createQueryForModifiedEntries(queryForModifiedEntries);

		if (log.isInfoEnabled())
		{
			log.info("Query: " + queryForModifiedEntries.toString());
		}

		SQLQuery query = getSession().createSQLQuery(queryForModifiedEntries.toString());

		query.setTimestamp("createdOn", lastSyncDate);
		query.setTimestamp("modifiedOn", lastSyncDate);
		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);

		List<Long> returnValue = query.addScalar("conceptCount", Hibernate.LONG).list();

		if (CollectionUtils.isEmpty(returnValue))
		{
			return 0;
		}
		else
		{
			return returnValue.get(0).intValue();
		}
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param queryForModifiedEntries
	 *
	 * @author shalini
	 * @createdOn 03-Apr-2012
	 * @modifiedOn 03-Apr-2012 
	 * 
	 */
	private void createQueryForModifiedEntries(StringBuilder queryForModifiedEntries)
	{
		queryForModifiedEntries.append(" from concept c LEFT OUTER JOIN concept_hotspot_mapping chm ");
		queryForModifiedEntries.append("on c.id=chm.concept_id  ");
		queryForModifiedEntries
				.append("where c.category_id in (select cc.id from concept_category cc where cc.delete_flag =:deleteFlag) and ");
		queryForModifiedEntries
				.append(" ((c.created_on< :createdOn and c.modified_on>= :modifiedOn  and c.delete_flag= :deleteFlag) ");
		queryForModifiedEntries
				.append("or  c.id in (select concept_id from  concept_hotspot_mapping chm where (chm.modified_on>= :modifiedOn ) ))");
	}

	@Override
	public int getDeletedEntitiesAfterSyncDateCount(Timestamp lastSyncDate)
	{
		StringBuilder queryForDeletedEntries = new StringBuilder();

		queryForDeletedEntries.append(" select count( c.code) ");
		createQueryForDeletedEntries(queryForDeletedEntries);

		Query query = getSession().createQuery(queryForDeletedEntries.toString());
		query.setTimestamp("createdOn", lastSyncDate);
		query.setTimestamp("modifiedOn", lastSyncDate);
		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_TRUE);

		List<Long> returnValue = query.list();

		if (CollectionUtils.isEmpty(returnValue))
		{
			return 0;
		}
		else
		{
			return returnValue.get(0).intValue();
		}
	}

	@Override
	public String getNewlyAddedEntitiesAfterSyncDate(Timestamp lastSyncDate, int pageNumber, int pageSize, String login)
	{
		final List<HashMap> conceptMapList = new LinkedList<HashMap>();
		
/*Fetching concept codes and setting page size on that*/
		
		StringBuilder queryForConceptCode = new StringBuilder();
		queryForConceptCode.append("select distinct(c.code) ccode ");
		createQueryForNewEntriesAfterSyncDate(queryForConceptCode);
		
		if (log.isInfoEnabled())
		{
			log.info("in newly added queryForConceptCode: " + queryForConceptCode.toString());
		}

		SQLQuery query1 = getSession().createSQLQuery(queryForConceptCode.toString());
		query1.setTimestamp("createdOn", lastSyncDate);
		query1.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);
		

		query1.setFirstResult(pageNumber * pageSize);
		query1.setMaxResults(pageSize);

		List<String> conceptCodes = query1.addScalar("ccode", Hibernate.STRING).list();

		log.info("conceptCodes: " + conceptCodes.size());
		
		StringBuilder queryForNewEntries = new StringBuilder();
		
		queryForNewEntries.append("select {c.*}, {chm.*} ");
		
		createQueryForNewEntriesAfterSyncDate(queryForNewEntries);
		appendConceptCodeWithIn(conceptCodes, queryForNewEntries);

		SQLQuery query = getSession().createSQLQuery(queryForNewEntries.toString());

		query.setTimestamp("createdOn", lastSyncDate);
		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);

		/*query.setFirstResult(pageNumber * pageSize);
		query.setMaxResults(pageSize);*/

		List<Object[]> list = query.addEntity("c", Concept.class).addEntity("chm", ConceptHotspotMapping.class).list();

		if (log.isInfoEnabled())
		{
			log.info("List size: " + list.size());
		}

		/*if (CollectionUtils.isEmpty(list))
		{
			return null;
		}*/

		if (log.isDebugEnabled())
		{
			log.debug("list : " + ((list == null) ? "null" : list.size()));
		}

		HashMap<String, ConceptWrapper> conceptWrapperCache = new HashMap<String, ConceptWrapper>();

		for (Object[] obj : list)
		{
			Concept currentConcept = (Concept) obj[0];

			String currentConceptCode = currentConcept.getCode();

			ConceptWrapper currentConceptWrapper = null;

			// add Concept
			if (!conceptWrapperCache.containsKey(currentConceptCode))
			{
				currentConceptWrapper = new ConceptWrapper();
				currentConceptWrapper.setConcept(currentConcept);

				conceptWrapperCache.put(currentConceptCode, currentConceptWrapper);
			}
			else
			{
				currentConceptWrapper = conceptWrapperCache.get(currentConceptCode);
			}

			if (obj[1] != null)
			{
				// add concept hotspot
				ConceptHotspotMapping currentConceptHotspot = (ConceptHotspotMapping) obj[1];
				List<ConceptHotspotMapping> hotspotList = currentConceptWrapper.getHotspot();

				if (currentConceptHotspot.getDeleteFlag().equals("F"))
				{
					if (!hotspotList.contains(currentConceptHotspot))
					{
						hotspotList.add(currentConceptHotspot);
					}
				}
			}

			if (log.isInfoEnabled())
			{
				log.info("Concept Wrapper: " + currentConceptWrapper.toString());
				log.info("Size of cache: " + conceptWrapperCache.size());
			}

		}

		if (log.isDebugEnabled())
		{
			log.debug("conceptWrapperCache : " + conceptWrapperCache);
		}

		formatWrapper(conceptMapList, conceptWrapperCache, "ADD");
		HashMap dataMap = IcatalogUtility.createResponseMessage(conceptMapList);

		String response = IcatalogUtility.createJSONFromMap(dataMap);

		return response;
	}

	@Override
	public String getModifiedEntitiesAfterSyncDate(Timestamp lastSyncDate, int pageNumber, int pageSize, String login)
	{
		final List<HashMap> conceptMapList = new LinkedList<HashMap>();
/*Fetching concept codes and setting page size on that*/
		
		StringBuilder queryForConceptCode = new StringBuilder();
		queryForConceptCode.append("select distinct(c.code) ccode ");
		createQueryForModifiedEntries(queryForConceptCode);
		
		if (log.isInfoEnabled())
		{
			log.info("in modified queryForConceptCode: " + queryForConceptCode.toString());
		}

		SQLQuery query1 = getSession().createSQLQuery(queryForConceptCode.toString());
		query1.setTimestamp("createdOn", lastSyncDate);
		query1.setTimestamp("modifiedOn", lastSyncDate);
		query1.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);
		

		query1.setFirstResult(pageNumber * pageSize);
		query1.setMaxResults(pageSize);

		List<String> conceptCodes = query1.addScalar("ccode", Hibernate.STRING).list();

		log.info("conceptCodes: " + conceptCodes.size());

		//Fetching data for concept as per previously retrieved code
		
		StringBuilder queryForModifiedEntries = new StringBuilder();
		queryForModifiedEntries.append("select {c.*}, {chm.*} ");

		createQueryForModifiedEntries(queryForModifiedEntries);
		appendConceptCodeWithIn(conceptCodes, queryForModifiedEntries);
		
		SQLQuery query = getSession().createSQLQuery(queryForModifiedEntries.toString());

		query.setTimestamp("createdOn", lastSyncDate);
		query.setTimestamp("modifiedOn", lastSyncDate);
		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);

		/*query.setFirstResult(pageNumber * pageSize);
		query.setMaxResults(pageSize);*/

		List<Object[]> list = query.addEntity("c", Concept.class).addEntity("chm", ConceptHotspotMapping.class).list();

		if (log.isInfoEnabled())
		{
			log.info("List size: " + list.size());
		}

		/*if (CollectionUtils.isEmpty(list))
		{
			return null;
		}
		*/
		if (log.isDebugEnabled())
		{
			log.debug("list : " + ((list == null) ? "null" : list.size()));
		}

		HashMap<String, ConceptWrapper> conceptWrapperCache = new HashMap<String, ConceptWrapper>();

		for (Object[] obj : list)
		{
			Concept currentConcept = (Concept) obj[0];

			String currentConceptCode = currentConcept.getCode();

			ConceptWrapper currentConceptWrapper = null;

			// add Concept
			if (!conceptWrapperCache.containsKey(currentConceptCode))
			{
				currentConceptWrapper = new ConceptWrapper();
				currentConceptWrapper.setConcept(currentConcept);

				conceptWrapperCache.put(currentConceptCode, currentConceptWrapper);
			}
			else
			{
				currentConceptWrapper = conceptWrapperCache.get(currentConceptCode);
			}

			if (obj[1] != null)
			{

				// add concept hotspot
				ConceptHotspotMapping currentConceptHotspot = (ConceptHotspotMapping) obj[1];
				List<ConceptHotspotMapping> hotspotList = currentConceptWrapper.getHotspot();

				if (currentConceptHotspot.getDeleteFlag().equals("F"))
				{
					if (!hotspotList.contains(currentConceptHotspot))
					{
						hotspotList.add(currentConceptHotspot);
					}
				}
			}

			if (log.isInfoEnabled())
			{
				log.info("Concept Wrapper: " + currentConceptWrapper.toString());
				log.info("Size of cache: " + conceptWrapperCache.size());
			}

		}

		if (log.isDebugEnabled())
		{
			log.debug("conceptWrapperCache : " + conceptWrapperCache);
		}

		formatWrapper(conceptMapList, conceptWrapperCache, "MODIFY");
		HashMap dataMap = IcatalogUtility.createResponseMessage(conceptMapList);

		String response = IcatalogUtility.createJSONFromMap(dataMap);

		return response;
	}

	@Override
	public String getDeletedEntitiesAfterSyncDate(Timestamp lastSyncDate, int pageNumber, int pageSize)
	{
		final List<HashMap> conceptMapList = new LinkedList<HashMap>();
		StringBuilder queryForDeletedEntries = new StringBuilder();

		createQueryForDeletedEntries(queryForDeletedEntries);

		Query query = getSession().createQuery(queryForDeletedEntries.toString());

		query.setTimestamp("createdOn", lastSyncDate);
		query.setTimestamp("modifiedOn", lastSyncDate);
		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_TRUE);

		query.setFirstResult(pageNumber * pageSize);
		query.setMaxResults(pageSize);

		List<Concept> list = query.list();

		if (log.isInfoEnabled())
		{
			log.info("List size: " + list.size());
		}

		/*	if (CollectionUtils.isEmpty(list))
			{
				return null;
			}*/

		if (log.isDebugEnabled())
		{
			log.debug("list : " + ((list == null) ? "null" : list.size()));
		}

		HashMap<String, ConceptWrapper> conceptWrapperCache = new HashMap<String, ConceptWrapper>();

		for (Concept currentConcept : list)
		{

			String currentConceptCode = currentConcept.getCode();

			ConceptWrapper currentConceptWrapper = null;

			// add Concept
			if (!conceptWrapperCache.containsKey(currentConceptCode))
			{
				currentConceptWrapper = new ConceptWrapper();
				currentConceptWrapper.setConcept(currentConcept);

				conceptWrapperCache.put(currentConceptCode, currentConceptWrapper);
			}
			else
			{
				currentConceptWrapper = conceptWrapperCache.get(currentConceptCode);
			}

			if (log.isInfoEnabled())
			{
				log.info("Concept Wrapper: " + currentConceptWrapper.toString());
				log.info("Size of cache: " + conceptWrapperCache.size());
			}

		}

		if (log.isDebugEnabled())
		{
			log.debug("conceptWrapperCache : " + conceptWrapperCache);
		}

		formatWrapper(conceptMapList, conceptWrapperCache, "DELETE");
		HashMap dataMap = IcatalogUtility.createResponseMessage(conceptMapList);

		String response = IcatalogUtility.createJSONFromMap(dataMap);

		return response;
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param queryForDeletedEntries
	 *
	 * @author shalini
	 * @createdOn 04-Apr-2012
	 * @modifiedOn 04-Apr-2012 
	 * 
	 */
	private void createQueryForDeletedEntries(StringBuilder queryForDeletedEntries)
	{
		queryForDeletedEntries
				.append(" From Concept c where c.createdOn< :createdOn and c.modifiedOn >= :modifiedOn and c.deleteFlag= :deleteFlag");

	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param searchConcept
	 * @param conceptCategoryId
	 * @return
	 *
	 * @author himanshu
	 * @createdOn 02-May-2012
	 * @modifiedOn 02-May-2012 
	 * 
	 */

	public List<Concept> customSearch(Concept searchConcept, Long conceptCategoryId)
	{
		StringBuilder searchQueryBuilder = new StringBuilder(
				" select c from Concept c,ConceptCategory cc where c.deleteFlag = :deleteFlag");

		boolean isFirstClause = true;

		String searchTags = searchConcept.getName();

		Long conceptCategorySearch = conceptCategoryId;

		System.out.println("========In Dao Layer=====CustomSearch========with CategoryID======:::"
				+ conceptCategorySearch);

		if (null != searchTags)
		{
			if (isFirstClause)
			{
				searchQueryBuilder.append(" and ");
				isFirstClause = false;
			}
			else
			{
				searchQueryBuilder.append(" and ");
			}

			searchQueryBuilder
					.append("  ( c.name like :searchTags or c.code like :searchTags or c.searchTags like :searchTags) ");
			isFirstClause = false;
		}

		searchQueryBuilder.append(" and c.categoryId=:conceptCategorySearch ");

		searchQueryBuilder.append(" and c.categoryId=cc.id and cc.deleteFlag='F' ");

		Query query = getSession().createQuery(searchQueryBuilder.toString());
		query.setString("deleteFlag", "F");

		if (null != searchTags)
		{
			query.setParameter("searchTags", "%" + searchTags + "%");
		}

		if (conceptCategorySearch != 0)
		{
			query.setParameter("conceptCategorySearch", conceptCategorySearch);
		}

		log.info("=====query for search============::: " + query);

		List<Concept> conceptList = query.list();

		log.info("=======CustomSearch=======Concept size is===========:::" + conceptList.size());

		return conceptList;

	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param searchConcept
	 * @return
	 *
	 * @author himanshu
	 * @createdOn 02-May-2012
	 * @modifiedOn 02-May-2012 
	 * 
	 */
	@Override
	public List<Concept> doCustomSearch(Concept searchConcept)
	{

		log.info("=======In Dao Layer===doCustomSearch=====Without Concept Category===");

		StringBuilder searchQueryBuilder = new StringBuilder(
				"select c from Concept c,ConceptCategory cc where c.deleteFlag = :deleteFlag");

		boolean isFirstClause = true;

		String searchTags = searchConcept.getName();
		log.info("=======In Dao Layer===doCustomSearch=====Without Concept Category===SearchTag:::" + searchTags);

		if (null != searchTags)
		{
			if (isFirstClause)
			{
				searchQueryBuilder.append(" and ");
				isFirstClause = false;
			}
			else
			{
				searchQueryBuilder.append(" and");
			}

			searchQueryBuilder
					.append(" ( c.name like :searchTags or c.code like :searchTags or c.searchTags like :searchTags) ");
		}

		searchQueryBuilder.append(" and c.categoryId=cc.id and cc.deleteFlag='F' ");

		Query query = getSession().createQuery(searchQueryBuilder.toString());
		query.setString("deleteFlag", "F");

		if (null != searchTags)
		{
			query.setParameter("searchTags", "%" + searchTags + "%");
		}

		log.info("----query for search-----::: " + query);

		List<Concept> conceptList = query.list();

		log.info("===In DoCustom Search==resultList size is===:::" + conceptList.size());
		return conceptList;

	}

	public List<Concept> getOldestConcept(long id)
	{

		log.info("-------------In ConceptHibernateDao / getOldestConcept-------------------");

		long searchTags = id;

		log.info("-------------In ConceptHibernateDao / getOldestConcept / Category_Id-------------------:"
				+ searchTags);

		StringBuilder searchQueryBuilder = new StringBuilder(
				"from Concept c where c.deleteFlag = :deleteFlag");

		searchQueryBuilder.append(" and c.categoryId =:searchTags order by c.createdOn ASC 1");

		Query query = getSession().createQuery(searchQueryBuilder.toString());
		
		query.setString("deleteFlag", "F");

		query.setParameter("searchTags", searchTags);

		log.info("---------------Query for Getting Oldest Concept Code------------------------::: " + query);

		List<Concept> conceptList = query.list();
		
		log.info("---------------------Final List----------------------"+conceptList);

		return conceptList;

	}

}
