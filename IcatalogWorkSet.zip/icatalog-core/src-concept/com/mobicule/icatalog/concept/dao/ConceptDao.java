package com.mobicule.icatalog.concept.dao;

import java.util.HashMap;
import java.util.List;

import com.mobicule.component.system.db.dao.GenericDataBeanDAO;
import com.mobicule.icatalog.common.dao.SyncDao;
import com.mobicule.icatalog.concept.bean.Concept;
import com.mobicule.icatalog.concept.bean.ConceptWrapper;

public interface ConceptDao extends GenericDataBeanDAO<Concept>, SyncDao
{
	public void formatWrapper(List<HashMap> conceptMapList, HashMap<String, ConceptWrapper> conceptWrapperCache,
			String action);

	public void formatHotSpotWrapper(List<HashMap> conceptMapList, HashMap<String, ConceptWrapper> conceptWrapperCache,
			String conceptImageLocation);

	public List<Concept> customSearch(Concept searchConcept, Long conceptCategoryId);

	public List<Concept> doCustomSearch(Concept searchConcept);
	
	public List<Concept> getOldestConcept(long id);

}
