package com.mobicule.icatalog.concept.dao;

import java.util.List;

import com.mobicule.component.system.db.dao.GenericDataBeanDAO;
import com.mobicule.icatalog.common.dao.SyncDao;
import com.mobicule.icatalog.concept.bean.ConceptCategory;

public interface ConceptCategoryDao extends GenericDataBeanDAO<ConceptCategory>, SyncDao
{

	List<ConceptCategory> searchName(String name);

	List<ConceptCategory> doCustomSearch(ConceptCategory conceptCategory);

	List<ConceptCategory> getConceptCategory(String code);
}
