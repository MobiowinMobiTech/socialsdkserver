package com.mobicule.icatalog.concept.dao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.util.CollectionUtils;

import com.mobicule.component.system.db.dao.GenericDataBeanDAO;
import com.mobicule.icatalog.common.dao.AbstractSyncDao;
import com.mobicule.icatalog.concept.bean.ConceptCategory;
import com.mobicule.icatalog.core.constants.IcatalogUtility;

public class ConceptCategoryHibernateDao extends AbstractSyncDao<ConceptCategory> implements ConceptCategoryDao
{
	private Log log = LogFactory.getLog(this.getClass());

	private Map<String, List<String>> imageConfig;


	public Map<String, List<String>> getImageConfig() {
		return imageConfig;
	}

	public void setImageConfig(Map<String, List<String>> imageConfig) {
		this.imageConfig = imageConfig;
	}

	@Override
	public List<ConceptCategory> searchName(String name)
	{
		List<ConceptCategory> categoryList = new ArrayList<ConceptCategory>();

		Query query = getSession().createQuery(
				" from ConceptCategory cc where cc.deleteFlag = :deleteFlag and (upper(cc.name) like upper('%" + name
						+ "%') or upper(cc.code) like upper('%" + name + "%')) ");

		query.setParameter("deleteFlag", "F");

		categoryList = query.list();

		return categoryList;
	}

	@Override
	public String findAllAfterSyncDate(Timestamp lastSyncDate, int pageNumber, int pageSize, String entity)
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String getNewlyAddedEntities(int pageNumber, int pageSize,String login)
	{
		final List<HashMap> conceptCategoryMapList = new ArrayList<HashMap>();
		List<String> imageBasePath =  (List<String>)imageConfig.get("IMAGE_BASE_PATH");

		if (log.isInfoEnabled())
		{
			log.info("in newly added Entity pagenumber: " + pageNumber);
		}

		StringBuilder queryForNewEntries = new StringBuilder();
		createQueryForNewEntries(queryForNewEntries);

		if (log.isInfoEnabled())
		{
			log.info("in newly added queryForNewEntries: " + queryForNewEntries.toString());
		}

		Query query = getSession().createQuery(queryForNewEntries.toString());
		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);

		query.setFirstResult(pageNumber * pageSize);
		query.setMaxResults(pageSize);

		List<ConceptCategory> list = query.list();

		if (log.isInfoEnabled())
		{
			log.info("List size: " + list.size());
		}

		/*if (CollectionUtils.isEmpty(list))
		{
			return null;
		}*/

		if (log.isDebugEnabled())
		{
			log.debug("list : " + ((list == null) ? "null" : list.size()));
		}
		for (ConceptCategory conceptCat : list)
		{
			HashMap conceptCatMap = new HashMap();
			List<String> imgList = new ArrayList<String>();

			imgList = IcatalogUtility.fetchImageList(imageBasePath.get(0),"concept_category", conceptCat.getCode());
			List<String> imgConfigList = configImgList(imgList);

			log.info("code:" + conceptCat.getCode() + " ImageList: " + imgList.size());
			conceptCatMap.put("id", conceptCat.getId());
			conceptCatMap.put("code", conceptCat.getCode());
			conceptCatMap.put("name", conceptCat.getName());

			if (conceptCat.getDescription() != null)
			{
				conceptCatMap.put("description", conceptCat.getDescription());
			}

			if (imgConfigList != null)
			{
				conceptCatMap.put("image", imgConfigList);
			}
			else
				log.info("img list size: " + imgConfigList.size());

			//conceptCatMap.put("image", imgConfigList);
			conceptCatMap.put("syncFlag", "A");

			conceptCategoryMapList.add(conceptCatMap);
		}

		HashMap dataMap = IcatalogUtility.createResponseMessage(conceptCategoryMapList);

		String response = IcatalogUtility.createJSONFromMap(dataMap);

		return response;
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param imgList
	 * @return
	 *
	 * @author shalini
	 * @createdOn 09-Apr-2012
	 * @modifiedOn 09-Apr-2012 
	 * 
	 */
	private List<String> configImgList(List<String> imgList)
	{
		int i;
		Map mapValues = new HashMap();
		mapValues.put("config", imageConfig.get("IMG_DIM_CONCEPT_CAT"));
		log.info("map values" + mapValues);
		List<String> configList = new ArrayList<String>();
		//String newConfig=null;
		for (String img : imgList)
		{
			List imgConfig = (List) mapValues.get("config");

			for (i = 0; i < imgConfig.size(); i++)
			{
				String newConfig = img.concat("-" + imgConfig.get(i));
				log.info("new Img" + newConfig);
				configList.add(newConfig);
			}

		}
		return configList;
	}

	@Override
	public int getAddedEntitiesCount(String login)
	{
		StringBuilder queryForNewEntries = new StringBuilder();

		queryForNewEntries.append("select count(*) ");
		createQueryForNewEntries(queryForNewEntries);
		Query query = getSession().createQuery(queryForNewEntries.toString());

		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);

		List<Long> returnValue = query.list();

		if (CollectionUtils.isEmpty(returnValue))
		{
			return 0;
		}
		else
		{
			return returnValue.get(0).intValue();
		}
	}

	private void createQueryForNewEntries(StringBuilder queryForNewEntries)
	{
		queryForNewEntries.append("FROM ConceptCategory cc ");
		queryForNewEntries.append("WHERE deleteFlag = :deleteFlag order by cc.code");

	}

	@Override
	public int getNewlyAddedEntitiesAfterSyncDateCount(Timestamp lastSyncDate,String login)
	{
		StringBuilder queryForNewEntries = new StringBuilder();

		queryForNewEntries.append(" select count(*) ");
		createQueryForNewEntriesAfterSyncDate(queryForNewEntries);

		Query query = getSession().createQuery(queryForNewEntries.toString());

		if (log.isInfoEnabled())
		{
			log.info("query in add: " + queryForNewEntries);
		}

		query.setTimestamp("createdOn", lastSyncDate);
		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);

		List<Long> returnValue = query.list();

		if (CollectionUtils.isEmpty(returnValue))
		{
			return 0;
		}
		else
		{
			return returnValue.get(0).intValue();
		}
	}

	private void createQueryForNewEntriesAfterSyncDate(StringBuilder queryForNewEntries)
	{
		queryForNewEntries.append("From ConceptCategory cc ");
		queryForNewEntries.append("where cc.createdOn >=:createdOn and ");
		queryForNewEntries.append("deleteFlag = :deleteFlag order by cc.code");

	}

	@Override
	public int getModifiedEntitiesAfterSyncDateCount(Timestamp lastSyncDate,String login)
	{
		StringBuilder queryForModifiedEntries = new StringBuilder();

		queryForModifiedEntries.append(" select count(*) ");
		createQueryForModifiedEntries(queryForModifiedEntries);

		if (log.isInfoEnabled())
		{
			log.info("Query: " + queryForModifiedEntries.toString());
		}

		Query query = getSession().createQuery(queryForModifiedEntries.toString());

		query.setTimestamp("createdOn", lastSyncDate);
		query.setTimestamp("modifiedOn", lastSyncDate);
		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);

		List<Long> returnValue = query.list();

		if (CollectionUtils.isEmpty(returnValue))
		{
			return 0;
		}
		else
		{
			return returnValue.get(0).intValue();
		}
	}

	private void createQueryForModifiedEntries(StringBuilder queryForModifiedEntries)
	{
		queryForModifiedEntries.append("From ConceptCategory cc ");
		queryForModifiedEntries.append("where cc.createdOn < :createdOn ");
		queryForModifiedEntries.append(" AND cc.modifiedOn >= :modifiedOn  ");
		queryForModifiedEntries.append(" AND cc.deleteFlag = :deleteFlag ");
		queryForModifiedEntries.append(" order by cc.code ");

	}

	@Override
	public int getDeletedEntitiesAfterSyncDateCount(Timestamp lastSyncDate)
	{
		StringBuilder queryForDeletedEntries = new StringBuilder();

		queryForDeletedEntries.append(" select count(*) ");
		createQueryForModifiedEntries(queryForDeletedEntries);

		Query query = getSession().createQuery(queryForDeletedEntries.toString());
		query.setTimestamp("createdOn", lastSyncDate);
		query.setTimestamp("modifiedOn", lastSyncDate);
		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_TRUE);

		List<Long> returnValue = query.list();

		if (CollectionUtils.isEmpty(returnValue))
		{
			return 0;
		}
		else
		{
			return returnValue.get(0).intValue();
		}
	}

	@Override
	public String getNewlyAddedEntitiesAfterSyncDate(Timestamp lastSyncDate, int pageNumber, int pageSize,String login)
	{
		final List<HashMap> conceptCategoryMapList = new ArrayList<HashMap>();
		List<String> imageBasePath =  (List<String>)imageConfig.get("IMAGE_BASE_PATH");
		StringBuilder queryForNewEntries = new StringBuilder();

		createQueryForNewEntriesAfterSyncDate(queryForNewEntries);

		Query query = getSession().createQuery(queryForNewEntries.toString());

		query.setTimestamp("createdOn", lastSyncDate);
		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);

		query.setFirstResult(pageNumber * pageSize);
		query.setMaxResults(pageSize);

		List<ConceptCategory> list = query.list();

		if (log.isInfoEnabled())
		{
			log.info("List size: " + list.size());
		}

		/*	if (CollectionUtils.isEmpty(list))
			{
				return null;
			}*/

		if (log.isDebugEnabled())
		{
			log.debug("list : " + ((list == null) ? "null" : list.size()));
		}

		for (ConceptCategory conceptCat : list)
		{
			HashMap conceptCatMap = new HashMap();
			List<String> imgList = new ArrayList<String>();

			imgList = IcatalogUtility.fetchImageList(imageBasePath.get(0),"concept_category", conceptCat.getCode());
			List<String> imgConfigList = configImgList(imgList);

			log.info("code:" + conceptCat.getCode() + " ImageList: " + imgList.size());
			conceptCatMap.put("id", conceptCat.getId());
			conceptCatMap.put("code", conceptCat.getCode());
			conceptCatMap.put("name", conceptCat.getName());

			if (conceptCat.getDescription() != null)
			{
				conceptCatMap.put("description", conceptCat.getDescription());
			}
			if (imgConfigList != null)
			{
				conceptCatMap.put("image", imgConfigList);
			}
			else
				log.info("img list size: " + imgConfigList.size());

			//conceptCatMap.put("image", imgConfigList);
			conceptCatMap.put("syncFlag", "A");

			conceptCategoryMapList.add(conceptCatMap);
		}

		HashMap dataMap = IcatalogUtility.createResponseMessage(conceptCategoryMapList);

		String response = IcatalogUtility.createJSONFromMap(dataMap);

		return response;
	}

	@Override
	public String getModifiedEntitiesAfterSyncDate(Timestamp lastSyncDate, int pageNumber, int pageSize,String login)
	{
		final List<HashMap> conceptCategoryMapList = new ArrayList<HashMap>();
		List<String> imageBasePath =  (List<String>)imageConfig.get("IMAGE_BASE_PATH");
		StringBuilder queryForModifiedEntries = new StringBuilder();

		createQueryForModifiedEntries(queryForModifiedEntries);

		Query query = getSession().createQuery(queryForModifiedEntries.toString());

		query.setTimestamp("createdOn", lastSyncDate);
		query.setTimestamp("modifiedOn", lastSyncDate);
		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);

		query.setFirstResult(pageNumber * pageSize);
		query.setMaxResults(pageSize);

		List<ConceptCategory> list = query.list();

		if (log.isInfoEnabled())
		{
			log.info("List size: " + list.size());
		}

		/*if (CollectionUtils.isEmpty(list))
		{
			return null;
		}*/

		if (log.isDebugEnabled())
		{
			log.debug("list : " + ((list == null) ? "null" : list.size()));
		}

		for (ConceptCategory conceptCat : list)
		{

			HashMap conceptCatMap = new HashMap();

			List<String> imgList = new ArrayList<String>();

			imgList = IcatalogUtility.fetchImageList(imageBasePath.get(0),"concept_category", conceptCat.getCode());
			List<String> imgConfigList = configImgList(imgList);

			log.info("code:" + conceptCat.getCode() + " ImageList: " + imgList.size());
			conceptCatMap.put("id", conceptCat.getId());
			conceptCatMap.put("code", conceptCat.getCode());
			conceptCatMap.put("name", conceptCat.getName());
			if (conceptCat.getDescription() != null)
			{
				conceptCatMap.put("description", conceptCat.getDescription());
			}

			if (imgConfigList != null)
			{
				conceptCatMap.put("image", imgConfigList);
			}
			else
				log.info("img list size: " + imgConfigList.size());

			//conceptCatMap.put("image", imgConfigList);
			conceptCatMap.put("syncFlag", "M");

			conceptCategoryMapList.add(conceptCatMap);
		}

		HashMap dataMap = IcatalogUtility.createResponseMessage(conceptCategoryMapList);

		String response = IcatalogUtility.createJSONFromMap(dataMap);

		return response;
	}

	@Override
	public String getDeletedEntitiesAfterSyncDate(Timestamp lastSyncDate, int pageNumber, int pageSize)
	{
		final List<HashMap> conceptCategoryMapList = new ArrayList<HashMap>();

		StringBuilder queryForDeletedEntries = new StringBuilder();

		createQueryForModifiedEntries(queryForDeletedEntries);

		Query query = getSession().createQuery(queryForDeletedEntries.toString());

		query.setTimestamp("createdOn", lastSyncDate);
		query.setTimestamp("modifiedOn", lastSyncDate);
		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_TRUE);

		query.setFirstResult(pageNumber * pageSize);
		query.setMaxResults(pageSize);

		List<ConceptCategory> list = query.list();

		if (log.isInfoEnabled())
		{
			log.info("List size: " + list.size());
		}

		/*	if (CollectionUtils.isEmpty(list))
			{
				return null;
			}*/

		if (log.isDebugEnabled())
		{
			log.debug("list : " + ((list == null) ? "null" : list.size()));
		}

		for (ConceptCategory conceptCat : list)
		{
			HashMap conceptCatMap = new HashMap();

			conceptCatMap.put("id", conceptCat.getId());
			conceptCatMap.put("code", conceptCat.getCode());
			conceptCatMap.put("name", conceptCat.getName());
			if (conceptCat.getDescription() != null)
			{
				conceptCatMap.put("description", conceptCat.getDescription());
			}

			conceptCatMap.put("syncFlag", "D");

			conceptCategoryMapList.add(conceptCatMap);
		}

		HashMap dataMap = IcatalogUtility.createResponseMessage(conceptCategoryMapList);

		String response = IcatalogUtility.createJSONFromMap(dataMap);

		return response;
	}

	@Override
	public List<ConceptCategory> doCustomSearch(ConceptCategory conceptCategory)
	{

		StringBuilder searchQueryBuilder = new StringBuilder(" from ConceptCategory where deleteFlag = :deleteFlag ");

		String searchTags = conceptCategory.getCode();
		System.out.println("----------------IN doCustomSearch----------------" + searchTags);

		if (null != searchTags)
		{
			searchQueryBuilder.append("  and ( name like :searchTags or code like :searchTags )");
		}
		
		String searchQuery = searchQueryBuilder.toString();
		
		System.out.println("QUERY IS " + searchQuery);
		
		Query query = getSession().createQuery(searchQuery);
		
		query.setString("deleteFlag", "F");

		if (null != searchTags)
		{			
			query.setString("searchTags", searchTags + "%");
		}

		List<ConceptCategory> conceptCategoryList = query.list();

		System.out.println("----------------After doCustomSearch and getting List----------------"
				+ conceptCategoryList);

		return conceptCategoryList;
	}
	
	
	public List<ConceptCategory> getConceptCategory(String code)
	{

		StringBuilder searchQueryBuilder = new StringBuilder(" from ConceptCategory where deleteFlag = :deleteFlag ");

		String searchTags = code;
		System.out.println("------------In ConceptCategoryHibernateDao / getConceptCategoryForImage / Code----------------:" + searchTags);

		if (null != searchTags)
		{
			searchQueryBuilder.append("and code = :searchTags");
		}
		
		String searchQuery = searchQueryBuilder.toString();
		
		System.out.println("---------------QUERY IS---------------: " + searchQuery);
		
		Query query = getSession().createQuery(searchQuery);
		
		query.setString("deleteFlag", "F");

		if (null != searchTags)
		{			
			query.setString("searchTags", searchTags);
		}

		List<ConceptCategory> conceptCategoryList = query.list();

		System.out.println("----------After Getting Concept Category List----------------"+ conceptCategoryList);

		return conceptCategoryList;
	}
		
	
}
