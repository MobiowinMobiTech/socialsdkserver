/**
******************************************************************************
* C O P Y R I G H T  A N D  C O N F I D E N T I A L I T Y  N O T I C E
* <p>
* Copyright © 2008-2009 Mobicule Technologies Pvt. Ltd. All rights reserved. 
* This is proprietary information of Mobicule Technologies Pvt. Ltd.and is 
* subject to applicable licensing agreements. Unauthorized reproduction, 
* transmission or distribution of this file and its contents is a 
* violation of applicable laws.
******************************************************************************
*
* @project icatalog-core
*/
package com.mobicule.icatalog.appconfig.dao;

import java.io.IOException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.codehaus.jackson.JsonParseException;
import org.codehaus.jackson.map.JsonMappingException;
import org.codehaus.jackson.map.ObjectMapper;
import org.hibernate.Query;
import org.springframework.util.CollectionUtils;

import com.mobicule.component.system.db.dao.GenericDataBeanDAO;
import com.mobicule.icatalog.appconfig.bean.AppConfig;
import com.mobicule.icatalog.common.dao.AbstractSyncDao;
import com.mobicule.icatalog.core.constants.IcatalogUtility;

/**
* 
* <enter description here>
*
* @author shalini <Nair>
* @see 
*
* @createdOn 05-Apr-2012
* @modifiedOn
*
* @copyright © 2008-2009 Mobicule Technologies Pvt. Ltd. All rights reserved.
*/
public class AppConfigHibernateDao extends AbstractSyncDao<AppConfig> implements AppConfigDao
{

	private Log log = LogFactory.getLog(getClass());

	@Override
	public String findAllAfterSyncDate(Timestamp lastSyncDate, int pageNumber, int pageSize, String entity)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param pageNumber
	 * @param pageSize
	 * @return
	 *
	 * @author shalini
	 * @createdOn 05-Apr-2012
	 * @modifiedOn 05-Apr-2012 
	 * 
	 */
	@Override
	public String getNewlyAddedEntities(int pageNumber, int pageSize, String login)
	{
		final List<HashMap> appConfigMapList = new LinkedList<HashMap>();
		log.info("in newly added Entity pagenumber: " + pageNumber);

		StringBuilder queryForNewEntries = new StringBuilder();
		createQueryForNewEntries(queryForNewEntries);
		log.info("in newly added queryForNewEntries: " + queryForNewEntries.toString());

		Query query = getSession().createQuery(queryForNewEntries.toString());
		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);

		query.setFirstResult(pageNumber * pageSize);
		query.setMaxResults(pageSize);

		List<AppConfig> list = query.list();

		log.info("List size: " + list.size());

		if (CollectionUtils.isEmpty(list))
		{
			return null;
		}

		log.debug("list : " + ((list == null) ? "null" : list.size()));

		for (AppConfig appconfig : list)
		{
			HashMap appConfigMap = new HashMap();
			appConfigMap.put("id", appconfig.getId());
			appConfigMap.put("key", appconfig.getKey());

			String value = appconfig.getValue();

			List<String> valueList = new ArrayList<String>();
			valueList = formatValue(value);

			appConfigMap.put("value", valueList);

			appConfigMap.put("syncFlag", "A");

			appConfigMapList.add(appConfigMap);
		}

		HashMap dataMap = IcatalogUtility.createResponseMessage(appConfigMapList);

		String response = IcatalogUtility.createJSONFromMap(dataMap);

		return response;
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param value
	 * @return
	 *
	 * @author shalini
	 * @createdOn 23-Apr-2012
	 * @modifiedOn 23-Apr-2012 
	 * 
	 */
	private List<String> formatValue(String value)
	{
		List<String> valueList = new ArrayList<String>();

		String[] valueArray = null;
		log.info("value: " + value);

		if (null == value)
		{

			return valueList;
		}

		/*else
		{
			if (!(value.equalsIgnoreCase("")))
			{
				valueArray = value.split(",");
				log.info("valueArray: " + valueArray);

				if (null != valueArray || valueArray.length != 0)
				{
					for (int i = 0; i < valueArray.length; i++)
					{
						valueList.add(valueArray[i]);
					}
				}
			}
		}*/

		else
		{
			ObjectMapper mapper = new ObjectMapper();
			try
			{
				valueList = mapper.readValue(value, List.class);
			}
			catch (JsonParseException e)
			{

				e.printStackTrace();
			}
			catch (JsonMappingException e)
			{

				e.printStackTrace();
			}
			catch (IOException e)
			{

				e.printStackTrace();
			}

			log.info("valueList: " + valueList.size());
			return valueList;
		}

	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @return
	 *
	 * @author shalini
	 * @createdOn 05-Apr-2012
	 * @modifiedOn 05-Apr-2012 
	 * 
	 */
	@Override
	public int getAddedEntitiesCount(String login)
	{
		StringBuilder queryForNewEntries = new StringBuilder();

		queryForNewEntries.append("select count(*) ");
		createQueryForNewEntries(queryForNewEntries);
		Query query = getSession().createQuery(queryForNewEntries.toString());

		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);

		List<Long> returnValue = query.list();

		if (CollectionUtils.isEmpty(returnValue))
		{
			return 0;
		}
		else
		{
			return returnValue.get(0).intValue();
		}
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param queryForNewEntries
	 *
	 * @author shalini
	 * @createdOn 05-Apr-2012
	 * @modifiedOn 05-Apr-2012 
	 * 
	 */
	private void createQueryForNewEntries(StringBuilder queryForNewEntries)
	{
		queryForNewEntries.append("FROM AppConfig  ");
		queryForNewEntries.append("WHERE deleteFlag = :deleteFlag ");

	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param lastSyncDate
	 * @return
	 *
	 * @author shalini
	 * @createdOn 05-Apr-2012
	 * @modifiedOn 05-Apr-2012 
	 * 
	 */
	@Override
	public int getNewlyAddedEntitiesAfterSyncDateCount(Timestamp lastSyncDate, String login)
	{
		StringBuilder queryForNewEntries = new StringBuilder();

		queryForNewEntries.append(" select count(*) ");
		createQueryForNewEntriesAfterSyncDate(queryForNewEntries);

		Query query = getSession().createQuery(queryForNewEntries.toString());

		log.info("query in add: " + queryForNewEntries);

		query.setTimestamp("createdOn", lastSyncDate);
		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);

		List<Long> returnValue = query.list();

		if (CollectionUtils.isEmpty(returnValue))
		{
			return 0;
		}
		else
		{
			return returnValue.get(0).intValue();
		}
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param queryForNewEntries
	 *
	 * @author shalini
	 * @createdOn 05-Apr-2012
	 * @modifiedOn 05-Apr-2012 
	 * 
	 */
	private void createQueryForNewEntriesAfterSyncDate(StringBuilder queryForNewEntries)
	{
		queryForNewEntries.append("From AppConfig  ");
		queryForNewEntries.append("where createdOn >=:createdOn and ");
		queryForNewEntries.append("deleteFlag = :deleteFlag ");

	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param lastSyncDate
	 * @return
	 *
	 * @author shalini
	 * @createdOn 05-Apr-2012
	 * @modifiedOn 05-Apr-2012 
	 * 
	 */
	@Override
	public int getModifiedEntitiesAfterSyncDateCount(Timestamp lastSyncDate, String login)
	{
		StringBuilder queryForModifiedEntries = new StringBuilder();

		queryForModifiedEntries.append(" select count(*) ");
		createQueryForModifiedEntries(queryForModifiedEntries);
		log.info("Query: " + queryForModifiedEntries.toString());
		Query query = getSession().createQuery(queryForModifiedEntries.toString());

		query.setTimestamp("createdOn", lastSyncDate);
		query.setTimestamp("modifiedOn", lastSyncDate);
		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);

		List<Long> returnValue = query.list();

		if (CollectionUtils.isEmpty(returnValue))
		{
			return 0;
		}
		else
		{
			return returnValue.get(0).intValue();
		}
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param queryForModifiedEntries
	 *
	 * @author shalini
	 * @createdOn 05-Apr-2012
	 * @modifiedOn 05-Apr-2012 
	 * 
	 */
	private void createQueryForModifiedEntries(StringBuilder queryForModifiedEntries)
	{
		queryForModifiedEntries.append("From AppConfig  ");
		queryForModifiedEntries.append("where createdOn < :createdOn ");
		queryForModifiedEntries.append(" AND modifiedOn >= :modifiedOn  ");
		queryForModifiedEntries.append(" AND deleteFlag = :deleteFlag ");

	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param lastSyncDate
	 * @return
	 *
	 * @author shalini
	 * @createdOn 05-Apr-2012
	 * @modifiedOn 05-Apr-2012 
	 * 
	 */
	@Override
	public int getDeletedEntitiesAfterSyncDateCount(Timestamp lastSyncDate)
	{
		StringBuilder queryForDeletedEntries = new StringBuilder();

		queryForDeletedEntries.append(" select count(*) ");
		createQueryForModifiedEntries(queryForDeletedEntries);

		Query query = getSession().createQuery(queryForDeletedEntries.toString());
		query.setTimestamp("createdOn", lastSyncDate);
		query.setTimestamp("modifiedOn", lastSyncDate);
		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_TRUE);

		List<Long> returnValue = query.list();

		if (CollectionUtils.isEmpty(returnValue))
		{
			return 0;
		}
		else
		{
			return returnValue.get(0).intValue();
		}
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param lastSyncDate
	 * @param pageNumber
	 * @param pageSize
	 * @return
	 *
	 * @author shalini
	 * @createdOn 05-Apr-2012
	 * @modifiedOn 05-Apr-2012 
	 * 
	 */
	@Override
	public String getNewlyAddedEntitiesAfterSyncDate(Timestamp lastSyncDate, int pageNumber, int pageSize, String login)
	{
		final List<HashMap> appConfigMapList = new LinkedList<HashMap>();
		StringBuilder queryForNewEntries = new StringBuilder();

		createQueryForNewEntriesAfterSyncDate(queryForNewEntries);

		Query query = getSession().createQuery(queryForNewEntries.toString());

		query.setTimestamp("createdOn", lastSyncDate);
		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);

		query.setFirstResult(pageNumber * pageSize);
		query.setMaxResults(pageSize);

		List<AppConfig> list = query.list();

		log.info("List size: " + list.size());

		if (CollectionUtils.isEmpty(list))
		{
			return null;
		}

		log.debug("list : " + ((list == null) ? "null" : list.size()));

		for (AppConfig appConfig : list)
		{
			HashMap appConfigMap = new HashMap();
			appConfigMap.put("id", appConfig.getId());
			appConfigMap.put("key", appConfig.getKey());

			String value = appConfig.getValue();

			List<String> valueList = formatValue(value);

			appConfigMap.put("value", valueList);

			appConfigMap.put("syncFlag", "A");

			appConfigMapList.add(appConfigMap);
		}

		HashMap dataMap = IcatalogUtility.createResponseMessage(appConfigMapList);

		String response = IcatalogUtility.createJSONFromMap(dataMap);

		return response;
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param lastSyncDate
	 * @param pageNumber
	 * @param pageSize
	 * @return
	 *
	 * @author shalini
	 * @createdOn 05-Apr-2012
	 * @modifiedOn 05-Apr-2012 
	 * 
	 */
	@Override
	public String getModifiedEntitiesAfterSyncDate(Timestamp lastSyncDate, int pageNumber, int pageSize, String login)
	{
		final List<HashMap> appConfigMapList = new LinkedList<HashMap>();
		StringBuilder queryForModifiedEntries = new StringBuilder();

		createQueryForModifiedEntries(queryForModifiedEntries);

		Query query = getSession().createQuery(queryForModifiedEntries.toString());

		query.setTimestamp("createdOn", lastSyncDate);
		query.setTimestamp("modifiedOn", lastSyncDate);
		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);

		query.setFirstResult(pageNumber * pageSize);
		query.setMaxResults(pageSize);

		List<AppConfig> list = query.list();

		log.info("List size: " + list.size());

		if (CollectionUtils.isEmpty(list))
		{
			return null;
		}

		log.debug("list : " + ((list == null) ? "null" : list.size()));

		for (AppConfig appConfig : list)
		{
			HashMap appConfigMap = new HashMap();
			appConfigMap.put("id", appConfig.getId());
			appConfigMap.put("key", appConfig.getKey());

			String value = appConfig.getValue();

			List<String> valueList = formatValue(value);

			appConfigMap.put("value", valueList);

			appConfigMap.put("syncFlag", "M");
			appConfigMapList.add(appConfigMap);
		}

		HashMap dataMap = IcatalogUtility.createResponseMessage(appConfigMapList);

		String response = IcatalogUtility.createJSONFromMap(dataMap);

		return response;
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param lastSyncDate
	 * @param pageNumber
	 * @param pageSize
	 * @return
	 *
	 * @author shalini
	 * @createdOn 05-Apr-2012
	 * @modifiedOn 05-Apr-2012 
	 * 
	 */
	@Override
	public String getDeletedEntitiesAfterSyncDate(Timestamp lastSyncDate, int pageNumber, int pageSize)
	{
		final List<HashMap> appConfigMapList = new LinkedList<HashMap>();

		StringBuilder queryForDeletedEntries = new StringBuilder();

		createQueryForModifiedEntries(queryForDeletedEntries);

		Query query = getSession().createQuery(queryForDeletedEntries.toString());

		query.setTimestamp("createdOn", lastSyncDate);
		query.setTimestamp("modifiedOn", lastSyncDate);
		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_TRUE);

		query.setFirstResult(pageNumber * pageSize);
		query.setMaxResults(pageSize);

		List<AppConfig> list = query.list();

		log.info("List size: " + list.size());

		if (CollectionUtils.isEmpty(list))
		{
			return null;
		}

		log.debug("list : " + ((list == null) ? "null" : list.size()));

		for (AppConfig appConfig : list)
		{
			HashMap appconfigMap = new HashMap();
			appconfigMap.put("id", appConfig.getId());
			appconfigMap.put("key", appConfig.getKey());

			String value = appConfig.getValue();

			List<String> valueList = formatValue(value);

			appconfigMap.put("value", valueList);

			appconfigMap.put("syncFlag", "D");

			appConfigMapList.add(appconfigMap);
		}

		HashMap dataMap = IcatalogUtility.createResponseMessage(appConfigMapList);

		String response = IcatalogUtility.createJSONFromMap(dataMap);

		return response;
	}

	public String checkSyncFlag(String entity)
	{
		Query query = getSession().createQuery(
				" SELECT ac.value from AppConfig ac where ac.deleteFlag = :deleteFlag and ac.key = :key");

		query.setParameter("deleteFlag", "F");
		query.setParameter("key", entity);

		List<String> syncList = query.list();

		if (null == syncList)
		{
			return null;
		}

		String value = syncList.get(0);

		return value;
	}
	
	public void updateSyncFlag(String entity)
	{
		Query query = getSession().createQuery("UPDATE AppConfig ac " +
				"SET ac.value = :entity WHERE ac.key=:entity_key and ac.deleteFlag = :deleteFlag");
		
		query.setParameter("entity", entity);
		query.setParameter("entity_key", "sync");
		query.setParameter("deleteFlag", "F");
		
		query.executeUpdate();
		
	}

}
