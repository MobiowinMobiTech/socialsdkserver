/**
******************************************************************************
* C O P Y R I G H T  A N D  C O N F I D E N T I A L I T Y  N O T I C E
* <p>
* Copyright © 2008-2009 Mobicule Technologies Pvt. Ltd. All rights reserved. 
* This is proprietary information of Mobicule Technologies Pvt. Ltd.and is 
* subject to applicable licensing agreements. Unauthorized reproduction, 
* transmission or distribution of this file and its contents is a 
* violation of applicable laws.
******************************************************************************
*
* @project icatalog-core
*/
package com.mobicule.icatalog.appconfig.service;

import java.sql.Timestamp;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.mobicule.icatalog.appconfig.bean.AppConfig;
import com.mobicule.icatalog.appconfig.dao.AppConfigDao;
import com.mobicule.icatalog.entity.service.EntityServiceImpl;
import com.mobicule.icatalog.entity.service.SyncService;

/**
* 
* <enter description here>
*
* @author shalini <Nair>
* @see 
*
* @createdOn 05-Apr-2012
* @modifiedOn
*
* @copyright © 2008-2009 Mobicule Technologies Pvt. Ltd. All rights reserved.
*/
public class AppConfigServiceImpl extends EntityServiceImpl<AppConfig, AppConfigDao> implements AppConfigService,
		SyncService
{

	private Log log = LogFactory.getLog(this.getClass());

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param lastSyncDate
	 * @param pageNumber
	 * @param pageSize
	 * @param entity
	 * @param action
	 * @return
	 *
	 * @author shalini
	 * @createdOn 05-Apr-2012
	 * @modifiedOn 05-Apr-2012 
	 * 
	 */
	@Override
	public String fetchAllAfterSyncDate(Timestamp lastSyncDate, int pageNumber, int pageSize, String entity,
			String action, String login)
	{
		log.info("In service Impl: " + lastSyncDate + ", " + pageNumber);
		return getGenericDataBeanDAO().fetchAllAfterSyncDate(lastSyncDate, pageNumber, pageSize, entity, action, login);
	}

	@Override
	public String checkSyncFlag(String entity)
	{
		return getGenericDataBeanDAO().checkSyncFlag(entity);
	}
	
	public void updateSyncFlag(String entity)
	{
		getGenericDataBeanDAO().updateSyncFlag(entity);
	}

}
