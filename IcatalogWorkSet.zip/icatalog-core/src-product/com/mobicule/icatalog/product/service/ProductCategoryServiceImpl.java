package com.mobicule.icatalog.product.service;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.mobicule.icatalog.entity.service.EntityServiceImpl;
import com.mobicule.icatalog.entity.service.SyncService;
import com.mobicule.icatalog.product.bean.ProductCategory;
import com.mobicule.icatalog.product.dao.ProductCategoryDao;

public class ProductCategoryServiceImpl extends EntityServiceImpl<ProductCategory, ProductCategoryDao> implements
		ProductCategoryService, SyncService
{
	private Log log = LogFactory.getLog(this.getClass());

	@Override
	public List<ProductCategory> searchName(String name)
	{
		return getGenericDataBeanDAO().searchName(name);
	}

	@Override
	public String fetchAllAfterSyncDate(Timestamp lastSyncDate, int pageNumber, int pageSize, String entity,
			String action,String login)
	{
		if (log.isInfoEnabled())
		{
			log.info("In service Impl: " + lastSyncDate + ", " + pageNumber);
		}
		return getGenericDataBeanDAO().fetchAllAfterSyncDate(lastSyncDate, pageNumber, pageSize, entity, action,login);
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param productCategory
	 * @return
	 *
	 * @author himanshu
	 * @createdOn 07-Apr-2012
	 * @modifiedOn 07-Apr-2012 
	 * 
	 */
	@Override
	public List<ProductCategory> doCustomSearch(ProductCategory productCategory)
	{

		return getGenericDataBeanDAO().doCustomSearch(productCategory);
	}
	@Override
	public List<ProductCategory> doProductCategorySearch(ProductCategory productCategory)
	{
		List<ProductCategory> productCategoryList = new ArrayList<ProductCategory>();
		productCategoryList = getGenericDataBeanDAO().findMatchingBeans(productCategory);
		return productCategoryList;
	}

	@Override
	public List<ProductCategory> checkUniqueCode(String code)
	{

		ProductCategory  productCategory= new ProductCategory();
		List<ProductCategory> productCategoryBeanList = new ArrayList<ProductCategory>();

		
		productCategory.setCode(code);

		log.info("Search bean is :" + productCategory);

		productCategoryBeanList = getGenericDataBeanDAO().findMatchingBeans(productCategory);

		return productCategoryBeanList;

	}
}
