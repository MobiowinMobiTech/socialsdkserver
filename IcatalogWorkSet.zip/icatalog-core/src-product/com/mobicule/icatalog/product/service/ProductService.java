package com.mobicule.icatalog.product.service;

import java.util.Collection;
import java.util.List;

import com.mobicule.icatalog.entity.service.EntityService;
import com.mobicule.icatalog.product.bean.Product;
import com.mobicule.icatalog.product.bean.ProductInventory;
import com.mobicule.icatalog.product.bean.ProductPrice;
import com.mobicule.icatalog.product.bean.ProductRecommendation;
import com.mobicule.icatalog.product.bean.ProductVariant;
import com.mobicule.icatalog.product.bean.ProductWrapper;
import com.mobicule.icatalog.product.dao.ProductDao;

public interface ProductService extends EntityService<Product, ProductDao>
{

	public List<ProductWrapper> customSearch(Product searchProduct, Long productCategoryId);

	public ProductWrapper fetchProductwithPriceFromCode(String code);

	public Product checkRecordExistsForProductCode(String code);

	public void addProductsFromFTP(Collection<Product> collection);

	public void updateProductsFromFTP(Collection<Product> collection);

	public ProductInventory checkRecordExistsForProductAndStore(Long prodId, Long terrId);

	public void addFTPInventory(Collection<ProductInventory> collection);

	public void updateFTPInventory(Collection<ProductInventory> collection);

	public ProductPrice checkPriceExistsForProduct(Long productId);

	public void addFtpPrice(Collection<ProductPrice> collection);

	public void updateFtpPrice(Collection<ProductPrice> collection);

	public void imageUpdate(String code);

	public List<ProductWrapper> doCustomSearch(Product searchProduct);

	public List<ProductWrapper> searchWrapper(ProductWrapper productWrapper);

	public List<ProductWrapper> searchWrapperDetails(ProductWrapper productWrapper, long id);

	public List<ProductWrapper> productRecommendList(ProductWrapper productWrapper, long id);

	public List<ProductWrapper> productVariantList(ProductWrapper productWrapper, long id);

	public boolean addInventory(ProductInventory inventory);

	public boolean editInventory(ProductInventory inventory);

	public boolean deleteInventory(ProductInventory inventory);

	public boolean addPrice(ProductPrice price);

	public boolean updatePrice(ProductPrice price);

	public boolean deletePrice(ProductPrice price);

	public boolean addVariants(ProductVariant variants);

	public boolean editVariants(ProductVariant variants);

	public boolean deleteVariants(ProductVariant variants);

	public boolean addRecommendation(ProductRecommendation recommendation);

	public boolean editRecommendation(ProductRecommendation recommendation);

	public boolean deleteRecommendation(ProductRecommendation recommendation);
	
	public boolean softDeleteVariants(ProductVariant productVariant);

	public List<Product> doProductListsearch(Product searchProduct);

	public List<ProductRecommendation> doProductRecomendationsearch(ProductRecommendation searchProductRecomendation);

	public List<Product> doProductVariantListsearch(Product searchProduct);

	public List<ProductVariant> doProductVariantsearch(ProductVariant searchProductVariant);
}
