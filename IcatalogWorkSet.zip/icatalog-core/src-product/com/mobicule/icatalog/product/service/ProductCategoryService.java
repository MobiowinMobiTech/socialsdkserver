package com.mobicule.icatalog.product.service;

import java.util.List;

import com.mobicule.icatalog.entity.service.EntityService;
import com.mobicule.icatalog.product.bean.ProductCategory;
import com.mobicule.icatalog.product.dao.ProductCategoryDao;

public interface ProductCategoryService extends EntityService<ProductCategory, ProductCategoryDao>
{

	public List<ProductCategory> searchName(String name);

	public List<ProductCategory> doCustomSearch(ProductCategory productCategory);
	
	public List<ProductCategory> doProductCategorySearch(ProductCategory productCategory);
	public List<ProductCategory> checkUniqueCode(String code);
}
