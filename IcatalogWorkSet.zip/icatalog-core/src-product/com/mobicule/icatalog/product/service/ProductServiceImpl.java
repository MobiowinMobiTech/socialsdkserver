package com.mobicule.icatalog.product.service;

import java.sql.Timestamp;
import java.util.Collection;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.mobicule.icatalog.commons.MoreThanOneRecodeFoundException;
import com.mobicule.icatalog.entity.service.EntityServiceImpl;
import com.mobicule.icatalog.entity.service.SyncService;
import com.mobicule.icatalog.product.bean.Product;
import com.mobicule.icatalog.product.bean.ProductInventory;
import com.mobicule.icatalog.product.bean.ProductPrice;
import com.mobicule.icatalog.product.bean.ProductRecommendation;
import com.mobicule.icatalog.product.bean.ProductVariant;
import com.mobicule.icatalog.product.bean.ProductWrapper;
import com.mobicule.icatalog.product.dao.ProductDao;
import com.mobicule.icatalog.product.dao.ProductInventoryDao;
import com.mobicule.icatalog.product.dao.ProductPriceDao;
import com.mobicule.icatalog.product.dao.ProductRecommendationDao;
import com.mobicule.icatalog.product.dao.ProductVariantDao;

public class ProductServiceImpl extends EntityServiceImpl<Product, ProductDao> implements ProductService, SyncService
{
	private Log log = LogFactory.getLog(this.getClass());

	private ProductInventoryDao inventoryDao;

	private ProductPriceDao prodPriceDao;

	private ProductVariantDao variantDao;

	private ProductRecommendationDao recommendationDao;

	public ProductVariantDao getVariantDao()
	{
		return variantDao;
	}

	public void setVariantDao(ProductVariantDao variantDao)
	{
		this.variantDao = variantDao;
	}

	public ProductPriceDao getProdPriceDao()
	{
		return prodPriceDao;
	}

	public void setProdPriceDao(ProductPriceDao prodPriceDao)
	{
		this.prodPriceDao = prodPriceDao;
	}

	public ProductRecommendationDao getRecommendationDao()
	{
		return recommendationDao;
	}

	public void setRecommendationDao(ProductRecommendationDao recommendationDao)
	{
		this.recommendationDao = recommendationDao;
	}

	public ProductInventoryDao getInventoryDao()
	{
		return inventoryDao;
	}

	public void setInventoryDao(ProductInventoryDao inventoryDao)
	{
		this.inventoryDao = inventoryDao;
	}

	@Override
	public boolean addInventory(ProductInventory inventory)
	{
		if (inventory == null)
		{
			log.error("entity is null");
			return false;
		}

		if (inventory.getId() != null)
		{
			log.error("entity id is not null");
			return false;
		}

		try
		{
			inventoryDao.add(inventory);

			return true;
		}
		catch (Exception e)
		{
			log.error("entity not added", e);

			return false;
		}
	}

	@Override
	public boolean editInventory(ProductInventory inventory)
	{
		if (inventory == null)
		{
			log.error("entity is null");
			return false;
		}

		if (inventory.getId() == null)
		{
			return false;
		}

		try
		{
			inventoryDao.update(inventory);

			return true;
		}
		catch (Exception e)
		{
			log.error("entity not added", e);

			return false;
		}
	}

	@Override
	public boolean deleteInventory(ProductInventory inventory)
	{
		if (inventory == null)
		{
			log.error("entity is null");
			return false;
		}

		if (inventory.getId() == null)
		{
			return false;
		}

		try
		{
			inventoryDao.softDelete(inventory);

			return true;
		}
		catch (Exception e)
		{
			log.error("entity not added", e);

			return false;
		}
	}

	@Override
	public boolean addPrice(ProductPrice price)
	{
		if (price == null)
		{
			log.error("entity is null");
			return false;
		}

		if (price.getId() != null)
		{
			log.error("entity id is not null");
			return false;
		}

		try
		{
			prodPriceDao.add(price);

			return true;
		}
		catch (Exception e)
		{
			log.error("entity not added", e);

			return false;
		}
	}

	@Override
	public boolean updatePrice(ProductPrice price)
	{
		if (price == null)
		{
			log.error("entity is null");
			return false;
		}

		if (price.getId() == null)
		{
			return false;
		}

		try
		{
			prodPriceDao.update(price);

			return true;
		}
		catch (Exception e)
		{
			log.error("entity not added", e);

			return false;
		}
	}

	@Override
	public boolean deletePrice(ProductPrice price)
	{
		if (price == null)
		{
			log.error("entity is null");
			return false;
		}

		if (price.getId() == null)
		{
			return false;
		}

		try
		{
			prodPriceDao.softDelete(price);

			return true;
		}
		catch (Exception e)
		{
			log.error("entity not added", e);

			return false;
		}
	}

	@Override
	public boolean addVariants(ProductVariant variants)
	{
		if (variants == null)
		{
			log.error("entity is null");
			return false;
		}

		if (variants.getId() != null)
		{
			log.error("entity id is not null");
			return false;
		}

		try
		{
			variantDao.add(variants);

			return true;
		}
		catch (Exception e)
		{
			log.error("entity not added", e);

			return false;
		}
	}

	@Override
	public boolean editVariants(ProductVariant variants)

	{
		if (variants == null)
		{
			log.error("entity is null");
			return false;
		}

		if (variants.getId() == null)
		{
			return false;
		}

		try
		{
			variantDao.update(variants);

			return true;
		}
		catch (Exception e)
		{
			log.error("entity not added", e);

			return false;
		}
	}

	@Override
	public boolean deleteVariants(ProductVariant variants)
	{
		if (variants == null)
		{
			log.error("entity is null");
			return false;
		}

		if (variants.getId() == null)
		{
			return false;
		}

		try
		{
			variantDao.softDelete(variants);

			return true;
		}
		catch (Exception e)
		{
			log.error("entity not added", e);

			return false;
		}
	}

	@Override
	public boolean addRecommendation(ProductRecommendation recommendation)
	{
		if (recommendation == null)
		{
			log.error("entity is null");
			return false;
		}

		if (recommendation.getId() != null)
		{
			log.error("entity id is not null");
			return false;
		}

		try
		{
			recommendationDao.add(recommendation);

			return true;
		}
		catch (Exception e)
		{
			log.error("entity not added", e);

			return false;
		}
	}

	@Override
	public boolean editRecommendation(ProductRecommendation recommendation)
	{
		if (recommendation == null)
		{
			log.error("entity is null");
			return false;
		}

		if (recommendation.getId() == null)
		{
			return false;
		}

		try
		{
			recommendationDao.update(recommendation);

			return true;
		}
		catch (Exception e)
		{
			log.error("entity not added", e);

			return false;
		}
	}

	@Override
	public boolean deleteRecommendation(ProductRecommendation recommendation)
	{
		if (recommendation == null)
		{
			log.error("entity is null");
			return false;
		}

		if (recommendation.getId() == null)
		{
			return false;
		}

		try
		{
			recommendationDao.softDelete(recommendation);

			return true;
		}
		catch (Exception e)
		{
			log.error("entity not added", e);

			return false;
		}
	}

	@Override
	public List<ProductWrapper> doCustomSearch(Product searchProduct)
	{
		return getGenericDataBeanDAO().doCustomSearch(searchProduct);
	}

	public List<ProductWrapper> customSearch(Product searchProduct, Long productCategoryId)
	{
		return getGenericDataBeanDAO().customSearch(searchProduct, productCategoryId);
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param lastSyncDate
	 * @param pageNumber
	 * @param pageSize
	 * @param entity
	 * @param action
	 * @return
	 *
	 * @author shalini
	 * @createdOn 30-Mar-2012
	 * @modifiedOn 30-Mar-2012 
	 * 
	 */
	@Override
	public String fetchAllAfterSyncDate(Timestamp lastSyncDate, int pageNumber, int pageSize, String entity,
			String action, String login)
	{
		log.info("In service Impl: " + lastSyncDate + ", " + pageNumber);
		return getGenericDataBeanDAO().fetchAllAfterSyncDate(lastSyncDate, pageNumber, pageSize, entity, action, login);

	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @return
	 *
	 * @author himanshu
	 * @createdOn 17-Apr-2012
	 * @modifiedOn 17-Apr-2012 
	 * 
	 */
	@Override
	public List<ProductWrapper> searchWrapper(ProductWrapper productWrapper)
	{
		return getGenericDataBeanDAO().searchWrapper(productWrapper);
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param productWrapper
	 * @param id
	 * @return
	 *
	 * @author himanshu
	 * @createdOn 17-Apr-2012
	 * @modifiedOn 17-Apr-2012 
	 * 
	 */
	@Override
	public List<ProductWrapper> searchWrapperDetails(ProductWrapper productWrapper, long id)
	{
		return getGenericDataBeanDAO().searchWrapperDetails(productWrapper, id);
	}

	@Override
	public List<ProductWrapper> productRecommendList(ProductWrapper productWrapper, long id)
	{
		return getGenericDataBeanDAO().productRecommendList(productWrapper, id);
	}

	public List<ProductWrapper> productVariantList(ProductWrapper productWrapper, long id)
	{
		return variantDao.productVariantList(productWrapper, id);
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param code
	 * @return
	 *
	 * @author shalini
	 * @createdOn 26-Apr-2012
	 * @modifiedOn 26-Apr-2012 
	 * 
	 */
	@Override
	public Product checkRecordExistsForProductCode(String code)
	{
		Product searchProductDetailsBean = new Product();

		log.info("--------- product code --------" + code);

		searchProductDetailsBean.setCode(code);

		//searchProductDetailsBean.setDeleteFlag("F");

		List<Product> list = getGenericDataBeanDAO().findMatchingBeans(searchProductDetailsBean);

		if (list == null || list.size() == 0)
		{
			log.info("list null" + list + "or size 0" + list.size());

			return null;
		}

		try
		{

			if (list.size() > 1)
			{
				log.info("more than 1 record exist size" + list.size());
				throw new MoreThanOneRecodeFoundException();

			}
		}
		catch (Exception e)
		{
			log.info("Error");
		}

		log.info("single record found size" + list.size());

		return list.get(0);
	}

	@Override
	public List<Product> doProductListsearch(Product searchProduct)
	{
		List<Product> productList = null;

		log.info("==========in do productList Search============");
		productList = recommendationDao.doProductListsearch(searchProduct);
		log.info("==========after productList Search fetching============");
		return productList;
	}

	public List<ProductRecommendation> doProductRecomendationsearch(ProductRecommendation searchProductRecomendation)
	{
		List<ProductRecommendation> productRecommendationList = null;

		if (0 != searchProductRecomendation.getProductId())
		{
			log.info("==========in do productRecommendationList Search============");
			productRecommendationList = recommendationDao.doProductRecomendationsearch(searchProductRecomendation);
			log.info("==========after productRecommendationList Search fetching============");
			return productRecommendationList;
		}
		else
		{
			return productRecommendationList;
		}
	}

	@Override
	public List<Product> doProductVariantListsearch(Product searchProduct)
	{
		List<Product> productList = null;
		if (searchProduct.getSearchTags() != null)
		{
			log.info("==========in do productVariantList Search============");
			productList = variantDao.doProductVariantListsearch(searchProduct);
			log.info("==========after productVariantList Search fetching============");
			return productList;
		}
		else
		{
			return productList;
		}
	}

	public List<ProductVariant> doProductVariantsearch(ProductVariant searchProductVariant)
	{
		List<ProductVariant> productVariantList = null;

		if (0 != searchProductVariant.getProductId())
		{
			log.info("==========in do productVariantList Search============");
			productVariantList = variantDao.doProductVariantsearch(searchProductVariant);
			log.info("==========after productVariantList Search fetching============");
			return productVariantList;
		}
		else
		{
			return productVariantList;
		}
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param collection
	 *
	 * @author shalini
	 * @createdOn 26-Apr-2012
	 * @modifiedOn 26-Apr-2012 
	 * 
	 */
	@Override
	public void addProductsFromFTP(Collection<Product> collection)
	{

		for (Product currentProduct : collection)
		{
			if (currentProduct != null && currentProduct.getDeleteFlag().equalsIgnoreCase("F"))
			{
				getGenericDataBeanDAO().add(currentProduct);
			}
		}

	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param collection
	 *
	 * @author shalini
	 * @createdOn 26-Apr-2012
	 * @modifiedOn 26-Apr-2012 
	 * 
	 */
	@Override
	public void updateProductsFromFTP(Collection<Product> collection)
	{
		for (Product currentProduct : collection)
		{
			if (currentProduct != null)
			{
				setFieldsOnUpdate(currentProduct);
				getGenericDataBeanDAO().update(currentProduct);
			}
		}

	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param currentProduct
	 *
	 * @author shalini
	 * @createdOn 26-Apr-2012
	 * @modifiedOn 26-Apr-2012 
	 * 
	 */
	private void setFieldsOnUpdate(Product currentProduct)
	{
		Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
		
		currentProduct.setModifiedOn(currentTimestamp);
	}	

	private void setFieldsOnUpdate(Product currentProduct, boolean imageFlag)
	{
		Timestamp currentTimestamp = new Timestamp(System.currentTimeMillis());
		
		currentProduct.setModifiedOn(currentTimestamp);
		currentProduct.setImageModifiedOn(currentTimestamp);
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param prodId
	 * @param terrId
	 * @return
	 *
	 * @author shalini
	 * @createdOn 27-Apr-2012
	 * @modifiedOn 27-Apr-2012 
	 * 
	 */
	@Override
	public ProductInventory checkRecordExistsForProductAndStore(Long prodId, Long terrId)
	{
		ProductInventory prodInventory = new ProductInventory();
		prodInventory.setProductId(prodId);
		prodInventory.setTerritoryId(terrId);
		prodInventory.setDeleteFlag("F");

		List<ProductInventory> inventoryList = inventoryDao.findMatchingBeans(prodInventory);

		if (inventoryList == null || inventoryList.size() == 0)
		{
			log.info("list null" + inventoryList + "or size 0" + inventoryList.size());

			return null;
		}

		try
		{

			if (inventoryList.size() > 1)
			{
				log.info("more than 1 record exist size" + inventoryList.size());
				throw new MoreThanOneRecodeFoundException();

			}
		}
		catch (Exception e)
		{
			log.info("Error");
		}

		log.info("single record found size" + inventoryList.size());

		return inventoryList.get(0);

	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param collection
	 *
	 * @author shalini
	 * @createdOn 28-Apr-2012
	 * @modifiedOn 28-Apr-2012 
	 * 
	 */
	@Override
	public void addFTPInventory(Collection<ProductInventory> collection)
	{
		for (ProductInventory inventory : collection)
		{

			addInventory(inventory);

		}

	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param collection
	 *
	 * @author shalini
	 * @createdOn 28-Apr-2012
	 * @modifiedOn 28-Apr-2012 
	 * 
	 */
	@Override
	public void updateFTPInventory(Collection<ProductInventory> collection)
	{
		for (ProductInventory inventory : collection)
		{

			editInventory(inventory);

		}

	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param productId
	 * @return
	 *
	 * @author shalini
	 * @createdOn 28-Apr-2012
	 * @modifiedOn 28-Apr-2012 
	 * 
	 */
	@Override
	public ProductPrice checkPriceExistsForProduct(Long productId)
	{
		ProductPrice prodPrice = new ProductPrice();

		prodPrice.setProductId(productId);
		prodPrice.setDeleteFlag("F");

		List<ProductPrice> priceList = prodPriceDao.searchBean(prodPrice);

		log.info("priceList: " + priceList.size());

		if (priceList == null || priceList.size() == 0)
		{
			log.info("list null" + priceList + "or size 0" + priceList.size());

			return null;
		}

		try
		{

			if (priceList.size() > 1)
			{
				log.info("more than 1 record exist size" + priceList.size());
				throw new MoreThanOneRecodeFoundException();

			}
		}
		catch (Exception e)
		{
			log.info("Error");
		}

		log.info("single record found size" + priceList.size());

		return priceList.get(0);

	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param collection
	 *
	 * @author shalini
	 * @createdOn 28-Apr-2012
	 * @modifiedOn 28-Apr-2012 
	 * 
	 */
	@Override
	public void addFtpPrice(Collection<ProductPrice> collection)
	{
		for (ProductPrice price : collection)
		{
			addPrice(price);
		}

	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param collection
	 *
	 * @author shalini
	 * @createdOn 28-Apr-2012
	 * @modifiedOn 28-Apr-2012 
	 * 
	 */
	@Override
	public void updateFtpPrice(Collection<ProductPrice> collection)
	{
		for (ProductPrice price : collection)
		{
			updatePrice(price);
		}

	}

	public void imageUpdate(String code)
	{
		Product existingProduct = checkRecordExistsForProductCode(code);
		if (existingProduct != null && existingProduct.getDeleteFlag().equalsIgnoreCase("F"))
		{
			//setFieldsOnUpdate(existingProduct);
			
			setFieldsOnUpdate(existingProduct, true);
			getGenericDataBeanDAO().update(existingProduct);
		}

	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param code
	 * @return
	 *
	 * @author shalini
	 * @createdOn 18-May-2012
	 * @modifiedOn 18-May-2012 
	 * 
	 */
	@Override
	public ProductWrapper fetchProductwithPriceFromCode(String code)
	{
		ProductWrapper product = getGenericDataBeanDAO().fetchProductwithPrice(code);

		return product;
	}

	@Override
	public boolean softDeleteVariants(ProductVariant productVariant)
	{
		/*boolean status=false;*/
		
		int i = variantDao.softDeleteVariants(productVariant);
		if(0 != i)
		{			
			return true;
		}
		else 
		{
			return false;
		}
		
		
	}
}
