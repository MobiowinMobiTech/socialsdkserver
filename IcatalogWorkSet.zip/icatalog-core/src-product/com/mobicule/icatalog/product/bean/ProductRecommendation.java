package com.mobicule.icatalog.product.bean;

import com.mobicule.component.db.standardbean.SimpleDataBean;

public class ProductRecommendation extends SimpleDataBean
{

	private static final long serialVersionUID = 1L;

	private Long productId;

	private Long recommendId;

	public Long getProductId()
	{
		return productId;
	}

	public void setProductId(Long productId)
	{
		this.productId = productId;
	}

	public Long getRecommendId()
	{
		return recommendId;
	}

	public void setRecommendId(Long recommendId)
	{
		this.recommendId = recommendId;
	}

}
