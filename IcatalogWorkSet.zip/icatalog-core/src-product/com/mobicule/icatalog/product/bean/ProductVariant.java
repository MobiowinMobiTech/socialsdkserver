package com.mobicule.icatalog.product.bean;

import com.mobicule.component.db.standardbean.SimpleDataBean;

public class ProductVariant extends SimpleDataBean
{

	private static final long serialVersionUID = 1L;

	private long productId;

	private long variantId;

	public long getProductId()
	{
		return productId;
	}

	public void setProductId(long productId)
	{
		this.productId = productId;
	}

	public long getVariantId()
	{
		return variantId;
	}

	public void setVariantId(long variantId)
	{
		this.variantId = variantId;
	}

	@Override
	public String toString()
	{
		StringBuilder builder = new StringBuilder();
		builder.append("ProductVariant [\n\tproductId=");
		builder.append(productId);
		builder.append(", \n\tvariantId=");
		builder.append(variantId);
		builder.append("\n]");
		return builder.toString();
	}
	
	

}
