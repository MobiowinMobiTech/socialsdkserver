package com.mobicule.icatalog.product.bean;

import com.mobicule.component.db.standardbean.SimpleDataBean;

public class ProductInventory extends SimpleDataBean
{

	private static final long serialVersionUID = 1L;
	
	private Long productId;
	private Long inventory;
	private Long territoryId;
	
	public long getTerritoryId()
	{
		return territoryId;
	}

	public void setTerritoryId(Long territoryId)
	{
		this.territoryId = territoryId;
	}

	public Long getProductId()
	{
		return productId;
	}
	
	public void setProductId(Long productId) 
	{
		this.productId = productId;
	}
	
	public Long getInventory() 
	{
		return inventory;
	}
	
	public void setInventory(Long inventory)
	{
		this.inventory = inventory;
	}

}
