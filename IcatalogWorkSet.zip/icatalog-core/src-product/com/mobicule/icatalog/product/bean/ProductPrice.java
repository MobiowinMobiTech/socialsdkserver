package com.mobicule.icatalog.product.bean;

import com.mobicule.component.db.standardbean.SimpleDataBean;

public class ProductPrice extends SimpleDataBean
{

	private static final long serialVersionUID = 1L;

	private Long productId;

	private Double retailPrice;

	public Long getProductId()
	{
		return productId;
	}

	public void setProductId(Long productId)
	{
		this.productId = productId;
	}

	public Double getRetailPrice()
	{
		return retailPrice;
	}

	public void setRetailPrice(Double retailPrice)
	{
		this.retailPrice = retailPrice;
	}

}
