package com.mobicule.icatalog.product.bean;

import java.sql.Timestamp;

import com.mobicule.component.db.standardbean.StandardBean;

public class Product extends StandardBean
{

	private static final long serialVersionUID = 1L;

	private Long categoryId;

	private String dimensions;

	private String offerFlag;

	private String offerDescription;

	private String giftFlag;

	private String giftDescription;

	private String searchTags;

	private String brand;

	private String season;

	private String department;

	private String subDepartment;

	private String productClass;

	private String subClass;

	private String style;
	
	private Timestamp imageModifiedOn;

	public Long getCategoryId()

	{
		return categoryId;
	}

	public void setCategoryId(Long categoryId)

	{
		this.categoryId = categoryId;
	}

	public String getDimensions()
	{
		return dimensions;
	}

	public void setDimensions(String dimensions)
	{
		this.dimensions = dimensions;
	}

	public String getOfferFlag()
	{
		return offerFlag;
	}

	public void setOfferFlag(String offerFlag)
	{
		this.offerFlag = offerFlag;
	}

	public String getOfferDescription()
	{
		return offerDescription;
	}

	public void setOfferDescription(String offerDescription)
	{
		this.offerDescription = offerDescription;
	}

	public String getGiftFlag()
	{
		return giftFlag;
	}

	public void setGiftFlag(String giftFlag)
	{
		this.giftFlag = giftFlag;
	}

	public String getGiftDescription()
	{
		return giftDescription;
	}

	public void setGiftDescription(String giftDescription)
	{
		this.giftDescription = giftDescription;
	}

	public String getSearchTags()
	{
		return searchTags;
	}

	public void setSearchTags(String searchTags)
	{
		this.searchTags = searchTags;
	}

	public String getBrand()
	{
		return brand;
	}

	public void setBrand(String brand)
	{
		this.brand = brand;
	}

	public String getSeason()
	{
		return season;
	}

	public void setSeason(String season)
	{
		this.season = season;
	}

	public String getDepartment()
	{
		return department;
	}

	public void setDepartment(String department)
	{
		this.department = department;
	}

	public String getSubDepartment()
	{
		return subDepartment;
	}

	public void setSubDepartment(String subDepartment)
	{
		this.subDepartment = subDepartment;
	}

	public String getProductClass()
	{
		return productClass;
	}

	public void setProductClass(String productClass)
	{
		this.productClass = productClass;
	}

	public String getSubClass()
	{
		return subClass;
	}

	public void setSubClass(String subClass)
	{
		this.subClass = subClass;
	}

	public String getStyle()
	{
		return style;
	}

	public void setStyle(String style)
	{
		this.style = style;
	}

	public Timestamp getImageModifiedOn()
	{
		return imageModifiedOn;
	}

	public void setImageModifiedOn(Timestamp imageModifiedOn)
	{
		this.imageModifiedOn = imageModifiedOn;
	}

	/*@Override
	public String toString()
	{
		StringBuilder builder = new StringBuilder();
		builder.append("SimpleDataBean [\n\tid=");
		builder.append(id);
		builder.append("StandardBean [\n\tcode=");
		builder.append(code);
		builder.append(", \n\tname=");
		builder.append(name);
		builder.append(", \n\tdescription=");
		builder.append(description);
		builder.append("\n]");
		builder.append("Product [\n\tcategoryId=");
		builder.append(categoryId);
		builder.append(", \n\tdimensions=");
		builder.append(dimensions);
		builder.append(", \n\tofferFlag=");
		builder.append(offerFlag);
		builder.append(", \n\tofferDescription=");
		builder.append(offerDescription);
		builder.append(", \n\tgiftFlag=");
		builder.append(giftFlag);
		builder.append(", \n\tgiftDescription=");
		builder.append(giftDescription);
		builder.append(", \n\tsearchTags=");
		builder.append(searchTags);
		builder.append(", \n\tbrand=");
		builder.append(brand);
		builder.append(", \n\tseason=");
		builder.append(season);
		builder.append(", \n\tdepartment=");
		builder.append(department);
		builder.append(", \n\tsubDepartment=");
		builder.append(subDepartment);
		builder.append(", \n\tproductClass=");
		builder.append(productClass);
		builder.append(", \n\tsubClass=");
		builder.append(subClass);
		builder.append(", \n\tstyle=");
		builder.append(style);
		builder.append("\n]");
		return builder.toString();

	}
*/
}
