package com.mobicule.icatalog.product.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
******************************************************************************
* C O P Y R I G H T  A N D  C O N F I D E N T I A L I T Y  N O T I C E
* <p>
* Copyright © 2008-2009 Mobicule Technologies Pvt. Ltd. All rights reserved. 
* This is proprietary information of Mobicule Technologies Pvt. Ltd.and is 
* subject to applicable licensing agreements. Unauthorized reproduction, 
* transmission or distribution of this file and its contents is a 
* violation of applicable laws.
******************************************************************************
*
* @project icatalog-core
*/

/**
* 
* <enter description here>
*
* @author shalini <Nair>
* @see 
*
* @createdOn 03-Apr-2012
* @modifiedOn
*
* @copyright © 2008-2009 Mobicule Technologies Pvt. Ltd. All rights reserved.
*/
public class ProductWrapper implements Serializable
{
	private static final long serialVersionUID = 1L;

	private Product product;

	private ProductPrice price;

	private ProductInventory inventory;

	private List<ProductRecommendation> recommended;

	private List<ProductVariant> variant;

	public ProductWrapper()
	{
		recommended = new ArrayList<ProductRecommendation>();
		variant = new ArrayList<ProductVariant>();
	}

	public Product getProduct()
	{
		return product;
	}

	public void setProduct(Product product)
	{
		this.product = product;
	}

	public ProductPrice getPrice()
	{
		return price;
	}

	public void setPrice(ProductPrice price)
	{
		this.price = price;
	}

	public ProductInventory getInventory()
	{
		return inventory;
	}

	public void setInventory(ProductInventory inventory)
	{
		this.inventory = inventory;
	}

	public List<ProductRecommendation> getRecommended()
	{
		return recommended;
	}

	public void setRecommended(List<ProductRecommendation> recommended)
	{
		this.recommended = recommended;
	}

	public List<ProductVariant> getVariant()
	{
		return variant;
	}

	public void setVariant(List<ProductVariant> variant)
	{
		this.variant = variant;
	}

	@Override
	public String toString()
	{
		StringBuilder builder = new StringBuilder();
		builder.append("ProductWrapper [\n\tproduct=");
		builder.append(product);
		builder.append(", \n\tprice=");
		builder.append(price);
		builder.append(", \n\tinventory=");
		builder.append(inventory);
		builder.append(", \n\trecommended=");
		builder.append(recommended);
		builder.append(", \n\tvariant=");
		builder.append(variant);
		builder.append("]");
		return builder.toString();
	}
}
