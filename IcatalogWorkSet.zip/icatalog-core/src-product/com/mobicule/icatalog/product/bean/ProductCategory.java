package com.mobicule.icatalog.product.bean;

import java.sql.Timestamp;

import com.mobicule.component.db.standardbean.StandardBean;

public class ProductCategory extends StandardBean
{
	private static final long serialVersionUID = 1L;
	
	private Timestamp imageModifiedOn;

	public Timestamp getImageModifiedOn()
	{
		return imageModifiedOn;
	}

	public void setImageModifiedOn(Timestamp imageModifiedOn)
	{
		this.imageModifiedOn = imageModifiedOn;
	}
}
