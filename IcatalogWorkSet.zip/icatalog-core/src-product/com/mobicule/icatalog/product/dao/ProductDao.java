package com.mobicule.icatalog.product.dao;

import java.util.List;

import com.mobicule.component.system.db.dao.GenericDataBeanDAO;
import com.mobicule.icatalog.common.dao.SyncDao;
import com.mobicule.icatalog.product.bean.Product;
import com.mobicule.icatalog.product.bean.ProductWrapper;

public interface ProductDao extends GenericDataBeanDAO<Product>, SyncDao
{
	public List<ProductWrapper> doCustomSearch(Product searchProduct);

	public List<ProductWrapper> customSearch(Product searchProduct, Long productCategoryId);  
	
	public List<ProductWrapper> searchWrapper(ProductWrapper productWrapper);
	
	public List<ProductWrapper> searchWrapperDetails(ProductWrapper productWrapper,long id);
	
	public List<ProductWrapper> productRecommendList(ProductWrapper productWrapper,long id);

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param code
	 * @return
	 *
	 * @author shalini
	 * @createdOn 18-May-2012
	 * @modifiedOn 18-May-2012 
	 * 
	 */
	public ProductWrapper fetchProductwithPrice(String code);
	
}
