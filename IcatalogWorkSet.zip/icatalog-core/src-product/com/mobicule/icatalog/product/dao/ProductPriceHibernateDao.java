package com.mobicule.icatalog.product.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.springframework.dao.DataAccessException;

import com.mobicule.component.system.db.dao.GenericDataBeanHibernateDAO;
import com.mobicule.icatalog.product.bean.ProductPrice;

public class ProductPriceHibernateDao extends GenericDataBeanHibernateDAO<ProductPrice> implements ProductPriceDao
{
	private Log log = LogFactory.getLog(this.getClass());
	
	@Override
	public List<ProductPrice> searchBean(ProductPrice prodPrice)
	{
		log.info("-------------inside searchBean----");
		List<ProductPrice> priceList=new ArrayList<ProductPrice>();

		StringBuilder searchQueryBuilder = new StringBuilder(" from ProductPrice pp where pp.productId= :productId and pp.deleteFlag= :deleteFlag");
		Query query = getSession().createQuery(searchQueryBuilder.toString());
		
		query.setParameter("productId", prodPrice.getProductId());
		query.setParameter("deleteFlag", "F");
		
		 priceList = query.list();
		
		return priceList;
	}

}
