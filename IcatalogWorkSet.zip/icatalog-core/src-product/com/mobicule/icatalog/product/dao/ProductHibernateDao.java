package com.mobicule.icatalog.product.dao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.springframework.dao.DataAccessResourceFailureException;
import org.springframework.util.CollectionUtils;

import com.mobicule.component.system.db.dao.GenericDataBeanDAO;
import com.mobicule.icatalog.common.dao.AbstractSyncDao;
import com.mobicule.icatalog.core.constants.IcatalogUtility;
import com.mobicule.icatalog.core.constants.SyncConstants;
import com.mobicule.icatalog.product.bean.Product;
import com.mobicule.icatalog.product.bean.ProductInventory;
import com.mobicule.icatalog.product.bean.ProductPrice;
import com.mobicule.icatalog.product.bean.ProductRecommendation;
import com.mobicule.icatalog.product.bean.ProductVariant;
import com.mobicule.icatalog.product.bean.ProductWrapper;
import com.mobicule.icatalog.systemuser.bean.SystemUser;
import com.mobicule.icatalog.systemuser.dao.SystemUserDao;

public class ProductHibernateDao extends AbstractSyncDao<Product> implements ProductDao
{

	private Log log = LogFactory.getLog(this.getClass());

	private Map<String, List<String>> imageConfig;

	private SystemUserDao userDao;

	public SystemUserDao getUserDao()
	{
		return userDao;
	}

	public void setUserDao(SystemUserDao userDao)
	{
		this.userDao = userDao;
	}

	public Map<String, List<String>> getImageConfig()
	{
		return imageConfig;
	}

	public void setImageConfig(Map<String, List<String>> imageConfig)
	{
		this.imageConfig = imageConfig;
	}

	public StringBuilder productListQueryBuilder(StringBuilder productListQueryString)
	{
		productListQueryString.append(" from product p ");
		productListQueryString.append(" join product_category pc on pc.id=p.category_id ");
		productListQueryString.append(" left join product_price pp on pp.product_id=p.id ");
		productListQueryString.append(" left join product_inventory pi on pi.product_id=p.id ");
		productListQueryString.append(" where p.delete_flag='F' ");
		productListQueryString.append(" and pc.delete_flag='F' ");
		return productListQueryString;
	}

	public List<ProductWrapper> doCustomSearch(Product searchProduct)
	{
		log.info("-----doCustomSearch------Without Product Category---");

		StringBuilder searchQueryBuilder = new StringBuilder(" select {p.*},{pp.*},{pi.*} ");

		searchQueryBuilder = productListQueryBuilder(searchQueryBuilder);

		ProductWrapper productWrapper = null;

		List<ProductWrapper> productList = new ArrayList<ProductWrapper>();

		boolean isFirstClause = false;

		Long id = searchProduct.getId();
		String searchTags = searchProduct.getSearchTags();
		String brand = searchProduct.getBrand();
		String department = searchProduct.getDepartment();
		String subdepartment = searchProduct.getSubDepartment();
		String productclass = searchProduct.getProductClass();
		String subClass = searchProduct.getSubClass();
		String style = searchProduct.getStyle();
		String offer = searchProduct.getOfferFlag();
		String gift = searchProduct.getGiftFlag();

		log.info("============Name====================" + searchTags);
		log.info("============Brand====================" + brand);

		if (null != searchTags)
		{
			if (isFirstClause)
			{
				searchQueryBuilder.append(" where ");
				isFirstClause = false;
			}
			else
			{
				searchQueryBuilder.append(" and");
			}

			searchQueryBuilder
					.append(" ( p.search_tags like :searchTags or p.name like :searchTags or p.code like :searchTags) ");
		}

		if (null != department)
		{
			if (isFirstClause)
			{
				searchQueryBuilder.append(" where ");
				isFirstClause = false;
			}
			else
			{
				searchQueryBuilder.append(" and ");
			}

			searchQueryBuilder.append(" p.department like :department ");
		}

		if (null != brand)
		{
			if (isFirstClause)
			{
				searchQueryBuilder.append(" where ");
				isFirstClause = false;
			}
			else
			{
				searchQueryBuilder.append(" and ");
			}

			searchQueryBuilder.append(" p.brand like :brand ");
		}

		if (null != subdepartment)
		{
			if (isFirstClause)
			{
				searchQueryBuilder.append(" where ");
				isFirstClause = false;
			}
			else
			{
				searchQueryBuilder.append(" and ");
			}

			searchQueryBuilder.append(" p.sub_department like :subdepartment ");
		}

		if (null != productclass)
		{
			if (isFirstClause)
			{
				searchQueryBuilder.append(" where ");
				isFirstClause = false;
			}
			else
			{
				searchQueryBuilder.append(" and ");
			}

			searchQueryBuilder.append(" p.class like :productclass ");
		}

		if (null != subClass)
		{
			if (isFirstClause)
			{
				searchQueryBuilder.append(" where ");
				isFirstClause = false;
			}
			else
			{
				searchQueryBuilder.append(" and ");
			}

			searchQueryBuilder.append(" p.sub_class like :subClass ");
		}

		if (null != style)
		{
			if (isFirstClause)
			{
				searchQueryBuilder.append(" where ");
				isFirstClause = false;
			}
			else
			{
				searchQueryBuilder.append(" and ");
			}

			searchQueryBuilder.append(" p.style like :style ");
		}

		if (null != offer)
		{
			if (isFirstClause)
			{
				searchQueryBuilder.append(" where ");
				isFirstClause = false;
			}
			else
			{
				searchQueryBuilder.append(" and ");
			}

			searchQueryBuilder.append(" p.offer_flag like :offer ");
		}

		if (null != gift)
		{
			if (isFirstClause)
			{
				searchQueryBuilder.append(" where ");
				isFirstClause = false;
			}
			else
			{
				searchQueryBuilder.append(" and ");
			}

			searchQueryBuilder.append(" p.gift_flag like :gift ");
		}

		if (null != id)
		{
			if (isFirstClause)
			{
				searchQueryBuilder.append(" where ");
				isFirstClause = false;
			}
			else
			{
				searchQueryBuilder.append(" and");
			}

			searchQueryBuilder.append(" ( p.id =:id ) ");
		}

		SQLQuery query = getSession().createSQLQuery(searchQueryBuilder.toString());

		if (null != searchTags)
		{
			query.setParameter("searchTags", "%" + searchTags + "%");
		}

		if (null != brand)
		{
			query.setParameter("brand", "" + brand + "%");
		}

		if (null != department)
		{
			query.setParameter("department", "" + department + "%");
		}

		if (null != subdepartment)
		{
			query.setParameter("subdepartment", "" + subdepartment + "%");
		}

		if (null != productclass)
		{
			query.setParameter("productclass", "" + productclass + "%");
		}

		if (null != subClass)
		{
			query.setParameter("subClass", "" + subClass + "%");
		}

		if (null != style)
		{
			query.setParameter("style", "" + style + "%");
		}

		if (null != offer)
		{
			query.setParameter("offer", "" + offer + "%");
		}

		if (null != gift)
		{
			query.setParameter("gift", "" + gift + "%");
		}

		if (null != id)
		{
			query.setParameter("id", id);
		}

		log.info("--*********--query for search---****************--::: " + query);

		List<Object[]> resultList = query.addEntity("p", Product.class).addEntity("pp", ProductPrice.class)
				.addEntity("pi", ProductInventory.class).list();

		log.info("----resultList size is----:::" + resultList.size());

		for (Object[] obj : resultList)
		{

			Product currentproduct = (Product) obj[0];
			ProductPrice currentProductPrice = (ProductPrice) obj[1];
			ProductInventory currenProductInventory = (ProductInventory) obj[2];

			productWrapper = new ProductWrapper();

			productWrapper.setProduct(currentproduct);
			productWrapper.setPrice(currentProductPrice);
			productWrapper.setInventory(currenProductInventory);

			productList.add(productWrapper);

		}

		log.info("----------------Product List----------------:::" + productList);
		return productList;
	}

	@Override
	public String findAllAfterSyncDate(Timestamp lastSyncDate, int pageNumber, int pageSize, String entity)
	{
		return null;
	}

	@Override
	public String getNewlyAddedEntities(int pageNumber, int pageSize, String login)
	{
		final List<HashMap> productMapList = new LinkedList<HashMap>();
		
		Long userId = fetchUserId(login);

		log.info("userId: " + userId);

		/*Fetching product codes and setting page size on that*/
		
		StringBuilder queryForProdCode = new StringBuilder();
		queryForProdCode.append("select distinct(p.code) pcode ");
		createQueryForNewEntries(queryForProdCode);
		
		if (log.isInfoEnabled())
		{
			log.info("in newly added queryForProdCode: " + queryForProdCode.toString());
		}

		SQLQuery query1 = getSession().createSQLQuery(queryForProdCode.toString());
		query1.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);
		query1.setLong("userId", userId);

		query1.setFirstResult(pageNumber * pageSize);
		query1.setMaxResults(pageSize);

		List<String> productCodes = query1.addScalar("pcode", Hibernate.STRING).list();

		log.info("productCodes: " + productCodes.size());

		//Fetching data for products as per previously retrieved code

		StringBuilder queryForNewEntries = new StringBuilder();
		queryForNewEntries.append("select {p.*},{pp.*},{inv_view.*},{prm.*}, {pvm.*} ");

		createQueryForNewEntries(queryForNewEntries);

		 appendProductCodeWithIn(productCodes,queryForNewEntries);


		if (log.isInfoEnabled())
		{
			log.info("in newly added queryForNewEntries: " + queryForNewEntries.toString());
		}

		SQLQuery query = getSession().createSQLQuery(queryForNewEntries.toString());
		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);
		query.setLong("userId", userId);

		/*query.setFirstResult(pageNumber * pageSize);
		query.setMaxResults(pageSize);*/

		List<Object[]> list = query.addEntity("p", Product.class).addEntity("pp", ProductPrice.class)
				.addEntity("inv_view", ProductInventory.class).addEntity("prm", ProductRecommendation.class)
				.addEntity("pvm", ProductVariant.class).list();

		if (log.isInfoEnabled())
		{
			log.info("List size: " + list.size());
		}

		/*if (CollectionUtils.isEmpty(list))
		{
			return null;
		}*/

		if (log.isDebugEnabled())
		{
			log.debug("list : " + ((list == null) ? "null" : list.size()));
		}

		for (Object[] obj : list)
		{
			log.info("Id's of product in list: " + ((Product) obj[0]).getId());

		}
		HashMap<String, ProductWrapper> productWrapperCache = new HashMap<String, ProductWrapper>();

		for (Object[] obj : list)
		{
			Product currentProduct = (Product) obj[0];

			String currentProductCode = currentProduct.getCode();

			ProductWrapper currentProductWrapper = null;

			log.info("Product id: " + currentProduct.getId());

			// add Product
			if (!productWrapperCache.containsKey(currentProductCode))
			{
				currentProductWrapper = new ProductWrapper();
				currentProductWrapper.setProduct(currentProduct);

				productWrapperCache.put(currentProductCode, currentProductWrapper);
			}
			else
			{
				currentProductWrapper = productWrapperCache.get(currentProductCode);
			}

			// add Inventory and Price
			if (obj[2] != null)
			{
				currentProductWrapper.setInventory((ProductInventory) obj[2]);
			}
			if (obj[1] != null)
			{
				currentProductWrapper.setPrice((ProductPrice) obj[1]);
			}

			// add variant product
			if (obj[4] != null)
			{
				ProductVariant currentProductVariant = (ProductVariant) obj[4];
				List<ProductVariant> variantList = currentProductWrapper.getVariant();

				if (currentProductVariant.getDeleteFlag().equalsIgnoreCase("F"))
				{
					if (!variantList.contains(currentProductVariant))
					{
						variantList.add(currentProductVariant);
					}
				}
			}

			// add recommended product
			if (obj[3] != null)
			{
				ProductRecommendation currentProductRecommendation = (ProductRecommendation) obj[3];
				List<ProductRecommendation> recommendedList = currentProductWrapper.getRecommended();

				if (currentProductRecommendation.getDeleteFlag().equalsIgnoreCase("F"))
				{

					if (!recommendedList.contains(currentProductRecommendation))
					{
						recommendedList.add(currentProductRecommendation);
					}
				}
			}

			if (log.isInfoEnabled())
			{
				log.info("Product Wrapper: " + currentProductWrapper.toString());
				log.info("Size of cache: " + productWrapperCache.size());
			}
		}

		if (log.isDebugEnabled())
		{
			log.debug("productWrapperCache : " + productWrapperCache);
		}

		formatWrapper(productMapList, productWrapperCache, "ADD");
		HashMap dataMap = IcatalogUtility.createResponseMessage(productMapList);

		String response = IcatalogUtility.createJSONFromMap(dataMap);

		return response;
	}

	/*public String appendProductCode(List<String> meterReadinglist)
	{
		String whereClause = " and ( ";

		for (int i = 0; i < (meterReadinglist.size()); i++)
		{
			whereClause = whereClause + " p.code = '" + ((meterReadinglist.get(i))) + "' or";
		}

		whereClause = whereClause.substring(0, ((whereClause.length()) - 3));
		
		whereClause=whereClause+ " )";

		return whereClause;
	}*/
	
	public  void appendProductCodeWithIn(List<String> codeList, StringBuilder queryBuilder)
    {
        if (CollectionUtils.isEmpty(codeList))
        {
            return;
        }

        queryBuilder.append(" and ( ");
        int chunkRemainder = 0;
        boolean isFirstTime = true;

        for (int i = 0; i < codeList.size(); i++)
        {
            String code = codeList.get(i);

            chunkRemainder = (i) % SyncConstants.MAX_IN_QUERY_LIST_SIZE;

            if (chunkRemainder == 0)
            {
                if (isFirstTime)
                {
                    isFirstTime = false;
                }
                else
                {
                	queryBuilder.append(" or ");
                }

                queryBuilder.append(" p.code in  ( '");

                queryBuilder.append(code);

                if (!(chunkRemainder == SyncConstants.MAX_IN_QUERY_LIST_SIZE - 1) && (i < codeList.size() - 1))
                {
                	queryBuilder.append("', '");
                }
                else if (i == (codeList.size() - 1))
                {
                	queryBuilder.append("' ) ");
                }
            }
            else if (chunkRemainder == SyncConstants.MAX_IN_QUERY_LIST_SIZE - 1)
            {
            	queryBuilder.append(code);
            	queryBuilder.append("' ) ");
            }
            else
            {
            	queryBuilder.append(code);

                if (!(chunkRemainder == SyncConstants.MAX_IN_QUERY_LIST_SIZE - 1) && (i < codeList.size() - 1))
                {
                	queryBuilder.append("', '");
                }
                else if (i == (codeList.size() - 1))
                {
                	queryBuilder.append("' ) ");
                }
            }
        }
        
        queryBuilder.append(" )");
    }

	private void formatWrapper(List<HashMap> productMapList, HashMap<String, ProductWrapper> productWrapperCache,
			String action)
	{
		List<String> imageBasePath = (List<String>) imageConfig.get("IMAGE_BASE_PATH");
		for (String key : productWrapperCache.keySet())
		{
			ProductWrapper wrapper = new ProductWrapper();
			HashMap<String, Object> formattedProduct = new HashMap<String, Object>();
			
			int i = 0;

			wrapper = productWrapperCache.get(key);

			List<String> imgList = new ArrayList<String>();

			imgList = IcatalogUtility.fetchImageList(imageBasePath.get(0), "product", wrapper.getProduct().getCode());
			if (!(imgList.isEmpty()))
			{

				List<String> imgConfigList = configImgList(imgList);

				formattedProduct.put("id", wrapper.getProduct().getId().toString());
				formattedProduct.put("code", wrapper.getProduct().getCode());
				formattedProduct.put("name", wrapper.getProduct().getName());
				formattedProduct.put("imgModOn", wrapper.getProduct().getImageModifiedOn());

				if (wrapper.getProduct().getDescription() != null)
				{
					formattedProduct.put("description", wrapper.getProduct().getDescription());
				}
				if (wrapper.getProduct().getDimensions() != null)
				{
					formattedProduct.put("dimension", wrapper.getProduct().getDimensions());
				}
				if (wrapper.getProduct().getOfferFlag() != null)
				{
					formattedProduct.put("offer_flag", wrapper.getProduct().getOfferFlag());
				}
				if (wrapper.getProduct().getOfferDescription() != null)
				{
					formattedProduct.put("offer_description", wrapper.getProduct().getOfferDescription());
				}
				if (wrapper.getProduct().getGiftFlag() != null)
				{
					formattedProduct.put("gift_flag", wrapper.getProduct().getGiftFlag());
				}
				if (wrapper.getProduct().getGiftDescription() != null)
				{
					formattedProduct.put("gift_description", wrapper.getProduct().getGiftDescription());
				}
				if (wrapper.getProduct().getSearchTags() != null)
				{
					formattedProduct.put("search_tags", wrapper.getProduct().getSearchTags());
				}
				if (wrapper.getProduct().getBrand() != null)
				{
					formattedProduct.put("brand", wrapper.getProduct().getBrand());
				}
				if (wrapper.getProduct().getSeason() != null)
				{
					formattedProduct.put("season", wrapper.getProduct().getSeason());
				}
				if (wrapper.getProduct().getDepartment() != null)
				{
					formattedProduct.put("department", wrapper.getProduct().getDepartment());
				}
				if (wrapper.getProduct().getSubDepartment() != null)
				{
					formattedProduct.put("sub_department", wrapper.getProduct().getSubDepartment());
				}
				if (wrapper.getProduct().getProductClass() != null)
				{
					formattedProduct.put("class", wrapper.getProduct().getProductClass());
				}
				if (wrapper.getProduct().getSubClass() != null)
				{
					formattedProduct.put("sub_class", wrapper.getProduct().getSubClass());
				}
				if (wrapper.getProduct().getStyle() != null)
				{
					formattedProduct.put("style", wrapper.getProduct().getStyle());
				}

				if (wrapper.getInventory() != null)
				{
					formattedProduct.put("inventory", wrapper.getInventory().getInventory());
				}
				if (wrapper.getPrice() != null)
				{
					formattedProduct.put("price", wrapper.getPrice().getRetailPrice());
				}

				formattedProduct.put("category_id", wrapper.getProduct().getCategoryId());
				List<Long> variantIdList = new ArrayList<Long>();

				for (i = 0; i < wrapper.getVariant().size(); i++)
				{
					/*if (i == 0)
					{
						variantBuilder.append(wrapper.getVariant().get(i).getVariantId());
					}
					else
					{
						variantBuilder.append(" , ");
						variantBuilder.append(wrapper.getVariant().get(i).getVariantId());
					}*/
					Product variantProduct = findMatchingBeanById(Product.class, "id", wrapper.getVariant().get(i)
							.getVariantId());
					log.info("variant code: " + variantProduct.getCode());
					List<String> variantImgList = IcatalogUtility.fetchImageList(imageBasePath.get(0), "product",
							variantProduct.getCode());
					if (variantImgList.size() != 0)
					{
						variantIdList.add(wrapper.getVariant().get(i).getVariantId());
					}
					//variantIdList.add(wrapper.getVariant().get(i).getVariantId());
				}
				formattedProduct.put("variants", variantIdList);

				List<Long> recommendedIdList = new ArrayList<Long>();

				for (i = 0; i < wrapper.getRecommended().size(); i++)
				{

					Product recommendProduct = findMatchingBeanById(Product.class, "id", wrapper.getRecommended()
							.get(i).getRecommendId());
					log.info("recommended code: " + recommendProduct.getCode());
					List<String> recommendImgList = IcatalogUtility.fetchImageList(imageBasePath.get(0), "product",
							recommendProduct.getCode());
					if (recommendImgList.size() != 0)
					{
						recommendedIdList.add(wrapper.getRecommended().get(i).getRecommendId());
					}

				}
				formattedProduct.put("recommended", recommendedIdList);

				if (imgConfigList != null)
				{
					formattedProduct.put("image", imgConfigList);
				}
				else
					log.info("img list size: " + imgConfigList.size());

				if (action.equalsIgnoreCase("add"))
				{
					formattedProduct.put("sync_flag", "A");
				}
				else if (action.equalsIgnoreCase("modify"))
				{
					formattedProduct.put("sync_flag", "M");
				}
				else if (action.equalsIgnoreCase("delete"))
				{
					formattedProduct.put("sync_flag", "D");
				}

				productMapList.add(formattedProduct);
			}

		}

	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param imgList
	 * @return
	 *
	 * @author shalini
	 * @createdOn 10-Apr-2012
	 * @modifiedOn 10-Apr-2012 
	 * 
	 */
	private List<String> configImgList(List<String> imgList)
	{
		int i;
		Map mapValues = new HashMap();
		mapValues.put("config", imageConfig.get("IMG_DIM_PRODUCT"));
		log.info("map values" + mapValues);
		List<String> configList = new ArrayList<String>();
		//String newConfig=null;
		for (String img : imgList)
		{
			List imgConfig = (List) mapValues.get("config");

			for (i = 0; i < imgConfig.size(); i++)
			{
				String newConfig = img.concat("-" + imgConfig.get(i));
				log.info("new Img" + newConfig);
				configList.add(newConfig);
			}

		}
		return configList;
	}

	@Override
	public int getAddedEntitiesCount(String login)
	{
		StringBuilder queryForNewEntries = new StringBuilder();
		Long userId = fetchUserId(login);

		queryForNewEntries.append("select count( distinct(p.code)) pcount ");
		createQueryForNewEntries(queryForNewEntries);

		SQLQuery query = getSession().createSQLQuery(queryForNewEntries.toString());

		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);
		query.setLong("userId", userId);

		List<Long> returnValue = query.addScalar("pcount", Hibernate.LONG).list();

		if (CollectionUtils.isEmpty(returnValue))
		{
			return 0;
		}
		else
		{
			return returnValue.get(0).intValue();
		}
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param login
	 * @return
	 *
	 * @author shalini
	 * @createdOn 07-May-2012
	 * @modifiedOn 07-May-2012 
	 * 
	 */
	private Long fetchUserId(String login)
	{
		SystemUser user = new SystemUser();
		user.setLogin(login);
		user.setDeleteFlag("F");

		List<SystemUser> userList = new ArrayList<SystemUser>();
		userList = userDao.findMatchingBeans(user);
		if ((userList != null) && (userList.size() != 0) && (userList.size() < 2))
		{
			return userList.get(0).getId();
		}
		else
			return null;

	}

	private void createQueryForNewEntries(StringBuilder queryForNewEntries)
	{

		queryForNewEntries.append(" from product p ");
		queryForNewEntries.append("join product_category pc on pc.id = p.category_id ");
		queryForNewEntries.append("left join product_price pp on p.id = pp.product_id ");
		queryForNewEntries.append("left join (select pi.* from product_inventory pi  ");
		queryForNewEntries.append("join territory_user_map tum on tum.territory_id = pi.territory_id  ");
		queryForNewEntries.append("where tum.user_id = :userId) inv_view on p.id = inv_view.product_id ");
		queryForNewEntries.append("left join ( select pm.* from product_recommendation_mapping pm ");
		queryForNewEntries.append("join product prod on prod.id=pm.recommended_product_id ");
		queryForNewEntries.append("join product_category cat on prod.category_id=cat.id ");
		queryForNewEntries.append("where cat.delete_flag = :deleteFlag and prod.delete_flag=:deleteFlag ) ");
		queryForNewEntries.append(" prm on prm.product_id = p.id ");
		queryForNewEntries.append("left join ( select pv.* from product_variant_mapping pv ");
		queryForNewEntries.append("	join product prod on prod.id=pv.variant_product_id ");
		queryForNewEntries.append("	join product_category cat on prod.category_id=cat.id ");
		queryForNewEntries.append("	where cat.delete_flag = 'F' and prod.delete_flag='F' ) ");
		queryForNewEntries.append("	pvm on pvm.product_id = p.id ");
		queryForNewEntries.append("where pc.delete_flag = :deleteFlag and p.delete_flag=:deleteFlag ");
	}

	@Override
	public int getNewlyAddedEntitiesAfterSyncDateCount(Timestamp lastSyncDate, String login)
	{
		StringBuilder queryForNewEntries = new StringBuilder();

		Long userId = fetchUserId(login);

		log.info("userId: " + userId);

		queryForNewEntries.append(" select count(distinct(p.code)) pcount ");
		createQueryForNewEntriesAfterSyncDate(queryForNewEntries);

		SQLQuery query = getSession().createSQLQuery(queryForNewEntries.toString());

		if (log.isInfoEnabled())
		{
			log.info("query in add: " + queryForNewEntries);
		}

		query.setTimestamp("createdOn", lastSyncDate);
		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);
		query.setLong("userId", userId);

		List<Long> returnValue = query.addScalar("pcount", Hibernate.LONG).list();

		if (CollectionUtils.isEmpty(returnValue))
		{
			return 0;
		}
		else
		{
			return returnValue.get(0).intValue();
		}
	}

	private void createQueryForNewEntriesAfterSyncDate(StringBuilder queryForNewEntries)
	{
		/*queryForNewEntries.append("From Product p,ProductPrice pp, ProductInventory pi, ProductRecommendation prm ");
		queryForNewEntries
				.append("where p.categoryId in (select id from ProductCategory where deleteFlag=:deleteFlag) ");
		queryForNewEntries.append("and pi.productId=p.id and pp.productId=p.id ");
		queryForNewEntries.append("and prm.productId=p.id and ");
		queryForNewEntries.append("pi.territoryId in (select territoryCode from UserTerritoryMapping ");
		queryForNewEntries.append("where userCode=:userId and deleteFlag=:deleteFlag) and ");
		queryForNewEntries.append("((p.createdOn>= :createdOn ) or (pp.createdOn>=:createdOn)");
		queryForNewEntries.append("	or (prm.createdOn>=:createdOn) or (pi.createdOn>=:createdOn ))");
		queryForNewEntries
				.append("and p.deleteFlag=:deleteFlag and pi.deleteFlag=:deleteFlag and pp.deleteFlag=:deleteFlag and prm.deleteFlag=:deleteFlag ");
		*/

		queryForNewEntries.append(" from product p ");
		queryForNewEntries.append("join product_category pc on pc.id = p.category_id ");
		queryForNewEntries.append("left join product_price pp on p.id = pp.product_id ");
		queryForNewEntries.append("left join (select pi.* from product_inventory pi ");
		queryForNewEntries.append("join territory_user_map tum on tum.territory_id = pi.territory_id  ");
		queryForNewEntries.append("where tum.user_id = :userId) inv_view on p.id = inv_view.product_id ");
		queryForNewEntries.append("left join (select pm.* from product_recommendation_mapping pm  ");
		queryForNewEntries.append("join product prod on prod.id=pm.recommended_product_id ");
		queryForNewEntries.append("join product_category cat on prod.category_id=cat.id ");
		queryForNewEntries
				.append("where cat.delete_flag = :deleteFlag and prod.delete_flag= :deleteFlag) prm on prm.product_id = p.id ");
		queryForNewEntries.append("left join ( select pv.* from product_variant_mapping pv ");
		queryForNewEntries.append("	join product prod on prod.id=pv.variant_product_id ");
		queryForNewEntries.append("	join product_category cat on prod.category_id=cat.id ");
		queryForNewEntries.append("	where cat.delete_flag = 'F' and prod.delete_flag='F' ) ");
		queryForNewEntries.append("	pvm on pvm.product_id = p.id ");
		queryForNewEntries
				.append("where pc.delete_flag = :deleteFlag and p.delete_flag= :deleteFlag and p.created_on>= :createdOn ");
	}

	@Override
	public int getModifiedEntitiesAfterSyncDateCount(Timestamp lastSyncDate, String login)
	{
		
		
		StringBuilder queryForModifiedEntries = new StringBuilder();

		Long userId = fetchUserId(login);

		log.info("userId: " + userId);

		log.info("ProductHibernateDao/getModifiedEntitiesAfterSyncDateCount ");
		
		queryForModifiedEntries.append(" select count(distinct(p.code)) as pcount ");
		createQueryForModifiedEntries(queryForModifiedEntries);

		if (log.isInfoEnabled())
		{
			log.info("Query: " + queryForModifiedEntries.toString());
		}

		SQLQuery query = getSession().createSQLQuery(queryForModifiedEntries.toString());

		query.setTimestamp("createdOn", lastSyncDate);
		query.setTimestamp("modifiedOn", lastSyncDate);
		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);
		query.setLong("userId", userId);

		List<Long> returnValue = query.addScalar("pcount", Hibernate.LONG).list();

		if (CollectionUtils.isEmpty(returnValue))
		{
			return 0;
		}
		else
		{
			return returnValue.get(0).intValue();
		}
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param queryForModifiedEntries
	 *
	 * @author shalini
	 * @createdOn 10-Apr-2012
	 * @modifiedOn 10-Apr-2012 
	 * 
	 */
	private void createQueryForModifiedEntries(StringBuilder queryForModifiedEntries)
	{
		/*queryForModifiedEntries
				.append("From Product p,ProductPrice pp, ProductInventory pi, ProductRecommendation prm  ");
		queryForModifiedEntries
				.append("where p.categoryId in (select id from ProductCategory where deleteFlag=:deleteFlag) ");
		queryForModifiedEntries.append("and pi.productId=p.id and pp.productId=p.id ");
		queryForModifiedEntries.append("and prm.productId=p.id  and ");
		queryForModifiedEntries.append("pi.territoryId in (select territoryCode from UserTerritoryMapping ");
		queryForModifiedEntries.append("where userCode=:userId and deleteFlag=:deleteFlag) and ");
		queryForModifiedEntries
				.append("((p.createdOn< :createdOn and p.modifiedOn>= :modifiedOn ) or (pp.createdOn< :createdOn and pp.modifiedOn>= :modifiedOn)");
		queryForModifiedEntries
				.append("	or (prm.createdOn< :createdOn and prm.modifiedOn>= :modifiedOn) or (pi.createdOn< :createdOn and pi.modifiedOn>= :modifiedOn))");
		queryForModifiedEntries
				.append("and p.deleteFlag=:deleteFlag and pi.deleteFlag=:deleteFlag and pp.deleteFlag=:deleteFlag and prm.deleteFlag=:deleteFlag ");
		*/
		queryForModifiedEntries.append(" from product p ");
		queryForModifiedEntries.append("join product_category pc on pc.id = p.category_id ");
		queryForModifiedEntries.append("left join product_price pp on p.id = pp.product_id ");
		queryForModifiedEntries.append("left join (select pi.* from product_inventory pi ");
		queryForModifiedEntries.append("join territory_user_map tum on tum.territory_id = pi.territory_id  ");
		queryForModifiedEntries.append("where tum.user_id = :userId) inv_view on p.id = inv_view.product_id ");
		queryForModifiedEntries.append("left join (select pm.* from product_recommendation_mapping pm  ");
		queryForModifiedEntries.append("join product prod on prod.id=pm.recommended_product_id ");
		queryForModifiedEntries.append("join product_category cat on prod.category_id=cat.id ");
		queryForModifiedEntries
				.append("where cat.delete_flag = :deleteFlag and prod.delete_flag= :deleteFlag) prm on prm.product_id = p.id ");
		queryForModifiedEntries.append("left join ( select pv.* from product_variant_mapping pv ");
		queryForModifiedEntries.append(" join product prod on prod.id=pv.variant_product_id ");
		queryForModifiedEntries.append(" join product_category cat on prod.category_id=cat.id ");
		queryForModifiedEntries.append(" where cat.delete_flag =:deleteFlag and prod.delete_flag=:deleteFlag ) ");
		queryForModifiedEntries.append(" pvm on pvm.product_id = p.id ");
		queryForModifiedEntries.append(" where pc.delete_flag = :deleteFlag and p.delete_flag= :deleteFlag and ");
		queryForModifiedEntries.append("((p.created_on< :createdOn and p.modified_on>=:modifiedOn) ");
		queryForModifiedEntries.append(" or ( pp.modified_on>=:modifiedOn) ");
		queryForModifiedEntries.append(" or ( inv_view.modified_on>=:modifiedOn) ");
		queryForModifiedEntries
				.append(" or p.id in (select pvm.product_id from product_variant_mapping pvm where  pvm.modified_on>=:modifiedOn)");
		queryForModifiedEntries
				.append(" or p.id in (select prm.product_id from product_recommendation_mapping prm where  prm.modified_on>=:modifiedOn))");

	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param queryForDeletedEntries
	 *
	 * @author shalini
	 * @createdOn 02-Apr-2012
	 * @modifiedOn 02-Apr-2012 
	 * 
	 */

	private void createQueryForDeletedEntries(StringBuilder queryForDeletedEntries)
	{
		queryForDeletedEntries
				.append(" From Product p where p.createdOn<:createdOn and p.modifiedOn >=:modifiedOn and p.deleteFlag=:deleteFlag");

	}

	@Override
	public int getDeletedEntitiesAfterSyncDateCount(Timestamp lastSyncDate)
	{
		StringBuilder queryForDeletedEntries = new StringBuilder();
		log.info("ProductHibernateDao/getDeletedEntitiesAfterSyncDateCount ");
		
		queryForDeletedEntries.append(" select count(p.code) ");
		createQueryForDeletedEntries(queryForDeletedEntries);

		try
		{
			Query query = getSession().createQuery(queryForDeletedEntries.toString());
			query.setTimestamp("createdOn", lastSyncDate);
			query.setTimestamp("modifiedOn", lastSyncDate);
			query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_TRUE);

			List<Long> returnValue = query.list();

			if (CollectionUtils.isEmpty(returnValue))
			{
				return 0;
			}
			else
			{
				return returnValue.get(0).intValue();
			}
		}
		catch (DataAccessResourceFailureException e)
		{
			log.info("Exception : "+e);
			e.printStackTrace();
		}
		catch (HibernateException e)
		{
			log.info("Exception : "+e);
			e.printStackTrace();
		}
		catch (IllegalStateException e)
		{
			log.info("Exception : "+e);
			e.printStackTrace();
		}
		
		return 0;
	}

	@Override
	public String getNewlyAddedEntitiesAfterSyncDate(Timestamp lastSyncDate, int pageNumber, int pageSize, String login)
	{
		final List<HashMap> productMapList = new LinkedList<HashMap>();

		Long userId = fetchUserId(login);

		log.info("userId: " + userId);
		
           /*Fetching product codes and setting page size on that*/
		
		StringBuilder queryForProdCode = new StringBuilder();
		queryForProdCode.append("select distinct(p.code) pcode ");
		createQueryForNewEntriesAfterSyncDate(queryForProdCode);
		
		if (log.isInfoEnabled())
		{
			log.info("in newly added queryForProdCode: " + queryForProdCode.toString());
		}

		SQLQuery query1 = getSession().createSQLQuery(queryForProdCode.toString());
		query1.setTimestamp("createdOn", lastSyncDate);
		query1.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);
		query1.setLong("userId", userId);

		query1.setFirstResult(pageNumber * pageSize);
		query1.setMaxResults(pageSize);

		List<String> productCodes = query1.addScalar("pcode", Hibernate.STRING).list();

		log.info("productCodes: " + productCodes.size());

		//Fetching data for products as per previously retrieved code
		
		StringBuilder queryForNewEntries = new StringBuilder();
		queryForNewEntries.append("select {p.*},{inv_view.*},{pp.*},{prm.*},{pvm.*} ");

		createQueryForNewEntriesAfterSyncDate(queryForNewEntries);
		 appendProductCodeWithIn(productCodes,queryForNewEntries);

		SQLQuery query = getSession().createSQLQuery(queryForNewEntries.toString());

		query.setTimestamp("createdOn", lastSyncDate);
		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);
		query.setLong("userId", userId);

		/*query.setFirstResult(pageNumber * pageSize);
		query.setMaxResults(pageSize);*/

		List<Object[]> list = query.addEntity("p", Product.class).addEntity("pp", ProductPrice.class)
				.addEntity("inv_view", ProductInventory.class).addEntity("prm", ProductRecommendation.class)
				.addEntity("pvm", ProductVariant.class).list();

		if (log.isInfoEnabled())
		{
			log.info("Query: " + queryForNewEntries.toString());
			log.info("List size: " + list.size());
		}

		/*if (CollectionUtils.isEmpty(list))
		{
			return null;
		}
		*/
		if (log.isDebugEnabled())
		{
			log.debug("list : " + ((list == null) ? "null" : list.size()));
		}

		HashMap<String, ProductWrapper> productWrapperCache = new HashMap<String, ProductWrapper>();

		for (Object[] obj : list)
		{
			Product currentProduct = (Product) obj[0];

			String currentProductCode = currentProduct.getCode();

			ProductWrapper currentProductWrapper = null;

			// add Product
			if (!productWrapperCache.containsKey(currentProductCode))
			{
				currentProductWrapper = new ProductWrapper();
				currentProductWrapper.setProduct(currentProduct);

				productWrapperCache.put(currentProductCode, currentProductWrapper);
			}
			else
			{
				currentProductWrapper = productWrapperCache.get(currentProductCode);
			}

			// add Inventory and Price
			if (obj[1] != null)
			{
				currentProductWrapper.setPrice((ProductPrice) obj[1]);
			}
			if (obj[2] != null)
			{
				currentProductWrapper.setInventory((ProductInventory) obj[2]);
			}

			// add variant product
			if (obj[4] != null)
			{
				ProductVariant currentProductVariant = (ProductVariant) obj[4];
				List<ProductVariant> variantList = currentProductWrapper.getVariant();

				if (currentProductVariant.getDeleteFlag().equalsIgnoreCase("F"))
				{
					if (!variantList.contains(currentProductVariant))
					{
						variantList.add(currentProductVariant);
					}
				}
			}

			if (obj[3] != null)
			{
				// add recommended product
				ProductRecommendation currentProductRecommendation = (ProductRecommendation) obj[3];
				List<ProductRecommendation> recommendedList = currentProductWrapper.getRecommended();

				if (currentProductRecommendation.getDeleteFlag().equalsIgnoreCase("F"))
				{
					if (!recommendedList.contains(currentProductRecommendation))
					{
						recommendedList.add(currentProductRecommendation);
					}
				}

			}
			if (log.isInfoEnabled())
			{
				log.info("Product Wrapper: " + currentProductWrapper.toString());
				log.info("Size of cache: " + productWrapperCache.size());
			}

		}

		if (log.isDebugEnabled())
		{
			log.debug("productWrapperCache : " + productWrapperCache);
		}

		formatWrapper(productMapList, productWrapperCache, "ADD");
		HashMap dataMap = IcatalogUtility.createResponseMessage(productMapList);

		String response = IcatalogUtility.createJSONFromMap(dataMap);

		return response;
	}

	@Override
	public String getModifiedEntitiesAfterSyncDate(Timestamp lastSyncDate, int pageNumber, int pageSize, String login)
	{
		final List<HashMap> productMapList = new LinkedList<HashMap>();
		Long userId = fetchUserId(login);

		log.info("userId: " + userId);
/*Fetching product codes and setting page size on that*/
		
		StringBuilder queryForProdCode = new StringBuilder();
		queryForProdCode.append("select distinct(p.code) pcode ");
		createQueryForModifiedEntries(queryForProdCode);
		
		if (log.isInfoEnabled())
		{
			log.info("in modified  queryForProdCode: " + queryForProdCode.toString());
		}

		SQLQuery query1 = getSession().createSQLQuery(queryForProdCode.toString());
		query1.setTimestamp("createdOn", lastSyncDate);
		query1.setTimestamp("modifiedOn", lastSyncDate);
		query1.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);
		query1.setLong("userId", userId);

		query1.setFirstResult(pageNumber * pageSize);
		query1.setMaxResults(pageSize);

		List<String> productCodes = query1.addScalar("pcode", Hibernate.STRING).list();

		log.info("productCodes: " + productCodes.size());

		//Fetching data for products as per previously retrieved code
		
		StringBuilder queryForModifiedEntries = new StringBuilder();

		queryForModifiedEntries.append("select {p.*},{pp.*},{inv_view.*},{prm.*}, {pvm.*} ");

		createQueryForModifiedEntries(queryForModifiedEntries);
		 appendProductCodeWithIn(productCodes,queryForModifiedEntries);
		 
		SQLQuery query = getSession().createSQLQuery(queryForModifiedEntries.toString());

		query.setTimestamp("createdOn", lastSyncDate);
		query.setTimestamp("modifiedOn", lastSyncDate);
		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_FALSE);
		query.setLong("userId", userId);

		/*query.setFirstResult(pageNumber * pageSize);
		query.setMaxResults(pageSize);*/

		List<Object[]> list = query.addEntity("p", Product.class).addEntity("pp", ProductPrice.class)
				.addEntity("inv_view", ProductInventory.class).addEntity("prm", ProductRecommendation.class)
				.addEntity("pvm", ProductVariant.class).list();

		if (log.isInfoEnabled())
		{
			log.info("List size: " + list.size());
		}

		/*	if (CollectionUtils.isEmpty(list))
			{
				return null;
			}*/

		if (log.isDebugEnabled())
		{
			log.debug("list : " + ((list == null) ? "null" : list.size()));
		}

		HashMap<String, ProductWrapper> productWrapperCache = new HashMap<String, ProductWrapper>();

		for (Object[] obj : list)
		{
			Product currentProduct = (Product) obj[0];

			String currentProductCode = currentProduct.getCode();

			ProductWrapper currentProductWrapper = null;

			// add Product
			if (!productWrapperCache.containsKey(currentProductCode))
			{
				currentProductWrapper = new ProductWrapper();
				currentProductWrapper.setProduct(currentProduct);

				productWrapperCache.put(currentProductCode, currentProductWrapper);
			}
			else
			{
				currentProductWrapper = productWrapperCache.get(currentProductCode);
			}

			// add Inventory and Price
			if (obj[2] != null)
			{
				currentProductWrapper.setInventory((ProductInventory) obj[2]);
			}
			if (obj[1] != null)
			{
				currentProductWrapper.setPrice((ProductPrice) obj[1]);
			}

			// add variant product
			if (obj[4] != null)
			{
				ProductVariant currentProductVariant = (ProductVariant) obj[4];
				List<ProductVariant> variantList = currentProductWrapper.getVariant();
				if (currentProductVariant.getDeleteFlag().equalsIgnoreCase("F"))
				{
					if (!variantList.contains(currentProductVariant))
					{
						variantList.add(currentProductVariant);
					}
				}
			}

			if (obj[3] != null)
			{
				// add recommended product
				ProductRecommendation currentProductRecommendation = (ProductRecommendation) obj[3];
				List<ProductRecommendation> recommendedList = currentProductWrapper.getRecommended();
				if (currentProductRecommendation.getDeleteFlag().equalsIgnoreCase("F"))
				{

					if (!recommendedList.contains(currentProductRecommendation))
					{
						recommendedList.add(currentProductRecommendation);
					}
				}
			}
			if (log.isInfoEnabled())
			{
				log.info("Product Wrapper: " + currentProductWrapper.toString());
				log.info("Size of cache: " + productWrapperCache.size());
			}

		}

		if (log.isDebugEnabled())
		{
			log.debug("productWrapperCache : " + productWrapperCache);
		}

		formatWrapper(productMapList, productWrapperCache, "MODIFY");
		HashMap dataMap = IcatalogUtility.createResponseMessage(productMapList);

		String response = IcatalogUtility.createJSONFromMap(dataMap);

		return response;
	}

	@Override
	public String getDeletedEntitiesAfterSyncDate(Timestamp lastSyncDate, int pageNumber, int pageSize)
	{
		final List<HashMap> productMapList = new LinkedList<HashMap>();
		StringBuilder queryForDeletedEntries = new StringBuilder();

		createQueryForDeletedEntries(queryForDeletedEntries);

		Query query = getSession().createQuery(queryForDeletedEntries.toString());

		query.setTimestamp("createdOn", lastSyncDate);
		query.setTimestamp("modifiedOn", lastSyncDate);
		query.setString("deleteFlag", GenericDataBeanDAO.DELETE_FLAG_TRUE);

		query.setFirstResult(pageNumber * pageSize);
		query.setMaxResults(pageSize);

		List<Product> list = query.list();

		if (log.isInfoEnabled())
		{
			log.info("List size: " + list.size());
		}

		/*	if (CollectionUtils.isEmpty(list))
			{
				return null;
			}
		*/
		if (log.isDebugEnabled())
		{
			log.debug("list : " + ((list == null) ? "null" : list.size()));
		}

		HashMap<String, ProductWrapper> productWrapperCache = new HashMap<String, ProductWrapper>();

		for (Product currentProduct : list)
		{

			String currentProductCode = currentProduct.getCode();

			ProductWrapper currentProductWrapper = null;

			// add Product
			if (!productWrapperCache.containsKey(currentProductCode))
			{
				currentProductWrapper = new ProductWrapper();
				currentProductWrapper.setProduct(currentProduct);

				productWrapperCache.put(currentProductCode, currentProductWrapper);
			}

			if (log.isInfoEnabled())
			{
				log.info("Product Wrapper: " + currentProductWrapper.toString());
				log.info("Size of cache: " + productWrapperCache.size());
			}

		}

		if (log.isDebugEnabled())
		{
			log.debug("productWrapperCache : " + productWrapperCache);
		}

		formatWrapper(productMapList, productWrapperCache, "DELETE");
		HashMap dataMap = IcatalogUtility.createResponseMessage(productMapList);

		String response = IcatalogUtility.createJSONFromMap(dataMap);

		return response;
	}

	public List<ProductWrapper> customSearch(Product searchProduct, Long productCategoryId)
	{
		System.out.println("-----------CustomSearch--------------------");

		StringBuilder searchQueryBuilder = new StringBuilder(" select {p.*},{pp.*},{pi.*} ");

		searchQueryBuilder = productListQueryBuilder(searchQueryBuilder);

		ProductWrapper productWrapper = null;

		List<ProductWrapper> productList = new ArrayList<ProductWrapper>();

		boolean isFirstClause = false;

		String searchTags = searchProduct.getSearchTags();
		String brand = searchProduct.getBrand();
		String department = searchProduct.getDepartment();
		String subdepartment = searchProduct.getSubDepartment();
		String productclass = searchProduct.getProductClass();
		String subClass = searchProduct.getSubClass();
		String style = searchProduct.getStyle();
		Long productCategorySearch = productCategoryId;
		String offer = searchProduct.getOfferFlag();
		String gift = searchProduct.getGiftFlag();

		log.info("");

		if (null != searchTags)
		{
			if (isFirstClause)
			{
				searchQueryBuilder.append(" where ");
				isFirstClause = false;
			}
			else
			{
				searchQueryBuilder.append(" and ");
			}

			searchQueryBuilder
					.append("  ( p.search_tags like :searchTags or p.name like :searchTags or p.code like :searchTags) ");
			isFirstClause = false;
		}

		if (null != department)
		{
			if (isFirstClause)
			{
				searchQueryBuilder.append(" where ");
				isFirstClause = false;
			}
			else
			{
				searchQueryBuilder.append(" and ");
			}

			searchQueryBuilder.append(" p.department like :department ");
		}

		if (null != brand)
		{
			if (isFirstClause)
			{
				searchQueryBuilder.append(" where ");
				isFirstClause = false;
			}
			else
			{
				searchQueryBuilder.append(" and ");
			}

			searchQueryBuilder.append(" p.brand like :brand ");
		}

		if (null != subdepartment)
		{
			if (isFirstClause)
			{
				searchQueryBuilder.append(" where ");
				isFirstClause = false;
			}
			else
			{
				searchQueryBuilder.append(" and ");
			}

			searchQueryBuilder.append(" p.sub_department like :subdepartment ");
		}

		if (null != productclass)
		{
			if (isFirstClause)
			{
				searchQueryBuilder.append(" where ");
				isFirstClause = false;
			}
			else
			{
				searchQueryBuilder.append(" and ");
			}

			searchQueryBuilder.append(" p.class like :productclass ");
		}

		if (null != subClass)
		{
			if (isFirstClause)
			{
				searchQueryBuilder.append(" where ");
				isFirstClause = false;
			}
			else
			{
				searchQueryBuilder.append(" and ");
			}

			searchQueryBuilder.append(" p.sub_class like :subClass ");
		}

		if (null != style)
		{
			if (isFirstClause)
			{
				searchQueryBuilder.append(" where ");
				isFirstClause = false;
			}
			else
			{
				searchQueryBuilder.append(" and ");
			}

			searchQueryBuilder.append(" p.style like :style ");
		}

		if (null != offer)
		{
			if (isFirstClause)
			{
				searchQueryBuilder.append(" where ");
				isFirstClause = false;
			}
			else
			{
				searchQueryBuilder.append(" and ");
			}

			searchQueryBuilder.append(" p.offer_flag like :offer ");
		}

		if (null != gift)
		{
			if (isFirstClause)
			{
				searchQueryBuilder.append(" where ");
				isFirstClause = false;
			}
			else
			{
				searchQueryBuilder.append(" and ");
			}

			searchQueryBuilder.append(" p.gift_flag like :gift ");
		}

		if (isFirstClause)
		{
			searchQueryBuilder.append(" where ");
			isFirstClause = false;
		}
		else
		{
			searchQueryBuilder.append(" and ");
		}
		searchQueryBuilder.append(" p.category_id=:productCategorySearch ");

		SQLQuery query = getSession().createSQLQuery(searchQueryBuilder.toString());

		if (null != searchTags)
		{
			query.setParameter("searchTags", "%" + searchTags + "%");
		}

		if (null != brand)
		{
			query.setParameter("brand", "" + brand + "%");
		}

		if (null != department)
		{
			query.setParameter("department", "" + department + "%");
		}

		if (null != subdepartment)
		{
			query.setParameter("subdepartment", "" + subdepartment + "%");
		}

		if (null != productclass)
		{
			query.setParameter("productclass", "" + productclass + "%");
		}

		if (null != subClass)
		{
			query.setParameter("subClass", "" + subClass + "%");
		}

		if (null != style)
		{
			query.setParameter("style", "" + style + "%");
		}

		if (null != offer)
		{
			query.setParameter("offer", "" + offer + "%");
		}

		if (null != gift)
		{
			query.setParameter("gift", "" + gift + "%");
		}

		if (productCategorySearch != 0)
		{
			query.setParameter("productCategorySearch", productCategorySearch);
		}

		log.info("----query for search-----::: " + query);

		List<Object[]> resultList = query.addEntity("p", Product.class).addEntity("pp", ProductPrice.class)
				.addEntity("pi", ProductInventory.class).list();

		log.info("----resultList size is----:::" + resultList.size());

		for (Object[] obj : resultList)
		{

			Product currentproduct = (Product) obj[0];
			ProductPrice currentProductPrice = (ProductPrice) obj[1];
			ProductInventory currenProductInventory = (ProductInventory) obj[2];

			productWrapper = new ProductWrapper();

			productWrapper.setProduct(currentproduct);
			productWrapper.setPrice(currentProductPrice);
			productWrapper.setInventory(currenProductInventory);

			productList.add(productWrapper);

		}

		log.info("------In Custom Search----------And Final Product List----------------:::" + productList);
		return productList;
	}

	public List<ProductWrapper> searchWrapper(ProductWrapper productWrap)
	{
		log.info("-----searchWrapper------");

		ProductWrapper productWrapper = null;
		List<ProductWrapper> productList = new ArrayList<ProductWrapper>();

		StringBuilder searchQueryBuilder = new StringBuilder(" select {p.*},{pp.*},{pi.*} ");

		searchQueryBuilder = productListQueryBuilder(searchQueryBuilder);

		SQLQuery query = getSession().createSQLQuery(searchQueryBuilder.toString());

		List<Object[]> resultList = query.addEntity("p", Product.class).addEntity("pp", ProductPrice.class)
				.addEntity("pi", ProductInventory.class).list();

		log.info("----resultList size is----:::" + resultList.size());

		for (Object[] obj : resultList)
		{

			Product currentproduct = (Product) obj[0];
			ProductPrice currentProductPrice = (ProductPrice) obj[1];
			ProductInventory currenProductInventory = (ProductInventory) obj[2];

			productWrapper = new ProductWrapper();

			productWrapper.setProduct(currentproduct);
			productWrapper.setPrice(currentProductPrice);
			productWrapper.setInventory(currenProductInventory);

			productList.add(productWrapper);

		}

		return productList;
	}

	public List<ProductWrapper> searchWrapperDetails(ProductWrapper productWrap, long id)
	{
		log.info("-----searchWrapperDetails------");

		long proid = id;
		ProductWrapper productWrapper = null;
		List<ProductWrapper> productList = new ArrayList<ProductWrapper>();

		StringBuilder searchQueryBuilder = new StringBuilder(" select {p.*},{pp.*},{pi.*} ");

		searchQueryBuilder = productListQueryBuilder(searchQueryBuilder);

		searchQueryBuilder.append(" and p.id=:proid ");

		SQLQuery query = getSession().createSQLQuery(searchQueryBuilder.toString());

		if (proid != 0)
		{
			query.setParameter("proid", proid);
		}

		List<Object[]> resultList = query.addEntity("p", Product.class).addEntity("pp", ProductPrice.class)
				.addEntity("pi", ProductInventory.class).list();

		log.info("----resultList size is----:::" + resultList.size());

		for (Object[] obj : resultList)
		{

			Product currentproduct = (Product) obj[0];
			ProductPrice currentProductPrice = (ProductPrice) obj[1];
			ProductInventory currenProductInventory = (ProductInventory) obj[2];

			productWrapper = new ProductWrapper();

			productWrapper.setProduct(currentproduct);
			productWrapper.setPrice(currentProductPrice);
			productWrapper.setInventory(currenProductInventory);

			productList.add(productWrapper);

		}
		log.info("------------In searchWrapperDetails---------");
		return productList;
	}

	@Override
	public List<ProductWrapper> productRecommendList(ProductWrapper product, long id)
	{
		log.info("-----productRecommendList------");

		long proid = id;
		ProductWrapper productWrapper = null;
		List<ProductWrapper> productRecommendList = new ArrayList<ProductWrapper>();

		StringBuilder searchQueryBuilder = new StringBuilder(" select {p.*},{pp.*},{pi.*} ");

		searchQueryBuilder.append(" from product p ");
		searchQueryBuilder.append(" join product_category pc on pc.id=p.category_id ");
		searchQueryBuilder.append(" left join product_price pp on pp.product_id=p.id ");
		searchQueryBuilder.append(" left join product_inventory pi on pi.product_id=p.id ");
		searchQueryBuilder.append(" join product_recommendation_mapping pr on pr.recommended_product_id=p.id ");
		searchQueryBuilder.append(" where p.delete_flag='F' ");
		searchQueryBuilder.append(" and pc.delete_flag='F' ");
		searchQueryBuilder.append(" and pr.delete_flag='F'");

		searchQueryBuilder.append(" and pr.product_id=:proid ");

		SQLQuery query = getSession().createSQLQuery(searchQueryBuilder.toString());

		if (proid != 0)
		{
			query.setParameter("proid", proid);
		}

		log.info("----query for search-----::: " + query);

		List<Object[]> resultList = query.addEntity("p", Product.class).addEntity("pp", ProductPrice.class)
				.addEntity("pi", ProductInventory.class).list();

		log.info("----resultList size is----:::" + resultList.size());
		log.info("----resultList is----:::" + resultList);

		for (Object[] obj : resultList)
		{

			Product currentproduct = (Product) obj[0];

			productWrapper = new ProductWrapper();

			productWrapper.setProduct(currentproduct);

			productRecommendList.add(productWrapper);

		}

		log.info("------------In productRecommendList---------with ProductList:::" + resultList);
		return productRecommendList;
	}

	@Override
	public ProductWrapper fetchProductwithPrice(String code)
	{
		String retrievalQuery = "select *  from product p left join product_price pp on p.id=pp.product_id where p.code=:code";
		SQLQuery query = getSession().createSQLQuery(retrievalQuery);
		query.setString("code", code);
		ProductWrapper productWrapper = new ProductWrapper();

		List<Object[]> returnValue = query.addEntity("p", Product.class).addEntity("pp", ProductPrice.class).list();

		for (Object[] obj : returnValue)
		{
			Product prod = (Product) obj[0];
			ProductPrice prodPrice = (ProductPrice) obj[1];

			productWrapper.setProduct(prod);
			productWrapper.setPrice(prodPrice);
		}
		return productWrapper;
	}

}
