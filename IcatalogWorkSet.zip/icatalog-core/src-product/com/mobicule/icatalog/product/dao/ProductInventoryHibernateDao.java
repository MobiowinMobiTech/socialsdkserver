package com.mobicule.icatalog.product.dao;

import com.mobicule.component.system.db.dao.GenericDataBeanHibernateDAO;
import com.mobicule.icatalog.product.bean.ProductInventory;

public class ProductInventoryHibernateDao extends GenericDataBeanHibernateDAO<ProductInventory> implements ProductInventoryDao
{

}
