package com.mobicule.icatalog.product.dao;

import java.util.List;

import com.mobicule.component.system.db.dao.GenericDataBeanDAO;
import com.mobicule.icatalog.common.dao.SyncDao;
import com.mobicule.icatalog.product.bean.ProductCategory;

public interface ProductCategoryDao extends GenericDataBeanDAO<ProductCategory>, SyncDao
{

	List<ProductCategory> searchName(String name);

	List<ProductCategory> doCustomSearch(ProductCategory productCategory);

}
