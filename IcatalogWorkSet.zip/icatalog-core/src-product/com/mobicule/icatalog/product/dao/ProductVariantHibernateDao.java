package com.mobicule.icatalog.product.dao;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.hibernate.SQLQuery;

import com.mobicule.component.system.db.dao.GenericDataBeanHibernateDAO;
import com.mobicule.icatalog.product.bean.Product;
import com.mobicule.icatalog.product.bean.ProductInventory;
import com.mobicule.icatalog.product.bean.ProductPrice;
import com.mobicule.icatalog.product.bean.ProductVariant;
import com.mobicule.icatalog.product.bean.ProductWrapper;

public class ProductVariantHibernateDao extends GenericDataBeanHibernateDAO<ProductVariant> implements
		ProductVariantDao
{
	private Log log = LogFactory.getLog(this.getClass());

	@Override
	public List<ProductWrapper> productVariantList(ProductWrapper product, long id)
	{
		log.info("-----productVariantList------");

		long proid = id;
		ProductWrapper productWrapper = null;
		List<ProductWrapper> productVariantList = new ArrayList<ProductWrapper>();

		StringBuilder searchQueryBuilder = new StringBuilder(" select {p.*},{pp.*},{pi.*} ");

		searchQueryBuilder.append(" from product p ");
		searchQueryBuilder.append(" join product_category pc on pc.id=p.category_id ");
		searchQueryBuilder.append(" left join product_price pp on pp.product_id=p.id ");
		searchQueryBuilder.append(" left join product_inventory pi on pi.product_id=p.id ");
		searchQueryBuilder.append(" join product_variant_mapping pv on  pv.variant_product_id=p.id ");
		searchQueryBuilder.append(" where p.delete_flag='F' ");
		searchQueryBuilder.append(" and pc.delete_flag='F' ");
		searchQueryBuilder.append(" and pv.delete_flag='F'");

		searchQueryBuilder.append(" and pv.product_id=:proid ");

		SQLQuery query = getSession().createSQLQuery(searchQueryBuilder.toString());

		if (proid != 0)
		{
			query.setParameter("proid", proid);
		}

		log.info("----query for search-----::: " + query);

		List<Object[]> resultList = query.addEntity("p", Product.class).addEntity("pp", ProductPrice.class)
				.addEntity("pi", ProductInventory.class).list();

		log.info("----resultList size is----:::" + resultList.size());
		log.info("----resultList is----:::" + resultList);

		for (Object[] obj : resultList)
		{

			Product currentproduct = (Product) obj[0];

			productWrapper = new ProductWrapper();

			productWrapper.setProduct(currentproduct);

			productVariantList.add(productWrapper);

		}

		log.info("------------productVariantList---------with VariantList:::" + resultList);
		return productVariantList;
	}

	@Override
	public List<Product> doProductVariantListsearch(Product searchProduct)
	{

		log.info("-----doProductVariantListsearch------");

		StringBuilder searchQueryBuilder = new StringBuilder(
				"select distinct p from Product p,ProductCategory pc where p.categoryId=pc.id and pc.deleteFlag='F' and p.deleteFlag='F'");

		boolean isFirstClause = true;

		String searchTags = searchProduct.getSearchTags();

		if (null != searchTags)
		{
			searchQueryBuilder.append(" and");

			searchQueryBuilder
					.append(" ( p.searchTags like :searchTags or p.name like :searchTags or p.code like :searchTags or p.style like :searchTags) ");
		}

		Query query = getSession().createQuery(searchQueryBuilder.toString());

		if (null != searchTags)
		{
			query.setParameter("searchTags", "" + searchTags + "%");
		}

		log.info("----query for searchProduct-----::: " + query);

		List<Product> productList = query.list();

		log.info("----resultList size is----:::" + productList.size());

		log.info("----------------Product List----------------:::" + productList);
		return productList;
	}

	@Override
	public List<ProductVariant> doProductVariantsearch(ProductVariant searchProductVariant)
	{

		log.info("-----doProductVariantListsearch------");

		StringBuilder searchQueryBuilder = new StringBuilder(
				"select pv from ProductVariant pv,ProductCategory pc,Product p");

		boolean isFirstClause = true;

		Long productId = searchProductVariant.getProductId();

		if (null != productId)
		{
			if (isFirstClause)
			{
				searchQueryBuilder.append(" where ");
				isFirstClause = false;
			}
			else
			{
				searchQueryBuilder.append(" and");
			}

			searchQueryBuilder.append(" pv.variantId=p.id and p.categoryId=pc.id "
					+ " and pc.deleteFlag='F' and p.deleteFlag='F' and pv.deleteFlag='F'");
		}
		searchQueryBuilder.append(" and pv.productId =:productId ");

		Query query = getSession().createQuery(searchQueryBuilder.toString());

		if (null != productId)
		{
			query.setParameter("productId", productId);
		}

		log.info("----query for searchProductVariant-----::: " + query);

		List<ProductVariant> productVariantList = query.list();

		log.info("----resultList size is----:::" + productVariantList.size());

		log.info("----------------Product List----------------:::" + productVariantList);
		return productVariantList;
	}

	public int softDeleteVariants(ProductVariant productVariant)
	{

		log.info("-----SoftDeleteVariants------");

		StringBuilder searchQueryBuilder = new StringBuilder(" update ProductVariant set deleteFlag='T' ");

		Long productId = productVariant.getProductId();
		Long productVariantId = productVariant.getVariantId();

		if (null != productId)
		{
			searchQueryBuilder.append(" where productId = :productId ");
		}
		if (null != productVariantId)
		{
			searchQueryBuilder.append(" and variantId = :productVariantId ");
		}

		Query query = getSession().createQuery(searchQueryBuilder.toString());

		if (null != productId)
		{
			query.setParameter("productId", productId);
		}

		if (null != productId)
		{
			query.setParameter("productVariantId", productVariantId);
		}

		log.info("----query for Soft Delete Product Variant-----::: " + query);

		 int i = query.executeUpdate();
		
		 return i;
		
		
	}

}
