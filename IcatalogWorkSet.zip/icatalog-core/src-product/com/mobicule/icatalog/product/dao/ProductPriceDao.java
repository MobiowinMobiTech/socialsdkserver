package com.mobicule.icatalog.product.dao;

import java.util.List;

import com.mobicule.component.system.db.dao.GenericDataBeanDAO;
import com.mobicule.icatalog.product.bean.ProductPrice;

public interface ProductPriceDao extends GenericDataBeanDAO<ProductPrice>
{

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @param prodPrice
	 * @return
	 *
	 * @author shalini
	 * @createdOn 30-Apr-2012
	 * @modifiedOn 30-Apr-2012 
	 * 
	 */
	List<ProductPrice> searchBean(ProductPrice prodPrice);

}
