package com.mobicule.icatalog.product.dao;

import java.util.List;

import com.mobicule.component.system.db.dao.GenericDataBeanDAO;
import com.mobicule.icatalog.product.bean.Product;
import com.mobicule.icatalog.product.bean.ProductVariant;
import com.mobicule.icatalog.product.bean.ProductWrapper;

public interface ProductVariantDao extends GenericDataBeanDAO<ProductVariant>
{
	public List<ProductWrapper> productVariantList(ProductWrapper productWrapper,long id);
	
	public List<Product> doProductVariantListsearch(Product searchProduct);
	
	public List<ProductVariant> doProductVariantsearch(ProductVariant searchProductVariant);
	
	public int softDeleteVariants(ProductVariant productVariant);
}
