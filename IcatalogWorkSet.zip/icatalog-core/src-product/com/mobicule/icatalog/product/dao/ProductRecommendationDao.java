package com.mobicule.icatalog.product.dao;

import java.util.List;

import com.mobicule.component.system.db.dao.GenericDataBeanDAO;
import com.mobicule.icatalog.product.bean.Product;
import com.mobicule.icatalog.product.bean.ProductRecommendation;

public interface ProductRecommendationDao extends GenericDataBeanDAO<ProductRecommendation>
{
	
	public List<Product> doProductListsearch(Product searchProduct);
	public List<ProductRecommendation> doProductRecomendationsearch(ProductRecommendation searchProductRecomendation);
}
