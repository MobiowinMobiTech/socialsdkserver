package com.mobicule.icatalog.product.dao;

import com.mobicule.component.system.db.dao.GenericDataBeanDAO;
import com.mobicule.icatalog.product.bean.ProductInventory;

public interface ProductInventoryDao extends GenericDataBeanDAO<ProductInventory>
{

}
