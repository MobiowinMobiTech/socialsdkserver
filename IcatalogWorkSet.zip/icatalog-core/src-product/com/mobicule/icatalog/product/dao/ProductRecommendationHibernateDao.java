package com.mobicule.icatalog.product.dao;


import java.util.List;

import org.hibernate.Query;

import com.mobicule.component.system.db.dao.GenericDataBeanHibernateDAO;
import com.mobicule.icatalog.product.bean.Product;


import com.mobicule.icatalog.product.bean.ProductRecommendation;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class ProductRecommendationHibernateDao extends GenericDataBeanHibernateDAO<ProductRecommendation> implements ProductRecommendationDao
{
	
	private Log log = LogFactory.getLog(this.getClass());
	
	
	@Override
	public List<Product> doProductListsearch(Product searchProduct)
	{
		
		log.info("-----doProductListsearch------");

		StringBuilder searchQueryBuilder = new StringBuilder("select p from Product p,ProductCategory pc where p.categoryId=pc.id and pc.deleteFlag='F' and p.deleteFlag='F'");

		//Product product = null;

		boolean isFirstClause = false;

		String searchTags = searchProduct.getSearchTags();
		String brand = searchProduct.getBrand();
		String department = searchProduct.getDepartment();
		String subdepartment = searchProduct.getSubDepartment();
		String productclass = searchProduct.getProductClass();
		String subClass = searchProduct.getSubClass();

		log.info("searchTags , brand , department , subdepartment , class , subclass "+searchTags+" , "+brand+" , "+department+" , "+subdepartment+" , "+productclass+" , "+subClass);

		if (null != searchTags)
		{
			searchQueryBuilder.append(" and ");

			searchQueryBuilder
					.append(" ( p.searchTags like :searchTags or p.name like :searchTags or p.code like :searchTags or p.style like :searchTags) ");
		}

		if (null != department)
		{
			if (isFirstClause)
			{
				searchQueryBuilder.append(" where ");
				isFirstClause = false;
			}
			else
			{
				searchQueryBuilder.append(" and ");
			}

			searchQueryBuilder.append(" p.department =:department ");
		}

		if (null != brand)
		{
			if (isFirstClause)
			{
				searchQueryBuilder.append(" where ");
				isFirstClause = false;
			}
			else
			{
				searchQueryBuilder.append(" and ");
			}

			searchQueryBuilder.append(" p.brand like :brand ");
		}

		if (null != subdepartment)
		{
			if (isFirstClause)
			{
				searchQueryBuilder.append(" where ");
				isFirstClause = false;
			}
			else
			{
				searchQueryBuilder.append(" and ");
			}

			searchQueryBuilder.append(" p.subDepartment like :subdepartment ");
		}

		if (null != productclass)
		{
			if (isFirstClause)
			{
				searchQueryBuilder.append(" where ");
				isFirstClause = false;
			}
			else
			{
				searchQueryBuilder.append(" and ");
			}

			searchQueryBuilder.append(" p.productClass like :productclass ");
		}

		if (null != subClass)
		{
			if (isFirstClause)
			{
				searchQueryBuilder.append(" where ");
				isFirstClause = false;
			}
			else
			{
				searchQueryBuilder.append(" and ");
			}

			searchQueryBuilder.append(" p.subClass like :subClass ");
		}
		
		Query query = getSession().createQuery(searchQueryBuilder.toString());

		if (null != searchTags)
		{
			query.setParameter("searchTags", "" + searchTags + "%");
		}

		if (null != brand)
		{
			query.setParameter("brand", "" + brand + "%");
		}

		if (null != department)
		{
			query.setString("department",department);
		}

		if (null != subdepartment)
		{
			query.setParameter("subdepartment", "" + subdepartment + "%");
		}

		if (null != productclass)
		{
			query.setParameter("productclass", "" + productclass + "%");
		}

		if (null != subClass)
		{
			query.setParameter("subClass", "" + subClass + "%");
		}

		log.info("----query for searchProduct-----::: " + query);

		List<Product> productList = query.list();
		

		log.info("----resultList size is----:::" + productList.size());

		

		log.info("----------------Product List----------------:::" + productList);
		return productList;
	}


@Override
public List<ProductRecommendation> doProductRecomendationsearch(ProductRecommendation searchProductRecomendation)
{
	
	log.info("-----doRecommendedProductListsearch------");

	StringBuilder searchQueryBuilder = new StringBuilder("select pr from ProductRecommendation pr,ProductCategory pc,Product p");

	//Product product = null;

	boolean isFirstClause = true;

	Long productId = searchProductRecomendation.getProductId();
	

	if (null != productId)
	{
		if (isFirstClause)
		{
			searchQueryBuilder.append(" where ");
			isFirstClause = false;
		}
		else
		{
			searchQueryBuilder.append(" and");
		}

		searchQueryBuilder
		.append(" pr.recommendId=p.id and p.categoryId=pc.id " +
				" and pc.deleteFlag='F' and p.deleteFlag='F' and pr.deleteFlag='F'");
	}
	searchQueryBuilder
	.append(" and pr.productId =:productId ");
	
	
	Query query = getSession().createQuery(searchQueryBuilder.toString());

	if (null != productId)
	{
		query.setParameter("productId",productId);
	}


	log.info("----query for searchProductRecomendation-----::: " + query);

	List<ProductRecommendation> productRecommendationList = query.list();
	

	log.info("----resultList size is----:::" + productRecommendationList.size());

	

	log.info("----------------Product List----------------:::" + productRecommendationList);
	return productRecommendationList;
}
}
