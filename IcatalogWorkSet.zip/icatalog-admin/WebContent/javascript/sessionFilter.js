function sessionFilter() {
	
	sessionStorage.clear();
}