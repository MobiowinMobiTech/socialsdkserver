package com.mobicule.icatalog.user.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.management.RuntimeErrorException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.CollectionUtils;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.mobicule.icatalog.admin.common.CommonServices;
import com.mobicule.icatalog.appconfig.service.AppConfigService;
import com.mobicule.icatalog.systemuser.bean.Profile;
import com.mobicule.icatalog.systemuser.bean.SystemUser;
import com.mobicule.icatalog.systemuser.bean.Territory;
import com.mobicule.icatalog.systemuser.bean.UserTerritoryMapping;
import com.mobicule.icatalog.systemuser.service.ActivityService;
import com.mobicule.icatalog.systemuser.service.ProfileService;
import com.mobicule.icatalog.systemuser.service.RoleService;
import com.mobicule.icatalog.systemuser.service.SystemUserService;
import com.mobicule.icatalog.systemuser.service.TerritoryService;
import com.mobicule.icatalog.systemuser.service.UserTerritoryMappingService;

public class UserController extends MultiActionController
{

	private Log log = LogFactory.getLog(this.getClass());

	private RoleService roleService;

	private ProfileService profileService;

	private ActivityService activityService;

	private SystemUserService systemUserService;

	private TerritoryService territoryService;

	private UserTerritoryMappingService userTerritoryMappingService;

	private AppConfigService appConfigService;

	public AppConfigService getAppConfigService()
	{
		return appConfigService;
	}

	public void setAppConfigService(AppConfigService appConfigService)
	{
		this.appConfigService = appConfigService;
	}

	public SystemUserService getSystemUserService()
	{
		return systemUserService;
	}

	public void setSystemUserService(SystemUserService systemUserService)
	{
		this.systemUserService = systemUserService;
	}

	public RoleService getRoleService()
	{
		return roleService;
	}

	public void setRoleService(RoleService roleService)
	{
		this.roleService = roleService;
	}

	public ProfileService getProfileService()
	{
		return profileService;
	}

	public void setProfileService(ProfileService profileService)
	{
		this.profileService = profileService;
	}

	public ActivityService getActivityService()
	{
		return activityService;
	}

	public void setActivityService(ActivityService activityService)
	{
		this.activityService = activityService;
	}

	public TerritoryService getTerritoryService()
	{
		return territoryService;
	}

	public void setTerritoryService(TerritoryService territoryService)
	{
		this.territoryService = territoryService;
	}

	public UserTerritoryMappingService getUserTerritoryMappingService()
	{
		return userTerritoryMappingService;
	}

	public void setUserTerritoryMappingService(UserTerritoryMappingService userTerritoryMappingService)
	{
		this.userTerritoryMappingService = userTerritoryMappingService;
	}

	public ModelAndView addSystemUser(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		log.info("---------In UserController / addUser()----------");

		SystemUser systemUser = getSystemUserBean(request, null);
		try
		{
			HttpSession session = request.getSession();
			SystemUser sysAdmin = (SystemUser) session.getAttribute("systemUser");
			systemUser.setCreatedBy(sysAdmin.getId());
			systemUser.setModifiedBy(sysAdmin.getId());
			systemUserService.add(systemUser);
		}
		catch (Exception e)
		{
			throw new RuntimeErrorException(null);
		}

		systemUser = fetchExistingSystemUser(request.getParameter("login"));

		try
		{
			boolean status = addTerritoryUserMapping(request, systemUser);
		}
		catch (Exception e)
		{
			throw new RuntimeErrorException(null);
		}

		return getSystemUserList(request, response);
	}

	private boolean addTerritoryUserMapping(HttpServletRequest request, SystemUser systemUser)
	{
		boolean status = false;
		//for territory add

		if (log.isInfoEnabled())
		{
			log.info("--- after all values were caught  ---");
		}
		String[] territoryId = request.getParameterValues("territory");
		if (null != territoryId)
		{
			log.info("---size of territory ID ---" + territoryId.length);
			log.info("---value of territory ID ---" + territoryId.toString());
			int idSize = territoryId.length;
			log.info("---after empty mapping bean instatiation ---");
			HttpSession session;
			session = request.getSession();
			SystemUser admin = (SystemUser) session.getAttribute("systemUser");

			List<UserTerritoryMapping> systemUserterritoryList = null;
			log.info("----**********-------When Empty systemUserTerritortList Instantiated-------**********--------"
					+ systemUserterritoryList);
			systemUserterritoryList = userTerritoryMappingService.doUserTerritorySearch(systemUser.getId());
			log.info("----**********-------systemUserterritoryList-------**********--------" + systemUserterritoryList);
			if (!systemUserterritoryList.isEmpty())
			{
				log.info("======systemUserterritoryList is not empty surprising---!!!!!!!========");
			}
			else
			{
				log.info("======systemUserterritoryList is empty in else========");
			}
			HashMap<Long, UserTerritoryMapping> systemUserterritoryMap = new HashMap<Long, UserTerritoryMapping>();

			List<Long> territoryIdList = new ArrayList<Long>();
			HashMap<Long, UserTerritoryMapping> territoryIdMap = new HashMap<Long, UserTerritoryMapping>();

			// List & Map for UserTerritoryMapping From the database(Entire table) 
			UserTerritoryMapping userTM = new UserTerritoryMapping();
			List<UserTerritoryMapping> userTerritoryFullList = userTerritoryMappingService.doCustomSearch(userTM);
			HashMap<Long, UserTerritoryMapping> userTerritoryFullMap = new HashMap<Long, UserTerritoryMapping>();
			int fullListSize = 0;
			if (!userTerritoryFullList.isEmpty())
			{
				log.info("------=========Full list is not empty------=========" + userTerritoryFullList);
				fullListSize = userTerritoryFullList.size();
				for (int i = 0; i < fullListSize; i++)
				{
					userTerritoryFullMap.put(userTerritoryFullList.get(i).getUserCode(), userTerritoryFullList.get(i));
				}
			}

			UserTerritoryMapping userTerritoryMap = null;
			int systemUserListSize = 0;
			if (!systemUserterritoryList.isEmpty())
			{
				systemUserListSize = systemUserterritoryList.size();

				for (int i = 0; i < systemUserListSize; i++)
				{
					log.info("---------*****------terri map-------*****-------" + systemUserterritoryMap);
					systemUserterritoryMap.put(systemUserterritoryList.get(i).getTerritoryCode(),
							systemUserterritoryList.get(i));
				}
			}

			for (int i = 0; i < idSize; i++)
			{
				territoryIdMap.put(Long.parseLong(territoryId[i]), new UserTerritoryMapping());
				log.info("-----*****-----territoryId to be added----*****-------" + Long.parseLong(territoryId[i]));
				log.info("---*****-------territoryIdMap when being populated--------********--------" + territoryIdMap);
			}
			for (int i = 0; i < idSize; i++)
			{
				territoryIdList.add(Long.parseLong(territoryId[i]));
				log.info("territoryIdList" + territoryIdList);
			}
			for (int i = 0; i < idSize; i++)
			{
				if (!systemUserterritoryList.isEmpty())
				{
					log.info("----------systemUserterritoryList is not empty--------------");
					log.info("systemUser map" + systemUserterritoryMap);
					log.info("territoryId where i=" + i + "--->" + territoryId[i]);
					log.info("systemUser map entity where i=" + i + "--->"
							+ systemUserterritoryMap.get(Long.parseLong(territoryId[i])));
					if (!systemUserterritoryMap.containsKey(Long.parseLong(territoryId[i])))
					{
						log.info("------------user not matched so adding----------------");
						userTerritoryMap = new UserTerritoryMapping();
						userTerritoryMap.setCreatedBy(admin.getId());
						userTerritoryMap.setModifiedBy(admin.getId());
						userTerritoryMap.setTerritoryCode(Long.parseLong(territoryId[i]));
						userTerritoryMap.setUserCode(systemUser.getId());
						userTerritoryMappingService.add(userTerritoryMap);
					}
				}
				else
				{
					log.info("------------in else since list is empty-----------------");
					userTerritoryMap = new UserTerritoryMapping();
					userTerritoryMap.setCreatedBy(admin.getId());
					userTerritoryMap.setModifiedBy(admin.getId());
					userTerritoryMap.setTerritoryCode(Long.parseLong(territoryId[i]));
					userTerritoryMap.setUserCode(systemUser.getId());
					userTerritoryMappingService.add(userTerritoryMap);
				}
			}
			if (!systemUserterritoryList.isEmpty())
			{
				log.info("---------In remove user since list is not empty---------------");
				for (int i = 0; i < systemUserListSize; i++)
				{
					log.info("terri map" + territoryIdMap);
					log.info("-----terri in sysUser-----" + systemUserterritoryList.get(i));
					log.info("------terri map contains-------"
							+ territoryIdMap.containsKey(systemUserterritoryList.get(i)));
					if (!territoryIdMap.containsKey(systemUserterritoryList.get(i).getTerritoryCode()))
					{
						log.info("---------In remove user since user not found---------------");
						userTerritoryMap = new UserTerritoryMapping();
						log.info("------ID OF USERTERRITORYLIST---------" + systemUserterritoryList.get(i).getId());
						userTerritoryMap.setId(systemUserterritoryList.get(i).getId());

						SystemUser sysAdmin = (SystemUser) session.getAttribute("systemUser");
						userTerritoryMap.setModifiedBy(sysAdmin.getId());
						userTerritoryMappingService.delete(userTerritoryMap);
					}
				}
			}

			return status;
		}

		return status;
	}

	private SystemUser getSystemUserBean(HttpServletRequest request, SystemUser existingSystemUser)
	{
		log.info("-------------- in getUserBean Method  -------------");

		if (existingSystemUser == null)
		{
			existingSystemUser = new SystemUser();
		}

		String login = request.getParameter("login");
		String password = request.getParameter("password");
		String firstName = request.getParameter("firstName");
		String middleName = request.getParameter("middleName");
		String lastName = request.getParameter("lastName");
		String mobileNo = request.getParameter("mobileNo");
		String email = request.getParameter("email");
		String address = request.getParameter("address");
		String contactPerson = request.getParameter("contactPerson");
		String role = "1";
		String profile = request.getParameter("profile");
		String id = request.getParameter("id");

		log.info("--- Login  ---" + login);
		log.info("---------firstName----------" + firstName);
		log.info("---------middleName----------" + middleName);
		log.info("---------lastName----------" + lastName);
		log.info("---------mobileNo----------" + mobileNo);
		log.info("---------email----------" + email);
		log.info("---------address----------" + address);
		log.info("---------contactPerson----------" + contactPerson);
		log.info("---------role----------" + role);
		log.info("---------profile----------" + profile);
		log.info("---------id od systemUser----------" + id);
		if ((login != null) && !login.equalsIgnoreCase(""))
		{
			existingSystemUser.setLogin(login);
		}

		if ((password != null) && !password.equalsIgnoreCase(""))
		{
			existingSystemUser.setPassword(password);
		}

		if ((firstName != null) && !firstName.equalsIgnoreCase(""))
		{
			existingSystemUser.setFirstName(firstName);
		}

		existingSystemUser.setMiddleName(middleName);

		if ((lastName != null) && !lastName.equalsIgnoreCase(""))
		{
			existingSystemUser.setLastName(lastName);
		}

		if ((mobileNo != null) && !mobileNo.equalsIgnoreCase(""))
		{
			existingSystemUser.setPhoneNumber(mobileNo);
		}

		if ((email != null) && !email.equalsIgnoreCase(""))
		{
			existingSystemUser.setEmail(email);
		}

		existingSystemUser.setAddress(address);

		existingSystemUser.setContactPerson(contactPerson);

		if ((role != null) && !role.equalsIgnoreCase(""))
		{
			existingSystemUser.setRoleId(Long.parseLong(role));
		}

		if ((profile != null) && !profile.equalsIgnoreCase(""))
		{
			existingSystemUser.setProfileId(Long.parseLong(profile));
		}

		existingSystemUser.setCode(login);

		log.info("---------PRIMARY KEY OF THE SYSTEM USER TABLE----------" + existingSystemUser.getId());
		return existingSystemUser;
	}

	private boolean isEmpty(String name)
	{
		return ((null == name) || (name.trim().equals("")));
	}

	public ModelAndView updateSystemUser(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		HttpSession session = request.getSession();
		SystemUser existingSystemUser = (SystemUser) session.getAttribute("details");
		existingSystemUser = getSystemUserBean(request, existingSystemUser);
		if (existingSystemUser != null)
		{

			SystemUser sysAdmin = (SystemUser) session.getAttribute("systemUser");
			existingSystemUser.setModifiedBy(sysAdmin.getId());
			systemUserService.update(existingSystemUser);

			boolean status = addTerritoryUserMapping(request, existingSystemUser);

			return getSystemUserList(request, response);
		}
		else
		{
			request.setAttribute("errorMsg", "Code does not exists...");
			return new ModelAndView("/masters/conceptCategory/conceptCategoryWorkbench");
		}
	}

	public ModelAndView updateSyncFlag(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		HttpSession session = request.getSession();

		String entity = request.getParameter("entity");
		
		log.info("------Entity------Sync-----"+entity);

		if (entity != null)
		{
			appConfigService.updateSyncFlag(entity);
			
			String syncFlag = appConfigService.checkSyncFlag("sync");
			
			SystemUser systemUser = new SystemUser();
			systemUser.setDeleteFlag("F");
			List<SystemUser> systemUserList = systemUserService.activeUserSearch(systemUser);
			
			session.setAttribute("syncFlag", syncFlag);
			request.setAttribute("systemUserList", systemUserList);

			return new ModelAndView("/masters/user/userWorkbench");

		}
		else
		{
			return new ModelAndView("/masters/user/userWorkbench");
		}

	}

	public ModelAndView detailsSystemUser(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		log.info("----in details method-----");
		String code = request.getParameter("code");

		SystemUser existingSystemUser = fetchExistingSystemUser(code);
		log.info("----existing systemUser found-----" + existingSystemUser);
		if (existingSystemUser != null)
		{
			HttpSession session = request.getSession();
			session.setAttribute("details", existingSystemUser);
			Profile profile = new Profile();
			log.info("----profile id---ppprrrrrrroooooo-------iiiiiiddddd------" + existingSystemUser.getProfileId()
					+ "-------------");
			profile.setId(existingSystemUser.getProfileId());
			log.info("----profile alone-----" + profile + "-------------");
			List<Profile> profileList = profileService.doCustomSearch(profile);

			profile = profileList.get(0);
			session.setAttribute("profileList", profile);
			log.info("----profileList----pppppppppprrrrrrrrrooooo------" + profileList + "-------------");

			log.info("----existingSystemUser.getId()------" + existingSystemUser.getId() + "-------------");
			List<Territory> territoryList = territoryService.doTerritorySearch(existingSystemUser);
			session.setAttribute("territoryList", territoryList);
			log.info("----profileList----tttttttttttteeeeeeeeerrrrrrrrr------" + territoryList + "-------------");

			if ("details".equals(request.getParameter("details")))
			{
				return new ModelAndView("/masters/user/userDetails");
			}
			else
			{
				roleProfile(request, response);
				return new ModelAndView("/masters/user/editUser");
			}

		}
		else
		{
			request.setAttribute("errorMsg", "Code does not exists...");
			return new ModelAndView("/masters/user/userWorkbench");
		}
	}

	public ModelAndView deleteSystemUser(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		String code = request.getParameter("code");

		SystemUser existingSystemUser = fetchExistingSystemUser(code);

		if (existingSystemUser != null)
		{
			HttpSession session = request.getSession();
			SystemUser sysAdmin = (SystemUser) session.getAttribute("systemUser");

			existingSystemUser.setModifiedBy(sysAdmin.getId());

			systemUserService.delete(existingSystemUser);

			return getSystemUserList(request, response);
		}
		else
		{
			request.setAttribute("errorMsg", "Code does not exist...");

			return new ModelAndView("/masters/user/userWorkbench");
		}
	}

	private SystemUser fetchExistingSystemUser(String code)
	{
		SystemUser searchSystemuser = new SystemUser();
		searchSystemuser.setCode(code);

		List<SystemUser> searchResult = systemUserService.doUserSearch(searchSystemuser);
		log.info("-------------------------------searchResult --------------------------" + searchResult);
		if (CollectionUtils.isEmpty(searchResult))
		{
			return null;
		}

		if (searchResult.size() > 1)
		{
			throw new RuntimeException("Duplicate Records Found...");
		}

		return searchResult.get(0);
	}

	public ModelAndView getSystemUserSearch(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		log.info("-------------- in getSystemUserSearch Method by code -------------");

		SystemUser systemUser = new SystemUser();

		String code = request.getParameter("searchName");

		log.info("--- code ---" + code);

		if (!isEmpty(code))
		{
			systemUser.setCode(code);
		}
		else
		{
			return new ModelAndView("/masters/user/userWorkbench");
		}
		boolean status = false;
		List<SystemUser> systemUserSearch = systemUserService.doCustomSearch(systemUser);
		log.info("--- In getSystemUsersearch  ---" + systemUserSearch);
		/*if(systemUserSearch == null || systemUserSearch.isEmpty())
		{
			status=true;
			log.info("--- Status is-------"+status);
			getSystemUserList(request,response);
			request.setAttribute("error", status);
		}
		else
		{*/
		request.setAttribute("systemUserList", systemUserSearch);
		//}
		return new ModelAndView("/masters/user/userWorkbench");
	}

	public ModelAndView getSystemUserList(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		log.info("--- In getSystemUserList  ---");
		SystemUser systemUser = new SystemUser();
		systemUser.setDeleteFlag("F");
		List<SystemUser> systemUserList = systemUserService.activeUserSearch(systemUser);
		log.info("--- In getSystemUserList  ---" + systemUserList);
		log.info("UserController/getSystemUserList SystemUserList:"
				+ ((systemUserList == null) ? "Null " : systemUserList.size()));

		log.info("-------------------------------Final List--------------------------" + systemUserList);
		
		HttpSession session=request.getSession();
		
		String syncFlag = appConfigService.checkSyncFlag("sync");		
		
		session.setAttribute("syncFlag", syncFlag);		
		request.setAttribute("systemUserList", systemUserList);

		return new ModelAndView("/masters/user/userWorkbench");
	}

	public ModelAndView onAddClick(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException
	{
		roleProfile(request, response);

		return new ModelAndView("/masters/user/addUser");

	}

	public void roleProfile(HttpServletRequest request, HttpServletResponse response)
	{
		HttpSession session = request.getSession();
		Profile profile = new Profile();
		List<Profile> profileList = profileService.search(profile);
		log.info("--- In addClick  ---" + profileList);
		log.info("UserController/getSystemUserList SystemUserList:"
				+ ((profileList == null) ? "Null " : profileList.size()));

		log.info("-------------------------------Final List--------------------------" + profileList);
		session.setAttribute("fullProfileList", profileList);

		Territory territory = new Territory();
		List<Territory> territoryList = territoryService.search(territory);
		log.info("--- In addClick  ---" + territoryList);
		log.info("UserController/getSystemUserList SystemUserList:"
				+ ((territoryList == null) ? "Null " : territoryList.size()));

		log.info("-------------------------------Final List--------------------------" + territoryList);
		session = request.getSession();
		session.setAttribute("fullTerritoryList", territoryList);
	}

	public ModelAndView isUserNameAvailable(HttpServletRequest request, HttpServletResponse response)
	{

		String responseHTML = null;
		ModelAndView modelAndView = new ModelAndView("commons/ajaxResponsePage");
		log.info("login entered" + request.getParameter("login"));
		try
		{
			if ((null == request.getParameter("login"))
			/*|| request.getParameter("mobileNumber").trim().equals(IcatalogConstants.EMPTY_STRING)*/)
			{
				log.info("username not valid");
				responseHTML = CommonServices.getCrossImgHtml() + "Invalid LoginId";
			}
			else
			{
				log.info("in try");

				List<SystemUser> userBeanList = systemUserService.checkUniqueUserName(request.getParameter("login")
						.trim());

				if (userBeanList.size() > 0)
				{
					log.info("inside if");
					responseHTML = CommonServices.getCrossImgHtml()
							+ "Login not available. Please Enter different Login.";

					log.info("responseHTML ::: " + responseHTML);
				}
				else
				{
					log.info("inside else");
					responseHTML = CommonServices.getTickImgHtml() + "Available!";
				}

			}
			modelAndView.addObject(com.mobicule.icatalog.admin.common.IcatalogConstants.AJAX_RESPONSE_HTML,
					responseHTML);
			log.info("Just After the ADD" + modelAndView);
		}
		catch (Exception e)
		{
			log.error("Exception while checking for unique username :" + e);
			e.printStackTrace();

		}
		log.info("Value of ressponseHTML" + responseHTML.toString());
		log.info("Just before the RETURN" + modelAndView);
		return modelAndView;
	}
}
