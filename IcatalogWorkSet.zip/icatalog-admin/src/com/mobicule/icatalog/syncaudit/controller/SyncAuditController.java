package com.mobicule.icatalog.syncaudit.controller;

import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.management.RuntimeErrorException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.catalina.Session;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.CollectionUtils;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;


import com.mobicule.icatalog.syncaudit.bean.SyncAudit;
import com.mobicule.icatalog.syncaudit.bean.SyncAuditWrapper;
import com.mobicule.icatalog.syncaudit.service.SyncAuditService;
import com.mobicule.icatalog.systemuser.bean.SystemUser;
import com.mobicule.icatalog.systemuser.service.SystemUserService;
import com.mobicule.icatalog.admin.common.*;
import com.mobicule.icatalog.core.common.*;
import com.sun.org.apache.xerces.internal.impl.xpath.regex.ParseException;
public class SyncAuditController extends MultiActionController
{
	
	private Log log = LogFactory.getLog(this.getClass());
	private SyncAuditService syncAuditService;
	private SystemUserService systemUserService;
	
	
	public SystemUserService getSystemUserService() {
		return systemUserService;
	}
	public void setSystemUserService(SystemUserService systemUserService) {
		this.systemUserService = systemUserService;
	}
	public SyncAuditService getSyncAuditService() {
		return syncAuditService;
	}
	public void setSyncAuditService(SyncAuditService syncAuditService) {
		this.syncAuditService = syncAuditService;
	}
	


private boolean isEmpty(String name)
{
	return ((null == name) || (name.trim().equals("")));
}


public ModelAndView getSyncAudit(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		log.info("-------------- in getSyncAuditSearch Method by code -------------");
		
		SyncAudit syncAudit = new SyncAudit();

		String master = request.getParameter("master");

		log.info("--- master ---" + master);
		
		if (!isEmpty(master))
		{
			syncAudit.setMaster(master) ;
		}
		else
		{
			return new ModelAndView("/masters/user/syncAuditWorkbench");
		}
		boolean status=false;
		/*List<SyncAudit> syncAuditSearch = syncAuditService.doCustomSearch(syncAudit);
		log.info("--- In getSyncAuditsearch  ---"+syncAuditSearch);
		if(syncAuditSearch == null || syncAuditSearch.isEmpty())
		{
			status=true;
			log.info("--- Status is-------"+status);
			getSyncAuditList(request,response);
			request.setAttribute("error", status);
		}
		else
		{
			request.setAttribute("syncAuditList", syncAuditSearch);
		}*/
		return new ModelAndView("/masters/syncAudit/syncAuditWorkbench");	
	}

public ModelAndView getSyncAuditList(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
	log.info("--- In getSyncAuditList  ---");
	SyncAudit syncAudit = new SyncAudit();
	String userId=request.getParameter("id");
	if(null!=userId)
	{
		log.info("userId :"+userId);
		syncAudit.setId(Long.parseLong(userId));
	}
	syncAudit.setDeleteFlag("F");
	log.info("--- empty syncAudit instantiation  ---");
		List<SyncAudit> syncAuditList = new ArrayList<SyncAudit>(); 
		
				syncAuditList =syncAuditService.syncAuditList(syncAudit);
				
		/*log.info("--- syncAuditList  ---"+syncAuditList);*/
		log.info("SyncAuditController/getSyncAuditList SyncAuditList:"
				+ ((syncAuditList == null) ? "Null " : syncAuditList.size()));

		/*log.info("-------------------------------Final List--------------------------"+syncAuditList);*/
		HttpSession session=request.getSession();
		session.setAttribute("syncAuditList", syncAuditList);
		SystemUser systemUser=new SystemUser();
		systemUser.setDeleteFlag("F");
		List<SystemUser> systemUserList=systemUserService.activeUserSearch(systemUser);
		List<String> masterList=syncAuditService.masterSearch(syncAudit);
		List<SyncAuditWrapper> syncAuditWrapperList=syncAuditService.syncAuditWrapperDetails(syncAudit);
		
		session.setAttribute("syncAuditWrapperList",syncAuditWrapperList);
		session.setAttribute("masterList",masterList);
		session.setAttribute("syncAuditSystemUsersList",systemUserList);
		return new ModelAndView("/masters/syncAudit/syncAuditWorkbench");
	}
public ModelAndView getSyncAuditSearch(HttpServletRequest request, HttpServletResponse response)
		throws ServletException, IOException, java.text.ParseException
{

	log.info("--- In getSyncAuditSearch  ---");
	String master=request.getParameter("master");
	
	String syncDate=request.getParameter("syncDate");
	String userId=request.getParameter("userId");
	Timestamp syncDateTimestampDate = null;
	
	SyncAudit syncAudit = new SyncAudit();
	
	if(master!="")
	{
		log.info("<--- master in controller  --->"+master);
		syncAudit.setMaster(master);
	}
	if(null!=userId)
	{
		log.info("<--- userId in controller not null --->  "+userId);
		if(0!=Long.parseLong(userId))
		{
			log.info("<--- userId in controller not null i.e. if 0 --->  "+userId);
			syncAudit.setUserId(Long.parseLong(userId));
		}
	}
	else
	{
		HttpSession session = request.getSession();
		SystemUser systemUser=(SystemUser)session.getAttribute("systemUser");
		
		log.info("<--- userId in controller  null--->  "+systemUser.getId());
		syncAudit.setUserId(systemUser.getId());
	}
	if((syncDate != null) && !syncDate.equals(ICatalogConstants.EMPTY_STRING))
	{

		try {
			syncDateTimestampDate = com.mobicule.icatalog.core.common.CommonServices.convertDateToTimeStamp(
					(syncDate.trim()) + " 00:00:00",
					com.mobicule.icatalog.core.common.CommonServices.DATE_FORMATE_dd_MMM_yyyyHH_mm_ss);
		} catch (Exception e) {
			
			e.printStackTrace();
		}
	}
	
	List<SyncAuditWrapper> syncAuditWrapperList =(List<SyncAuditWrapper>)syncAuditService.doCustomSearch(syncAudit,syncDateTimestampDate);
			
	log.info("SyncAuditController/getSyncAuditList SyncAuditList:"
			+ ((syncAuditWrapperList == null) ? "Null " : syncAuditWrapperList.size()));
	HttpSession session=request.getSession();
	session.setAttribute("syncAuditWrapperList", syncAuditWrapperList);
		
	return new ModelAndView("/masters/syncAudit/syncAuditWorkbench");
}

}
