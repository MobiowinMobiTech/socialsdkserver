/**
******************************************************************************
* C O P Y R I G H T  A N D  C O N F I D E N T I A L I T Y  N O T I C E
* <p>
* Copyright © 2008-2009 Mobicule Technologies Pvt. Ltd. All rights reserved. 
* This is proprietary information of Mobicule Technologies Pvt. Ltd.and is 
* subject to applicable licensing agreements. Unauthorized reproduction, 
* transmission or distribution of this file and its contents is a 
* violation of applicable laws.
******************************************************************************
*
* @project icatalog-admin
*/
package com.mobicule.icatalog.product.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.mobicule.icatalog.admin.common.CommonServices;
import com.mobicule.icatalog.core.common.ICatalogConstants;
import com.mobicule.icatalog.product.bean.ProductCategory;
import com.mobicule.icatalog.product.service.ProductCategoryService;
import com.mobicule.icatalog.systemuser.bean.SystemUser;

/**
* 
* <enter description here>
*
* @author himanshu singh
* @see 
*
* @createdOn Mar 29, 2012
* @modifiedOn
*
* @copyright © 2008-2009 Mobicule Technologies Pvt. Ltd. All rights reserved.
*/
public class ProductCategoryController extends MultiActionController
{
	private Log log = LogFactory.getLog(this.getClass());

	private ProductCategoryService productCategoryService;

	private Map<String, List<String>> imageConfig;

	public Map<String, List<String>> getImageConfig()
	{
		return imageConfig;
	}

	public void setImageConfig(Map<String, List<String>> imageConfig)
	{
		this.imageConfig = imageConfig;
	}

	public ProductCategoryService getProductCategoryService()
	{
		return productCategoryService;
	}

	public void setProductCategoryService(ProductCategoryService productCategoryService)
	{
		this.productCategoryService = productCategoryService;
	}

	public ModelAndView addProductCategory(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		log.info("---------In ProductCategoryController / addProductCategory()----------");

		HttpSession session = request.getSession();
		SystemUser sysAdmin = (SystemUser) session.getAttribute("systemUser");

		ProductCategory deletedProductCategory = (ProductCategory) session
				.getAttribute("deleted_product_category_code");

		if (null == deletedProductCategory)
		{
			ProductCategory productCategory = getProductCategoryBean(request, null);
			productCategory.setDeleteFlag("F");
			productCategory.setModifiedBy(sysAdmin.getId());
			productCategory.setCreatedBy(sysAdmin.getId());
			productCategoryService.add(productCategory);
		}
		else
		{
			getProductCategoryBean(request, deletedProductCategory);
			deletedProductCategory.setDeleteFlag("F");
			deletedProductCategory.setModifiedBy(sysAdmin.getId());
			deletedProductCategory.setCreatedBy(sysAdmin.getId());
			productCategoryService.update(deletedProductCategory);
			session.setAttribute("deleted_product_category_code", null);
		}

		return getProductCategoryList(request, response);
	}

	private ProductCategory getProductCategoryBean(HttpServletRequest request, ProductCategory existingProductCategory)
	{
		log.info("-------------- in getUserBean Method  -------------");

		int count = 0;
		String imageExtension = null;
		String conceptImagePath = null;
		String conceptImageLocation = null;
		List<String> imageBasePath = (List<String>) imageConfig.get("IMAGE_BASE_PATH");
		List<String> imageDirectoryNames = (List<String>) imageConfig.get("IMAGE_DIRECTORY_NAMES");

		if (existingProductCategory == null)
		{
			existingProductCategory = new ProductCategory();
		}

		String code = request.getParameter("txtCode");
		String name = request.getParameter("txtName");
		String description = request.getParameter("txtDescription");

		log.info("--- Code  ---" + code);
		log.info("---------name----------" + name);
		log.info("=========Description=======" + description);

		// IMAGE UPLOAD STARTS

		Assert.state(request.getParameter("type").equals("genericFileMulti"), "type != genericFileMulti");

		final MultipartHttpServletRequest multiRequest = (MultipartHttpServletRequest) request;
		log.info("---------After multipart----------");
		final Map files = multiRequest.getFileMap();

		List<Object> filesList = new Vector<Object>(files.values());

		for (Object object : filesList)
		{
			CommonsMultipartFile commonsMultipartFile = (CommonsMultipartFile) object;
			if (!commonsMultipartFile.isEmpty())
			{
				count++;
			}
		}

		log.info("count is::" + count);

		for (Object object : filesList)
		{
			System.out.println("class name : " + object.getClass());
			CommonsMultipartFile commonsMultipartFile = (CommonsMultipartFile) object;
			log.info("\n\nOriginalFilename = " + commonsMultipartFile.getOriginalFilename());
			log.info("ContentType = " + commonsMultipartFile.getContentType());
			log.info("Name = " + commonsMultipartFile.getName());
			log.info("Size = " + commonsMultipartFile.getSize());
			log.info("StorageDescription " + commonsMultipartFile.getStorageDescription());

			String fileName = commonsMultipartFile.getOriginalFilename().toLowerCase();
			log.info("fileName is:" + fileName);

			if (!fileName.isEmpty())
			{

				int indexOfDot = fileName.lastIndexOf(".");

				String extension = fileName.substring(indexOfDot + 1);

				log.info("extension is::" + extension.toLowerCase());

				String basedir = imageBasePath.get(0);
				//String basedir = SyncConstants.IMGPATH;

				if (commonsMultipartFile.getName().equalsIgnoreCase("productfile"))
				{
					log.info("in productfile");
					log.info("file name is::" + fileName);

					int lastIndex = fileName.lastIndexOf(".");

					log.info("lastIndex is::" + lastIndex);
					imageExtension = fileName.substring(lastIndex);
					log.info("extension is::" + imageExtension);

					conceptImagePath = imageDirectoryNames.get(3) + "/";
					//conceptImagePath = "products/";

					conceptImageLocation = basedir + conceptImagePath;

					log.info("conceptImageLocation is::" + conceptImageLocation);

					existingProductCategory.setImageModifiedOn(new Timestamp(System.currentTimeMillis()));

					try
					{
						saveEmailImage(conceptImageLocation, commonsMultipartFile, code, imageExtension);
					}
					catch (Exception e)
					{
						e.printStackTrace();
					}

				}

			}
		}

		// IMAGE UPLOAD ENDS

		if ((code != null) && !code.equalsIgnoreCase(""))
		{
			existingProductCategory.setCode(code);
		}

		if ((name != null) && !name.equalsIgnoreCase(""))
		{
			existingProductCategory.setName(name);
		}

		if ((description != null) && !description.equalsIgnoreCase(""))
		{
			existingProductCategory.setDescription(description);
		}
		else
		{
			existingProductCategory.setDescription("");
		}

		return existingProductCategory;
	}

	private void saveEmailImage(String basedir, MultipartFile multipartFile, String code, String extension)
			throws Exception
	{
		File localEmailDir = new File(basedir);
		if (!localEmailDir.exists())
		{
			localEmailDir.mkdirs();

			File emaildir = new File(localEmailDir, code + extension);

			FileOutputStream fileOutputStream = new FileOutputStream(emaildir);
			fileOutputStream.write(multipartFile.getBytes());

		}
		else
		{
			File emaildir = new File(localEmailDir, code + extension);

			FileOutputStream fileOutputStream = new FileOutputStream(emaildir);
			fileOutputStream.write(multipartFile.getBytes());

		}

	}

	public ModelAndView updateProductCategory(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		String code = request.getParameter("txtCode");
		System.out.println("=============code============in update product category========:" + code);

		ProductCategory existingProductCategory = fetchExistingProductCategory(code);
		System.out.println("===========existingProductCategory===========in update product category================:"
				+ existingProductCategory);

		existingProductCategory = getProductCategoryBean(request, existingProductCategory);
		if (existingProductCategory != null)
		{
			HttpSession session = request.getSession();
			SystemUser sysAdmin = (SystemUser) session.getAttribute("systemUser");
			existingProductCategory.setModifiedBy(sysAdmin.getId());
			productCategoryService.update(existingProductCategory);

			return getProductCategoryList(request, response);
		}
		else
		{
			request.setAttribute("errorMsg", "Code does not exists...");
			return new ModelAndView("/masters/productCategory/productCategoryWorkbench");
		}
	}

	public ModelAndView deleteProductCategory(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		String code = request.getParameter("code");

		log.info("--------Code for deletion------------------in deleteProductCategory-----" + code);

		ProductCategory existingProductCategory = fetchExistingProductCategory(code);

		if (existingProductCategory != null)
		{
			HttpSession session = request.getSession();
			SystemUser sysAdmin = (SystemUser) session.getAttribute("systemUser");
			existingProductCategory.setModifiedBy(sysAdmin.getId());
			productCategoryService.delete(existingProductCategory);

			return getProductCategoryList(request, response);
		}
		else
		{
			request.setAttribute("errorMsg", "Code does not exists...");
			return new ModelAndView("/masters/productCategory/productCategoryWorkbench");
		}
	}

	private ProductCategory fetchExistingProductCategory(String code)
	{
		ProductCategory searchCategory = new ProductCategory();
		searchCategory.setCode(code);

		List<ProductCategory> searchResult = productCategoryService.search(searchCategory);

		if (CollectionUtils.isEmpty(searchResult))
		{
			return null;
		}

		if (searchResult.size() > 1)
		{
			throw new RuntimeException("Duplicate Records Found...");
		}

		return searchResult.get(0);
	}

	public ModelAndView getProductCategoryList(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		log.info(" In ProductCategoryController/getProductCategoryList");
		ProductCategory productCategory = new ProductCategory();

		productCategory.setDeleteFlag("F");

		List<ProductCategory> productCategoryList = productCategoryService.doProductCategorySearch(productCategory);

		log.info("ProductCategoryController/getProductCategoryList productCategoryList:"
				+ ((productCategoryList == null) ? "Null " : productCategoryList.size()));

		HttpSession session = request.getSession();
		session.setAttribute("productCategoryList", productCategoryList);

		return new ModelAndView("/masters/productCategory/productCategoryWorkbench");
	}

	public ModelAndView getProductCategorySearch(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		System.out.println("Inside Controller");
		ProductCategory productCategory = new ProductCategory();

		String code = request.getParameter("searchName");
		System.out.println("Inside Controller" + code);

		if (!isEmpty(code))
		{
			productCategory.setCode(code);
			log.info(productCategory.getCode());

		}

		log.info(" In getProductCategorySearch : " + productCategory);

		List<ProductCategory> productCategorySearch = productCategoryService.doCustomSearch(productCategory);

		log.info("Search Product Category : " + productCategorySearch);

		request.setAttribute("productCategoryList", productCategorySearch);
		return new ModelAndView("/masters/productCategory/productCategoryWorkbench");

	}

	private boolean isEmpty(String name)
	{
		return ((null == name) || (name.trim().equals("")));
	}

	public ModelAndView getProductCategory(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		System.out.println("Inside Controller/get Product Category");

		String code = request.getParameter("code");
		System.out.println("Inside Controller" + code);
		ProductCategory productCategory = null;
		if (!isEmpty(code))
		{
			productCategory = fetchExistingProductCategory(code);
			log.info(productCategory);
		}

		log.info(" In getProductCategory : " + productCategory);
		HttpSession session = request.getSession();

		session.setAttribute("productCategory", productCategory);

		return new ModelAndView("/masters/productCategory/editProductCategory");
	}

	public ModelAndView isCodeAvailable(HttpServletRequest request, HttpServletResponse response)
	{

		String responseHTML = null;
		ModelAndView modelAndView = new ModelAndView("commons/ajaxResponsePage");
		log.info("Code entered" + request.getParameter("txtCode"));
		try
		{
			if ((null == request.getParameter("txtCode"))
			/*|| request.getParameter("mobileNumber").trim().equals(IcatalogConstants.EMPTY_STRING)*/)
			{
				log.info("Code not valid");
				responseHTML = CommonServices.getCrossImgHtml() + "Invalid LoginId";
			}
			else
			{
				log.info("in try");

				List<ProductCategory> productCategoryList = productCategoryService.checkUniqueCode(request
						.getParameter("txtCode").trim());

				if (productCategoryList.size() > 0)
				{
					if (1 == productCategoryList.size())
					{
						if (productCategoryList.get(0).getDeleteFlag().equals("F"))
						{
							log.info("existing product code" + productCategoryList.get(0));
							log.info("existing product code delete flag:" + productCategoryList.get(0).getDeleteFlag());
							responseHTML = CommonServices.getCrossImgHtml()
									+ "Code not available. Please Enter different code.";
						}
						else
						{
							log.info("existing product code but soft deleted" + productCategoryList.get(0));
							log.info("existing product code delete flag:-----"
									+ productCategoryList.get(0).getDeleteFlag() + "----");
							responseHTML = CommonServices.getTickImgHtml() + "Available!";
							HttpSession session = request.getSession();
							session.setAttribute("deleted_product_category_code", productCategoryList.get(0));
						}
					}
					else
					{
						responseHTML = CommonServices.getCrossImgHtml()
								+ "Code not available. Please Enter different code.";
					}

					log.info("responseHTML ::: " + responseHTML);
				}
				else
				{
					log.info("inside else");
					responseHTML = CommonServices.getTickImgHtml() + "Available!";
				}

			}
			modelAndView.addObject(com.mobicule.icatalog.admin.common.IcatalogConstants.AJAX_RESPONSE_HTML,
					responseHTML);
			log.info("Just After the ADD" + modelAndView);
		}
		catch (Exception e)
		{
			log.error("Exception while checking for unique code :" + e);
			e.printStackTrace();

		}
		log.info("Value of ressponseHTML" + responseHTML.toString());
		log.info("Just before the RETURN" + modelAndView);
		return modelAndView;
	}

}
