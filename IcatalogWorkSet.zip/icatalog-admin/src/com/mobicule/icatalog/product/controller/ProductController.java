/**
******************************************************************************
* C O P Y R I G H T  A N D  C O N F I D E N T I A L I T Y  N O T I C E
* <p>
* Copyright © 2008-2009 Mobicule Technologies Pvt. Ltd. All rights reserved. 
* This is proprietary information of Mobicule Technologies Pvt. Ltd.and is 
* subject to applicable licensing agreements. Unauthorized reproduction, 
* transmission or distribution of this file and its contents is a 
* violation of applicable laws.
******************************************************************************
*
* @project icatalog-admin
*/
package com.mobicule.icatalog.product.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.mobicule.icatalog.product.bean.Product;
import com.mobicule.icatalog.product.bean.ProductCategory;
import com.mobicule.icatalog.product.bean.ProductRecommendation;
import com.mobicule.icatalog.product.bean.ProductVariant;
import com.mobicule.icatalog.product.bean.ProductWrapper;
import com.mobicule.icatalog.product.service.ProductCategoryService;
import com.mobicule.icatalog.product.service.ProductService;
import com.mobicule.icatalog.systemuser.bean.SystemUser;

/**
* 
* <enter description here>
*
* @author  himanshu singh>
* @see 
*
* @createdOn Apr 4, 2012
* @modifiedOn
*
* @copyright © 2008-2009 Mobicule Technologies Pvt. Ltd. All rights reserved.
*/
public class ProductController extends MultiActionController
{
	private Log log = LogFactory.getLog(this.getClass());

	private ProductService productService;

	private ProductCategoryService productCategoryService;

	public ProductService getProductService()
	{
		return productService;
	}

	public void setProductService(ProductService productService)
	{
		this.productService = productService;
	}

	public ProductCategoryService getProductCategoryService()
	{
		return productCategoryService;
	}

	public void setProductCategoryService(ProductCategoryService productCategoryService)
	{
		this.productCategoryService = productCategoryService;
	}

	public ModelAndView getProductSearch(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		log.info("ProductController/getProductSearch");

		String code = request.getParameter("txtSearch");
		Product product = new Product();
		product.setCode(code);
		product.setDeleteFlag("F");

		List<Product> ProductList = productService.search(product);

		log.info("ProductController/getProductSearch ProductList:"
				+ ((ProductList == null) ? "Null " : ProductList.size()));

		request.setAttribute("ProductList", ProductList);

		return new ModelAndView("/masters/product/editVariants");
	}

	public ModelAndView searchProduct(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{

		log.info("ProductController/searchProduct");

		String name = request.getParameter("searchName");
		String brand = request.getParameter("searchBrand");
		String department = request.getParameter("searchDepartment");
		String subdepartment = request.getParameter("searchSubDepartment");
		String productclass = request.getParameter("searchClass");
		String subclass = request.getParameter("searchSubClass");
		String style = request.getParameter("searchStyle");
		String offer = request.getParameter("chkOffers");
		String gift = request.getParameter("chkGift");

		String chkClass = request.getParameter("chkClass");
		String chkSubClass = request.getParameter("chkSubClass");
		String chkDept = request.getParameter("chkDept");
		String chkSubDept = request.getParameter("chkSubDept");
		String chkBrand = request.getParameter("chkBrand");

		String searchCat = request.getParameter("searchCategory");
		Long productCategoryId = Long.parseLong(searchCat);

		Product seachProduct = new Product();

		if (!isEmpty(name))
		{
			seachProduct.setName(name);
		}

		if (!isEmpty(brand))
		{
			seachProduct.setBrand(brand);
		}

		if (!isEmpty(department))
		{
			seachProduct.setDepartment(department);
		}

		if (!isEmpty(subdepartment))
		{
			seachProduct.setSubDepartment(subdepartment);
		}

		if (!isEmpty(productclass))
		{
			seachProduct.setProductClass(productclass);
		}

		if (!isEmpty(subclass))
		{
			seachProduct.setSubClass(subclass);
		}

		if (!isEmpty(style))
		{
			seachProduct.setStyle(style);
		}

		if (!isEmpty(name))
		{
			seachProduct.setSearchTags(name);
		}
		if (!isEmpty(offer))
		{
			log.info("....offer...." + offer);

			seachProduct.setOfferFlag("Y");
		}
		if (!isEmpty(gift))
		{
			log.info("....gift...." + gift);
			seachProduct.setGiftFlag("Y");
		}

		if (!isEmpty(chkClass))
		{
			seachProduct.setProductClass(chkClass);
		}
		if (!isEmpty(chkSubClass))
		{
			seachProduct.setSubClass(chkSubClass);
		}
		if (!isEmpty(chkDept))
		{
			seachProduct.setDepartment(chkDept);
		}
		if (!isEmpty(chkSubDept))
		{
			seachProduct.setSubDepartment(chkSubDept);
		}
		if (!isEmpty(chkBrand))
		{
			seachProduct.setBrand(chkBrand);
		}

		HttpSession session = request.getSession();

		if (productCategoryId != -1)
		{
			log.info("With Product Category........Value of productCategoryId" + productCategoryId);

			List<ProductWrapper> ProductList = productService.customSearch(seachProduct, productCategoryId);
			session.setAttribute("ProductList1", ProductList);

			return new ModelAndView("/masters/product/productWorkbench");
		}

		else
		{
			List<ProductWrapper> ProductList = productService.doCustomSearch(seachProduct);

			session.setAttribute("ProductList1", ProductList);
			System.out.println("-------Without Product Category---List:" + ProductList);

			return new ModelAndView("/masters/product/productWorkbench");
		}

	}

	public ModelAndView getProductList(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		ProductWrapper productWrapper = new ProductWrapper();
		Product product = new Product();
		product.setDeleteFlag("F");
		productWrapper.setProduct(product);
		ProductCategory productCategory = new ProductCategory();
		productCategory.setDeleteFlag("F");

		List<ProductCategory> productCategoryList = productCategoryService.search(productCategory);
		List<ProductWrapper> ProductList = productService.searchWrapper(productWrapper);

		log.info("ProductController/getProductWrapperList ProductWrapperList:"
				+ ((ProductList == null) ? "Null " : ProductList.size()));

		log.info("ProductController/getProductCategoryList productCategoryList:"
				+ ((productCategoryList == null) ? "Null " : productCategoryList.size()));

		HttpSession session = request.getSession();
		session.setAttribute("ProductList1", ProductList);
		session.setAttribute("productCategoryList", productCategoryList);
		return new ModelAndView("/masters/product/productWorkbench");
	}

	public ModelAndView searchProductCode(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		String id1 = request.getParameter("code");

		long id = Long.parseLong(id1);

		ProductWrapper productWrapper = new ProductWrapper();

		if (id != 0)
		{

			List<ProductWrapper> productList = productService.searchWrapperDetails(productWrapper, id);

			log.info("ProductController/searchProductCode productList:"
					+ ((productList == null) ? "Null " : productList.size()));

			List<ProductWrapper> productRecommendList = productService.productRecommendList(productWrapper, id);

			List<ProductWrapper> productVariantList = productService.productVariantList(productWrapper, id);

			HttpSession session = request.getSession();
			session.setAttribute("productList", productList);
			List<Product> productRecommendListin = new ArrayList<Product>();
			List<Product> productVariantListin = new ArrayList<Product>();
			int size = 0;
			int size1 = 0;

			if (productRecommendList != null)
			{
				size = productRecommendList.size();

				for (int i = 0; i < size; i++)
				{
					productRecommendListin.add(productRecommendList.get(i).getProduct());
				}

				session.setAttribute("productRecommendListin", productRecommendListin);
				log.info("----*****-----productRecommendListin-------------" + productRecommendListin);

				if (productVariantList != null)
				{
					size1 = productVariantList.size();

					for (int i = 0; i < size1; i++)
					{
						productVariantListin.add(productVariantList.get(i).getProduct());
					}

					session.setAttribute("productVariantListin", productVariantListin);
					log.info("----*****-----productVariantin-------------" + productVariantListin);

				}
				return new ModelAndView("/masters/product/productDetails");
			}

			request.setAttribute("errorMsg", "Code does not exists...");
			return new ModelAndView("/masters/product/productWorkbench");
		}
		else
		{
			request.setAttribute("errorMsg", "Code does not exists...");
			return new ModelAndView("/masters/product/productWorkbench");
		}

	}

	public ModelAndView searchProductCodeForEdit(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		String id1 = request.getParameter("code");

		long id = Long.parseLong(id1);

		ProductWrapper productWrapper = new ProductWrapper();

		if (id != 0)
		{

			List<ProductWrapper> productList = productService.searchWrapperDetails(productWrapper, id);

			log.info("ProductController/searchProductCode productList:"
					+ ((productList == null) ? "Null " : productList.size()));

			HttpSession session = request.getSession();
			session.setAttribute("productList", productList);

			return new ModelAndView("/masters/product/editProduct");
		}
		else
		{
			request.setAttribute("errorMsg", "Code does not exists...");
			return new ModelAndView("/masters/product/productWorkbench");
		}

	}

	public ModelAndView productEditCode(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		String desc = request.getParameter("txtDescription");
		String offer = request.getParameter("chkOffers");
		String gift = request.getParameter("chkGift");
		String searchTag = request.getParameter("txtSearchTags");
		System.out.println("========In productEditCode======OFFER:::" + offer);
		System.out.println("========In productEditCode======Gift:::" + gift);

		HttpSession session2 = request.getSession();
		Product product = (Product) session2.getAttribute("product");

		product.setDescription(desc);
		product.setOfferFlag(offer);
		product.setGiftFlag(gift);
		product.setSearchTags(searchTag);

		long id = product.getId();

		productService.update(product);

		ProductWrapper productWrapper = new ProductWrapper();

		List<ProductWrapper> productList = productService.searchWrapperDetails(productWrapper, id);

		log.info("ProductController/searchProductCode productList:"
				+ ((productList == null) ? "Null " : productList.size()));

		HttpSession session = request.getSession();
		session.setAttribute("productList", productList);

		return new ModelAndView("/masters/product/productDetails");

	}

	public ModelAndView searchProductforVariants(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{

		log.info("************ProductController/searchProductforVariants*********************");

		String name = request.getParameter("searchName");

		String chkClass = request.getParameter("chkClass");
		String chkSubClass = request.getParameter("chkSubClass");
		String chkDept = request.getParameter("chkDept");
		String chkSubDept = request.getParameter("chkSubDept");
		String chkBrand = request.getParameter("chkBrand");

		log.info("================Name======================" + name);
		log.info("==================Class====================" + chkClass);
		log.info("================SubClass======================" + chkSubClass);
		log.info("==================Dept====================" + chkDept);
		log.info("==================SubDept====================" + chkSubDept);
		log.info("===================Chk Brand===================" + chkBrand);

		Product seachProduct = new Product();

		if (name != null)
		{
			seachProduct.setSearchTags(name);
		}

		if (chkClass != null)
		{
			seachProduct.setProductClass(chkClass);
		}

		if (chkSubClass != null)
		{
			seachProduct.setSubClass(chkSubClass);
		}

		if (chkDept != null)
		{
			seachProduct.setDepartment(chkDept);
		}

		if (chkSubDept != null)
		{
			seachProduct.setSubDepartment(chkSubDept);
		}

		if (chkBrand != null)
		{
			seachProduct.setBrand(chkBrand);
		}

		HttpSession session = request.getSession();

		List<ProductWrapper> ProductList = productService.doCustomSearch(seachProduct);

		session.setAttribute("ProductListofVariants", ProductList);

		return new ModelAndView("/masters/product/editVariantProducts");

	}

	public ModelAndView searchProductList(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		Product product = new Product();
		product.setDeleteFlag("F");

		List<Product> productList = productService.search(product);

		log.info("ProductController/searchProductList productList:"
				+ ((productList == null) ? "Null " : productList.size()));

		HttpSession session = request.getSession();
		session.setAttribute("ProductList", productList);

		return null;
	}

	public ModelAndView duplication(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException
	{
		HttpSession session = request.getSession();
		if (request.getParameter("type").equals("related"))
		{
			log.info("===In related===");
			List<Product> productRecommendList = (List<Product>) session.getAttribute("productRecommendListin");
			List<Product> duplicateProductRecommendList = new ArrayList<Product>();
			duplicateProductRecommendList.addAll(productRecommendList);
			session.setAttribute("duplicateProductRecommendList", duplicateProductRecommendList);
			return new ModelAndView("/masters/product/editRecomendedProducts");
		}
		if (request.getParameter("type").equals("variants"))
		{
			log.info("===In variants===");
			List<Product> productVariantList = (List<Product>) session.getAttribute("productVariantListin");
			List<Product> duplicateProductVariantList = new ArrayList<Product>();
			duplicateProductVariantList.addAll(productVariantList);
			session.setAttribute("duplicateProductVariantList", duplicateProductVariantList);
			return new ModelAndView("/masters/product/editVariantProducts");
		}
		return new ModelAndView("/masters/product/productWorkbench");

	}

	public ModelAndView getSearchProducts(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		HttpSession session = request.getSession();
		String searchTags = request.getParameter("searchName");
		session.setAttribute("recomendSearchName", searchTags);
		if (searchTags.equals(""))
		{
			searchTags = null;
		}
		String group = request.getParameter("group");
		session.setAttribute("recomendGroup", group);
		String chkClass = request.getParameter("chkClass");
		session.setAttribute("recomendChkClass", chkClass);
		String chkSubClass = request.getParameter("chkSubClass");
		session.setAttribute("recomendChkSubClass", chkSubClass);
		String chkDept = request.getParameter("chkDept");
		session.setAttribute("recomendChkDept", chkDept);
		String chkSubDept = request.getParameter("chkSubDept");
		session.setAttribute("recomendChkSubDept", chkSubDept);
		String chkBrand = request.getParameter("chkBrand");
		session.setAttribute("recomendChkBrand", chkBrand);

		log.info("ProductController/searchProducts");

		Product product = new Product();
		product.setDeleteFlag("F");

		log.info("group/all :" + group);

		if (null != group)
		{
			if (group.equals("group"))
			{
				log.info("----------GROUP selected---------------");
				if (null != searchTags)
					searchTags = searchTags.trim();
				if (null != searchTags)
				{
					log.info(" searchtags :" + searchTags + "--");
					product.setSearchTags(searchTags);
				}
				if (null != chkClass)
					chkClass = chkClass.trim();
				if (null != chkClass)
				{
					log.info(" class :" + chkClass + "--");
					product.setProductClass(chkClass);
				}
				if (null != chkSubClass)
					chkSubClass = chkSubClass.trim();
				if (null != chkSubClass)
				{
					log.info(" subclass :" + chkSubClass + "--");
					product.setSubClass(chkSubClass);
				}
				if (null != chkDept)
					chkDept = chkDept.trim();
				if (null != chkDept)
				{
					log.info(" dept :" + chkDept + "--");
					product.setDepartment(chkDept);
				}
				if (null != chkSubDept)
					chkSubDept = chkSubDept.trim();
				if (null != chkSubDept)
				{
					log.info(" subDept :" + chkSubDept + "--");
					product.setSubDepartment(chkSubDept);
				}
				if (null != chkBrand)
					chkBrand = chkBrand.trim();
				if (null != chkBrand)
				{
					log.info(" brand :" + chkBrand + "--");
					product.setBrand(chkBrand);
				}
			}
			else if (group.equals("all"))
			{

				log.info("----------ALL selected---------------");
				if (null != searchTags)
					searchTags = searchTags.trim();
				if (null != searchTags)
				{
					log.info(" searchtags :" + searchTags + "--");
					product.setSearchTags(searchTags);
				}
			}
		}
		else
		{
			if (null != searchTags)
				searchTags = searchTags.trim();
			if (null != searchTags)
			{
				log.info(" searchtags :" + searchTags + "--");
				product.setSearchTags(searchTags);
			}
		}

		List<Product> productList = productService.doProductListsearch(product);

		log.info("ProductController/editRecommendedProductList productList:"
				+ ((productList == null) ? "Null " : productList.size()));

		List<Product> duplicateProductRecommendList = (List<Product>) session
				.getAttribute("duplicateProductRecommendList");

		HashMap<Long, Product> recoProductHM = new HashMap<Long, Product>();

		int size = 0;
		int proListSize = 0;

		if (!productList.isEmpty())
		{
			proListSize = productList.size();

			for (int i = 0; i < proListSize; i++)
			{
				recoProductHM.put(productList.get(i).getId(), productList.get(i));
			}
		}

		size = duplicateProductRecommendList.size();

		for (int i = 0; i < size; i++)
		{
			if (recoProductHM.containsKey(duplicateProductRecommendList.get(i).getId()))
			{

				productList.remove(productList.indexOf(duplicateProductRecommendList.get(i)));
			}
		}

		log.info("---***------>>>>Product" + (List<ProductWrapper>) session.getAttribute("productList"));
		Product currentProduct = ((List<ProductWrapper>) session.getAttribute("productList")).get(0).getProduct();
		if (recoProductHM.containsKey(currentProduct.getId()))
		{
			productList.remove(productList.indexOf(currentProduct));
		}

		session.setAttribute("searchProductList", productList);
		return new ModelAndView("/masters/product/editRecomendedProducts");

	}

	public ModelAndView getSearchProductVariants(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		log.info("==============ProductController/searchProductVariants====================");

		HttpSession session = request.getSession();
		String searchTags = request.getParameter("searchName");
		session.setAttribute("variantSearchName", searchTags);
		if (searchTags.equals(""))
		{
			searchTags = null;
		}
		String group = request.getParameter("group");
		session.setAttribute("variantGroup", group);
		String chkClass = request.getParameter("chkClass");
		session.setAttribute("variantChkClass", chkClass);
		String chkSubClass = request.getParameter("chkSubClass");
		session.setAttribute("variantChkSubClass", chkSubClass);
		String chkDept = request.getParameter("chkDept");
		session.setAttribute("variantChkDept", chkDept);
		String chkSubDept = request.getParameter("chkSubDept");
		session.setAttribute("variantChkSubDept", chkSubDept);
		String chkBrand = request.getParameter("chkBrand");
		session.setAttribute("variantChkBrand", chkBrand);

		log.info("ProductController/searchProducts");

		Product product = new Product();
		product.setDeleteFlag("F");

		log.info("group/all :" + group);
		if (null != group)
		{
			if (group.equals("group"))
			{
				log.info("----------GROUP selected---------------");
				if (null != searchTags)
					searchTags = searchTags.trim();
				if (null != searchTags)
				{
					log.info(" searchtags :" + searchTags + "--");
					product.setSearchTags(searchTags);
				}
				if (null != chkClass)
					chkClass = chkClass.trim();
				if (null != chkClass)
				{
					log.info(" class :" + chkClass + "--");
					product.setProductClass(chkClass);
				}
				if (null != chkSubClass)
					chkSubClass = chkSubClass.trim();
				if (null != chkSubClass)
				{
					log.info(" subclass :" + chkSubClass + "--");
					product.setSubClass(chkSubClass);
				}
				if (null != chkDept)
					chkDept = chkDept.trim();
				if (null != chkDept)
				{
					log.info(" dept :" + chkDept + "--");
					product.setDepartment(chkDept);
				}
				if (null != chkSubDept)
					chkSubDept = chkSubDept.trim();
				if (null != chkSubDept)
				{
					log.info(" subDept :" + chkSubDept + "--");
					product.setSubDepartment(chkSubDept);
				}
				if (null != chkBrand)
					chkBrand = chkBrand.trim();
				if (null != chkBrand)
				{
					log.info(" brand :" + chkBrand + "--");
					product.setBrand(chkBrand);
				}
			}
			else if (group.equals("all"))
			{

				log.info("----------ALL selected---------------");
				if (null != searchTags)
					searchTags = searchTags.trim();
				if (null != searchTags)
				{
					log.info(" searchtags :" + searchTags + "--");
					product.setSearchTags(searchTags);
				}
			}
		}
		else
		{
			if (null != searchTags)
				searchTags = searchTags.trim();
			if (null != searchTags)
			{
				log.info(" searchtags :" + searchTags + "--");
				product.setSearchTags(searchTags);
			}
		}
		List<Product> productList = productService.doProductListsearch(product);

		log.info("ProductController/editVariantProductList productList:"
				+ ((productList == null) ? "Null " : productList.size()));

		List<Product> duplicateProductVariantList = (List<Product>) session.getAttribute("duplicateProductVariantList");

		HashMap<Long, Product> variantProductHM = new HashMap<Long, Product>();

		int size = 0;
		int proListSize = 0;

		if (!productList.isEmpty())
		{
			proListSize = productList.size();

			for (int i = 0; i < proListSize; i++)
			{

				variantProductHM.put(productList.get(i).getId(), productList.get(i));
			}
		}
		size = duplicateProductVariantList.size();

		for (int i = 0; i < size; i++)
		{
			if (variantProductHM.containsKey(duplicateProductVariantList.get(i).getId()))
			{

				productList.remove(productList.indexOf(duplicateProductVariantList.get(i)));
			}
		}

		Product currentProduct = ((List<ProductWrapper>) session.getAttribute("productList")).get(0).getProduct();
		if (variantProductHM.containsKey(currentProduct.getId()))
		{

			productList.remove(productList.indexOf(currentProduct));
		}

		session.setAttribute("searchProductVariantList", productList);
		return new ModelAndView("/masters/product/editVariantProducts");

	}

	private boolean isEmpty(String name)
	{
		return ((null == name) || (name.trim().equals("")));
	}

	// add method for recommended products

	public ModelAndView addRecomendedProducts(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		String type = request.getParameter("type");

		if (null != type)
		{
			duplication(request, response);
		}

		String recoId1 = null;
		recoId1 = request.getParameter("recoList1");

		if (recoId1.equals("null"))
		{
			recoId1 = null;
		}

		String[] recomendId = null;
		if (null != recoId1)
		{
			recomendId = recoId1.split(",");
		}
		HttpSession session2 = request.getSession();
		long id = ((List<ProductWrapper>) session2.getAttribute("productList")).get(0).getProduct().getId();
		List<Product> productRecommendList = (List<Product>) session2.getAttribute("productRecommendListin");

		ProductRecommendation recommendation = new ProductRecommendation();
		recommendation.setProductId(id);
		List<ProductRecommendation> productRecommendationList = productService
				.doProductRecomendationsearch(recommendation);
		int size = 0;
		int recosize = 0;
		List<Long> recomendedListId1 = null;
		HashMap<Long, ProductRecommendation> recomendedListId = null;

		//New map of recomended products (ids)
		HashMap<Long, ProductRecommendation> newRecomendListId1 = new HashMap<Long, ProductRecommendation>();

		// new list of recomended products (ids)
		List<Long> newRecomendListId = new ArrayList<Long>();

		if (null != recomendId)
		{
			size = recomendId.length;

			for (int i = 0; i < size; i++)
			{

				newRecomendListId1.put(Long.parseLong(recomendId[i]), new ProductRecommendation());

			}

			for (int i = 0; i < size; i++)
			{

				newRecomendListId.add(Long.parseLong(recomendId[i]));
			}

		}

		if (!productRecommendationList.isEmpty())
		{
			recosize = productRecommendationList.size();
			recomendedListId1 = new ArrayList<Long>(); //Existing Recomended products list

			for (int i = 0; i < recosize; i++)
			{
				recomendedListId1.add(productRecommendationList.get(i).getRecommendId());
			}

			// Old map of recomended products(ids and their beans)
			recomendedListId = new HashMap<Long, ProductRecommendation>();

			for (int i = 0; i < recosize; i++)
			{
				recomendedListId.put(productRecommendationList.get(i).getRecommendId(),
						productRecommendationList.get(i));
			}
		}

		if (null != recomendId)
		{
			// if recommend id list is not empty
			size = recomendId.length;

			if (!productRecommendationList.isEmpty())
			{ // if session -product recommendation list is not empty

				for (int i = 0; i < size; i++)
				{
					if (!recomendedListId.containsKey(newRecomendListId.get(i)))
					{
						recommendation = new ProductRecommendation();
						recommendation.setProductId(id);
						recommendation.setRecommendId(newRecomendListId.get(i));
						HttpSession session = request.getSession();
						SystemUser sysAdmin = (SystemUser) session.getAttribute("systemUser");
						recommendation.setCreatedBy(sysAdmin.getId());
						recommendation.setModifiedBy(sysAdmin.getId());
						productService.addRecommendation(recommendation);

					}
				}
				ProductWrapper productWrapper = new ProductWrapper();
				List<ProductWrapper> productRecommendList1 = productService.productRecommendList(productWrapper, id);
				List<Product> productRecommendListin = new ArrayList<Product>();

				int size1 = productRecommendList1.size();

				for (int i = 0; i < size1; i++)
				{

					productRecommendListin.add(productRecommendList1.get(i).getProduct());
				}

				session2.setAttribute("productRecommendListin", productRecommendListin);

				log.info("-----just BEFORE SETTING THE RECO LIST ATTRIBUTE----------");

				session2.setAttribute("productRecommendList", productRecommendList);
				return new ModelAndView("/masters/product/productDetails");
			}
			else
			{ // if session -product recommendation list is empty

				if (null != recomendId)
				{
					size = recomendId.length;

					for (int i = 0; i < size; i++)
					{
						recommendation = new ProductRecommendation();
						recommendation.setProductId(id);
						recommendation.setRecommendId(newRecomendListId.get(i));
						HttpSession session = request.getSession();
						SystemUser sysAdmin = (SystemUser) session.getAttribute("systemUser");
						recommendation.setCreatedBy(sysAdmin.getId());
						recommendation.setModifiedBy(sysAdmin.getId());
						productService.addRecommendation(recommendation);
					}
				}

				ProductWrapper productWrapper = new ProductWrapper();
				List<ProductWrapper> productRecommendList1 = productService.productRecommendList(productWrapper, id);
				List<Product> productRecommendListin = new ArrayList<Product>();

				int size1 = productRecommendList1.size();

				for (int i = 0; i < size1; i++)
				{

					productRecommendListin.add(productRecommendList1.get(i).getProduct());
				}

				session2.setAttribute("productRecommendListin", productRecommendListin);

				return new ModelAndView("/masters/product/productDetails");
			}
		}
		else
		{
			return new ModelAndView("/masters/product/productDetails");
		}

	}

	// delete recommended products method

	public ModelAndView deleteRecomendedProducts(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		String type = request.getParameter("type");

		if (null != type)
		{
			duplication(request, response);
		}

		String recoId1 = null;
		recoId1 = request.getParameter("recoList1");

		if (recoId1.equals("null") || recoId1.isEmpty())
		{
			recoId1 = null;
		}

		String[] recomendId = null;
		if (null != recoId1)
		{
			recomendId = recoId1.split(",");
		}
		HttpSession session2 = request.getSession();
		long id = ((List<ProductWrapper>) session2.getAttribute("productList")).get(0).getProduct().getId();
		List<Product> productRecommendList = (List<Product>) session2.getAttribute("productRecommendListin");

		ProductRecommendation recommendation = new ProductRecommendation();
		recommendation.setProductId(id);
		List<ProductRecommendation> productRecommendationList = productService
				.doProductRecomendationsearch(recommendation);
		int size = 0;
		int recosize = 0;
		List<Long> recomendedListId1 = null;
		HashMap<Long, ProductRecommendation> recomendedListId = null;

		//New map of recomended products (ids)
		HashMap<Long, ProductRecommendation> newRecomendListId1 = new HashMap<Long, ProductRecommendation>();

		// new list of recomended products (ids)
		List<Long> newRecomendListId = new ArrayList<Long>();

		if (null != recomendId)
		{
			size = recomendId.length;

			for (int i = 0; i < size; i++)
			{
				newRecomendListId1.put(Long.parseLong(recomendId[i]), new ProductRecommendation());
			}
			for (int i = 0; i < size; i++)
			{

				newRecomendListId.add(Long.parseLong(recomendId[i]));
			}
		}

		if (!productRecommendationList.isEmpty())
		{
			recosize = productRecommendationList.size();
			recomendedListId1 = new ArrayList<Long>(); //Existing Recomended products list

			for (int i = 0; i < recosize; i++)
			{
				recomendedListId1.add(productRecommendationList.get(i).getRecommendId());
			}

			// Old map of recomended products(ids and their beans)
			recomendedListId = new HashMap<Long, ProductRecommendation>();

			for (int i = 0; i < recosize; i++)
			{
				recomendedListId.put(productRecommendationList.get(i).getRecommendId(),
						productRecommendationList.get(i));
			}
		}

		if (null != recomendId)
		{
			size = recomendId.length;

			if (!productRecommendationList.isEmpty())
			{
				// if session- product recommendation list is not empty

				for (int i = 0; i < recosize; i++)
				{
					if (newRecomendListId1.containsKey(recomendedListId1.get(i)))
					{
						recomendedListId.get(recomendedListId1.get(i)).setDeleteFlag("T");
						productService.editRecommendation(recomendedListId.get(recomendedListId1.get(i)));

					}
				}
				ProductWrapper productWrapper = new ProductWrapper();
				List<ProductWrapper> productRecommendList1 = productService.productRecommendList(productWrapper, id);
				List<Product> productRecommendListin = new ArrayList<Product>();

				int size1 = productRecommendList1.size();

				for (int i = 0; i < size1; i++)
				{

					productRecommendListin.add(productRecommendList1.get(i).getProduct());
				}

				session2.setAttribute("productRecommendListin", productRecommendListin);

				log.info("-----just BEFORE SETTING THE RECO LIST ATTRIBUTE----------");

				session2.setAttribute("productRecommendList", productRecommendList);
				return new ModelAndView("/masters/product/productDetails");
			}
			else
			{
				// if session-product recommendation list is empty

				return new ModelAndView("/masters/product/productDetails");
			}
		}
		else
		{
			return new ModelAndView("/masters/product/productDetails");
		}

	}

	// 	add product variant method

	public ModelAndView addProductVariants(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		String type = request.getParameter("type");

		if (null != type)
		{
			duplication(request, response);
		}

		String variantId1 = null;
		variantId1 = request.getParameter("variantList");
		log.info("-------------------------variantId1-------------------------------" + variantId1);
		if (variantId1.equals("null") || variantId1.isEmpty())
		{
			variantId1 = null;
		}

		String[] variantId = null;
		if (null != variantId1)
		{
			variantId = variantId1.split(",");
		}

		HttpSession session2 = request.getSession();
		long id = ((List<ProductWrapper>) session2.getAttribute("productList")).get(0).getProduct().getId();
		List<Product> productRecommendList = (List<Product>) session2.getAttribute("productVariantListin");

		ProductVariant variant = new ProductVariant();
		variant.setProductId(id);
		List<ProductVariant> productVariantList = productService.doProductVariantsearch(variant);
		int size = 0;
		int recosize = 0;
		List<Long> variantListId1 = null;
		HashMap<Long, ProductVariant> variantListId = null;

		//New map of Variant products (ids)
		HashMap<Long, ProductVariant> newVariantListId1 = new HashMap<Long, ProductVariant>();

		// new list of Variant products (ids)
		List<Long> newVariantListId = new ArrayList<Long>();

		if (null != variantId)
		{
			size = variantId.length;

			for (int i = 0; i < size; i++)
			{
				newVariantListId1.put(Long.parseLong(variantId[i]), new ProductVariant());
			}

			for (int i = 0; i < size; i++)
			{
				newVariantListId.add(Long.parseLong(variantId[i]));
			}
		}

		if (!productVariantList.isEmpty())
		{
			recosize = productVariantList.size();
			variantListId1 = new ArrayList<Long>(); //Existing Variant products list

			for (int i = 0; i < recosize; i++)
			{
				variantListId1.add(productVariantList.get(i).getVariantId());
			}

			// Old map of Variant products(ids and their beans)
			variantListId = new HashMap<Long, ProductVariant>();

			for (int i = 0; i < recosize; i++)
			{
				variantListId.put(productVariantList.get(i).getVariantId(), productVariantList.get(i));
			}
		}

		if (null != variantId)
		{
			size = variantId.length;

			if (!productVariantList.isEmpty())
			{
				// if session product variants list is not empty
				for (int i = 0; i < size; i++)
				{
					if (!variantListId.containsKey(newVariantListId.get(i)))
					{
						variant = new ProductVariant();
						variant.setProductId(id);
						variant.setVariantId(newVariantListId.get(i));
						HttpSession session = request.getSession();
						SystemUser sysAdmin = (SystemUser) session.getAttribute("systemUser");
						variant.setCreatedBy(sysAdmin.getId());
						variant.setModifiedBy(sysAdmin.getId());
						productService.addVariants(variant);

						variant = new ProductVariant();
						variant.setProductId(newVariantListId.get(i));
						variant.setVariantId(id);
						variant.setCreatedBy(sysAdmin.getId());
						variant.setModifiedBy(sysAdmin.getId());
						productService.addVariants(variant);
					}
				}

				ProductWrapper productWrapper = new ProductWrapper();
				List<ProductWrapper> productVariantList1 = productService.productVariantList(productWrapper, id);
				List<Product> productVariantListin = new ArrayList<Product>();

				int size1 = productVariantList1.size();

				for (int i = 0; i < size1; i++)
				{

					productVariantListin.add(productVariantList1.get(i).getProduct());
				}

				session2.setAttribute("productVariantListin", productVariantListin);

				log.info("-----just BEFORE SETTING THE Variant LIST ATTRIBUTE----------");

				session2.setAttribute("productVariantList", productVariantList);
				return new ModelAndView("/masters/product/productDetails");
			}
			else
			{
				// if session product variants list is empty

				if (null != variantId)
				{
					size = variantId.length;
					log.info("-----in else-- variantId not null-----" + variantId);

					for (int i = 0; i < size; i++)
					{
						variant = new ProductVariant();
						variant.setProductId(id);
						variant.setVariantId(newVariantListId.get(i));
						HttpSession session = request.getSession();
						SystemUser sysAdmin = (SystemUser) session.getAttribute("systemUser");
						variant.setCreatedBy(sysAdmin.getId());
						variant.setModifiedBy(sysAdmin.getId());
						productService.addVariants(variant);

						variant = new ProductVariant();
						variant.setProductId(newVariantListId.get(i));
						variant.setVariantId(id);
						variant.setCreatedBy(sysAdmin.getId());
						variant.setModifiedBy(sysAdmin.getId());
						productService.addVariants(variant);

					}
				}

				ProductWrapper productWrapper = new ProductWrapper();
				List<ProductWrapper> productVariantList1 = productService.productVariantList(productWrapper, id);
				List<Product> productVariantListin = new ArrayList<Product>();

				int size1 = productVariantList1.size();

				for (int i = 0; i < size1; i++)
				{

					productVariantListin.add(productVariantList1.get(i).getProduct());
				}

				session2.setAttribute("productVariantListin", productVariantListin);

				return new ModelAndView("/masters/product/productDetails");
			}
		}

		else
		{
			return new ModelAndView("/masters/product/productDetails");
		}
	}

	// delete product variants method

	public ModelAndView deleteProductVariants(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		String type = request.getParameter("type");

		if (null != type)
		{
			duplication(request, response);
		}

		String variantId1 = null;
		variantId1 = request.getParameter("variantList");
		
		log.info("-------------Variant List for Deletion--------------------" + variantId1);
		
		if (variantId1.equals("null"))
		{
			variantId1 = null;
		}

		String[] variantId = null;
		if (null != variantId1)
		{
			variantId = variantId1.split(",");
		}		
		
		HttpSession session2 = request.getSession();
		long id = ((List<ProductWrapper>) session2.getAttribute("productList")).get(0).getProduct().getId();

		log.info("-------------Variant []-----------"+variantId.toString());
		for (int i = 0; i < variantId.length; i++)
		{
			log.info("-------------For Loop-----------");
			
			String id2 = variantId[i];
			long id1 = Long.parseLong(id2);	
			
			log.info("-------------ID-----------"+id);
			log.info("-------------Loop ID1-----------"+id1);
			
			
			ProductVariant productVariant = new ProductVariant();			
			productVariant.setProductId(id1);
			productVariant.setVariantId(id);
			productVariant.setDeleteFlag("F");
						
			log.info("-------------Bean-----------"+productVariant.toString());
			boolean m = productService.softDeleteVariants(productVariant);
			log.info("-------------Deleted-------------"+m);
		}
		

		ProductVariant variant=new ProductVariant();
		variant.setProductId(id);
		List<ProductVariant> productVariantList= productService.doProductVariantsearch(variant);
		int size=0;
		int recosize=0;
		List<Long> variantListId1=null;
		HashMap<Long, ProductVariant> variantListId=null;
		
		//New map of Variant products (ids)
		HashMap<Long, ProductVariant> newVariantListId1=new HashMap<Long, ProductVariant>();
		
		// new list of Variant products (ids)
		List<Long> newVariantListId=new ArrayList<Long>(); 
		
		
		if(null!=variantId)
		{
			size=variantId.length;
			
			for(int i=0;i<size;i++)
			{
				newVariantListId1.put(Long.parseLong(variantId[i]),new ProductVariant());
			}

			for(int i=0;i<size;i++)
			{	
				newVariantListId.add(Long.parseLong(variantId[i]));
			}
		}
		
		if(!productVariantList.isEmpty())
		{
			recosize=productVariantList.size();
			log.info("---------------List of Variants to be deleted-------------------------"+recosize);
			variantListId1=new ArrayList<Long>(); //Existing Variant products list
		
			for(int i=0;i<recosize;i++)
			{
				variantListId1.add(productVariantList.get(i).getVariantId());
				log.info("---------------Parent Product Variant Bean-------------------------"+productVariantList.get(0));
			}
			
			// Old map of Variant products(ids and their beans)
			variantListId=new HashMap<Long, ProductVariant>();
			
			for(int i=0;i<recosize;i++)
			{
				variantListId.put(productVariantList.get(i).getVariantId(),productVariantList.get(i));				
			}	
		}
		
		if(null!=variantId)
		{
			size=variantId.length;
			
			if(!productVariantList.isEmpty())
			{	
				// if session product variants list is not empty
					
				for(int i=0;i<recosize;i++)
				{
					if(newVariantListId1.containsKey(variantListId1.get(i)))
					{
						variantListId.get(variantListId1.get(i)).setDeleteFlag("T");
						productService.editVariants(variantListId.get(variantListId1.get(i)));
					}
				}
				
				
				ProductWrapper productWrapper = new ProductWrapper();
				List<ProductWrapper> productVariantList1 = productService.productVariantList(productWrapper, id);
				List<Product>  productVariantListin=new ArrayList<Product>();
				
				int size1=productVariantList1.size();
				
				for(int i=0;i<size1;i++)
				{
					
					 productVariantListin.add(productVariantList1.get(i).getProduct());	
				}
				
				session2.setAttribute("productVariantListin", productVariantListin);
				
				log.info("-----just BEFORE SETTING THE Variant LIST ATTRIBUTE----------");
				
				session2.setAttribute("productVariantList", productVariantList);
				return new ModelAndView("/masters/product/productDetails");
			}
			else
			{	// if session-product variants list is empty
							
				return new ModelAndView("/masters/product/productDetails");
			}
		}
		else
		{
			return new ModelAndView("/masters/product/productDetails");
		}
		
	}

	public ModelAndView searchProductsForHotSpot(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		HttpSession session = request.getSession();
		String searchTags = request.getParameter("txtSearch");

		log.info("ProductController/searchProductsForHotSpot");

		if (searchTags == null)
		{
			return new ModelAndView("/masters/concept/hotspot_productSearch");
		}
		else
		{
			log.info("-----------In else where searchTag is not empty---------------");
			Product product = new Product();
			product.setDeleteFlag("F");
			product.setSearchTags(searchTags);
			List<Product> productListForHotSpot = productService.doProductListsearch(product);

			log.info("ProductController/editRecommendedProductList productList:"
					+ ((productListForHotSpot == null) ? "Null " : productListForHotSpot.size()));

			session.setAttribute("searchProductListForHotSpot", productListForHotSpot);
			return new ModelAndView("/conceptList/searchProductList");
		}
	}

}
