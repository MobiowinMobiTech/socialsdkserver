package com.mobicule.icatalog.image.Servlet;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.mobicule.component.system.springutil.SpringUtil;
import com.mobicule.icatalog.concept.service.ConceptService;

public class ImageServlet extends HttpServlet
{
	private static final long serialVersionUID = 1L;

	private Log log = LogFactory.getLog(this.getClass());

	public ImageServlet()
	{
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		ApplicationContext applicationContext = WebApplicationContextUtils
				.getRequiredWebApplicationContext(getServletContext());

		Map imageConfig = (Map) SpringUtil.getBean("imageConfig");
		List<String> imageBasePath = (List<String>) imageConfig.get("IMAGE_BASE_PATH");

		String entity = request.getParameter("entity");
		String imageName = null;
		String imagePath = null;
		log.info("------------Image Servlet------------Entity---------:" + entity);

		if (entity.equalsIgnoreCase("concept_category"))
		{
			String code = request.getParameter("image");
			log.info("------------Image Servlet------ConceptcategoryCode---------:" + code);

			ConceptService conceptService = (ConceptService) applicationContext.getBean("conceptService");

			if(code != null)
			{
				imageName = conceptService.getConceptCategoryImageCode(code);
				imagePath = imageBasePath.get(0) + "concept" + "/" + imageName + ".png";
			}
			else
			{
				/*imageName = conceptService.getConceptCategoryImageCode(code);*/
				imagePath = imageBasePath.get(0) + "default" + "/" + "default.png";
			}
			
		}
		else
		{
			imageName = request.getParameter("image");
			imagePath = imageBasePath.get(0) + entity + "/" + imageName + ".png";
		}

		FileInputStream fin = null;
		try
		{
			fin = new FileInputStream(imagePath);
			byte[] bytes = new byte[1024];
			while (fin.read(bytes) != -1)
			{
				response.getOutputStream().write(bytes);
			}

		}
		catch (Exception e)
		{
			defaultImage(request, response);
		}

	}

	private void defaultImage(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException
	{
		Map imageConfig = (Map) SpringUtil.getBean("imageConfig");
		List<String> imageBasePath = (List<String>) imageConfig.get("IMAGE_BASE_PATH");

		String entity = "default";
		String imageName = "default";
		String imagePath = imageBasePath.get(0) + entity + "/" + imageName + ".png";
		FileInputStream fin = null;

		fin = new FileInputStream(imagePath);
		byte[] bytes = new byte[1024];
		while (fin.read(bytes) != -1)
		{
			response.getOutputStream().write(bytes);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException
	{
		doGet(request, response);
	}
}
