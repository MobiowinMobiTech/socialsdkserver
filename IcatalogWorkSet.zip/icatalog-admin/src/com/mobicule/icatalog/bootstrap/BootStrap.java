package com.mobicule.icatalog.bootstrap;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.mobicule.icatalog.admin.common.CommonServices;



public class BootStrap implements ServletContextListener
{
	private Log log = LogFactory.getLog(getClass());

	@Override
	public void contextDestroyed(ServletContextEvent event) 
	{
		// TODO Auto-generated method stub
		
	}

	@Override
	public void contextInitialized(ServletContextEvent event)
	{
		try
		{
			log.info("****************Context Initialised***********************************");

			ServletContext context = event.getServletContext();

			CommonServices.setContextPathPath(context.getContextPath());

		}

		catch (Exception e)
		{
			e.printStackTrace();
			log.error("exception in bootstrap " + e);
		}
		catch (Throwable e)
		{
			e.printStackTrace();
			log.error("exception in bootstrap " + e);
		}
		
	}

}
