package com.mobicule.icatalog.login.authentication;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.mobicule.icatalog.systemuser.bean.SystemUser;

public class UserAuthenticationFilter implements Filter
{

	private FilterConfig filterConfig;

	private Log log = LogFactory.getLog(this.getClass());

	private static final String LOGIN_PAGE = "/pages/login/login.jsp";

	@Override
	public void destroy()
	{
		// TODO Auto-generated method stub
		filterConfig = null;

	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException,
			ServletException
	{
		// TODO Auto-generated method stub

		log.info("Inside UserAuthenticationFilter / doFilter()");

		HttpServletRequest httpRequest = (HttpServletRequest) request;
		HttpServletResponse httpResponse = (HttpServletResponse) response;

		HttpSession session = httpRequest.getSession(false);

		log.info("session : " + session);
		log.info("Relative Url : " + httpRequest.getRequestURI().substring(httpRequest.getContextPath().length()));

		if (filterConfig == null)
		{
			httpRequest.getRequestDispatcher(UserAuthenticationFilter.LOGIN_PAGE).forward(request, response);
		}
		else if (session == null)
		{
			httpRequest.getRequestDispatcher(UserAuthenticationFilter.LOGIN_PAGE).forward(request, response);
		}
		else
		{
			SystemUser userBean = (SystemUser) session.getAttribute("systemUser");

			String requestURI = httpRequest.getRequestURI();

			log.info("requestURI : " + requestURI);

			if (userBean == null)
			{
				log.info("User Session Not Verified.... Forwarding to login page....");

				httpRequest.getRequestDispatcher(UserAuthenticationFilter.LOGIN_PAGE).forward(request, response);
			}
			else
			{
				log.info("User Session Verified.... Forwarding to requested resource....");

				chain.doFilter(request, response);
			}
		}

	}

	@Override
	public void init(FilterConfig filterConfig) throws ServletException
	{

		this.filterConfig = filterConfig;

	}

}
