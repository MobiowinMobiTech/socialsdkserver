package com.mobicule.icatalog.login.authentication;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.mobicule.icatalog.product.bean.Product;

public class SessionURLFilter implements Filter 
{

	private Log log=LogFactory.getLog(this.getClass());
	private FilterConfig filterConfig;
	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		filterConfig = null;
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
	
		log.info("in doFilter method");
		
		HttpServletRequest httpRequest=(HttpServletRequest) request;
		HttpSession session=httpRequest.getSession();
		
		List<Product> recommendedProductList=(List<Product>)session.getAttribute("searchProductList");
		List<Product> productvariantList=(List<Product>)session.getAttribute("searchProductVariantList");
		
		//search options recommended products
		
		String searchTag=(String)session.getAttribute("recomendSearchName");
		
		String group=(String)session.getAttribute("recomendGroup");
		
		String chkClass=(String)session.getAttribute("recomendChkClass");
		
		String chkSubClass=(String)session.getAttribute("recomendChkSubClass");
		
		String chkDept=(String)session.getAttribute("recomendChkDept");
		
		String chkSubDept=(String)session.getAttribute("recomendChkSubDept");
		
		String chkBrand=(String)session.getAttribute("recomendChkBrand");
		
		//search options for variants
		
		String searchTag1=(String)session.getAttribute("variantSearchName");
		
		String group1=(String)session.getAttribute("variantGroup");
		
		String chkClass1=(String)session.getAttribute("variantChkClass");
		
		String chkSubClass1=(String)session.getAttribute("variantChkSubClass");
		
		String chkDept1=(String)session.getAttribute("variantChkDept");
		
		String chkSubDept1=(String)session.getAttribute("variantChkSubDept");
		
		String chkBrand1=(String)session.getAttribute("variantChkBrand");
		
		
		
		recommendedProductList=new ArrayList<Product>();
		productvariantList=new ArrayList<Product>();
		
		searchTag="";
		group="";
		chkClass=null;
		chkSubClass=null;
		chkDept=null;
		chkSubDept=null;
		chkBrand=null;
		
		searchTag1="";
		group1="";
		chkClass1=null;
		chkSubClass1=null;
		chkDept1=null;
		chkSubDept1=null;
		chkBrand1=null;
		session.setAttribute("searchProductList",recommendedProductList);
		session.setAttribute("searchProductVariantList",productvariantList);
		
		session.setAttribute("recomendSearchName",searchTag);
		
		session.setAttribute("recomendGroup",group);
		
		session.setAttribute("recomendChkClass",chkClass);
		
		session.setAttribute("recomendChkSubClass",chkSubClass);
		
		session.setAttribute("recomendChkDept",chkDept);
		
		session.setAttribute("recomendChkSubDept",chkSubDept);
		
		session.setAttribute("recomendChkBrand",chkBrand);
		
		
		session.setAttribute("variantSearchName",searchTag1);
		
		session.setAttribute("variantGroup",group1);
		
		session.setAttribute("variantChkClass",chkClass1);
		
		session.setAttribute("variantChkSubClass",chkSubClass1);
		
		session.setAttribute("variantChkDept",chkDept1);
		
		session.setAttribute("variantChkSubDept",chkSubDept1);
		
		session.setAttribute("variantChkBrand",chkBrand1);
		
		log.info("url filtered and  Session value cleared Verified.... Forwarding to requested resource....");

		chain.doFilter(request, response);
		
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
		this.filterConfig = filterConfig;
	}

}
