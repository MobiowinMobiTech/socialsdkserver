package com.mobicule.icatalog.login.authentication;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.mobicule.icatalog.systemuser.bean.Activity;
import com.mobicule.icatalog.systemuser.bean.Profile;
import com.mobicule.icatalog.systemuser.bean.ProfileActivityMapping;
import com.mobicule.icatalog.systemuser.bean.SystemUser;
import com.mobicule.icatalog.systemuser.service.ActivityService;
import com.mobicule.icatalog.systemuser.service.ProfileActivityService;
import com.mobicule.icatalog.systemuser.service.ProfileService;
import com.mobicule.icatalog.systemuser.service.SystemUserService;


public class UserAuthenticationController extends MultiActionController
{
	Log log = LogFactory.getLog(this.getClass());

	private SystemUserService systemUserService;

	private ProfileActivityService profileActivityService;
	
	private ActivityService activityService;
	
	private ProfileService profileService; 
	
	public ProfileService getProfileService() {
		return profileService;
	}

	public void setProfileService(ProfileService profileService) {
		this.profileService = profileService;
	}

	public ProfileActivityService getProfileActivityService() {
		return profileActivityService;
	}

	public void setProfileActivityService(
			ProfileActivityService profileActivityService) {
		this.profileActivityService = profileActivityService;
	}

	public ActivityService getActivityService() {
		return activityService;
	}

	public void setActivityService(ActivityService activityService) {
		this.activityService = activityService;
	}

	public SystemUserService getSystemUserService()
	{
		return systemUserService;
	}

	public void setSystemUserService(SystemUserService systemUserService)
	{
		this.systemUserService = systemUserService;
	}

	public ModelAndView login(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException
	{
		log.info("--------- In UserAuthenticationController /  login()");

		//HttpSession session = request.getSession();
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		log.info(" ----------- userName  ----------"+username);
		
		if ((username == null) || username.equalsIgnoreCase(""))
		{
			request.setAttribute("ENTER_USER_NAME", "ENTER USER NAME");
			return new ModelAndView("login/login");
		}

		if ((password == null) || password.equalsIgnoreCase(""))
		{
			request.setAttribute("ENTER_PASSWORD", "ENTER PASSWORD");
			return new ModelAndView("login/login");
		}

		SystemUser userBean = new SystemUser();

		userBean.setDeleteFlag("F");

		if ((username != null) && !username.equalsIgnoreCase(""))
		{
			userBean.setLogin(username);

		}

		if ((password != null) && !password.equalsIgnoreCase(""))
		{
			userBean.setPassword(password);

		}

		List<SystemUser> userBeans = systemUserService.authenticateUser(userBean);
		log.info(" ----------- size of userBeans  ----------" + userBeans.size());

		if ((userBeans == null) || (userBeans.size() == 0))
		{
			request.setAttribute("INVALID_USER", "LOGIN CREDENTIALS ARE NOT VALID. PLEASE TRY AGAIN");
			log.info("------------  User Not Found ------------");

			return new ModelAndView("login/login");
		}
		else if (userBeans.size() > 1)
		{
			request.setAttribute("INVALID_USER", "INVALID USER");
			log.info("------------ Invalid User ------------");

			return new ModelAndView("login/login");
		}
		else if (userBeans.size() == 1)
		{
			log.info("------------ valid User ------------");
			SystemUser systemUser = userBeans.get(0);
			
			HttpSession session=request.getSession();
			session.setAttribute("systemUser", systemUser);
			Profile profile=new Profile();
			profile.setId(systemUser.getProfileId());
			profile.setDeleteFlag("F");
			List<Profile> profileList= profileService.doCustomSearch(profile);
			List<ProfileActivityMapping> profileActivityMappingList =profileActivityService.doProfileActivityMappingSearch(profileList.get(0).getCode());
			
			List<Activity> activityList=new ArrayList<Activity>();
			Map<String, Activity> activityMap=new HashMap<String, Activity>();
			
			
			for(ProfileActivityMapping profileActivityMapping : profileActivityMappingList)
			{
				activityList.add(activityService.doActivitySearch(profileActivityMapping.getActivityCode()).get(0));
			}
			
			
			for(Activity activity : activityList)
			{
				activityMap.put(activity.getName(), activity);
			}
			session.setAttribute("activityMap", activityMap);
			if(activityMap.containsKey("ACCESS_USER_MODULE"))
			{
				request.getRequestDispatcher("/user.htm?method=getSystemUserList").forward(request, response);
			}
			else
			{
				request.getRequestDispatcher("/product.htm?method=getProductList").forward(request, response);
			}
		}

		return new ModelAndView("login/login");
	}
	
	public ModelAndView logout(HttpServletRequest request, HttpServletResponse response) throws ServletException,
	IOException
{
		log.info("----in logout method----");
		HttpSession session=request.getSession();
		session.removeAttribute("systemUser");
		request.setAttribute("LOGGED_OUT", "You have successfully logged out");
		
		return new ModelAndView("login/login");
}
}
