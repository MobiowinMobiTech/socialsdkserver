package com.mobicule.icatalog.admin.common;

public class IcatalogRequestConstants
{
	//ROLE
	public static final String ROLE_DELETION_SUCCESSFUL = "ROLE_DELETION_SUCCESSFUL";

	public static final String INVALID_ROLE = "INVALID_ROLE";

	//TERRITORY
	public static final String INVALID_TERRITORY = "INVALID_TERRITORY";

	//LOGIN
	public static final String INVALID_USER = "INVALID_USER";

	public static final String INVALID_USER_MESSAGE = "INVALID_USER_MESSAGE";

	public static final String USER_ADDITION_SUCCESSFUL = "USER_ADDITION_SUCCESSFUL";

	public static final String USER_ADDITION_SUCCESSFUL_MESSAGE = "User Successfully Added";

	public static final String USER_ADDITION_FAILED = "USER_ADDITION_FAILED";

	public static final String USER_ADDITION_FAILED_MESSAGE = "User Addition Failed";

	public static final String USER_PASSWORD_MISMATCH = "USER_PASSWORD_MISMATCH";

	public static final String USER_PASSWORD_MISMATCH_MESSAGE = "Password doesn't match with ConfirmPassword";

	public static final String USER_DELETION_SUCCESSFUL = "USER_DELETION_SUCCESSFUL";

	public static final String USER_DELETION_SUCCESSFUL_MESSAGE = "USER_DELETION_SUCCESSFUL_MESSAGE";

	public static final String USER_DELETION_FAILED = "USER_DELETION_FAILED";

	public static final String USER_DELETION_FAILED_MESSAGE = "USER_DELETION_FAILED_MESSAGE";

	public static final String USER_SEARCH = "USER_SEARCH";

	public static final String MARKET_SURVEYBEAN_LIST_DETAILS = "MARKET_SURVEYBEAN_LIST_DETAILS";

	public static final String STOCK_LEVEL_TYPE = "stockLevelType";
}