package com.mobicule.icatalog.admin.common;

public class IcatalogSessionConstants
{
	//ROLE
	public static final String ROLE_LIST = "ROLE_LIST";

	public static final String ROLE_SUB_WORKBENCH_LIST = "ROLE_SUB_WORKBENCH_LIST";

	public static final String ROLE_SUB_WORKBENCH_STATUS = "ROLE_SUB_WORKBENCH_STATUS";

	public static final String ROLE_SUB_WORKBENCH_BEAN = "ROLE_SUB_WORKBENCH_BEAN";

	public static final String TERRITORY_ASSIGNED_TO_ROLE = "TERRITORY_ASSIGNED_TO_ROLE";

	public static final String TERRITORY_UNASSIGNED_TO_ROLE = "TERRITORY_UNASSIGNED_TO_ROLE";

	//TERRITORY
	public static final String TERRITORY_LIST = "TERRITORY_LIST";

	public static final String TERRITORY_SUB_WORKBENCH_STATUS = "TERRITORY_SUB_WORKBENCH_STATUS";

	public static final String TERRITORY_SUB_WORKBENCH_BEAN = "TERRITORY_SUB_WORKBENCH_BEAN";

	//LOGIN
	public static final String USER_LIST = "USER_LIST";

	public static final String USER_SUB_WORKBENCH_BEANS = "USER_SUB_WORKBENCH_BEANS";

	public static final String USER_SUB_WORKBENCH_TITLE = "Territory";

	public static final String USER_SUB_WORKBENCH_STATUS = "USER_SUB_WORKBENCH_STATUS";

	//Mareket Survey
	public static final String MARKET_SURVEYBEAN_LIST = "MARKET_SURVEYBEAN_LIST";
	
	//SALES STOCK
	public static final String STOCKLIST = "stockList";
	public static final String STOCKENTRYLIST = "stockEntryList";

	
}