/**
******************************************************************************
* C O P Y R I G H T  A N D  C O N F I D E N T I A L I T Y  N O T I C E
* <p>
* Copyright © 2008-2009 Mobicule Technologies Pvt. Ltd. All rights reserved.
* This is proprietary information of Mobicule Technologies Pvt. Ltd.and is
* subject to applicable licensing agreements. Unauthorized reproduction,
* transmission or distribution of this file and its contents is a
* violation of applicable laws.
******************************************************************************
*
* @project msales-core
*/
package com.mobicule.icatalog.admin.common;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
*
* <enter description here>
*
* @author hardeep <enter lastname>
* @see
*
* @createdOn Sep 16, 2010
* @modifiedOn
*
* @copyright © 2008-2009 Mobicule Technologies Pvt. Ltd. All rights reserved.
*/
public class CommonServices
{
	private static Log log = LogFactory.getLog(CommonServices.class);

	private static String crossImgHtml;
	private static String proccessingImgPath;
	private static String tickImgHtml;
	private static String pattern="#########";
	private static String doubleToString;
	
	public static String getProccessingImgHtml()
	{
		return proccessingImgPath;
	}

	public static String getCrossImgHtml()
	{
		return crossImgHtml;
	}

	public static String getTickImgHtml()
	{
		return tickImgHtml;
	}

	public static void setContextPathPath(String contextPath)
	{
		proccessingImgPath = "<img alt=\"Please wait..\" src=\"" + contextPath + IcatalogConstants.IMG_PROCESSING_PATH
				+ "\">";
		crossImgHtml = "<img alt=\"\" src=\"" + contextPath + IcatalogConstants.IMG_CROSS_PATH + "\">";
		tickImgHtml = "<img alt=\"\" src=\"" + contextPath + IcatalogConstants.IMG_TICK_PATH + "\">";
	}
	
	public static String doubleToLong(Double price)
	{
		  DecimalFormat deciFormat= new DecimalFormat(pattern);
	      doubleToString = deciFormat.format(price);  
		return doubleToString;
	}
}
