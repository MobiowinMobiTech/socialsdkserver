/**
******************************************************************************
* C O P Y R I G H T  A N D  C O N F I D E N T I A L I T Y  N O T I C E
* <p>
* Copyright © 2008-2009 Mobicule Technologies Pvt. Ltd. All rights reserved. 
* This is proprietary information of Mobicule Technologies Pvt. Ltd.and is 
* subject to applicable licensing agreements. Unauthorized reproduction, 
* transmission or distribution of this file and its contents is a 
* violation of applicable laws.
******************************************************************************
*
* @project icatalog-admin
*/
package com.mobicule.icatalog.customer.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.mobicule.icatalog.concept.bean.Concept;
import com.mobicule.icatalog.concept.service.ConceptService;
import com.mobicule.icatalog.customer.bean.Customer;
import com.mobicule.icatalog.customer.bean.CustomerShortlist;
import com.mobicule.icatalog.customer.service.CustomerService;
import com.mobicule.icatalog.customer.service.CustomerShortlistService;
import com.mobicule.icatalog.product.bean.Product;
import com.mobicule.icatalog.product.bean.ProductWrapper;
import com.mobicule.icatalog.product.service.ProductService;
import com.mobicule.icatalog.systemuser.bean.SystemUser;
import com.mobicule.icatalog.systemuser.service.SystemUserService;

/**
* 
* <enter description here>
*
* @author himanshu <Singh>
* @see 
*
* @createdOn 14-May-2012
* @modifiedOn
*
* @copyright © 2008-2009 Mobicule Technologies Pvt. Ltd. All rights reserved.
*/
public class CustomerShortlistController extends MultiActionController
{
	private Log log = LogFactory.getLog(this.getClass());
	
	private CustomerShortlistService customerShortlistService;
	
	private CustomerService customerService;
	
	private ProductService productService;
	
	private ConceptService conceptService;
	
	private SystemUserService systemUserService;	
		
	public CustomerShortlistService getCustomerShortlistService()
	{
		return customerShortlistService;
	}

	public void setCustomerShortlistService(CustomerShortlistService customerShortlistService)
	{
		this.customerShortlistService = customerShortlistService;
	}

	public CustomerService getCustomerService()
	{
		return customerService;
	}

	public void setCustomerService(CustomerService customerService)
	{
		this.customerService = customerService;
	}

	public ProductService getProductService()
	{
		return productService;
	}

	public void setProductService(ProductService productService)
	{
		this.productService = productService;
	}

	public ConceptService getConceptService()
	{
		return conceptService;
	}

	public void setConceptService(ConceptService conceptService)
	{
		this.conceptService = conceptService;
	}
		
	public SystemUserService getSystemUserService()
	{
		return systemUserService;
	}

	public void setSystemUserService(SystemUserService systemUserService)
	{
		this.systemUserService = systemUserService;
	}

	public ModelAndView getCustomerList(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		Customer customer = new Customer(); 
		customer.setDeleteFlag(ICatalogConstants.FALSE_FLAG);
				
		List<Customer> customerList = customerService.search(customer);

		log.info("======In getCustomerList====Size of List=====::"+ 
		((customerList == null) ? "Null" : customerList.size()));

		HttpSession session = request.getSession(); 
		session.setAttribute("customerList", customerList);

		return new ModelAndView("/masters/customer/customerWorkbench");
	}
	
	public ModelAndView getCustomerSearch(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		String name = request.getParameter("searchName");
				
		log.info("==========In getCustomerList======Value of Customer_Name:::======"+name);
		
		Customer customer = new Customer(); 
		customer.setName(name);
		customer.setDeleteFlag(ICatalogConstants.FALSE_FLAG);
						
		List<Customer> customerList = customerService.CustomSearch(customer);
		
		log.info("======In getCustomerSearch====Size of customerList=====::"+ 
				((customerList == null) ? "Null" : customerList.size()));
		
		
		HttpSession session = request.getSession(); 
		session.setAttribute("customerList", customerList);

		return new ModelAndView("/masters/customer/customerWorkbench");
	}
	
	public ModelAndView getCustomerdetails(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		log.info("====In Controller======In getCustomerdetails(Super Method)============");
		
		String code = request.getParameter("code");
		long id = Long.parseLong(code);
				
		Customer customer = new Customer(); 
		customer.setId(id);
		customer.setDeleteFlag(ICatalogConstants.FALSE_FLAG);
						
		List<Customer> customerList = customerService.doCustomSearch(customer);
		
		log.info("======Customer Details====Size of CustomerList=====::"+ 
				((customerList == null) ? "Null" : customerList.size()));
		
		log.info("======Customer Details=======Customer List Using ID=====::"+customerList);
		
		CustomerShortlist customerShortlist = new CustomerShortlist();
		customerShortlist.setCustomerId(id);
		customerShortlist.setDeleteFlag(ICatalogConstants.FALSE_FLAG);
		
		List<CustomerShortlist> customerShortlistList = customerShortlistService.doCustomSearch(customerShortlist);
		
		log.info("======In getCustomerdetails====Size of customerShortlistList=====::"+ 
				((customerShortlistList == null) ? "Null" : customerShortlistList.size()));
		
		log.info("======Customer Shortlist Details=======CustomerShortList Using ID=====::"+customerList);
		
		
		List<Concept> conceptList = new ArrayList<Concept>();
		List<SystemUser> systemUserList = new ArrayList<SystemUser>();
		List<ProductWrapper> productWrapperList = new ArrayList<ProductWrapper>();
		double totalPrice=0;
		
				
		for (int i = 0; i < customerShortlistList.size(); i++) 
		{
			System.out.println("================In For Loop================="+customerShortlistList.get(i));
			
			CustomerShortlist customerShortlist2 = customerShortlistList.get(i);
			
			long userId = customerShortlist2.getUserId();
			System.out.println("======Value of User Id=======:"+userId);
			
			String itemType  = customerShortlist2.getShortlistedItemType();
			System.out.println("======Value of ItemType=======:"+itemType);
			
			String itemCode = customerShortlist2.getShortlistedItemCode();
			System.out.println("======Value of ItemCode=======:"+itemCode);
			String product = "PRODUCT";
			String concept = "CONCEPT";
			
			// For getting latest user...
			SystemUser systemUser = new SystemUser();
			systemUser.setId(userId);
			systemUser.setDeleteFlag("F");
			systemUserList = systemUserService.doCustomSearch(systemUser);
			
			System.out.println("===============After Getting Last User========User List====:"+systemUserList);
									
			if(itemType != "")
			{
			
				if(itemType.equalsIgnoreCase(product))
				{
					System.out.println("======In IF-Else====Method for getting Product Details===");
					
					ProductWrapper productWrapper = searchProductWrapper(itemCode);
					double price;
					
					if(productWrapper.getPrice() != null)
					{
						price = productWrapper.getPrice().getRetailPrice();
						totalPrice = totalPrice + price;
						
					}
					else
					{
						price = 0;
						totalPrice = totalPrice + price;
					}
					productWrapperList.add(productWrapper);
														
					System.out.println("======After Getting Bean of ProductWrapper==="+productWrapper);
					
					
										
					
					
				}
				if(itemType.equalsIgnoreCase(concept))
				{
					System.out.println("======In IF-ELSE====Method for getting Concept Details===");
					
					Concept concept2 = SearchConcept(itemCode);
					double price;
					
					if(concept2 != null)
					{	
						price = concept2.getRetailPrice();
						totalPrice = totalPrice + price;
						
					}
					else
					{
						price = 0;
						totalPrice = totalPrice + price;
					}
					conceptList.add(concept2);
									
				}
				
			}
						
		}
		
		HttpSession session = request.getSession(); 
		session.setAttribute("customerList", customerList);
		session.setAttribute("customerShortlistList", customerShortlistList);
		request.setAttribute("productWrapperList", productWrapperList);
		session.setAttribute("conceptList", conceptList);
		session.setAttribute("systemUserList", systemUserList);
		session.setAttribute("totalPrice", totalPrice);
		
		
		return new ModelAndView("/masters/customer/customerDetails");
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @return
	 *
	 * @author himanshu
	 * @createdOn 15-May-2012
	 * @modifiedOn 15-May-2012 
	 * 
	 */
	private Concept SearchConcept(String code)
	{
		log.info("======Code=====:"+code);
		
		Concept conceptBean = new Concept();
		conceptBean.setCode(code);
		conceptBean.setDeleteFlag("F");

		List<Concept> ConceptList = conceptService.search(conceptBean);

		log.info("=====List of Concept in searchConcept method===Size of list========"
				+ ((ConceptList == null) ? "Null " : ConceptList.size()));
		
		Concept concept = new Concept();
		System.out.println("=========In Concept Search Method==============Value of Concept When Initialized==============="+concept);
		if(ConceptList != null)
		{
			concept = ConceptList.get(0);
			return concept;
		}
				
		return concept;
	}

	/**
	 * <enter description here>
	 *
	 * <li>pre-condition <enter text> 
	 * <li>post-condition <enter text> 
	 *
	 * @return
	 *
	 * @author himanshu
	 * @createdOn 15-May-2012
	 * @modifiedOn 15-May-2012 
	 * 
	 */
		
	private ProductWrapper searchProductWrapper(String code)
	{
		log.info("======In Product Wrapper Method=====:");
		log.info("======Code=====:"+code);
		
		Product productBean = new Product();
		productBean.setSearchTags(code);
		productBean.setDeleteFlag("F");

		List<ProductWrapper> productWrapperList = productService.doCustomSearch(productBean);

		System.out.println("=====List of ProductWrapper in searchProduct method===Size of list====="
				+ ((productWrapperList == null) ? "Null " : productWrapperList.size()));
		
		ProductWrapper productWrapper = new ProductWrapper();
				
		if(productWrapperList != null)
		{	
			productWrapper = productWrapperList.get(0);
			return productWrapper;
		}
						
		return productWrapper;
	}
	
}
