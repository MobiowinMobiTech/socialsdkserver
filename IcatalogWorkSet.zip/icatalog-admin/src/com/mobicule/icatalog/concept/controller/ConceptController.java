/**
 ******************************************************************************
 * C O P Y R I G H T  A N D  C O N F I D E N T I A L I T Y  N O T I C E
 * <p>
 * Copyright © 2008-2009 Mobicule Technologies Pvt. Ltd. All rights reserved. 
 * This is proprietary information of Mobicule Technologies Pvt. Ltd.and is 
 * subject to applicable licensing agreements. Unauthorized reproduction, 
 * transmission or distribution of this file and its contents is a 
 * violation of applicable laws.
 ******************************************************************************
 *
 * @project icatalog-admin
 */
package com.mobicule.icatalog.concept.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Timestamp;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.me.JSONArray;
import org.json.me.JSONException;
import org.json.me.JSONObject;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.mobicule.icatalog.admin.common.CommonServices;
import com.mobicule.icatalog.concept.bean.Concept;
import com.mobicule.icatalog.concept.bean.ConceptCategory;
import com.mobicule.icatalog.concept.bean.ConceptHotspotMapping;
import com.mobicule.icatalog.concept.service.ConceptCategoryService;
import com.mobicule.icatalog.concept.service.ConceptService;
import com.mobicule.icatalog.core.common.ICatalogConstants;
import com.mobicule.icatalog.product.bean.Product;
import com.mobicule.icatalog.product.bean.ProductWrapper;
import com.mobicule.icatalog.product.service.ProductService;
import com.mobicule.icatalog.systemuser.bean.SystemUser;

/**
 * 
 * <enter description here>
 * 
 * @author shalini <Nair>
 * @see
 * 
 * @createdOn 19-Apr-2012
 * @modifiedOn
 * 
 * @copyright © 2008-2009 Mobicule Technologies Pvt. Ltd. All rights reserved.
 */
public class ConceptController extends MultiActionController
{
	private Log log = LogFactory.getLog(this.getClass());

	private ConceptService conceptService;

	private ProductService productService;

	private ConceptCategoryService conceptCategoryService;

	private Map<String, List<String>> imageConfig;

	public Map<String, List<String>> getImageConfig()
	{
		return imageConfig;
	}

	public void setImageConfig(Map<String, List<String>> imageConfig)
	{
		this.imageConfig = imageConfig;
	}

	public ConceptService getConceptService()
	{
		return conceptService;
	}

	public void setConceptService(ConceptService conceptService)
	{
		this.conceptService = conceptService;
	}

	public ConceptCategoryService getConceptCategoryService()
	{
		return conceptCategoryService;
	}

	public void setConceptCategoryService(ConceptCategoryService conceptCategoryService)
	{
		this.conceptCategoryService = conceptCategoryService;
	}

	public ProductService getProductService()
	{
		return productService;
	}

	public void setProductService(ProductService productService)
	{
		this.productService = productService;
	}

	public ModelAndView addConcept(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException
	{
		log.info("---------In ConceptController / addConcept()----------");

		HttpSession httpSession = request.getSession();
		SystemUser userloggedIn = (SystemUser) httpSession.getAttribute("systemUser");

		List<String> errorList = new Vector<String>();
		Concept concept = (Concept) httpSession.getAttribute("deleted_concept_code");

		if (null == concept)
		{
			log.info("=========Adding new Concept===================");
			Concept ConceptBean = getConceptBean(request, null, errorList);
			ConceptBean.setDeleteFlag("F");
			ConceptBean.setModifiedBy(userloggedIn.getId());
			ConceptBean.setCreatedBy(userloggedIn.getId());
			conceptService.add(ConceptBean);

			log.info("Concept added");
			log.info("imageCode = " + request.getAttribute("conceptCode"));

			String imageServletUrl = getImageServletUrl("concept", (String) request.getAttribute("conceptCode"));

			String conceptJson = conceptService.getImageWithHotSpot(ConceptBean, imageServletUrl);

			httpSession.setAttribute("concept", conceptJson);
			request.getRequestDispatcher("concept.htm?method=listHotSpots").forward(request, response);

		}
		else
		{
			log.info("=========Updating Concept with Delete_Flag======================");
			getConceptBean(request, concept, errorList);
			concept.setDeleteFlag("F");
			concept.setModifiedBy(userloggedIn.getId());
			concept.setCreatedBy(userloggedIn.getId());
			conceptService.update(concept);
			httpSession.setAttribute("deleted_concept_code", null);

			log.info("Concept added");
			log.info("imageCode = " + request.getAttribute("conceptCode"));

			String imageServletUrl = getImageServletUrl("concept", (String) request.getAttribute("conceptCode"));

			String conceptJson = conceptService.getImageWithHotSpot(concept, imageServletUrl);

			httpSession.setAttribute("concept", conceptJson);
			request.getRequestDispatcher("concept.htm?method=listHotSpots").forward(request, response);

		}

		return null;

	}

	/*private Boolean checkRequestParam(HttpServletRequest request,
			List<String> errorList) {
		log.info("request conceptfile =" + request.getParameter("conceptfile"));
		Boolean isValid = true;
		if (null == request.getParameter("txtCode").trim()
				|| request.getParameter("txtCode").equals("")) {
			isValid = false;
			errorList.add("Please enter valid concept code");
		} else {
			List<Concept> conceptList = conceptService
					.getConceptBeanList(request.getParameter("txtCode"));

			if (conceptList.size() > 0) {
				isValid = false;
				errorList.add("Concept code already exists");
			}
		}
		return isValid;
	}*/

	/**
	 * <enter description here>
	 * 
	 * <li>pre-condition <enter text> <li>post-condition <enter text>
	 * 
	 * @param request
	 * @param object
	 * @return
	 * 
	 * @author shalini
	 * @param errorList
	 * @throws Exception
	 * @createdOn 19-Apr-2012
	 * @modifiedOn 19-Apr-2012
	 * 
	 */
	private Concept getConceptBean(HttpServletRequest request, Concept existingConcept, List<String> errorList)
	{
		log.info("==================== getConceptBean Method =======================");

		int count = 0;
		String conceptImagePath = null;
		String conceptImageLocation = null;
		String code = null;
		List<String> imageBasePath = (List<String>) imageConfig.get("IMAGE_BASE_PATH");
		List<String> imageDirectoryNames = (List<String>) imageConfig.get("IMAGE_DIRECTORY_NAMES");

		String imageExtension = null;
		if (existingConcept == null)
		{
			existingConcept = new Concept();
		}

		code = request.getParameter("txtCode");
		String name = request.getParameter("txtName");
		log.info("--- Code  ---" + code);
		log.info("---------name----------" + name);
		String description = request.getParameter("txtDescription");
		Long category = Long.parseLong(request.getParameter("category"));
		String giftFlag = request.getParameter("giftFlag");
		Double retailPrice = null;

		if (request.getParameter("txtRetail") != null && !request.getParameter("txtRetail").equalsIgnoreCase(""))
		{
			retailPrice = Double.parseDouble(request.getParameter("txtRetail"));
		}

		Double offerPrice = null;

		if (request.getParameter("txtOffer") != null && !request.getParameter("txtOffer").equalsIgnoreCase(""))
		{
			offerPrice = Double.parseDouble(request.getParameter("txtOffer"));

		}

		String searchTag = request.getParameter("txtSearchTag");
		String brand = request.getParameter("txtBrand");

		log.info("--- Code  ---" + code);
		log.info("---------name----------" + name);

		// IMAGE UPLOAD STARTS

		Assert.state(request.getParameter("type").equals("genericFileMulti"), "type != genericFileMulti");

		final MultipartHttpServletRequest multiRequest = (MultipartHttpServletRequest) request;

		final Map files = multiRequest.getFileMap();

		List<Object> filesList = new Vector<Object>(files.values());

		for (Object object : filesList)
		{
			CommonsMultipartFile commonsMultipartFile = (CommonsMultipartFile) object;
			if (!commonsMultipartFile.isEmpty())
			{
				count++;
			}
		}

		log.info("count is::" + count);

		for (Object object : filesList)
		{
			System.out.println("class name : " + object.getClass());
			CommonsMultipartFile commonsMultipartFile = (CommonsMultipartFile) object;
			log.info("\n\nOriginalFilename = " + commonsMultipartFile.getOriginalFilename());
			log.info("ContentType = " + commonsMultipartFile.getContentType());
			log.info("Name = " + commonsMultipartFile.getName());
			log.info("Size = " + commonsMultipartFile.getSize());
			log.info("StorageDescription " + commonsMultipartFile.getStorageDescription());

			String fileName = commonsMultipartFile.getOriginalFilename().toLowerCase();
			log.info("fileName is:" + fileName);

			int indexOfDot = fileName.lastIndexOf(".");

			String extension = fileName.substring(indexOfDot + 1);

			log.info("extension is::" + extension.toLowerCase());

			String basedir = imageBasePath.get(0);
			//String basedir = SyncConstants.IMGPATH;

			if (commonsMultipartFile.getName().equalsIgnoreCase("conceptfile"))
			{
				log.info("in conceptfile");
				log.info("file name is::" + fileName);

				int lastIndex = fileName.lastIndexOf(".");

				log.info("lastIndex is::" + lastIndex);
				imageExtension = fileName.substring(lastIndex);
				log.info("extension is::" + imageExtension);

				conceptImagePath = imageDirectoryNames.get(0) + "/";
				//conceptImagePath = "concept/";

				conceptImageLocation = basedir + conceptImagePath;

				log.info("conceptImageLocation is::" + conceptImageLocation);

				existingConcept.setImageModifiedOn(new Timestamp(System.currentTimeMillis()));

				request.setAttribute("conceptCode", code);

				try
				{
					saveEmailImage(conceptImageLocation, commonsMultipartFile, code, imageExtension);
				}
				catch (Exception e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}

		}

		// IMAGE UPLOAD ENDS

		// writeImageToServer(imageFile);

		if ((code != null) && !code.equalsIgnoreCase(""))
		{
			existingConcept.setCode(code);
		}

		if ((name != null) && !name.equalsIgnoreCase(""))
		{
			existingConcept.setName(name);
		}

		if ((description != null) && !description.equalsIgnoreCase(""))
		{
			existingConcept.setDescription(description);
		}
		else
		{
			existingConcept.setDescription("");
		}

		if ((category != 0))
		{

			existingConcept.setCategoryId(category);
		}

		if ((brand != null) && !brand.equalsIgnoreCase(""))
		{
			existingConcept.setBrand(brand);
		}
		else
		{
			existingConcept.setBrand("");
		}

		if ((searchTag != null) && !searchTag.equalsIgnoreCase(""))
		{
			existingConcept.setSearchTags(searchTag);
		}
		else
		{
			existingConcept.setSearchTags("");
		}

		if ((retailPrice != null) && (retailPrice != 0.0))
		{
			existingConcept.setRetailPrice(retailPrice);
		}

		if ((offerPrice != null) && (offerPrice != 0.0))
		{
			existingConcept.setOfferFlag("Y");
			existingConcept.setOfferPrice(offerPrice);
		}
		else
		{
			existingConcept.setOfferFlag("N");
		}

		existingConcept.setGiftFlag(giftFlag);

		/*existingConcept.setModifiedBy(1989L);
		existingConcept.setCreatedBy(1989L);*/

		return existingConcept;
	}

	private void saveEmailImage(String basedir, MultipartFile multipartFile, String code, String extension)
			throws Exception
	{
		File localEmailDir = new File(basedir);
		if (!localEmailDir.exists())
		{
			localEmailDir.mkdirs();

			File emaildir = new File(localEmailDir, code + extension);

			FileOutputStream fileOutputStream = new FileOutputStream(emaildir);
			fileOutputStream.write(multipartFile.getBytes());

		}
		else
		{
			File emaildir = new File(localEmailDir, code + extension);

			FileOutputStream fileOutputStream = new FileOutputStream(emaildir);
			fileOutputStream.write(multipartFile.getBytes());

		}

	}

	public ModelAndView getConceptList(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{

		HttpSession session = request.getSession();

		Concept concept = new Concept();
		concept.setDeleteFlag("F");
		List<Concept> conceptList = conceptService.doCustomSearch(concept);

		log.info("ConceptController/getConceptList conceptList:"
				+ ((conceptList == null) ? "Null " : conceptList.size()));

		ConceptCategory conceptCategory = new ConceptCategory();
		conceptCategory.setDeleteFlag("F");
		List<ConceptCategory> conceptCategoryList = conceptCategoryService.search(conceptCategory);

		log.info("ConceptController/getConceptcategoryList conceptCategoryList:"
				+ ((conceptCategoryList == null) ? "Null " : conceptCategoryList.size()));

		session.setAttribute("conceptList", conceptList);
		session.setAttribute("conceptCategoryList", conceptCategoryList);

		return new ModelAndView("/masters/concept/conceptWorkbench");

	}

	public ModelAndView searchConcept(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{

		log.info("============ConceptController/searchConcept===============");

		String name = request.getParameter("searchName");
		String searchCat = request.getParameter("searchCategory");
		Long conceptCategoryId = Long.parseLong(searchCat);

		Concept searchConcept = new Concept();
		searchConcept.setName(name);
		searchConcept.setDeleteFlag("F");

		HttpSession session = request.getSession();

		if (conceptCategoryId != -1)
		{
			log.info("=========With Concept Category==========ConceptCategoryId===:::" + conceptCategoryId);

			List<Concept> conceptList = conceptService.customSearch(searchConcept, conceptCategoryId);

			log.info("===After Returning from Dao Layer in Controller=====" + conceptList.size());

			session.setAttribute("conceptList", conceptList);
			return new ModelAndView("/masters/concept/conceptWorkbench");
		}

		System.out.println("================Without Concept Category===============");

		List<Concept> conceptList = conceptService.doCustomSearch(searchConcept);
		session.setAttribute("conceptList", conceptList);

		return new ModelAndView("/masters/concept/conceptWorkbench");

	}

	public ModelAndView deleteConcept(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		String code = request.getParameter("code");

		log.info("--------Code for deletion------------------in deleteConceptCategory-----" + code);

		Concept existingConcept = fetchExistingConcept(code);

		if (existingConcept != null)
		{
			conceptService.delete(existingConcept);
			return getConceptList(request, response);
		}
		else
		{
			request.setAttribute("errorMsg", "Code does not exists...");
			return new ModelAndView("/masters/concept/conceptWorkbench");
		}
	}

	private Concept fetchExistingConcept(String code)
	{
		Concept searchConcept = new Concept();
		searchConcept.setCode(code);

		List<Concept> searchResult = conceptService.search(searchConcept);

		if (CollectionUtils.isEmpty(searchResult))
		{
			return null;
		}

		if (searchResult.size() > 1)
		{
			throw new RuntimeException("Duplicate Records Found...");
		}

		return searchResult.get(0);
	}

	public ModelAndView addHotSpotServlet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{

		String newHotspot = request.getParameter("new_hotspot");

		HttpSession httpSession = request.getSession();

		String concept = (String) httpSession.getAttribute("concept");
		SystemUser userloggedIn = (SystemUser) httpSession.getAttribute("systemUser");
		log.info("In addHotSpotServlet / concept = " + concept);
		try
		{
			JSONObject conceptJson = new JSONObject(concept);
			JSONArray hotspotArray = conceptJson.getJSONArray("hotspot_definition");
			JSONObject newHotspotJson = new JSONObject(newHotspot);

			ConceptHotspotMapping conceptHotspotMapping = new ConceptHotspotMapping();
			conceptHotspotMapping.setConceptId((conceptJson.getLong("id")));
			conceptHotspotMapping.setHotspotX(newHotspotJson.getLong("x_coordinate"));
			conceptHotspotMapping.setHotspotY(newHotspotJson.getLong("y_coordinate"));
			conceptHotspotMapping.setProductId(newHotspotJson.getLong("product_id"));
			conceptHotspotMapping.setCreatedOn(new Timestamp(System.currentTimeMillis()));
			conceptHotspotMapping.setCreatedBy(userloggedIn.getId());
			conceptHotspotMapping.setModifiedOn(new Timestamp(System.currentTimeMillis()));
			conceptHotspotMapping.setModifiedBy(userloggedIn.getId());
			conceptHotspotMapping.setDeleteFlag("F");

			Boolean isAdded = conceptService.addHotspot(conceptHotspotMapping);

			if (isAdded)
			{

				ConceptHotspotMapping conceptHotspotMappingBean = conceptService
						.getConceptHotspotMappingBean(conceptHotspotMapping);
				newHotspotJson.put("hotspot_mapping_id", conceptHotspotMappingBean.getId());
				hotspotArray.put(newHotspotJson);

				httpSession.setAttribute("concept", conceptJson.toString());
				log.info("In addHotSpotServlet / Updated conceptJson = " + conceptJson);
				request.getRequestDispatcher("concept.htm?method=listHotSpots").forward(request, response);

			}
			else
			{

				httpSession.setAttribute("concept", concept);
				request.setAttribute("error", "Error in inserting database");
				log.info("In addHotSpotServlet / old concept = " + concept);
				request.getRequestDispatcher("pages/masters/concept/concept_hotspot.jsp").forward(request, response);
			}

		}
		catch (JSONException e)
		{
			e.printStackTrace();
		}
		return null;
	}

	public ModelAndView deleteHotSpotServlet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		try
		{
			HttpSession httpSession = request.getSession();
			SystemUser userloggedIn = (SystemUser) httpSession.getAttribute("systemUser");

			String concept = (String) httpSession.getAttribute("concept");
			log.info("In deleteHotSpotServlet / concept = " + concept);
			JSONObject conceptJson = new JSONObject(concept);

			JSONArray hotspotArray = conceptJson.getJSONArray("hotspot_definition");

			String deletedHotspot = request.getParameter("deleted_hotspot");

			log.info(" In deleteHotSpotServlet / deletedHotspot = " + deletedHotspot);
			JSONObject deletedHotspotJson = new JSONObject(deletedHotspot);

			JSONObject currentJson = null;
			ConceptHotspotMapping conceptHotspotMappingBean = new ConceptHotspotMapping();
			JSONArray newHotspotArray = new JSONArray();

			for (int i = 0; i < hotspotArray.length(); i++)
			{
				currentJson = hotspotArray.getJSONObject(i);

				if ((currentJson.getInt("x_coordinate") == deletedHotspotJson.getInt("x_coordinate"))
						&& (currentJson.getInt("y_coordinate") == deletedHotspotJson.getInt("y_coordinate")))
				{

					conceptHotspotMappingBean.setId(currentJson.getLong("hotspot_mapping_id"));
					conceptHotspotMappingBean.setConceptId(conceptJson.getLong("id"));
					conceptHotspotMappingBean.setHotspotX(deletedHotspotJson.getLong("x_coordinate"));
					conceptHotspotMappingBean.setHotspotY(deletedHotspotJson.getLong("y_coordinate"));
					conceptHotspotMappingBean.setProductId(currentJson.getLong("product_id"));
					conceptHotspotMappingBean.setDeleteFlag("F");
					conceptHotspotMappingBean.setModifiedBy(userloggedIn.getId());
					conceptHotspotMappingBean.setModifiedOn(new Timestamp(System.currentTimeMillis()));
					continue;
				}

				newHotspotArray.put(currentJson);
			}

			conceptJson.put("hotspot_definition", newHotspotArray);
			Boolean isDeleted = false;

			if (conceptHotspotMappingBean != null)
			{
				isDeleted = conceptService.deleteConceptHotSpotMapping(conceptHotspotMappingBean);
			}

			if (isDeleted)
			{

				httpSession.setAttribute("concept", conceptJson.toString());
				request.getRequestDispatcher("concept.htm?method=listHotSpots").forward(request, response);
			}
			else
			{
				request.setAttribute("error", "Error in updating database");
				httpSession.setAttribute("concept", concept);
				request.getRequestDispatcher("pages/masters/concept/concept_hotspot.jsp").forward(request, response);
			}
		}
		catch (JSONException e)
		{
			e.printStackTrace();
		}
		return null;
	}

	public ModelAndView hotSpotDetailsServlet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{

		HttpSession session = request.getSession();
		Long productId = Long.parseLong(request.getParameter("productId"));
		System.out.println("-----in concept controller-----productId---------" + productId);
		Product product = new Product();
		product.setId(productId);
		List<ProductWrapper> productWrapperList = productService.doCustomSearch(product);
		ProductWrapper productWrapper = productWrapperList.get(0);
		log.info("----*****========----product----=========******------" + productWrapper);
		request.setAttribute("productHotSpot", productWrapper);
		return new ModelAndView("conceptList/productHotSpotDetails");
	}

	public ModelAndView listHotSpots(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException
	{

		HttpSession httpSession = request.getSession();

		String concept = (String) httpSession.getAttribute("concept");
		Concept detailConceptBean = (Concept) request.getAttribute("detailConceptBean");
		if (null == concept)
		{
			request.getRequestDispatcher("pages/masters/concept/conceptWorkbench.jsp").forward(request, response);
		}

		log.info(" In listHotSpots / conceptJson : " + httpSession.getAttribute("concept"));
		request.setAttribute("detailConceptBean", detailConceptBean);
		request.getRequestDispatcher("pages/masters/concept/concept_hotspot.jsp").forward(request, response);
		return null;

	}

	private String getImageServletUrl(String entity, String code)
	{

		List<String> imageServletPath = (List<String>) imageConfig.get("IMAGE_SERVLET_CONFIGURATIONS");

		String imageUrl = imageServletPath.get(0) + entity + "&" + imageServletPath.get(1) + "=" + code;
		/*String imageUrl = "http://10.0.0.7:8080/icatalog-admin/ImageServlet?entity="
				+ entity + "&image=" + code;*/

		log.info("========imageUrl==============" + imageUrl);
		return imageUrl;

	}

	private String printList(List listToPrint)
	{
		for (int i = 0; i < listToPrint.size(); i++)
		{
			log.info("Printing List = " + listToPrint.get(i));

		}
		return null;
	}

	public ModelAndView redirect(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException
	{
		HttpSession httpSession = request.getSession();
		httpSession.removeAttribute("concept");

		// response.sendRedirect("/SendRedirect/ValidUserServlet");
		request.getRequestDispatcher("pages/masters/concept/conceptWorkbench.jsp").forward(request, response);
		/* return new ModelAndView("/masters/concept/conceptWorkbench"); */
		return null;

	}

	public ModelAndView redirectToEditHotSpot(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{

		return new ModelAndView("/masters/concept/edit_concept_hotspot");

	}

	public ModelAndView redirectToEditConcept(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		HttpSession session = request.getSession();
		return new ModelAndView("/masters/concept/editConcept");

	}

	public ModelAndView getConceptDetails(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		HttpSession httpSession = request.getSession();

		if (null == ((String) request.getParameter("conceptCode")).trim()
				|| ((String) request.getParameter("conceptCode")).equals(""))
		{

			log.info("Concept code got = " + (String) request.getParameter("conceptCode"));
			return new ModelAndView("/masters/concept/conceptWorkbench");
		}
		else
		{
			String conceptCode = (String) request.getParameter("conceptCode");
			List<Concept> conceptList = (List<Concept>) httpSession.getAttribute("conceptList");
			List<ConceptCategory> conceptCategoryList = (List<ConceptCategory>) httpSession
					.getAttribute("conceptCategoryList");
			List<String> entityNames = (List<String>) imageConfig.get("IMAGE_DIRECTORY_NAMES");

			List<Concept> conceptBeanList = new LinkedList<Concept>();
			List<ConceptCategory> conceptCategoryBeanList = new LinkedList<ConceptCategory>();
			log.info("conceptList from session = " + conceptList);
			log.info("conceptCategoryList from session = " + conceptCategoryList);
			if (conceptList != null)
			{
				for (int i = 0; i < conceptList.size(); i++)
				{
					Concept concept = conceptList.get(i);
					if (concept.getCode().equals(conceptCode))
					{
						conceptBeanList.add(concept);
					}
				}

				Concept conceptBeanFetched = conceptBeanList.get(0);

				for (int i = 0; i < conceptCategoryList.size(); i++)
				{
					ConceptCategory conceptCategory = conceptCategoryList.get(i);
					if (conceptCategory.getId().equals(conceptBeanFetched.getCategoryId()))
					{
						conceptCategoryBeanList.add(conceptCategory);
					}
				}

				Concept conceptBean = new Concept();
				conceptBean.setCode(conceptCode);
				conceptBean.setDeleteFlag("F");

				String imageServletUrl = getImageServletUrl(entityNames.get(0), conceptCode);

				String conceptJson = conceptService.getImageWithHotSpot(conceptBean, imageServletUrl);

				request.setAttribute("detailConceptBean", conceptBeanFetched);
				request.setAttribute("detailConceptCategoryBean", conceptCategoryBeanList.get(0));
				httpSession.setAttribute("concept", conceptJson);
				request.getRequestDispatcher("concept.htm?method=listHotSpots").forward(request, response);
			}
			else
			{
				request.getRequestDispatcher("concept.htm?method=getConceptList").forward(request, response);
			}

		}
		return null;

	}

	/*public ModelAndView updateConcept(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
			{
		String code = (String)request.getParameter("conceptCode");
		Concept conceptBean  = fetchExistingConceptBean(code);

		if (conceptBean != null)
		{
			getConceptDetailsBean(request,conceptBean);
			log.info(" In updateConcept / conceptBean = " + conceptBean.getId());
			log.info(" In updateConcept / conceptBean = " + conceptBean);

			Boolean isUpdated = conceptService.update(conceptBean);

			log.info("isUpdated ="+isUpdated );
			if(isUpdated)
			{
				String imageUpload = (String)request.getParameter("imageUpload");
				if(imageUpload.equals("T") )
				{
					uploadImage(request);  
				}else
				{
					log.info("Image were not updated by user");
				}
				request.getRequestDispatcher("concept.htm?method=getConceptList")
				.forward(request, response);
			}else
			{
				return new ModelAndView("/masters/concept/editConcept");
			}


		}else
		{
			request.setAttribute("errorMsg", "Code does not exists...");
			return new ModelAndView("/masters/concept/conceptWorkbench");	
		}
		return null;

			}*/

	public ModelAndView updateConcept(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		String code = (String) request.getParameter("conceptCode");
		Concept conceptBean = fetchExistingConceptBean(code);

		if (conceptBean != null)
		{
			getConceptDetailsBean(request, conceptBean);
			log.info(" In updateConcept / conceptBean = " + conceptBean.getId());
			log.info(" In updateConcept / conceptBean = " + conceptBean);

			String imageUpload = (String) request.getParameter("imageUpload");

			if (imageUpload.equals("T"))
			{
				uploadImage(request);

				conceptBean.setImageModifiedOn(new Timestamp(System.currentTimeMillis()));
			}
			else
			{
				log.info("Image were not updated by user");
			}

			Boolean isUpdated = conceptService.update(conceptBean);

			log.info("isUpdated =" + isUpdated);

			if (isUpdated)
			{
				request.getRequestDispatcher("concept.htm?method=getConceptList").forward(request, response);
			}
			else
			{
				return new ModelAndView("/masters/concept/editConcept");
			}
		}
		else
		{
			request.setAttribute("errorMsg", "Code does not exists...");
			return new ModelAndView("/masters/concept/conceptWorkbench");
		}
		return null;

	}

	private void uploadImage(HttpServletRequest request)
	{

		int count = 0;
		String conceptImagePath = null;
		String conceptImageLocation = null;
		String code = null;
		String imageExtension = null;
		code = request.getParameter("conceptCode");
		List<String> imageBasePath = (List<String>) imageConfig.get("IMAGE_BASE_PATH");
		List<String> imageDirectoryNames = (List<String>) imageConfig.get("IMAGE_DIRECTORY_NAMES");

		Assert.state(request.getParameter("type").equals("genericFileMulti"), "type != genericFileMulti");

		final MultipartHttpServletRequest multiRequest = (MultipartHttpServletRequest) request;

		final Map files = multiRequest.getFileMap();

		List<Object> filesList = new Vector<Object>(files.values());

		for (Object object : filesList)
		{
			CommonsMultipartFile commonsMultipartFile = (CommonsMultipartFile) object;
			if (!commonsMultipartFile.isEmpty())
			{
				count++;
			}
		}

		log.info("count is::" + count);

		for (Object object : filesList)
		{
			System.out.println("class name : " + object.getClass());
			CommonsMultipartFile commonsMultipartFile = (CommonsMultipartFile) object;
			log.info("\n\nOriginalFilename = " + commonsMultipartFile.getOriginalFilename());
			log.info("ContentType = " + commonsMultipartFile.getContentType());
			log.info("Name = " + commonsMultipartFile.getName());
			log.info("Size = " + commonsMultipartFile.getSize());
			log.info("StorageDescription " + commonsMultipartFile.getStorageDescription());

			String fileName = commonsMultipartFile.getOriginalFilename().toLowerCase();
			log.info("fileName is:" + fileName);

			int indexOfDot = fileName.lastIndexOf(".");

			String extension = fileName.substring(indexOfDot + 1);

			log.info("extension is::" + extension.toLowerCase());

			String basedir = imageBasePath.get(0);
			//String basedir = SyncConstants.IMGPATH;

			if (commonsMultipartFile.getName().equalsIgnoreCase("conceptfile"))
			{
				log.info("in conceptfile");
				log.info("file name is::" + fileName);

				int lastIndex = fileName.lastIndexOf(".");

				log.info("lastIndex is::" + lastIndex);
				imageExtension = fileName.substring(lastIndex);
				log.info("extension is::" + imageExtension);

				conceptImagePath = imageDirectoryNames.get(0) + "/";
				//conceptImagePath = "concept/";

				conceptImageLocation = basedir + conceptImagePath;

				log.info("conceptImageLocation is::" + conceptImageLocation);
				request.setAttribute("conceptCode", code);

				try
				{
					saveEmailImage(conceptImageLocation, commonsMultipartFile, code, imageExtension);
				}
				catch (Exception e)
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			}
		}
	}

	private void getConceptDetailsBean(HttpServletRequest request, Concept conceptBean)
	{
		String code = (String) request.getParameter("conceptCode");
		String conceptName = (String) request.getParameter("txtName");
		String conceptDescription = (String) request.getParameter("txtDescription");
		String searchtag = (String) request.getParameter("txtSearchTags");
		String conceptBrand = (String) request.getParameter("txtBrand");
		//	 String imageUpload = (String)request.getParameter("imageUpload");
		log.info("Concept Code = " + request.getParameter("conceptCode"));
		log.info("Name = " + request.getParameter("txtName"));
		log.info("Description = " + request.getParameter("txtDescription"));
		log.info("==========================Search Tag==============================================" + searchtag);
		log.info("" + request.getParameter("txtBrand"));

		if (null == code || code.equalsIgnoreCase(""))
		{

			log.info("code" + code);

		}
		else
		{

			HttpSession httpSession = request.getSession();
			SystemUser userloggedIn = (SystemUser) httpSession.getAttribute("systemUser");

			if (null != conceptName && !conceptName.equalsIgnoreCase(""))
			{
				conceptBean.setName(conceptName);
			}
			if (null != conceptDescription && !conceptDescription.equalsIgnoreCase(""))
			{
				conceptBean.setDescription(conceptDescription);
			}
			else
			{
				conceptBean.setDescription("");
			}
			if (null != request.getParameter("category") && !request.getParameter("category").equalsIgnoreCase(""))
			{
				Long category = Long.parseLong(request.getParameter("category"));
				conceptBean.setCategoryId(category);
			}
			if (null != request.getParameter("txtRetail") && !request.getParameter("txtRetail").equalsIgnoreCase(""))
			{
				Double retailPrice = Double.parseDouble(request.getParameter("txtRetail"));
				conceptBean.setRetailPrice(retailPrice);
			}

			if (null != request.getParameter("txtOffer") && !request.getParameter("txtOffer").equalsIgnoreCase(""))
			{
				Double offerPrice = Double.parseDouble(request.getParameter("txtOffer"));
				conceptBean.setOfferPrice(offerPrice);
				conceptBean.setOfferFlag("Y");
			}
			else
			{
				conceptBean.setOfferFlag("N");
			}
			if (null != searchtag && !searchtag.equalsIgnoreCase(""))
			{
				conceptBean.setSearchTags(searchtag);
			}
			else
			{
				conceptBean.setSearchTags("");
			}
			if (null != conceptBrand && !conceptBrand.equalsIgnoreCase(""))
			{
				conceptBean.setBrand(conceptBrand);
			}
			else
			{
				conceptBean.setBrand("");
			}

			conceptBean.setGiftFlag(request.getParameter("giftFlag"));
			conceptBean.setModifiedBy(userloggedIn.getId());
			conceptBean.setModifiedOn(new Timestamp(System.currentTimeMillis()));
			conceptBean.setDeleteFlag("F");

			log.info("TYPE = " + request.getParameter("type"));
			// log.info("imageUpload = "+request.getParameter("imageUpload"));

		}

	}

	private Concept fetchExistingConceptBean(String code)
	{
		Concept searchConcept = new Concept();
		searchConcept.setCode(code);

		List<Concept> searchResult = conceptService.search(searchConcept);

		if (CollectionUtils.isEmpty(searchResult))
		{
			return null;
		}

		if (searchResult.size() > 1)
		{
			throw new RuntimeException("Duplicate Records Found...");
		}

		return searchResult.get(0);
	}

	public ModelAndView isConceptCodeAvailable(HttpServletRequest request, HttpServletResponse response)
	{

		String responseHTML = null;
		ModelAndView modelAndView = new ModelAndView("commons/ajaxResponsePage");
		log.info("concept Code entered" + request.getParameter("txtCode"));

		try
		{
			if ((null == request.getParameter("txtCode").trim()) || (request.getParameter("txtCode").trim().equals("")))
			{
				log.info("concept Code not valid");
				responseHTML = CommonServices.getCrossImgHtml() + "Invalid Concept Code";
			}
			else
			{

				List<Concept> conceptBeanList = conceptService.getConceptBeanList(request.getParameter("txtCode"));

				if (conceptBeanList.size() > 0)
				{
					if (conceptBeanList.get(0).getDeleteFlag().equals("F"))
					{
						log.info("existing concept code" + conceptBeanList.get(0));
						log.info("existing concept code delete flag:" + conceptBeanList.get(0).getDeleteFlag());
						responseHTML = CommonServices.getCrossImgHtml()
								+ "Code not available. Please Enter different code.";
					}
					else
					{
						log.info("existing concept code but soft deleted" + conceptBeanList.get(0));
						log.info("existing concept code delete flag:-----" + conceptBeanList.get(0).getDeleteFlag()
								+ "----");
						responseHTML = CommonServices.getTickImgHtml() + "Available!";
						HttpSession session = request.getSession();
						session.setAttribute("deleted_concept_code", conceptBeanList.get(0));
						System.out.println("=====conceptBeanList.get(0)=====" + conceptBeanList.get(0));
					}
				}
				else
				{
					responseHTML = CommonServices.getTickImgHtml() + "Available!";
				}
			}
			modelAndView.addObject(com.mobicule.icatalog.admin.common.IcatalogConstants.AJAX_RESPONSE_HTML,
					responseHTML);
		}
		catch (Exception e)
		{
			log.error("Exception while checking for unique Concept Code :" + e);
			e.printStackTrace();

		}
		return modelAndView;
	}

}
