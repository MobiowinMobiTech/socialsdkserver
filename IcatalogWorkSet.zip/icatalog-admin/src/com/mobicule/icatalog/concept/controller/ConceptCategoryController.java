package com.mobicule.icatalog.concept.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.mobicule.icatalog.admin.common.CommonServices;
import com.mobicule.icatalog.concept.bean.ConceptCategory;
import com.mobicule.icatalog.concept.service.ConceptCategoryService;
import com.mobicule.icatalog.systemuser.bean.SystemUser;

public class ConceptCategoryController extends MultiActionController
{

	private Log log = LogFactory.getLog(this.getClass());

	private ConceptCategoryService conceptCategoryService;

	private Map<String, List<String>> imageConfig;

	public Map<String, List<String>> getImageConfig()
	{
		return imageConfig;
	}

	public void setImageConfig(Map<String, List<String>> imageConfig)
	{
		this.imageConfig = imageConfig;
	}

	public ConceptCategoryService getConceptCategoryService()
	{
		return conceptCategoryService;
	}

	public void setConceptCategoryService(ConceptCategoryService conceptCategoryService)
	{
		this.conceptCategoryService = conceptCategoryService;
	}

	public ModelAndView addConceptCategory(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		log.info("---------In ConceptCategoryController / add()----------");

		HttpSession session = request.getSession();
		SystemUser sysAdmin = (SystemUser) session.getAttribute("systemUser");

		ConceptCategory deletedConceptCategory = (ConceptCategory) session
				.getAttribute("deleted_concept_category_code");

		if (null == deletedConceptCategory)
		{
			ConceptCategory conceptCategory = getConceptCategoryBean(request, null);
			conceptCategory.setDeleteFlag("F");
			conceptCategory.setModifiedBy(sysAdmin.getId());
			conceptCategory.setCreatedBy(sysAdmin.getId());
			conceptCategoryService.add(conceptCategory);
		}
		else
		{
			getConceptCategoryBean(request, deletedConceptCategory);
			deletedConceptCategory.setDeleteFlag("F");
			deletedConceptCategory.setModifiedBy(sysAdmin.getId());
			deletedConceptCategory.setCreatedBy(sysAdmin.getId());
			conceptCategoryService.update(deletedConceptCategory);
			session.setAttribute("deleted_product_category_code", null);
		}

		return getConceptCategoryList(request, response);
	}

	public ModelAndView updateConceptCategory(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		String code = request.getParameter("txtCode");

		log.info(":---------In ConceptCategoryController / Update() / Code----------:" + code);

		ConceptCategory existingConceptCategory = fetchExistingConceptCategory(code);

		log.info("---------In ConceptCategoryController / updateConceptCat() / existingConceptCategory----------"
				+ existingConceptCategory);

		if (existingConceptCategory != null)
		{
			log.info("---------In ConceptCategoryController / existingConceptCategory found----------");

			existingConceptCategory = getConceptCategoryBean(request, existingConceptCategory);

			HttpSession session = request.getSession();
			SystemUser sysAdmin = (SystemUser) session.getAttribute("systemUser");

			existingConceptCategory.setModifiedBy(sysAdmin.getId());

			conceptCategoryService.update(existingConceptCategory);

			return getConceptCategoryList(request, response);
		}
		else
		{
			request.setAttribute("errorMsg", "Code does not exists...");
			return new ModelAndView("/masters/conceptCategory/conceptCategoryWorkbench");
		}
	}

	public ModelAndView deleteConceptCategory(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		String code = request.getParameter("code");

		log.info("--------Code for deletion------------------in deleteConceptCategory-----" + code);

		ConceptCategory existingConceptCategory = fetchExistingConceptCategory(code);
		HttpSession session = request.getSession();
		SystemUser sysAdmin = (SystemUser) session.getAttribute("systemUser");
		if (existingConceptCategory != null)
		{
			existingConceptCategory.setModifiedBy(sysAdmin.getId());
			conceptCategoryService.delete(existingConceptCategory);

			return getConceptCategoryList(request, response);
		}
		else
		{
			request.setAttribute("errorMsg", "Code does not exists...");
			return new ModelAndView("/masters/conceptCategory/conceptCategoryWorkbench");
		}
	}

	private ConceptCategory fetchExistingConceptCategory(String code)
	{
		ConceptCategory searchCategory = new ConceptCategory();
		searchCategory.setCode(code);

		List<ConceptCategory> searchResult = conceptCategoryService.search(searchCategory);

		if (CollectionUtils.isEmpty(searchResult))
		{
			return null;
		}

		if (searchResult.size() > 1)
		{
			throw new RuntimeException("Duplicate Records Found...");
		}

		return searchResult.get(0);
	}

	public ModelAndView getConceptCategorySearch(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		log.info("-------------- in getConceptCategorySearch Method  -------------");

		ConceptCategory conceptCategory = new ConceptCategory();

		String code = request.getParameter("searchName");

		conceptCategory.setDeleteFlag("F");
		log.info("--- code ---" + code);

		if (!isEmpty(code))
		{
			conceptCategory.setCode(code);
		}

		List<ConceptCategory> conceptCategoryList = conceptCategoryService.doCustomSearch(conceptCategory);
		HttpSession session = request.getSession();
		session.setAttribute("conceptCategoryList", conceptCategoryList);
		return new ModelAndView("/masters/conceptCategory/conceptCategoryWorkbench");

	}

	private boolean isEmpty(String name)
	{
		return ((null == name) || (name.trim().equals("")));
	}

	private ConceptCategory getConceptCategoryBean(HttpServletRequest request, ConceptCategory existingConceptCategory)
	{
		log.info("----------------------In getConceptCategoryBean()----------------------");

		if (existingConceptCategory == null)
		{
			existingConceptCategory = new ConceptCategory();
		}

		/*int count = 0;
		String imageExtension = null;
		String conceptCategoryImagePath = null;
		String conceptImageLocation = null;*/

		String code = request.getParameter("txtCode");

		String name = request.getParameter("txtName");

		String description = request.getParameter("txtDescription");

		/*List<String> imageBasePath = (List<String>) imageConfig.get("IMAGE_BASE_PATH");
		List<String> imageDirectoryNames = (List<String>) imageConfig.get("IMAGE_DIRECTORY_NAMES");*/

		log.info("--------------Code---------------" + code);
		log.info("--------------Name---------------" + name);
		log.info("--------------Description---------------" + description);

		// IMAGE UPLOAD STARTS

		/*Assert.state(request.getParameter("type").equals("genericFileMulti"), "type != genericFileMulti");

		final MultipartHttpServletRequest multiRequest = (MultipartHttpServletRequest) request;

		final Map files = multiRequest.getFileMap();

		List<Object> filesList = new Vector<Object>(files.values());

		for (Object object : filesList)
		{
			CommonsMultipartFile commonsMultipartFile = (CommonsMultipartFile) object;
			if (!commonsMultipartFile.isEmpty())
			{
				count++;
			}
		}

		log.info("count is::" + count);

		for (Object object : filesList)
		{
			System.out.println("class name : " + object.getClass());
			CommonsMultipartFile commonsMultipartFile = (CommonsMultipartFile) object;
			log.info("\n\nOriginalFilename = " + commonsMultipartFile.getOriginalFilename());
			log.info("ContentType = " + commonsMultipartFile.getContentType());
			log.info("Name = " + commonsMultipartFile.getName());
			log.info("Size = " + commonsMultipartFile.getSize());
			log.info("StorageDescription " + commonsMultipartFile.getStorageDescription());

			String fileName = commonsMultipartFile.getOriginalFilename().toLowerCase();
			log.info("fileName is:" + fileName);

			if (!fileName.isEmpty())
			{

				int indexOfDot = fileName.lastIndexOf(".");

				String extension = fileName.substring(indexOfDot + 1);

				log.info("extension is::" + extension.toLowerCase());

				String basedir = imageBasePath.get(0);
				//String basedir = SyncConstants.IMGPATH;

				if (commonsMultipartFile.getName().equalsIgnoreCase("conceptCategoryfile"))
				{
					log.info("in conceptfile");
					log.info("file name is::" + fileName);

					int lastIndex = fileName.lastIndexOf(".");

					log.info("lastIndex is::" + lastIndex);
					imageExtension = fileName.substring(lastIndex);
					log.info("extension is::" + imageExtension);

					conceptCategoryImagePath = imageDirectoryNames.get(1) + "/";
					//conceptImagePath = "conceptCategory/";

					conceptImageLocation = basedir + conceptCategoryImagePath;

					log.info(" conceptCategoryImageLocation is:: " + conceptImageLocation);

					try
					{
						saveEmailImage(conceptImageLocation, commonsMultipartFile, code, imageExtension);
					}
					catch (Exception e)
					{
						e.printStackTrace();
					}

				}
			}

		}*/

		// IMAGE UPLOAD ENDS

		if ((code != null) && !code.equalsIgnoreCase(""))
		{
			existingConceptCategory.setCode(code);
		}

		if ((name != null) && !name.equalsIgnoreCase(""))
		{
			existingConceptCategory.setName(name);
		}

		if ((description != null) && !description.equalsIgnoreCase(""))
		{
			existingConceptCategory.setDescription(description);
		}
		else
		{
			existingConceptCategory.setDescription("");
		}

		return existingConceptCategory;
	}

	private void saveEmailImage(String basedir, MultipartFile multipartFile, String code, String extension)
			throws Exception
	{
		File localEmailDir = new File(basedir);
		if (!localEmailDir.exists())
		{
			localEmailDir.mkdirs();

			File emaildir = new File(localEmailDir, code + extension);

			FileOutputStream fileOutputStream = new FileOutputStream(emaildir);
			fileOutputStream.write(multipartFile.getBytes());

		}
		else
		{
			File emaildir = new File(localEmailDir, code + extension);

			FileOutputStream fileOutputStream = new FileOutputStream(emaildir);
			fileOutputStream.write(multipartFile.getBytes());

		}

	}

	public ModelAndView getConceptCategoryList(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		ConceptCategory conceptCategory = new ConceptCategory();

		conceptCategory.setDeleteFlag("F");

		List<ConceptCategory> conceptCategoryList = conceptCategoryService.search(conceptCategory);

		log.info("ConceptCategoryController/getConceptCategoryList conceptCategoryList:"
				+ ((conceptCategoryList == null) ? "Null " : conceptCategoryList.size()));

		HttpSession session = request.getSession();
		session.setAttribute("conceptCategoryList", conceptCategoryList);

		return new ModelAndView("/masters/conceptCategory/conceptCategoryWorkbench");
	}

	public ModelAndView getConceptCategory(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException
	{
		System.out.println("Inside Controller/get Concept Category");

		String code = request.getParameter("code");
		System.out.println("Inside Controller" + code);
		ConceptCategory conceptCategory = null;
		if (!isEmpty(code))
		{
			conceptCategory = fetchExistingConceptCategory(code);
			log.info(conceptCategory);
		}

		log.info(" In getProductCategory : " + conceptCategory);
		HttpSession session = request.getSession();

		session.setAttribute("conceptCategory", conceptCategory);

		return new ModelAndView("/masters/conceptCategory/editConceptCategory");
	}

	public ModelAndView isCodeAvailable(HttpServletRequest request, HttpServletResponse response)
	{

		String responseHTML = null;
		ModelAndView modelAndView = new ModelAndView("commons/ajaxResponsePage");

		log.info("Code entered" + request.getParameter("txtCode"));

		try
		{
			if ((null == request.getParameter("txtCode")))
			{
				log.info("Code not valid");
				responseHTML = CommonServices.getCrossImgHtml() + "Invalid LoginId";
			}
			else
			{
				log.info("in try");

				List<ConceptCategory> userBeanList = conceptCategoryService.checkUniqueConceptCategoryCode(request
						.getParameter("txtCode").trim());

				if (userBeanList.size() > 0)
				{
					if (1 == userBeanList.size())
					{
						if (userBeanList.get(0).getDeleteFlag().equals("F"))
						{
							log.info("existing concept code" + userBeanList.get(0));
							log.info("existing concept code delete flag:" + userBeanList.get(0).getDeleteFlag());
							responseHTML = CommonServices.getCrossImgHtml()
									+ "Code not available. Please Enter different code.";
						}
						else
						{
							log.info("existing concept code but soft deleted" + userBeanList.get(0));
							log.info("existing concept code delete flag:-----" + userBeanList.get(0).getDeleteFlag()
									+ "----");
							responseHTML = CommonServices.getTickImgHtml() + "Available!";
							HttpSession session = request.getSession();
							session.setAttribute("deleted_concept_category_code", userBeanList.get(0));
						}
					}
					else
					{
						responseHTML = CommonServices.getCrossImgHtml()
								+ "Code not available. Please Enter different code...";
					}

					log.info("responseHTML ::: " + responseHTML);
				}
				else
				{
					log.info("inside else");
					responseHTML = CommonServices.getTickImgHtml() + "Available!";
				}

			}
			modelAndView.addObject(com.mobicule.icatalog.admin.common.IcatalogConstants.AJAX_RESPONSE_HTML,
					responseHTML);
			log.info("Just After the ADD" + modelAndView);
		}
		catch (Exception e)
		{
			log.error("Exception while checking for unique code :" + e);
			e.printStackTrace();

		}
		log.info("Value of ressponseHTML" + responseHTML.toString());
		log.info("Just before the RETURN" + modelAndView);
		return modelAndView;
	}
}
