package com.mobiowin.windchim.service.app;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.mobiowin.windchim.commons.ApplicationConstant;
import com.mobiowin.windchim.messaging.IMessageService;
import com.mobiowin.windchim.service.helper.IAppSyncHelperServie;

@Service("eventSyncService")
@Component
public class EventSyncService implements IMessageService {

	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private IAppSyncHelperServie appSyncService;

	public Message<String> execute(Message<String> message) {
		log.info("Inside OrgEventSyncService/execute()");

		String jsonData = message.getPayload();

		Map<String, Object> messageHeaders = message.getHeaders();

		JSONObject dataJson = null;
		JSONObject reqDataJson = null;

		String response = null;
		String lastSyncDate = null;
		String eventId = null;

		HashMap<String, String> reqDataMap = null;

		try {
			dataJson = new JSONObject(jsonData);
			reqDataJson = dataJson.getJSONObject(ApplicationConstant.DATA);

			log.info("Last sync date " + reqDataJson.getString(ApplicationConstant.LAST_SYNC_DATE));

			if (reqDataJson.has(ApplicationConstant.LAST_SYNC_DATE)) {
				lastSyncDate = reqDataJson.getString(ApplicationConstant.LAST_SYNC_DATE);
			}
			
			if (reqDataJson.has(ApplicationConstant.EVENT_ID)) {
				eventId = reqDataJson.getString(ApplicationConstant.EVENT_ID);
			}

			if (log.isInfoEnabled()) {
				log.info("Message Headers is : " + messageHeaders);
				log.info("Message Headers is : " + eventId);

				log.info("LAST_SYNC_DATE is : " + lastSyncDate);

			}

			reqDataMap = getReqDataMap(lastSyncDate,eventId);

			response = appSyncService.syncEvent(reqDataMap);

			return MessageBuilder.withPayload(response).build();

		} catch (Exception ex) {
			log.error("Exception in OrgProfileService/execute() " + ex.getMessage(), ex.getCause());

		}

		return null;

	}

	private HashMap<String, String> getReqDataMap(String lastSyncDate,String eventId) {

		HashMap<String, String> reqDataMap = new HashMap<String, String>();
		reqDataMap.put(ApplicationConstant.EVENT_ID, eventId);
		reqDataMap.put(ApplicationConstant.LAST_SYNC_DATE, lastSyncDate);

		return reqDataMap;
	}
}
