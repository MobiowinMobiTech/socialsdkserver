package com.mobiowin.windchim.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "student_profile_master", catalog = "windchimp")
public class StudentProfileBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private String id;

	@Column(name = "enrollment_id")
	private String enrollmentId;
	
	@Column(name = "student_name")
	private String name;

	@Column(name = "branch_id")
	private String branchId;

	@Column(name = "class_name")
	private String className;

	@Column(name = "father_no")
	private String fatherNo;

	@Column(name = "father_name")
	private String fatherName;

	@Column(name = "mother_no")
	private String motherNo;

	@Column(name = "mother_name")
	private String motherName;

	@Column(name = "joining_dt")
	private Date doj;

	@Column(name = "birth_dt")
	private Date dob;

	@Column(name = "permanent_address")
	private String permanentAddress;

	@Column(name = "temp_address")
	private String tempAddress;

	@Column(name = "is_day_boarding")
	private String isDayBoarding;

	@Column(name = "is_van")
	private String isVan;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_dt")
	private Date createDt;

	@Column(name = "modified_by")
	private String modifiedBy;

	@Column(name = "modified_dt")
	private Date modifyDt;

	@Column(name = "del_flag")
	private String deleteFlag;

	public StudentProfileBean() {
		super();
	}

	

	public StudentProfileBean(String id, String enrollmentId, String name, String branchId, String className,
			String fatherNo, String fatherName, String motherNo, String motherName, Date doj, Date dob,
			String permanentAddress, String tempAddress, String isDayBoarding, String isVan, String createdBy,
			Date createDt, String modifiedBy, Date modifyDt, String deleteFlag) {
		super();
		this.id = id;
		this.enrollmentId = enrollmentId;
		this.name = name;
		this.branchId = branchId;
		this.className = className;
		this.fatherNo = fatherNo;
		this.fatherName = fatherName;
		this.motherNo = motherNo;
		this.motherName = motherName;
		this.doj = doj;
		this.dob = dob;
		this.permanentAddress = permanentAddress;
		this.tempAddress = tempAddress;
		this.isDayBoarding = isDayBoarding;
		this.isVan = isVan;
		this.createdBy = createdBy;
		this.createDt = createDt;
		this.modifiedBy = modifiedBy;
		this.modifyDt = modifyDt;
		this.deleteFlag = deleteFlag;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getEnrollmentId() {
		return enrollmentId;
	}

	public void setEnrollmentId(String enrollmentId) {
		this.enrollmentId = enrollmentId;
	}

	public String getBranchId() {
		return branchId;
	}

	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getFatherNo() {
		return fatherNo;
	}

	public void setFatherNo(String fatherNo) {
		this.fatherNo = fatherNo;
	}

	public String getFatherName() {
		return fatherName;
	}

	public void setFatherName(String fatherName) {
		this.fatherName = fatherName;
	}

	public String getMotherNo() {
		return motherNo;
	}

	public void setMotherNo(String motherNo) {
		this.motherNo = motherNo;
	}

	public String getMotherName() {
		return motherName;
	}

	public void setMotherName(String motherName) {
		this.motherName = motherName;
	}

	public Date getDoj() {
		return doj;
	}

	public void setDoj(Date doj) {
		this.doj = doj;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getPermanentAddress() {
		return permanentAddress;
	}

	public void setPermanentAddress(String permanentAddress) {
		this.permanentAddress = permanentAddress;
	}

	public String getTempAddress() {
		return tempAddress;
	}

	public void setTempAddress(String tempAddress) {
		this.tempAddress = tempAddress;
	}

	public String getIsDayBoarding() {
		return isDayBoarding;
	}

	public void setIsDayBoarding(String isDayBoarding) {
		this.isDayBoarding = isDayBoarding;
	}

	public String getIsVan() {
		return isVan;
	}

	public void setIsVan(String isVan) {
		this.isVan = isVan;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreateDt() {
		return createDt;
	}

	public void setCreateDt(Date createDt) {
		this.createDt = createDt;
	}

	public String getModifiedBy() {
		return modifiedBy;
	}

	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}

	public Date getModifyDt() {
		return modifyDt;
	}

	public void setModifyDt(Date modifyDt) {
		this.modifyDt = modifyDt;
	}

	public String getDeleteFlag() {
		return deleteFlag;
	}

	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}



	@Override
	public String toString() {
		return "StudentProfileBean [id=" + id + ", enrollmentId=" + enrollmentId + ", name=" + name + ", branchId="
				+ branchId + ", className=" + className + ", fatherNo=" + fatherNo + ", fatherName=" + fatherName
				+ ", motherNo=" + motherNo + ", motherName=" + motherName + ", doj=" + doj + ", dob=" + dob
				+ ", permanentAddress=" + permanentAddress + ", tempAddress=" + tempAddress + ", isDayBoarding="
				+ isDayBoarding + ", isVan=" + isVan + ", createdBy=" + createdBy + ", createDt=" + createDt
				+ ", modifiedBy=" + modifiedBy + ", modifyDt=" + modifyDt + ", deleteFlag=" + deleteFlag + "]";
	}

	

}
