package com.mobiowin.windchim.notification;

import java.util.HashMap;

public interface IFcmBroadcastService {

	void sendBroadcastNotification(HashMap<String, String> notificationDetailMap);

}
