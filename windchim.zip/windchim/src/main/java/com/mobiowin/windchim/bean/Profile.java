package com.mobiowin.windchim.bean;

import java.io.Serializable;

public class Profile implements Serializable
{

	private static final long serialVersionUID = 1L;

}
