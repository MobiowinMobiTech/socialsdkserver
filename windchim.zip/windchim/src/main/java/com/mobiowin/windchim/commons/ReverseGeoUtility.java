package com.mobiowin.windchim.commons;

import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class ReverseGeoUtility {
	public static Log log = LogFactory.getLog(ReverseGeoUtility.class);

	public static List<String> getReverseGeoDetails(String latitude, String longitude) {
		String address = null;
		String gURL = "http://maps.google.com/maps/api/geocode/xml?latlng=" + latitude + "," + longitude
				+ "&sensor=true";
		List<String> reverseGeoAddressList = null;

		try {
			DocumentBuilderFactory df = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = df.newDocumentBuilder();
			Document dom = db.parse(gURL);
			Element docEl = dom.getDocumentElement();
			NodeList nl = docEl.getElementsByTagName("result");

			if (nl != null && nl.getLength() > 0) {
				address = ((Element) nl.item(0)).getElementsByTagName("formatted_address").item(0).getTextContent();

				log.info("Address : " + address);

				reverseGeoAddressList = getDetailedAddress(address);
				return reverseGeoAddressList;
			}
		} catch (Exception ex) {
			log.error("Exception in ReverseGeoUtility/getReverseGeoDetails() : " + ex.getMessage(), ex.getCause());
			return reverseGeoAddressList;
		}

		return reverseGeoAddressList;
	}

	private static List<String> getDetailedAddress(String address) {
		log.info("Inside ReverseGeoUtility/getDetailedAddress()");

		String[] addressArray = address.split(",");

		System.out.println("addressArray : " + addressArray.length);

		List<String> addressList = new ArrayList<String>();

		for (String item : addressArray) {
			addressList.add(item);
		}

		
		System.out.println(addressList.toString());
		System.out.println(addressList.size());
		
		/*//String[] subAddress = addressList.get(addressList.size() - 2).split(" ");
		String subAddress1 = addressList.get(addressList.size() - 2);
		String[] subAddress = subAddress1.trim().split(" ");
		
		System.out.println(subAddress[0]);
		System.out.println(subAddress[1]);
		
		for (String item : subAddress) {
			System.out.println(item);
		}
		*/
		

		return addressList;
	}

	public static void main(String[] args) {

		ReverseGeoUtility.getReverseGeoDetails("19.197840", "72.827690");

	}
}
