package com.mobiowin.windchim.test;

import org.json.JSONObject;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestTemplate;

public class NotificationTest {

	public static void main(String[] args) 
	{
		HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);
		headers.set("Authorization", "key=" + "AIzaSyBotSWOnRtFJTnmSWjXbKPhNBGfKzTeq60");
		
		String notificationJsonData = getNotificationMessageData();

		HttpEntity<String> entity = new HttpEntity<String>(notificationJsonData, headers);
		
		//resposne = restTemplate.postForObject(fcmNotificationUrl, entity, String.class);
		RestTemplate restTemplate = new RestTemplate();
		String resposne = restTemplate.postForObject("https://fcm.googleapis.com/fcm/send", entity, String.class);
		JSONObject responseJson = new JSONObject(resposne);

		System.out.println("Resposne is : " + responseJson);
		
		
	}
	
	private static String getNotificationMessageData()
	{
		
		String urerId = "e2CBKea8fhI:APA91bFLl3lSs6JoIbGwqmFg6vpFIxHz8Z_E3QX-SllG1mkf6ICH8K0-4kHkYhxVxSJyYa3eWLt928TPU-xfBj2wzTug34EWvxFDggxhbyAPIOwHls3wiW-OUctGOxgrMrZ2JgjF5-Ke";
		JSONObject json = new JSONObject();
		json.put("to", urerId);
		JSONObject info = new JSONObject();
		
		info.put("title", "Paalan Test");
		info.put("body", "hiiii");
		
		//info.put("body", String.format(String.valueOf(notificationMessageConfig.get(notificationDataMap.get(ApplicationConstant.NOTIFICATION_TYPE))), notificationDataMap.get(ApplicationConstant.NAME),notificationDataMap.get(ApplicationConstant.ORG_ID)));
		json.put("data", info);

		//log.info("Json is : " + json);
		
		
		
		return json.toString();
	}
}
