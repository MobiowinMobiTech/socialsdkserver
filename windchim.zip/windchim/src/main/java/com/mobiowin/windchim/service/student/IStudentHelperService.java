package com.mobiowin.windchim.service.student;

import java.util.HashMap;

public interface IStudentHelperService {

	String validateLogin(HashMap<String, String> loginReqDataMap);

	String submitDeviceDetails(HashMap<String, String> studentNotificationDetailMap);

	String syncStudentHomeworkData(HashMap<String, String> studentNotificationDetailMap);

	String syncStudentTTkData(HashMap<String, String> studentNotificationDetailMap);

}
