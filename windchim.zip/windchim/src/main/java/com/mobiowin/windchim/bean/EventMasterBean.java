package com.mobiowin.windchim.bean;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "event_master", catalog = "windchimp")
public class EventMasterBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private String id;

	@Column(name = "event_id")
	private String eventId;

	@Column(name = "event_title")
	private String title;

	@Column(name = "event_sub_title")
	private String subTitle;

	@Column(name = "event_category")
	private String category;

	@Column(name = "event_discription")
	private String discription;

	@Column(name = "event_startdt")
	private Date startDt;

	@Column(name = "event_enddt")
	private Date endDt;
	
	@Column(name = "event_img1")
	private String img1;
	
	@Column(name = "event_img2")
	private String img2;
	
	@Column(name = "event_img3")
	private String img3;
	
	@Column(name = "event_img4")
	private String img4;

	@Column(name = "event_location")
	private String location;

	@Column(name = "created_by")
	private String createdBy;

	@Column(name = "created_dt")
	private Date createDt;

	@Column(name = "modified_by")
	private String modifiedBy;

	@Column(name = "modified_dt")
	private Date modifyDt;

	@Column(name = "del_flag")
	private String deleteFlag;
	
	@Transient
	private String eventType;
	
	
	public EventMasterBean(String id, String eventId, String title, String subTitle, String category,
			String discription, Date startDt, Date endDt, String img1, String img2, String img3, String img4,
			String location, String createdBy, Date createDt, String modifiedBy, Date modifyDt, String deleteFlag,
			String eventType) {
		super();
		this.id = id;
		this.eventId = eventId;
		this.title = title;
		this.subTitle = subTitle;
		this.category = category;
		this.discription = discription;
		this.startDt = startDt;
		this.endDt = endDt;
		this.img1 = img1;
		this.img2 = img2;
		this.img3 = img3;
		this.img4 = img4;
		this.location = location;
		this.createdBy = createdBy;
		this.createDt = createDt;
		this.modifiedBy = modifiedBy;
		this.modifyDt = modifyDt;
		this.deleteFlag = deleteFlag;
		this.eventType = eventType;
	}


	public EventMasterBean() {
		super();
	}


	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}


	public String getEventId() {
		return eventId;
	}


	public void setEventId(String eventId) {
		this.eventId = eventId;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public String getSubTitle() {
		return subTitle;
	}


	public void setSubTitle(String subTitle) {
		this.subTitle = subTitle;
	}


	public String getCategory() {
		return category;
	}


	public void setCategory(String category) {
		this.category = category;
	}


	public String getDiscription() {
		return discription;
	}


	public void setDiscription(String discription) {
		this.discription = discription;
	}


	


	public Date getStartDt() {
		return startDt;
	}


	public void setStartDt(Date startDt) {
		this.startDt = startDt;
	}


	public Date getEndDt() {
		return endDt;
	}


	public void setEndDt(Date endDt) {
		this.endDt = endDt;
	}


	public String getImg1() {
		return img1;
	}


	public void setImg1(String img1) {
		this.img1 = img1;
	}


	public String getImg2() {
		return img2;
	}


	public void setImg2(String img2) {
		this.img2 = img2;
	}


	public String getImg3() {
		return img3;
	}


	public void setImg3(String img3) {
		this.img3 = img3;
	}


	public String getImg4() {
		return img4;
	}


	public void setImg4(String img4) {
		this.img4 = img4;
	}


	public String getLocation() {
		return location;
	}


	public void setLocation(String location) {
		this.location = location;
	}


	public String getCreatedBy() {
		return createdBy;
	}


	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}


	public Date getCreateDt() {
		return createDt;
	}


	public void setCreateDt(Date createDt) {
		this.createDt = createDt;
	}


	public String getModifiedBy() {
		return modifiedBy;
	}


	public void setModifiedBy(String modifiedBy) {
		this.modifiedBy = modifiedBy;
	}


	public Date getModifyDt() {
		return modifyDt;
	}


	public void setModifyDt(Date modifyDt) {
		this.modifyDt = modifyDt;
	}


	public String getDeleteFlag() {
		return deleteFlag;
	}


	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}


	public String getEventType() {
		return eventType;
	}


	public void setEventType(String eventType) {
		this.eventType = eventType;
	}


	@Override
	public String toString() {
		return "EventMasterBean [id=" + id + ", eventId=" + eventId + ", title=" + title + ", subTitle=" + subTitle
				+ ", category=" + category + ", discription=" + discription + ", startDt=" + startDt + ", endDt="
				+ endDt + ", img1=" + img1 + ", img2=" + img2 + ", img3=" + img3 + ", img4=" + img4 + ", location="
				+ location + ", createdBy=" + createdBy + ", createDt=" + createDt + ", modifiedBy=" + modifiedBy
				+ ", modifyDt=" + modifyDt + ", deleteFlag=" + deleteFlag + ", eventType=" + eventType + "]";
	}

	
	
}
