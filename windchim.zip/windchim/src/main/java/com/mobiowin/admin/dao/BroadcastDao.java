package com.mobiowin.admin.dao;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.mobiowin.windchim.bean.BranchMasterBean;
import com.mobiowin.windchim.bean.ClassMasterBean;
import com.mobiowin.windchim.bean.GeneralBroadcastMasterBean;
import com.mobiowin.windchim.bean.HomeworkBroadcastMasterBean;
import com.mobiowin.windchim.commons.MobiowinConstants;

@Repository("broadcastDao")
@Component
public class BroadcastDao implements IBroadcastDao{
	
	private Log log = LogFactory.getLog(this.getClass());
	
	@Autowired
	private SessionFactory sessionFactory;

	Session session = null;
	Transaction transaction = null;

	public List<BranchMasterBean> fetchBranchDetails(BranchMasterBean branchMaster) {
		log.info("branchMaster : " + branchMaster);

		StringBuilder fetchBranchDetailsQueryBuilder = null;
		List<BranchMasterBean> branchList = null;
		try {
			fetchBranchDetailsQueryBuilder = new StringBuilder();
			fetchBranchDetailsQueryBuilder.append("from BranchMasterBean ");
			fetchBranchDetailsQueryBuilder.append("where deleteFlag =:deleteFlag ");
			

			Query query = sessionFactory.openSession().createQuery(fetchBranchDetailsQueryBuilder.toString());
			query.setParameter("deleteFlag", branchMaster.getDeleteFlag());
			

			branchList = query.list();

			log.info("branchList : " + branchList.size());

			return branchList;
		} catch (HibernateException e) {
			e.printStackTrace();
			log.error("Hibernate Exception in fetching branch details : " + e.getMessage());
			return branchList;
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception in fetching branch details : " + e.getMessage());
			return branchList;
		}
	}

	public List<ClassMasterBean> fetchClassDetails(ClassMasterBean classMasterBean) {
		log.info("classMasterBean : " + classMasterBean);

		StringBuilder fetchClassDetailsQueryBuilder = null;
		List<ClassMasterBean> classList = null;
		try {
			fetchClassDetailsQueryBuilder = new StringBuilder();
			fetchClassDetailsQueryBuilder.append("from ClassMasterBean ");
			fetchClassDetailsQueryBuilder.append("where deleteFlag =:deleteFlag ");
			

			Query query = sessionFactory.openSession().createQuery(fetchClassDetailsQueryBuilder.toString());
			query.setParameter("deleteFlag", classMasterBean.getDeleteFlag());
			

			classList = query.list();

			log.info("branchList : " + classList.size());

			return classList;
		} catch (HibernateException e) {
			e.printStackTrace();
			log.error("Hibernate Exception in fetching class details : " + e.getMessage());
			return classList;
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception in fetching class details : " + e.getMessage());
			return classList;
		}

	}

	public String saveGeneralBroadcast(GeneralBroadcastMasterBean generalBroadcastBean) {
		log.info("Inside BroadcastDao/saveGeneralBroadcast()");

		log.info("generalBroadcastBean : " + generalBroadcastBean);

		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			session.save(generalBroadcastBean);
			session.flush();
			transaction.commit();

			return MobiowinConstants.TRUE;
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
			log.error("Exception in submitUser : " + e.getMessage(), e.getCause());
			return MobiowinConstants.FALSE;
		} catch (Exception ex) {
			transaction.rollback();
			ex.printStackTrace();
			log.error("Exception in submitUser : " + ex.getMessage(), ex.getCause());
			return MobiowinConstants.FALSE;
		}
	}

	public List<GeneralBroadcastMasterBean> getActiveGeneralBroadcastList(
			GeneralBroadcastMasterBean broadcastMasterBean) {
		log.info("broadcastMasterBean : " + broadcastMasterBean);

		StringBuilder fetchDetailsQueryBuilder = null;
		List<GeneralBroadcastMasterBean> genBroadcastList = null;
		try {
			fetchDetailsQueryBuilder = new StringBuilder();
			fetchDetailsQueryBuilder.append("from GeneralBroadcastMasterBean ");
			fetchDetailsQueryBuilder.append("where deleteFlag =:deleteFlag ");
			fetchDetailsQueryBuilder.append("order by createDt ASC ");
			

			Query query = sessionFactory.openSession().createQuery(fetchDetailsQueryBuilder.toString());
			query.setParameter("deleteFlag", broadcastMasterBean.getDeleteFlag());
			

			genBroadcastList = query.list();

			log.info("genBroadcastList : " + genBroadcastList.size());

			return genBroadcastList;
		} catch (HibernateException e) {
			e.printStackTrace();
			log.error("Hibernate Exception in fetching branch details : " + e.getMessage());
			return genBroadcastList;
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception in fetching branch details : " + e.getMessage());
			return genBroadcastList;
		}
	}

	public List<HomeworkBroadcastMasterBean> getActiveHomeworkNotificationList(
			HomeworkBroadcastMasterBean homeworkBroadcastMasterBean) {
		log.info("homeworkBroadcastMasterBean : " + homeworkBroadcastMasterBean);

		StringBuilder fetchDetailsQueryBuilder = null;
		List<HomeworkBroadcastMasterBean> hwNotificationBroadcastList = null;
		try {
			fetchDetailsQueryBuilder = new StringBuilder();
			fetchDetailsQueryBuilder.append("from HomeworkBroadcastMasterBean ");
			fetchDetailsQueryBuilder.append("where deleteFlag =:deleteFlag ");
			fetchDetailsQueryBuilder.append("order by createDt ASC ");
			

			Query query = sessionFactory.openSession().createQuery(fetchDetailsQueryBuilder.toString());
			query.setParameter("deleteFlag", homeworkBroadcastMasterBean.getDeleteFlag());
			

			hwNotificationBroadcastList = query.list();

			log.info("HomeworkBroadcastList : " + hwNotificationBroadcastList.size());

			return hwNotificationBroadcastList;
		} catch (HibernateException e) {
			e.printStackTrace();
			log.error("Hibernate Exception in fetching homework notification details : " + e.getMessage());
			return hwNotificationBroadcastList;
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Exception in fetching homeworknotification details : " + e.getMessage());
			return hwNotificationBroadcastList;
		}
	}

	public String saveHwNotification(HomeworkBroadcastMasterBean homeworkBroadcastMasterBean) {
		log.info("Inside BroadcastDao/saveHwNotification()");

		log.info("homeworkBroadcastMasterBean : " + homeworkBroadcastMasterBean);

		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			session.save(homeworkBroadcastMasterBean);
			session.flush();
			transaction.commit();

			return MobiowinConstants.TRUE;
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
			log.error("Exception in saveHwNotification : " + e.getMessage(), e.getCause());
			return MobiowinConstants.FALSE;
		} catch (Exception ex) {
			transaction.rollback();
			ex.printStackTrace();
			log.error("Exception in saveHwNotification : " + ex.getMessage(), ex.getCause());
			return MobiowinConstants.FALSE;
		}
	}

}
