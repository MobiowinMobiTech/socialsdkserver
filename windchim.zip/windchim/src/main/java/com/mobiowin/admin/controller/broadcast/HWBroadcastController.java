package com.mobiowin.admin.controller.broadcast;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import javax.management.RuntimeErrorException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.mobiowin.admin.service.IBroadcastService;
import com.mobiowin.admin.service.ISystemUserService;
import com.mobiowin.windchim.bean.BranchMasterBean;
import com.mobiowin.windchim.bean.ClassMasterBean;
import com.mobiowin.windchim.bean.GeneralBroadcastMasterBean;
import com.mobiowin.windchim.bean.HomeworkBroadcastMasterBean;
import com.mobiowin.windchim.bean.SystemUser;

public class HWBroadcastController extends MultiActionController{

	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private ISystemUserService systemUserService;
	
	@Autowired
	private IBroadcastService broadcastService;

	public ModelAndView addSystemUser(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		log.info("---------In UserController / addUser()----------");

		HomeworkBroadcastMasterBean homeworkBroadcastMasterBean = getHomeworkNotificationBean(request);
		
		try {
			HttpSession session = request.getSession();
			
			homeworkBroadcastMasterBean.setCreatedBy("SYSTEM");
			homeworkBroadcastMasterBean.setModifiedBy("SYSTEM");
			homeworkBroadcastMasterBean.setCreateDt(new Date());
			homeworkBroadcastMasterBean.setModifyDt(new Date());
			homeworkBroadcastMasterBean.setDeleteFlag("F");
			broadcastService.addHomeworkNotification(homeworkBroadcastMasterBean);
		} catch (Exception e) {
			throw new RuntimeErrorException(null);
		}
		
		

		

		return getHWNotificationList(request, response);
	}

	public ModelAndView getHWNotificationList(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		HomeworkBroadcastMasterBean homeworkBroadcastMasterBean = new HomeworkBroadcastMasterBean();
		homeworkBroadcastMasterBean.setDeleteFlag("F");
		List<HomeworkBroadcastMasterBean> hwBroadcastList = broadcastService.activeHomeworkNotificationSearch(homeworkBroadcastMasterBean);

		log.info("--- In hwBroadcastList  ---" + hwBroadcastList);
		log.info("HWBroadcastController/getHWNotificationList hwBroadcastList:"
				+ ((hwBroadcastList == null) ? "Null " : hwBroadcastList.size()));

		log.info("-------------------------------Final List--------------------------" + hwBroadcastList);

		HttpSession session = request.getSession();

		request.setAttribute("systemUserList", hwBroadcastList);

		return new ModelAndView("/masters/homework/hwWorkbench");
	}
	
	private HomeworkBroadcastMasterBean getHomeworkNotificationBean(HttpServletRequest request) {
		log.info("-------------- in getUserBean Method  -------------");

		HomeworkBroadcastMasterBean homeworkBroadcastMasterBean = null;
		
		if(null != request)
		{
			homeworkBroadcastMasterBean = new HomeworkBroadcastMasterBean();
		}
		
		String title = request.getParameter("title");
		String subject = request.getParameter("subject");
		String profile = request.getParameter("profile");
		String className = request.getParameter("classname");

		log.info("--- title  ---" + title);
		log.info("---------subject----------" + subject);
		log.info("---------profile----------" + profile);
		log.info("---------className----------" + className);
		
		if ((title != null) && !title.equalsIgnoreCase("")) {
			homeworkBroadcastMasterBean.setTitle(title);
		}

		if ((subject != null) && !subject.equalsIgnoreCase("")) {
			homeworkBroadcastMasterBean.setDiscription(subject);
		}

		if ((profile != null) && !profile.equalsIgnoreCase("")) {
			homeworkBroadcastMasterBean.setBranchId(profile);
		}
		
		if ((className != null) && !className.equalsIgnoreCase("")) {
			homeworkBroadcastMasterBean.setClassName(className);
		}
		

		
		//log.info("--------generalBroadcastMasterBean---------" + generalBroadcastMasterBean.getId());
		return homeworkBroadcastMasterBean;
	}
	
	public ModelAndView onAddClick(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		getDetails(request, response);

		return new ModelAndView("/masters/homework/addHomework");

	}
	
	public void getDetails(HttpServletRequest request, HttpServletResponse response)
	{
		HttpSession session = request.getSession();
		BranchMasterBean branchMaster = new BranchMasterBean();
		branchMaster.setDeleteFlag("F");
		List<BranchMasterBean> branchList = broadcastService.fetchBranchDetails(branchMaster);
		log.info("--- In addClick  ---" + branchList);
		log.info("UserController/getSystemUserList SystemUserList:"
				+ ((branchList == null) ? "Null " : branchList.size()));

		log.info("-------------------------------Final List--------------------------" + branchList);
		session.setAttribute("fullProfileList", branchList);
		
		ClassMasterBean classMasterBean = new ClassMasterBean();
		classMasterBean.setDeleteFlag("F");
		List<ClassMasterBean> classList = broadcastService.fetchClassDetails(classMasterBean);
		log.info("--- In addClick  ---" + branchList);
		log.info("UserController/getSystemUserList SystemUserList:"
				+ ((classList == null) ? "Null " : classList.size()));

		log.info("-------------------------------Final List--------------------------" + classList);
		session.setAttribute("classList", classList);

		
	}

}
