package com.mobiowin.admin.controller.broadcast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.multiaction.MultiActionController;

import com.mobiowin.admin.service.IBroadcastService;
import com.mobiowin.admin.service.ISystemUserService;
import com.mobiowin.windchim.bean.EventMasterBean;
import com.mobiowin.windchim.commons.ApplicationConstant;
import com.mobiowin.windchim.commons.IdGeneratorUtility;

@Controller
public class EventBroadcastController extends MultiActionController {
	private Log log = LogFactory.getLog(this.getClass());

	@Autowired
	private ISystemUserService systemUserService;

	@Autowired
	private IBroadcastService broadcastService;

	@Autowired
	private @Resource Map<String, List<String>> imageconfig;

	public ModelAndView addEvent(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		log.info("---------In UserController / addUser()----------");

		EventMasterBean eventMasterBean = getEventMasterBean(request);

		try {
			HttpSession session = request.getSession();

			
			eventMasterBean.setModifiedBy("SYSTEM");
			eventMasterBean.setCreateDt(new Date());
			eventMasterBean.setModifyDt(new Date());
			eventMasterBean.setDeleteFlag("F");
			broadcastService.addEventNotification(eventMasterBean);
		} catch (Exception e) {
			
			log.error("Exception in submitting event : " + e.getMessage());
			e.printStackTrace();
		}
		finally {
			
		}

		return getEventNotificationList(request, response);
	}

	private EventMasterBean getEventMasterBean(HttpServletRequest request) {
		int count = 0;
		String imageExtension = null;
		List<String> imageBasePath = (List<String>) imageconfig.get("EVENT_BASE_PATH");
		String urlAppender = imageBasePath.get(1);
		List<String> imgFileList = null;
		StringBuilder imgUrlBuilder = null;
		final MultipartHttpServletRequest multiRequest = (MultipartHttpServletRequest) request;
		log.info("---------After multipart----------");
		final Map files = multiRequest.getFileMap();
		EventMasterBean eventMasterBean = new EventMasterBean();

		String title = request.getParameter("title");
		String subTitle = request.getParameter("subtitle");
		String discription = request.getParameter("subject");
		String startDt = request.getParameter("startdt");
		String endDt = request.getParameter("enddt");
		String createdBy = request.getParameter("createdby");

		if (log.isInfoEnabled()) {
			log.info("title : " + title);
			log.info("subTitle : " + subTitle);
			log.info("discription : " + discription);
			log.info("startDt : " + startDt);
			log.info("endDt : " + endDt);
			log.info("createdBy : " + createdBy);
		}

		eventMasterBean.setEventId("EVENT" + "_" + IdGeneratorUtility.generateOtp());
		eventMasterBean.setTitle(title);
		eventMasterBean.setSubTitle(subTitle);
		eventMasterBean.setDiscription(discription);
		eventMasterBean.setStartDt(new Date());
		eventMasterBean.setEndDt(new Date());
		eventMasterBean.setCreatedBy(createdBy);

		List<Object> filesList = new Vector<Object>(files.values());

		log.info("filesList : " + filesList.size());

		for (Object object : filesList) {
			CommonsMultipartFile commonsMultipartFile = (CommonsMultipartFile) object;
			if (!commonsMultipartFile.isEmpty()) {
				count++;
			}
		}

		log.info("count is::" + count);

		imgFileList = new ArrayList<String>();
		for (Object object : filesList) {
			System.out.println("class name : " + object.getClass());
			CommonsMultipartFile commonsMultipartFile = (CommonsMultipartFile) object;
			if (log.isInfoEnabled()) {
				log.info("\n\nOriginalFilename = " + commonsMultipartFile.getOriginalFilename());
				log.info("ContentType = " + commonsMultipartFile.getContentType());
				log.info("Name = " + commonsMultipartFile.getName());
				log.info("Size = " + commonsMultipartFile.getSize());
				log.info("StorageDescription " + commonsMultipartFile.getStorageDescription());
			}

			String fileName = commonsMultipartFile.getOriginalFilename().toLowerCase();
			log.info("fileName is:" + fileName);

			if (commonsMultipartFile.getSize() != 0) {
				if (!fileName.isEmpty()) {

					int indexOfDot = fileName.lastIndexOf(".");

					String extension = fileName.substring(indexOfDot + 1);

					log.info("extension is::" + extension.toLowerCase());

					String basedir = imageBasePath.get(0);
					// String basedir = SyncConstants.IMGPATH;

					if (commonsMultipartFile.getName() != null) {
						log.info("in productfile");
						log.info("file name is::" + fileName);

						int lastIndex = fileName.lastIndexOf(".");

						log.info("lastIndex is::" + lastIndex);
						imageExtension = fileName.substring(lastIndex);
						log.info("extension is::" + imageExtension);

						log.info("basedir is::" + basedir);

						String imgFileName = IdGeneratorUtility.generateOtp();
						if (saveEmailImage(basedir, imgFileName, commonsMultipartFile, imageExtension)) {
							imgUrlBuilder = new StringBuilder();
							imgUrlBuilder.append(imageBasePath.get(1));
							imgUrlBuilder.append(ApplicationConstant.ENTITY);
							imgUrlBuilder.append(ApplicationConstant.FLASH_VALUE_ASSIGNER);
							imgUrlBuilder.append(imageBasePath.get(3));
							imgUrlBuilder.append(ApplicationConstant.FLASH_URL_APPENDER);
							imgUrlBuilder.append(imageBasePath.get(2));
							imgUrlBuilder.append(ApplicationConstant.FLASH_VALUE_ASSIGNER);
							imgUrlBuilder.append(imgFileName);
							imgUrlBuilder.append(imageExtension);

							log.info("Img url is : " + imgUrlBuilder.toString());

							imgFileList.add(imgUrlBuilder.toString());

						}

					}
				} 
			}
		}

		log.info("imgFileList size is : " + imgFileList.size());
		

		if(imgFileList.size() == 1)
		{
			if (null != imgFileList.get(0) && !imgFileList.get(0).equals(ApplicationConstant.EMPTY_STRING)) {
				eventMasterBean.setImg1(imgFileList.get(0));
			}
		}
		
		if(imgFileList.size() == 2)
		{
			if (null != imgFileList.get(0) && !imgFileList.get(0).equals(ApplicationConstant.EMPTY_STRING)) {
				eventMasterBean.setImg1(imgFileList.get(0));
			}
			
			if (null != imgFileList.get(1) && !imgFileList.get(1).equals(ApplicationConstant.EMPTY_STRING)) {
				eventMasterBean.setImg2(imgFileList.get(1));
			}
		}
			
		if(imgFileList.size() == 3)
		{
			if (null != imgFileList.get(0) && !imgFileList.get(0).equals(ApplicationConstant.EMPTY_STRING)) {
				eventMasterBean.setImg1(imgFileList.get(0));
			}
			
			if (null != imgFileList.get(1) && !imgFileList.get(1).equals(ApplicationConstant.EMPTY_STRING)) {
				eventMasterBean.setImg2(imgFileList.get(1));
			}
			
			if (null != imgFileList.get(2) && !imgFileList.get(2).equals(ApplicationConstant.EMPTY_STRING)) {
				eventMasterBean.setImg3(imgFileList.get(2));
			}
		}
		
		if(imgFileList.size() == 4)
		{
			if (null != imgFileList.get(0) && !imgFileList.get(0).equals(ApplicationConstant.EMPTY_STRING)) {
				eventMasterBean.setImg1(imgFileList.get(0));
			}
			
			if (null != imgFileList.get(1) && !imgFileList.get(1).equals(ApplicationConstant.EMPTY_STRING)) {
				eventMasterBean.setImg2(imgFileList.get(1));
			}
			
			if (null != imgFileList.get(2) && !imgFileList.get(2).equals(ApplicationConstant.EMPTY_STRING)) {
				eventMasterBean.setImg3(imgFileList.get(2));
			}
			
			if (null != imgFileList.get(3) && !imgFileList.get(3).equals(ApplicationConstant.EMPTY_STRING)) {
				eventMasterBean.setImg4(imgFileList.get(3));
			}
		}
		
		
		return eventMasterBean;
	}

	private boolean saveEmailImage(String basedir, String name, CommonsMultipartFile commonsMultipartFile,
			String imageExtension) {

		boolean isSuccessfulWrite = false;
		try {
			File localEmailDir = new File(basedir);
			if (!localEmailDir.exists()) {
				localEmailDir.mkdirs();

				File emaildir = new File(localEmailDir, name + imageExtension);

				FileOutputStream fileOutputStream = new FileOutputStream(emaildir);
				fileOutputStream.write(commonsMultipartFile.getBytes());
				isSuccessfulWrite = true;

			} else {
				File emaildir = new File(localEmailDir, name + imageExtension);

				FileOutputStream fileOutputStream = new FileOutputStream(emaildir);
				fileOutputStream.write(commonsMultipartFile.getBytes());

				isSuccessfulWrite = true;

			}

			return isSuccessfulWrite;
		} catch (FileNotFoundException e) {
			log.error("File not found exception : " + e.getMessage());
			e.printStackTrace();
			return isSuccessfulWrite;
		} catch (IOException e) {
			log.error("IO exception while saving file : " + e.getMessage());
			e.printStackTrace();
			return isSuccessfulWrite;
		}

	}

	public ModelAndView onAddClick(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// getDetails(request, response);

		return new ModelAndView("/masters/event/addEvent");

	}

	public ModelAndView getEventNotificationList(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		EventMasterBean eventMasterBean = new EventMasterBean();
		eventMasterBean.setDeleteFlag("F");
		List<EventMasterBean> eventMasterList = broadcastService.activeEventSearch(eventMasterBean);

		log.info("--- In hwBroadcastList  ---" + eventMasterList);
		log.info("EventBroadcastController/getEventNotificationList eventMasterList:"
				+ ((eventMasterList == null) ? "Null " : eventMasterList.size()));

		log.info("-------------------------------Final List--------------------------" + eventMasterList);

		request.setAttribute("systemUserList", eventMasterList);

		return new ModelAndView("/masters/event/eventWorkbench");
	}
}
