package com.mobiowin.admin.bean;

import com.mobiowin.admin.component.StandardBean;

public class Profile extends StandardBean
{

	private static final long serialVersionUID = 1L;

}
